# Halcyon × Folia — complete phone patch (Tasks A–D) + Task E packaging

This is the single, complete patch for the **unmodified** `Halcyon-main.zip` and
`folia-web-min.zip`. It is not a delta that depends on previously uploaded task
patches. Task E also supplies a hardened replacement `build.yml`.

## Included visualizer work

### Task A — native Battery/Latent background

- Adds a low-resolution, vsync-paced native GLES mesh behind Folia's transparent
  WebView for Battery quality + Latent only, with the original web mesh retained
  as fallback.
- Retains all 17 lyric-style renderers, Dithering, other backgrounds and the
  existing quality/frame-rate governors.

### Task B — timestamped live beat reactions

- Adds a read-only Media3 output-sink PCM tap using presentation timestamps for
  both the primary player and gapless crossfade player.
- Causal 20 ms kick/bass, snare/body and hi-hat detection feeds Folia's external
  drum source without altering PCM or resetting Folia's beat clock.
- Prevents redundant htdemucs drum separation for tracks claimed by the live
  PCM source; preserves output-route timing controls and diagnostics.
- Synthetic detector tests passed as described in `TASK-B-ENGINE-REPORT.md`;
  real-song and physical-device latency checks remain necessary.

### Task C — Arabic RTL and connected text in all 17 styles

- Handles direction at each renderer's layout/reveal layer instead of reversing
  lyric or word arrays globally.
- Preserves source word order, ascending timestamps, punctuation, digits,
  embedded Latin runs, diacritics, Lam–Alef sequences, translations,
  romanization and backing vocals.
- Keeps existing RTL-aware styles on their native shaping path and limits
  presentation-form shaping to glyph-by-glyph renderers.
- Arabic-only horizontal connected text is used where vertical glyph columns
  would break Arabic joining; Latin vertical rendering remains on its old path.

### Task D — phone budgets ported from Android Folia v0.7.21 to v0.7.25

- Adapts the three added v0.7.25 styles: Hanabi, Machi and Nebbia.
- Restores mobile render-target, texture, DPR and ambient-background limits for
  the relevant newer paths, including Latent, Nomand, Sora, Monet and Pendolo.
- Preserves desktop render paths, visual composition, palettes and animation
  timing. Pixel-budget estimates are not measured battery/GPU benchmarks.

## Task E — unified packaging and hardened build workflow

- Consolidates A–D into one source-anchored, idempotent patch archive.
- Replaces filename-first ZIP selection with content-based discovery and fails
  clearly if multiple Halcyon, Folia or merged patch archives are present.
- Validates ZIP paths, duplicate entries, symlinks/special files, CRCs,
  compression ratio, entry count and expanded-size ceilings before extraction.
- Fixes the manual `use_patches: false` input so it really disables the patch.
- Pins build actions to full commit SHAs where available, limits repository
  permissions, disables persisted checkout credentials and validates Gradle
  wrappers.
- Makes the Halcyon licence/provenance check fatal; preserves Folia-to-native
  fallback and plain-Halcyon APK fallback after patched Kotlin compilation fails.
- Adds source hashes, build configuration and failure context to an uploaded
  build-info/log artifact.

## Verification status

- Clean unmodified Halcyon + Folia import and A–D patch application passed.
- Applying `apply.py` a second time produced the same full source-tree SHA-256.
- `tools/check_licenses.py` passed.
- 2,614 TypeScript/TSX files parsed with the installed TypeScript parser with
  zero syntax diagnostics. Node 22's `--experimental-strip-types --check`
  rejected 45 `.ts` files because that mode does not accept several TypeScript
  declarations used by this source; the TypeScript parser check is the
  successful syntax result.
- 24 patched Kotlin files passed delimiter checks; 191 unique Android/AndroidX
  imports were already present in the original Halcyon source; 30 explicit
  Halcyon-owned imports resolved to source declarations or generated `R`.
- Workflow YAML parsed, all 15 shell `run` blocks passed `bash -n`, and the
  exact embedded archive-import helper matched the locally tested helper.
- Renamed input ZIP detection, the no-patches path, duplicate-source rejection
  and ZIP path-traversal rejection were tested.
- Full npm/Vite and Android Release builds were not run: the local environment
  has Node 22 (the Folia package requires Node 24), no offline npm cache for all
  locked packages, and no Android SDK, `sdkmanager`, `adb` or Gradle install.
  See `TASK-E-VERIFICATION.md` and `TEST-ON-PHONE.md`.

The trimmed `folia-web-min.zip` does not need replacement. Upload the supplied
`build.yml` separately to `.github/workflows/build.yml`.
