# Halcyon × Folia — complete current patch (Tasks A + B + C)

This ZIP is the complete patch for the original `Halcyon-main.zip` and
`folia-web-min.zip`, not a delta over an older patch.

## Task C — Arabic RTL and joined letters in all 17 styles

- Audited the per-style measure, wrap, glyph-placement and reveal paths rather
  than reversing lyric/word arrays globally.
- Mirrored RTL word blocks and row coordinates from the right edge; kept source
  order, ascending word/grapheme timing and right-to-left active sweeps.
- Added direction-aware DOM and Canvas paths for Fume, Pendolo and Still.
- Added RTL placement/reveal handling for Cadenza, Cappella, Claddagh, Hanabi,
  Lumiere, Machi, Nebbia, Sonnet, Tempera and Tilt.
- Kept Classic, Partita, Monet and Diorama on their existing native RTL paths.
- Added grapheme-aware Arabic shaping for glyph-by-glyph renderers. It preserves
  diacritics, punctuation, spaces, digits, Latin runs, Lam-Alef timing, word
  timestamps, alternate text, translations and background vocals.
- For Arabic only, Hanabi and Lumiere's vertical glyph columns switch to joined
  horizontal text flow. Latin vertical settings and the other Latin renderer
  paths remain unchanged.

## Task B retained — real-time PCM beat reactions

- Read-only Media3 output-sink PCM taps use the audio presentation timestamp for
  both the primary player and gapless crossfade player.
- Causal 20 ms kick/bass, snare/body and hi-hat detection feeds Folia's external
  drum source without modifying PCM or resetting the beat clock.
- Suppresses redundant htdemucs separation for tracks claimed by the PCM source;
  keeps diagnostics and per-output manual timing calibration.
- Synthetic Kotlin tests and the partial-write sink harness passed as detailed
  in `TASK-B-ENGINE-REPORT.md`.

## Task A retained — native Battery/Latent mesh

- Adds a low-resolution, vsync-paced native GLES mesh behind Folia's transparent
  WebView for Battery + Latent only, with web fallback.
- Retains all 17 style renderers, Dithering, other backgrounds and existing
  quality/frame-rate governors. On-device visual and battery measurements remain
  required.

## Task C verification

- Eight Arabic/mixed-script runtime fixtures passed: grapheme counts and source
  timing preserved; punctuation, marks, digits and embedded Latin retained.
- 30 changed TypeScript/TSX files transpiled with zero syntax diagnostics.
- `apply.py` compiled and applied twice to clean source trees with identical
  hashes (idempotence verified).
- Full npm/Vite build and Android Release APK were not run. Headless Chromium
  stalled before screenshots could be captured. On-device Xiaomi 11T testing is
  still required; see `TASK-C-ENGINE-REPORT.md` and `TEST-ON-PHONE.md`.

See `TASK-A-ENGINE-REPORT.md`, `TASK-B-ENGINE-REPORT.md` and
`TASK-C-ENGINE-REPORT.md` for detailed reports and limits.
