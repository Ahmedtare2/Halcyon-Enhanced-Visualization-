# Task D — v0.7.21 Android phone budgets applied to v0.7.25

## Version comparison

The attached Android reference is Folia **v0.7.21**. The supplied current source is Folia **v0.7.25**.

| Built-in visualizer styles | IDs |
|---|---|
| v0.7.21 (14) | Cadenza, Cappella, Claddagh, Classic, Diorama, Fume, Lumiere, Monet, Partita, Pendolo, Sonnet, Still, Tempera, Tilt |
| v0.7.25 (17) | All 14 above, plus **Hanabi, Machi and Nebbia** |

The two versions have the same six standalone background IDs: **common, latent, monet, nomand, sora, url**. There are no new standalone background registry entries in v0.7.25. The newer styles do, however, contain additional high-cost scene and background render targets.

## What the older Android source does for phones

The v0.7.21 Android package carries `packaging/android/latest-source-overrides.json` and a shared `src/utils/mobileVisualizerBudget.ts`. The relevant budgets and source adaptations are:

- Canvas DPR: **1.5 maximum** on mobile.
- Pixi render/filter resolution: **1.25 maximum** on mobile, with a **1536 px** texture-axis guard.
- Ambient shader framebuffers: **0.30× CSS size**, with 384 px dimension and background-specific pixel caps.
- Latent: **384 × 256 = 98,304 px** maximum shader budget; smooth upscaling.
- Nomand: **384 × 384 = 147,456 px** shader budget.
- Sora: reduced ambient WebGL buffer (0.30×, 384 px longest side policy) with display-size upscaling.
- Monet: **384 × 256** worker paint canvas rather than 1920 × 1080, and blur radius scaled in proportion to the lower buffer width.
- Pendolo: mobile DPR cap is applied to both its WebGL and Canvas2D paths.
- Fluid's common cover background already uses a 320 px canvas and a downscaled image source, so no additional change was necessary there.

The older package also has a visibility/lifecycle gate and host-side frame pacing. Halcyon's current host lifecycle and the previously completed Tasks A/B already supply the corresponding mobile/Android lifecycle, frame-rate and native Latent hand-off behavior; Task D does not duplicate or replace those systems.

## Task D changes

A small shared mobile-budget helper is placed at `folia-host/src/utils/mobileVisualizerBudget.ts`. The build workflow copies `folia-host/` into Folia before running `apply.py`, so the helper is available to Vite without modifying the trimmed `folia-web-min.zip` archive.

### New v0.7.25 styles

| Style | Mobile adaptation | Expected render-target reduction (source-level estimate) |
|---|---|---|
| **Hanabi** | Pixi full-scene/filter resolution capped at 1.25 and 1536 px longest axis; glyph atlas texture cap 1536 px; existing `full` quality resolves to the style's existing `balanced` profile on mobile, retaining `low` when explicitly selected. | At a previous maximum 3× resolution, the main render target uses about 17.4% as many pixels (≈82.6% fewer). The balanced glow target is 0.7× per axis (49% of full glow pixels). |
| **Machi** | Full scene target capped at 1.5× and 1536 px longest axis; high shadow map capped from 2048 to 1536; high reflection scale capped from 0.5 to 0.3. Existing quality selections and automatic degradation remain intact. | At a previous maximum 3× ratio, the full scene target uses 25% as many pixels (≈75% fewer). The 1536² shadow map uses 56.25% of 2048² pixels (≈43.75% fewer); 0.3² reflection scale uses 36% of the 0.5² target area (≈64% fewer pixels). |
| **Nebbia** | WebGL2 output/fog/noise target capped at 1.5× and 1536 px longest axis. User-controlled jelly, burst, rain, scenery and condensation counts are not reduced. | At a previous maximum 3× ratio, full-resolution target area is 25% (≈75% fewer pixels). |

### Shared styles and backgrounds

- **Pendolo**: restore the older mobile 1.5× DPR cap after applying its user-selected render scale. Desktop requested DPR is left unchanged.
- **Latent**: mobile shader props use the older 0.30 minimum pixel ratio and 98,304 px cap; desktop keeps its current 1280 × 720 cap. Task A's native Battery/Latent renderer remains unchanged.
- **Nomand**: mobile Paper shader props use 0.30 pixel ratio and 147,456 px cap; desktop keeps the existing 1920 × 1080 budget.
- **Sora**: mobile TWGL buffer uses the 0.30× / 384 px ambient sizing policy and is upscaled by the canvas; desktop keeps TWGL's original full-size behavior.
- **Monet**: v0.7.25's 1920 × 1080 worker buffer becomes 384 × 256 on mobile. The blur radius scales with buffer width so the softened background does not become overly sharp after CSS upscaling. Desktop remains 1920 × 1080 with its original blur radius.
- **Fluid/common** and **URL** backgrounds are unchanged because Fluid already has a small raster path and URL is an externally supplied image surface rather than a heavy procedural render target.

No particle counts, scene geometry, palette, animation timings, lyric layout, or user tuning values were changed. The intent is to reduce internal framebuffer/texture work while retaining each style's composition and motion. Lower internal resolution can soften tiny details; the actual on-device visual match still needs to be judged on the phone.

## Cost estimate method

These are pixel-area comparisons derived from source constants and resolution ceilings, not measured GPU timings. Pixel work scales approximately with the square of the resolution ratio for a fixed full-screen pass. Actual savings vary with screen size, render-quality selection, antialiasing, scene complexity and device GPU.

| Renderer/background | Before (source ceiling) | Mobile ceiling | Approx. fewer pixels |
|---|---:|---:|---:|
| Hanabi full render target | 3.0× | 1.25× | 82.6% |
| Machi full render target | 3.0× | 1.5× | 75% |
| Machi shadow map | 2048² | 1536² | 43.75% |
| Machi reflection target | 0.5× each axis | 0.3× each axis | 64% |
| Nebbia full render target | 3.0× | 1.5× | 75% |
| Pendolo render target | 3.0× | 1.5× | 75% |
| Latent ambient shader | 1280×720 | ≤384×256 | 89.3% |
| Nomand ambient shader | 1920×1080 | ≤384×384 | 92.9% |
| Monet worker paint | 1920×1080 | 384×256 | 95.3% |
| Sora ambient canvas | 1.0× CSS | 0.30× CSS (max 384 policy) | ≈91% at 0.30× |

The table compares the prior v0.7.25 source ceilings with the new phone caps. It does not claim a measured frame-time or battery percentage.

## Verification

- Confirmed source versions from `package.json`: older reference v0.7.21, current source v0.7.25.
- Compared `BUILTIN_VISUALIZER_MODES` and `BUILTIN_VISUALIZER_BACKGROUND_MODES` in both archives; found three added styles and zero added standalone background IDs.
- Applied the complete patch to clean, unmodified `Halcyon-main.zip` + `folia-web-min.zip` after copying `folia-host/` as the workflow does.
- Applied the patch a second time; the full test-tree SHA-256 remained identical: `4a808f6873d8ab7be5a1227c4bfa23f11564134f1b2faeccee294c788b3d6cc2`.
- Halcyon licence/provenance checker passed.
- TypeScript/TSX transpile syntax scan: **2,494 files, 0 syntax errors**.
- Mobile-budget helper checks passed for mobile caps, desktop passthrough, ambient dimensions, texture cap and Hanabi mobile quality selection.
- Full npm/Vite build, Android Release APK build, visual parity, actual GPU load, thermal behavior and battery consumption were **not** measured in this environment. The extracted web-min source has no `node_modules`, and there is no Android SDK/physical phone attached here.

## Packaging

`apply.py` remains anchored and idempotent. The new helper is inside `folia-host/` and is automatically copied into Folia by the existing workflow. No separate `build.yml` or replacement `folia-web-min.zip` is required.
