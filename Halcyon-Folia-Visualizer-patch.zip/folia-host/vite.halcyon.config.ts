import path from 'path';
import { fileURLToPath } from 'url';
import { defineConfig, type ConfigEnv } from 'vite';
import baseConfig from './vite.config';

// vite.halcyon.config.ts
// Builds only halcyon-host.html with Folia's own Vite setup (plugins, defines, aliases),
// minus the PWA plugin and dev-server helpers, with relative asset paths for the Android WebView.

const here = path.dirname(fileURLToPath(import.meta.url));

export default defineConfig(async (env: ConfigEnv) => {
    const base = await (baseConfig as unknown as (e: ConfigEnv) => Promise<Record<string, any>>)(env);
    const plugins = (base.plugins ?? [])
        .flat(Infinity)
        .filter((plugin: any) => plugin && !String(plugin.name ?? '').startsWith('vite-plugin-pwa') && plugin.name !== 'folia-dev-lyric-proxy');
    return {
        ...base,
        base: './',
        plugins,
        build: {
            ...(base.build ?? {}),
            outDir: 'dist-halcyon',
            emptyOutDir: true,
            sourcemap: false,
            reportCompressedSize: false,
            rollupOptions: {
                ...(base.build?.rollupOptions ?? {}),
                input: { halcyon: path.resolve(here, 'halcyon-host.html') },
            },
        },
    };
});
