import { useSyncExternalStore } from 'react';
import { motionValue } from 'framer-motion';
import type { Line, Theme } from '../types';
import { DEFAULT_SMART_BEAT_SETTINGS } from '../types';
import { beginBeatFxTrack, setBeatFxEvents, setBeatFxIntensities, setBeatFxLiveEffects } from '../services/beatFx/beatFxLive';
import { beatEffectPartId, resolveBeatEffectPartStrength, resolveBeatEffectSetting } from '../services/beatFx/beatEffects';
import { useVisualizerSettingsStore } from '../stores/useVisualizerSettingsStore';
import type { BeatFxEvent } from '../services/beatFx/clock';
import { liveBeatEffects } from '../components/visualizer/beatClockTargets';
import { VISUALIZER_REGISTRY } from '../components/visualizer/registry';
import { VISUALIZER_BACKGROUND_REGISTRY } from '../components/visualizer/backgrounds/registry';

// src/halcyon/hostApi.ts
// State + the window.HalcyonHost API the Android WebView host calls into. No UI here.

export interface HostClock {
    positionSec: number;
    durationSec: number;
    anchoredAtMs: number;
    playing: boolean;
}

export interface HostState {
    rev: number;
    mode: string;
    background: string | null;
    lines: Line[];
    theme: Theme;
    track: { name: string; artist: string; coverUrl: string | null; seed: string };
    clock: HostClock;
    fontScale: number;
    showTranslation: boolean;
    staticMode: boolean;
    daylight: boolean;
    beatFx: boolean;
    beatStrength: number;
    settingsOpen: boolean;
    debug: boolean;
    rtlFix: boolean;
}

const DEFAULT_THEME: Theme = {
    name: 'Halcyon',
    backgroundColor: '#0b0f1a',
    primaryColor: '#f0f4fa',
    accentColor: '#ffc440',
    secondaryColor: '#60aaff',
    fontStyle: 'sans',
    animationIntensity: 'normal',
};

let state: HostState = {
    rev: 0,
    mode: 'classic',
    background: null,
    lines: [],
    theme: DEFAULT_THEME,
    track: { name: '', artist: '', coverUrl: null, seed: 'halcyon' },
    clock: { positionSec: 0, durationSec: 0, anchoredAtMs: 0, playing: false },
    fontScale: 1,
    showTranslation: true,
    staticMode: false,
    daylight: false,
    beatFx: true,
    beatStrength: 1,
    settingsOpen: false,
    debug: false,
    rtlFix: true,
};

const listeners = new Set<() => void>();
const commit = (patch: Partial<HostState>) => {
    state = { ...state, ...patch, rev: state.rev + 1 };
    listeners.forEach(listener => listener());
};

type AndroidHostApi = {
    onReady?: (json: string) => void;
    onFirstFrame?: () => void;
    onError?: (message: string) => void;
    onSettingsClosed?: () => void;
    onInfo?: (message: string) => void;
};
const androidHost = (): AndroidHostApi | undefined => (window as unknown as { AndroidHost?: AndroidHostApi }).AndroidHost;

/** Sends a message to the Android side (shown in the app's diagnostics). */
export const reportToAndroid = (message: string) => {
    try { androidHost()?.onError?.(message); } catch { /* the bridge is optional */ }
};

/** Closes Folia's style settings screen (from the page or from Android). */
export const closeHostSettings = () => {
    commit({ settingsOpen: false });
    try { androidHost()?.onSettingsClosed?.(); } catch { /* the bridge is optional */ }
};

export const subscribeHost = (listener: () => void) => {
    listeners.add(listener);
    return () => { listeners.delete(listener); };
};
export const getHostState = () => state;
export const useHostState = () => useSyncExternalStore(subscribeHost, getHostState);

/** Lyric time (s) extrapolated from the last anchor sent by Android. */
let liveClock: HostClock = state.clock;

export const getHostTimeSec = (nowMs: number): number => {
    const c = liveClock;
    if (!c.playing) return c.positionSec;
    const t = c.positionSec + (nowMs - c.anchoredAtMs) / 1000;
    return c.durationSec > 0 ? Math.min(t, c.durationSec) : t;
};

// Audio bands: plain MotionValues the visualizers read (written straight from the bridge, no React).
export const hostBands = {
    audioPower: motionValue(0),
    bass: motionValue(0),
    lowMid: motionValue(0),
    mid: motionValue(0),
    vocal: motionValue(0),
    treble: motionValue(0),
    spectrum: motionValue(new Uint8Array(0) as Uint8Array<ArrayBuffer>),
};

// Beats analysed by Halcyon (native) are fed into Folia's own beat-effect clock. Which effects play,
// and how strongly, follows Folia's own per-effect settings (the beat group of each style's
// settings screen), so an effect that is too heavy for the phone can simply be switched off there.
let beatsData: { key: string; events: BeatFxEvent[] } | null = null;
let installedBeatKey: string | null = null;
let lastEffectsKey = '';

const applyEffects = () => {
    const s = state;
    const store = useVisualizerSettingsStore.getState();
    const smartBeat = { ...store.smartBeat, mode: s.beatFx ? 'on' : 'off' } as typeof store.smartBeat;
    const strengths: Record<string, number> = {};
    if (s.beatFx && beatsData) {
        try {
            const effects = liveBeatEffects({
                ...store,
                smartBeat,
                visualizerMode: s.mode as never,
                visualizerBackgroundMode: (s.background ?? null) as never,
                pageTransparent: false,
            } as never);
            for (const effect of effects) {
                if (effect.source !== 'beats') continue;
                const setting = resolveBeatEffectSetting(smartBeat, effect.id);
                strengths[effect.id] = setting.strength;
                for (const part of effect.parts ?? []) {
                    strengths[beatEffectPartId(effect.id, part.key)] = resolveBeatEffectPartStrength(setting, part.key);
                }
            }
        } catch (error) {
            console.warn('[HalcyonHost] beat effects unavailable', error);
        }
    }
    setBeatFxIntensities(s.beatStrength, s.beatStrength);
    setBeatFxLiveEffects(strengths);
};

const applyBeats = () => {
    if (!state.beatFx || !beatsData) {
        installedBeatKey = null;
        beginBeatFxTrack(null);
    } else if (installedBeatKey !== beatsData.key + ':' + beatsData.events.length) {
        installedBeatKey = beatsData.key + ':' + beatsData.events.length;
        beginBeatFxTrack(beatsData.key);
        setBeatFxEvents(beatsData.key, beatsData.events, 'beat_this', undefined, 1);
    }
    applyEffects();
};

/** The frame governor in HalcyonStage calls this when the page cannot keep its frame rate. */
export const pauseBeatEffectsForPerformance = () => {
    if (!state.beatFx) return;
    commit({ beatFx: false });
    applyBeats();
    try { androidHost()?.onInfo?.('Beat effects switched off: the frame rate dropped. Lower the render scale or re-enable them in Tune.'); } catch { /* optional */ }
};

const parse = <T,>(json: string, fallback: T): T => {
    try { return JSON.parse(json) as T; } catch { return fallback; }
};

interface WireLine {
    s: number; e: number; t: string;
    w: Array<[string, number, number]>;
    tr?: string; ro?: string; a?: string;
}

export const installHalcyonHost = () => {
    const api = {
        setMode(id: string) {
            commit({ mode: id });
            applyBeats();
        },
        setBackground(id: string) {
            commit({ background: id ? id : null });
            applyBeats();
        },
        setTheme(json: string) {
            const theme = parse<Theme | null>(json, null);
            if (theme) commit({ theme });
        },
        setSong(json: string) {
            const song = parse<{ name?: string; artist?: string; cover?: string | null; seed?: string } | null>(json, null);
            if (!song) return;
            commit({
                track: {
                    name: song.name ?? '',
                    artist: song.artist ?? '',
                    coverUrl: song.cover ?? null,
                    seed: song.seed ?? 'halcyon',
                },
            });
        },
        setLyrics(json: string) {
            const wire = parse<WireLine[]>(json, []);
            const lines: Line[] = wire.map(item => ({
                startTime: item.s,
                endTime: item.e,
                fullText: item.t,
                words: item.w.map(([text, start, end]) => ({ text, startTime: start, endTime: end })),
                translation: item.tr || undefined,
                romanization: item.ro || undefined,
                agentId: item.a || undefined,
            }));
            commit({ lines });
        },
        setClock(positionMs: number, durationMs: number, playing: boolean, anchorMs: number) {
            liveClock = {
                positionSec: positionMs / 1000,
                durationSec: durationMs / 1000,
                anchoredAtMs: anchorMs > 0 ? anchorMs : Date.now(),
                playing,
            };
            // The anchor itself is read straight from liveClock; React only hears about the
            // things that change what is drawn (play/pause, length), so position updates are free.
            if (state.clock.playing !== playing || state.clock.durationSec !== liveClock.durationSec) {
                commit({ clock: liveClock });
            }
        },
        setBands(bass: number, lowMid: number, mid: number, vocal: number, treble: number, power: number) {
            hostBands.bass.set(bass);
            hostBands.lowMid.set(lowMid);
            hostBands.mid.set(mid);
            hostBands.vocal.set(vocal);
            hostBands.treble.set(treble);
            hostBands.audioPower.set(power);
        },
        setBeats(json: string) {
            const data = parse<{ key: string; beats: number[]; impact?: number[]; downbeat: number; allDown?: boolean } | null>(json, null);
            if (!data || !data.beats || data.beats.length === 0) {
                beatsData = null;
            } else {
                const events: BeatFxEvent[] = data.beats.map((ms, i) => ({
                    t: ms / 1000,
                    kind: data.allDown || (data.downbeat >= 0 && (i - data.downbeat) % 4 === 0) ? 'downbeat' : 'beat',
                    impact: data.impact ? data.impact[i] : undefined,
                }));
                beatsData = { key: data.key, events };
            }
            applyBeats();
        },
        setOptions(json: string) {
            const o = parse<Partial<{ fontScale: number; showTranslation: boolean; staticMode: boolean; daylight: boolean; beatFx: boolean; beatStrength: number; rtlFix: boolean }>>(json, {});
            commit({
                fontScale: o.fontScale ?? state.fontScale,
                showTranslation: o.showTranslation ?? state.showTranslation,
                staticMode: o.staticMode ?? state.staticMode,
                daylight: o.daylight ?? state.daylight,
                beatFx: o.beatFx ?? state.beatFx,
                beatStrength: o.beatStrength ?? state.beatStrength,
                rtlFix: o.rtlFix ?? state.rtlFix,
            });
            applyBeats();
        },
        openSettings(open: boolean) {
            commit({ settingsOpen: open });
        },
        setDebug(debug: boolean) {
            commit({ debug });
        },
        setFps(fps: number) {
            const setter = (window as unknown as { __halcyonSetFps?: (f: number) => void }).__halcyonSetFps;
            if (setter) setter(fps);
        },
    };
    (window as unknown as { HalcyonHost: typeof api }).HalcyonHost = api;

    // A change in Folia's own beat settings (made on the style settings screen) re-applies the effects.
    useVisualizerSettingsStore.subscribe(store => {
        const key = JSON.stringify(store.smartBeat);
        if (key !== lastEffectsKey) {
            lastEffectsKey = key;
            applyEffects();
        }
    });

    const host = (window as unknown as { AndroidHost?: { onReady?: (json: string) => void } }).AndroidHost;
    if (host && host.onReady) {
        const modes = VISUALIZER_REGISTRY.map(entry => ({ id: entry.mode, label: entry.labelFallback }));
        const backgrounds = VISUALIZER_BACKGROUND_REGISTRY.map(entry => ({ id: entry.mode, label: entry.labelFallback }));
        host.onReady(JSON.stringify({ modes, backgrounds }));
    }
};
