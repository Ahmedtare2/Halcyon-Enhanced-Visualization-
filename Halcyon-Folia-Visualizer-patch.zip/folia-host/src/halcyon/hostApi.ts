import { useSyncExternalStore } from 'react';
import { motionValue } from 'framer-motion';
import type { Line, Theme } from '../types';
import { DEFAULT_SMART_BEAT_SETTINGS } from '../types';
import { beginBeatFxTrack, setBeatFxEvents, setBeatFxIntensities, setBeatFxLiveEffects, replaceFutureBeatFxEvents } from '../services/beatFx/beatFxLive';
import { beatEffectPartId, resolveBeatEffectPartStrength, resolveBeatEffectSetting } from '../services/beatFx/beatEffects';
import { setExternalDrumHits } from '../services/analysis/drumHits';
import { useVisualizerSettingsStore } from '../stores/useVisualizerSettingsStore';
import type { BeatFxEvent } from '../services/beatFx/clock';
import { liveBeatEffects } from '../components/visualizer/beatClockTargets';
import { VISUALIZER_REGISTRY } from '../components/visualizer/registry';
import { VISUALIZER_BACKGROUND_REGISTRY } from '../components/visualizer/backgrounds/registry';

// src/halcyon/hostApi.ts
// State + the window.HalcyonHost API the Android WebView host calls into. No UI here.

export interface HostClock {
    positionSec: number;
    durationSec: number;
    anchoredAtMs: number;
    playing: boolean;
}

export interface HostState {
    rev: number;
    mode: string;
    background: string | null;
    lines: Line[];
    theme: Theme;
    track: { name: string; artist: string; coverUrl: string | null; seed: string };
    clock: HostClock;
    fontScale: number;
    showTranslation: boolean;
    staticMode: boolean;
    daylight: boolean;
    beatFx: boolean;
    beatStrength: number;
    settingsOpen: boolean;
    debug: boolean;
    rtlFix: boolean;
    /** True only after Halcyon's optional low-resolution GLES backdrop linked successfully. */
    nativeBackdropAvailable: boolean;
    /** Android Battery preset: temporarily lowers only the existing global lyric render scale. */
    batteryProfile: boolean;
}

const DEFAULT_THEME: Theme = {
    name: 'Halcyon',
    backgroundColor: '#0b0f1a',
    primaryColor: '#f0f4fa',
    accentColor: '#ffc440',
    secondaryColor: '#60aaff',
    fontStyle: 'sans',
    animationIntensity: 'normal',
};

let state: HostState = {
    rev: 0,
    mode: 'classic',
    background: null,
    lines: [],
    theme: DEFAULT_THEME,
    track: { name: '', artist: '', coverUrl: null, seed: 'halcyon' },
    clock: { positionSec: 0, durationSec: 0, anchoredAtMs: 0, playing: false },
    fontScale: 1,
    showTranslation: true,
    staticMode: false,
    daylight: false,
    beatFx: true,
    beatStrength: 1,
    settingsOpen: false,
    debug: false,
    rtlFix: true,
    nativeBackdropAvailable: false,
    batteryProfile: false,
};

const listeners = new Set<() => void>();
const commit = (patch: Partial<HostState>) => {
    state = { ...state, ...patch, rev: state.rev + 1 };
    listeners.forEach(listener => listener());
};

type AndroidHostApi = {
    onReady?: (json: string) => void;
    onFirstFrame?: () => void;
    onError?: (message: string) => void;
    onSettingsClosed?: () => void;
    onInfo?: (message: string) => void;
    onNativeBackdropDemand?: (enabled: boolean) => void;
    onNativeBackdropPalette?: (json: string) => void;
    onNativeBackdropTuning?: (json: string) => void;
};
const androidHost = (): AndroidHostApi | undefined => (window as unknown as { AndroidHost?: AndroidHostApi }).AndroidHost;

/** Sends a message to the Android side (shown in the app's diagnostics). */
export const reportToAndroid = (message: string) => {
    try { androidHost()?.onError?.(message); } catch { /* the bridge is optional */ }
};

/** Closes Folia's style settings screen (from the page or from Android). */
export const closeHostSettings = () => {
    commit({ settingsOpen: false });
    try { androidHost()?.onSettingsClosed?.(); } catch { /* the bridge is optional */ }
};

export const subscribeHost = (listener: () => void) => {
    listeners.add(listener);
    return () => { listeners.delete(listener); };
};
export const getHostState = () => state;
export const useHostState = () => useSyncExternalStore(subscribeHost, getHostState);

/** Lyric time (s) extrapolated from the last anchor sent by Android. */
let liveClock: HostClock = state.clock;

export const getHostTimeSec = (nowMs: number): number => {
    const c = liveClock;
    if (!c.playing) return c.positionSec;
    const t = c.positionSec + (nowMs - c.anchoredAtMs) / 1000;
    return c.durationSec > 0 ? Math.min(t, c.durationSec) : t;
};

// Audio bands: plain MotionValues the visualizers read (written straight from the bridge, no React).
export const hostBands = {
    audioPower: motionValue(0),
    bass: motionValue(0),
    lowMid: motionValue(0),
    mid: motionValue(0),
    vocal: motionValue(0),
    treble: motionValue(0),
    spectrum: motionValue(new Uint8Array(0) as Uint8Array<ArrayBuffer>),
};

// Beats analysed by Halcyon (native) are fed into Folia's own beat-effect clock. Which effects play,
// and how strongly, follows Folia's own per-effect settings (the beat group of each style's
// settings screen), so an effect that is too heavy for the phone can simply be switched off there.
let beatsData: { key: string; events: BeatFxEvent[]; hasDrums: boolean; source: number } | null = null;
let installedBeatKey: string | null = null;
let lastEffectsKey = '';
interface LiveDrumHit { t: number; k: number; s: number }
let liveDrums: { key: string; enabled: boolean; ready: boolean; offsetSec: number; light: boolean; hits: LiveDrumHit[]; hasKick: boolean } | null = null;

const applyEffects = () => {
    const s = state;
    const store = useVisualizerSettingsStore.getState();
    const smartBeat = { ...store.smartBeat, mode: s.beatFx ? 'on' : 'off' } as typeof store.smartBeat;
    const strengths: Record<string, number> = {};
    if (s.beatFx && beatsData) {
        try {
            const effects = liveBeatEffects({
                ...store,
                smartBeat,
                visualizerMode: s.mode as never,
                visualizerBackgroundMode: (s.background ?? null) as never,
                pageTransparent: false,
            } as never);
            for (const effect of effects) {
                if (effect.source !== 'beats' && !(effect.source === 'drums' && beatsData.hasDrums)) continue;
                const setting = resolveBeatEffectSetting(smartBeat, effect.id);
                strengths[effect.id] = setting.strength;
                for (const part of effect.parts ?? []) {
                    strengths[beatEffectPartId(effect.id, part.key)] = resolveBeatEffectPartStrength(setting, part.key);
                }
            }
        } catch (error) {
            console.warn('[HalcyonHost] beat effects unavailable', error);
        }
    }
    setBeatFxIntensities(s.beatStrength, s.beatStrength);
    setBeatFxLiveEffects(strengths);
};

const applyBeats = (installEvents = false) => {
    if (!state.beatFx || !beatsData) {
        if (installedBeatKey !== null) {
            installedBeatKey = null;
            beginBeatFxTrack(null);
        }
    } else {
        const changedTrack = installedBeatKey !== beatsData.key;
        if (changedTrack) {
            installedBeatKey = beatsData.key;
            beginBeatFxTrack(beatsData.key);
            installEvents = true;
        }
        if (installEvents && !(liveDrums?.enabled && liveDrums.ready && liveDrums.key === beatsData.key && liveDrums.hasKick)) {
            setBeatFxEvents(beatsData.key, beatsData.events, 'beat_this', undefined, 1);
        }
    }
    applyEffects();
};

/** The frame governor in HalcyonStage calls this when the page cannot keep its frame rate. */
export const pauseBeatEffectsForPerformance = () => {
    if (!state.beatFx) return;
    commit({ beatFx: false });
    applyBeats();
    try { androidHost()?.onInfo?.('Beat effects switched off: the frame rate dropped. Lower the render scale or re-enable them in Tune.'); } catch { /* optional */ }
};

const parse = <T,>(json: string, fallback: T): T => {
    try { return JSON.parse(json) as T; } catch { return fallback; }
};

interface WireLine {
    s: number; e: number; t: string;
    w: Array<[string, number, number]>;
    tr?: string; ro?: string; a?: string;
}

export const installHalcyonHost = () => {
    const api = {
        setNativeBackdropAvailable(available: boolean) {
            if (state.nativeBackdropAvailable !== available) commit({ nativeBackdropAvailable: available });
        },
        setBatteryProfile(enabled: boolean) {
            if (state.batteryProfile !== enabled) commit({ batteryProfile: enabled });
        },
        setMode(id: string) {
            commit({ mode: id });
            applyBeats();
        },
        setBackground(id: string) {
            commit({ background: id ? id : null });
            applyBeats();
        },
        setTheme(json: string) {
            const theme = parse<Theme | null>(json, null);
            if (theme) commit({ theme });
        },
        setSong(json: string) {
            const song = parse<{ name?: string; artist?: string; cover?: string | null; seed?: string } | null>(json, null);
            if (!song) return;
            commit({
                track: {
                    name: song.name ?? '',
                    artist: song.artist ?? '',
                    coverUrl: song.cover ?? null,
                    seed: song.seed ?? 'halcyon',
                },
            });
        },
        setLyrics(json: string) {
            const wire = parse<WireLine[]>(json, []);
            const lines: Line[] = wire.map(item => ({
                startTime: item.s,
                endTime: item.e,
                fullText: item.t,
                words: item.w.map(([text, start, end]) => ({ text, startTime: start, endTime: end })),
                translation: item.tr || undefined,
                romanization: item.ro || undefined,
                agentId: item.a || undefined,
            }));
            commit({ lines });
        },
        setClock(positionMs: number, durationMs: number, playing: boolean, anchorMs: number) {
            liveClock = {
                positionSec: positionMs / 1000,
                durationSec: durationMs / 1000,
                anchoredAtMs: anchorMs > 0 ? anchorMs : Date.now(),
                playing,
            };
            // The anchor itself is read straight from liveClock; React only hears about the
            // things that change what is drawn (play/pause, length), so position updates are free.
            if (state.clock.playing !== playing || state.clock.durationSec !== liveClock.durationSec) {
                commit({ clock: liveClock });
            }
        },
        setBands(bass: number, lowMid: number, mid: number, vocal: number, treble: number, power: number) {
            hostBands.bass.set(bass);
            hostBands.lowMid.set(lowMid);
            hostBands.mid.set(mid);
            hostBands.vocal.set(vocal);
            hostBands.treble.set(treble);
            hostBands.audioPower.set(power);
        },
        setBeats(json: string) {
            const data = parse<{
                key: string; source?: number; beats?: number[]; impact?: number[]; downbeat?: number; allDown?: boolean; downAbove?: number;
                drums?: { times: number[]; kinds: number[]; strengths: number[] };
            } | null>(json, null);
            if (!data || !data.key) {
                beatsData = null;
            } else {
                const times = data.beats ?? [];
                const events: BeatFxEvent[] = times.map((ms, i) => {
                    const strength = data.impact ? data.impact[i] : undefined;
                    const strong = data.downAbove !== undefined && data.downAbove >= 0 && strength !== undefined && strength >= data.downAbove;
                    const downbeat = data.downbeat ?? -1;
                    const onBar = downbeat >= 0 && (i - downbeat) % 4 === 0;
                    return { t: ms / 1000, kind: data.allDown || strong || onBar ? 'downbeat' : 'beat', impact: strength };
                });
                let hasDrums = false;
                if (data.drums && data.drums.times.length > 0 && !(liveDrums?.key === data.key && liveDrums.enabled)) {
                    setExternalDrumHits(data.key, {
                        times: Float64Array.from(data.drums.times),
                        strengths: Float32Array.from(data.drums.strengths),
                        kinds: Uint8Array.from(data.drums.kinds),
                    });
                    hasDrums = true;
                }
                beatsData = { key: data.key, events, hasDrums, source: data.source ?? 0 };
            }
            if (liveDrums?.key !== data?.key) {
                liveDrums = null;
            }
            applyBeats(true);
        },
        setLiveDrums(json: string) {
            const data = parse<{
                key: string; reset?: boolean; enabled?: boolean; ready?: boolean; offsetMs?: number; light?: boolean;
                hits?: Array<{ t: number; k: number; s: number }>;
            } | null>(json, null);
            if (!data || !data.key) return;
            if (data.reset || liveDrums?.key !== data.key) {
                const enabled = Boolean(data.enabled);
                liveDrums = { key: data.key, enabled, ready: false, offsetSec: (data.offsetMs ?? 0) / 1000, light: Boolean(data.light), hits: [], hasKick: false };
                if (enabled) {
                    // Claim the source before the first hit arrives. This also prevents Folia from
                    // starting its heavyweight htdemucs pass while the native PCM stream warms up.
                    setExternalDrumHits(data.key, { times: new Float64Array(0), strengths: new Float32Array(0), kinds: new Uint8Array(0) });
                    if (beatsData?.key === data.key) beatsData.hasDrums = false;
                }
                applyBeats(true);
                return;
            }
            const live = liveDrums;
            if (!live || live.key !== data.key) return;
            const wasReady = live.ready;
            const wasEnabled = live.enabled;
            live.enabled = data.enabled ?? live.enabled;
            live.ready = data.ready ?? live.ready;
            live.offsetSec = (data.offsetMs ?? live.offsetSec * 1000) / 1000;
            live.light = data.light ?? live.light;
            if (!live.enabled) {
                if (wasEnabled || live.hits.length > 0) {
                    live.hits = [];
                    live.hasKick = false;
                    if (beatsData?.key === live.key) {
                        beatsData.hasDrums = false;
                        applyEffects();
                    }
                }
                return;
            }
            let addedHits = false;
            if (Array.isArray(data.hits)) {
                // The Android bridge sends only new sequence numbers. Merge each hit as it arrives
                // instead of sorting and rebuilding the whole history on every 10 ms poll.
                for (const hit of data.hits) {
                    if (!Number.isFinite(hit.t) || hit.t < 0 || !Number.isFinite(hit.s) || hit.k < 0 || hit.k > 2) continue;
                    const next = { t: hit.t, k: hit.k, s: Math.max(0, Math.min(1, hit.s)) };
                    // Coalesce only repeated hits of the same instrument. A kick, snare and hat
                    // may land in one PCM frame and must never suppress each other. Keep the first
                    // onset timestamp while retaining the strongest same-kind confidence.
                    let mergeIndex = -1;
                    for (let i = live.hits.length - 1; i >= 0; i -= 1) {
                        const previous = live.hits[i]!;
                        if (next.t - previous.t > 0.09) break;
                        if (previous.k === next.k) { mergeIndex = i; break; }
                    }
                    if (mergeIndex >= 0) {
                        const previous = live.hits[mergeIndex]!;
                        if (next.s > previous.s) live.hits[mergeIndex] = { ...previous, s: next.s };
                    } else {
                        live.hits.push(next);
                    }
                    if (next.k === 0) live.hasKick = true;
                    addedHits = true;
                }
                if (live.hits.length > 4096) live.hits.splice(0, live.hits.length - 4096);
            }
            // Before the first 250 ms of PCM has arrived, retain the hits but don't label the
            // stream ready. Re-send the accumulated head once the warm-up flag flips.
            if (!live.ready || (!addedHits && wasReady === live.ready)) return;
            if (live.hits.length > 0) {
                const shifted = live.hits
                    .filter(hit => !live.light || (hit.k !== 2 && hit.s >= 0.6))
                    .map(hit => ({ ...hit, t: hit.t + live.offsetSec }));
                setExternalDrumHits(live.key, {
                    times: Float64Array.from(shifted.map(hit => hit.t)),
                    strengths: Float32Array.from(shifted.map(hit => hit.s)),
                    kinds: Uint8Array.from(shifted.map(hit => hit.k)),
                });
                const newlyHasDrums = beatsData?.key === live.key && !beatsData.hasDrums && shifted.length > 0;
                if (beatsData?.key === live.key && shifted.length > 0) beatsData.hasDrums = true;
                // Kicks drive the heavy/downbeat pulse; snares add a lighter beat-level accent.
                // Hats remain available to styles that consume DrumHits directly, but do not drive
                // the shared beat clock (their subdivisions would make every style flicker).
                const percussionByTime = new Map<number, BeatFxEvent>();
                for (const hit of shifted) {
                    if (hit.k !== 0 && hit.k !== 1) continue;
                    const nearestDownbeat = hit.k === 0
                        && (beatsData?.events.some(event => event.kind === 'downbeat' && Math.abs(event.t - hit.t) <= 0.12) ?? false);
                    const event: BeatFxEvent = { t: hit.t, kind: nearestDownbeat ? 'downbeat' : 'beat', impact: hit.s };
                    const previous = percussionByTime.get(hit.t);
                    if (!previous
                        || (event.kind === 'downbeat' && previous.kind !== 'downbeat')
                        || (previous.kind !== 'downbeat' && (event.impact ?? 0) > (previous.impact ?? 0))) {
                        percussionByTime.set(hit.t, event);
                    }
                }
                const percussionEvents = [...percussionByTime.values()].sort((a, b) => a.t - b.t);
                if (percussionEvents.length > 0 && state.beatFx && beatsData?.key === live.key && beatsData.source === 0) {
                    // Respect the user's source selection: source 1 keeps the analysed beat grid;
                    // source 0 follows the live bass/snare transient stream.
                    replaceFutureBeatFxEvents(live.key, percussionEvents);
                }
                if (newlyHasDrums) applyEffects();
            }
        },
        setOptions(json: string) {
            const o = parse<Partial<{ fontScale: number; showTranslation: boolean; staticMode: boolean; daylight: boolean; beatFx: boolean; beatStrength: number; rtlFix: boolean }>>(json, {});
            commit({
                fontScale: o.fontScale ?? state.fontScale,
                showTranslation: o.showTranslation ?? state.showTranslation,
                staticMode: o.staticMode ?? state.staticMode,
                daylight: o.daylight ?? state.daylight,
                beatFx: o.beatFx ?? state.beatFx,
                beatStrength: o.beatStrength ?? state.beatStrength,
                rtlFix: o.rtlFix ?? state.rtlFix,
            });
            applyBeats();
        },
        openSettings(open: boolean) {
            commit({ settingsOpen: open });
        },
        setDebug(debug: boolean) {
            commit({ debug });
        },
        setFps(fps: number) {
            const setter = (window as unknown as { __halcyonSetFps?: (f: number) => void }).__halcyonSetFps;
            if (setter) setter(fps);
        },
    };
    (window as unknown as { HalcyonHost: typeof api }).HalcyonHost = api;

    // A change in Folia's own beat settings (made on the style settings screen) re-applies the effects.
    useVisualizerSettingsStore.subscribe(store => {
        const key = JSON.stringify(store.smartBeat);
        if (key !== lastEffectsKey) {
            lastEffectsKey = key;
            applyEffects();
        }
    });

    const host = (window as unknown as { AndroidHost?: { onReady?: (json: string) => void } }).AndroidHost;
    if (host && host.onReady) {
        const modes = VISUALIZER_REGISTRY.map(entry => ({ id: entry.mode, label: entry.labelFallback }));
        const backgrounds = VISUALIZER_BACKGROUND_REGISTRY.map(entry => ({ id: entry.mode, label: entry.labelFallback }));
        host.onReady(JSON.stringify({ modes, backgrounds }));
    }
};
