import type { Line, Word } from '../types';

// Arabic is prepared in logical reading order. RTL renderers keep browser shaping; renderers that
// rasterize one grapheme at a time receive Unicode presentation forms, one unchanged grapheme per
// timed unit. We never reverse Line.words or collapse lam-alef into a single timing unit.

// [isolated, final, initial, medial] - 0 when the form does not exist.
const FORMS: Record<number, [number, number, number, number]> = {
    0x0621: [0xFE80, 0, 0, 0],
    0x0622: [0xFE81, 0xFE82, 0, 0],
    0x0623: [0xFE83, 0xFE84, 0, 0],
    0x0624: [0xFE85, 0xFE86, 0, 0],
    0x0625: [0xFE87, 0xFE88, 0, 0],
    0x0626: [0xFE89, 0xFE8A, 0xFE8B, 0xFE8C],
    0x0627: [0xFE8D, 0xFE8E, 0, 0],
    0x0628: [0xFE8F, 0xFE90, 0xFE91, 0xFE92],
    0x0629: [0xFE93, 0xFE94, 0, 0],
    0x062A: [0xFE95, 0xFE96, 0xFE97, 0xFE98],
    0x062B: [0xFE99, 0xFE9A, 0xFE9B, 0xFE9C],
    0x062C: [0xFE9D, 0xFE9E, 0xFE9F, 0xFEA0],
    0x062D: [0xFEA1, 0xFEA2, 0xFEA3, 0xFEA4],
    0x062E: [0xFEA5, 0xFEA6, 0xFEA7, 0xFEA8],
    0x062F: [0xFEA9, 0xFEAA, 0, 0],
    0x0630: [0xFEAB, 0xFEAC, 0, 0],
    0x0631: [0xFEAD, 0xFEAE, 0, 0],
    0x0632: [0xFEAF, 0xFEB0, 0, 0],
    0x0633: [0xFEB1, 0xFEB2, 0xFEB3, 0xFEB4],
    0x0634: [0xFEB5, 0xFEB6, 0xFEB7, 0xFEB8],
    0x0635: [0xFEB9, 0xFEBA, 0xFEBB, 0xFEBC],
    0x0636: [0xFEBD, 0xFEBE, 0xFEBF, 0xFEC0],
    0x0637: [0xFEC1, 0xFEC2, 0xFEC3, 0xFEC4],
    0x0638: [0xFEC5, 0xFEC6, 0xFEC7, 0xFEC8],
    0x0639: [0xFEC9, 0xFECA, 0xFECB, 0xFECC],
    0x063A: [0xFECD, 0xFECE, 0xFECF, 0xFED0],
    0x0641: [0xFED1, 0xFED2, 0xFED3, 0xFED4],
    0x0642: [0xFED5, 0xFED6, 0xFED7, 0xFED8],
    0x0643: [0xFED9, 0xFEDA, 0xFEDB, 0xFEDC],
    0x0644: [0xFEDD, 0xFEDE, 0xFEDF, 0xFEE0],
    0x0645: [0xFEE1, 0xFEE2, 0xFEE3, 0xFEE4],
    0x0646: [0xFEE5, 0xFEE6, 0xFEE7, 0xFEE8],
    0x0647: [0xFEE9, 0xFEEA, 0xFEEB, 0xFEEC],
    0x0648: [0xFEED, 0xFEEE, 0, 0],
    0x0649: [0xFEEF, 0xFEF0, 0, 0],
    0x064A: [0xFEF1, 0xFEF2, 0xFEF3, 0xFEF4],
};

const TATWEEL = 0x0640;
const ZWNJ = 0x200C;
const ZWJ = 0x200D;
const MARK_RE = /\p{M}/u;

const splitGraphemes = (text: string): string[] => {
    if (typeof Intl !== 'undefined' && 'Segmenter' in Intl) {
        const segmenter = new Intl.Segmenter(undefined, { granularity: 'grapheme' });
        return Array.from(segmenter.segment(text), item => item.segment);
    }
    const out: string[] = [];
    for (const char of Array.from(text)) {
        if (MARK_RE.test(char) || char === ZWJ || char === ZWNJ) {
            if (out.length) out[out.length - 1] += char;
            else out.push(char);
        } else out.push(char);
    }
    return out;
};

const firstBaseCodePoint = (cluster: string): number | null => {
    for (const char of Array.from(cluster)) {
        const cp = char.codePointAt(0) ?? 0;
        if (MARK_RE.test(char) || cp === ZWJ || cp === ZWNJ) continue;
        return cp;
    }
    return null;
};
const hasZwnj = (cluster: string) => cluster.includes(String.fromCodePoint(ZWNJ));
const hasZwj = (cluster: string) => cluster.includes(String.fromCodePoint(ZWJ));
const canJoinPrevious = (cp: number | null) => cp === TATWEEL || (cp !== null && Boolean(FORMS[cp]?.[1]));
const canJoinNext = (cp: number | null) => cp === TATWEEL || (cp !== null && Boolean(FORMS[cp]?.[2]));

/**
 * Shapes only the base Arabic character inside each grapheme. Combining marks and join controls
 * remain attached and are never discarded. Output grapheme count and source order are preserved.
 */
export const shapeArabic = (text: string): string[] => {
    const clusters = splitGraphemes(text);
    return clusters.map((cluster, index) => {
        const cp = firstBaseCodePoint(cluster);
        const forms = cp === null ? undefined : FORMS[cp];
        if (!forms) return cluster;

        const previous = index > 0 ? clusters[index - 1]! : '';
        const next = index + 1 < clusters.length ? clusters[index + 1]! : '';
        const previousCp = firstBaseCodePoint(previous);
        const nextCp = firstBaseCodePoint(next);
        const previousJoinControl = hasZwj(previous);
        const currentJoinControl = hasZwj(cluster);
        const joinsPrevious = !hasZwnj(previous) && !hasZwnj(cluster)
            && canJoinPrevious(cp)
            && (canJoinNext(previousCp) || previousJoinControl || currentJoinControl);
        const joinsNext = !hasZwnj(cluster) && !hasZwnj(next)
            && canJoinNext(cp)
            && (canJoinPrevious(nextCp) || currentJoinControl || hasZwj(next));

        let form = forms[0];
        if (joinsPrevious && joinsNext) form = forms[3] || forms[1] || forms[2] || forms[0];
        else if (joinsPrevious) form = forms[1] || forms[0];
        else if (joinsNext) form = forms[2] || forms[0];
        const shaped = String.fromCodePoint(form || cp!);
        const base = Array.from(cluster).find(char => (char.codePointAt(0) ?? 0) === cp) ?? '';
        const suffix = cluster.slice(base.length);
        return shaped + suffix;
    });
};

export const shapeArabicText = (text: string): string => shapeArabic(text).join('');

/** Each renderer gets the text representation its own layout/reveal code requires. */
export type ArabicMode = 'native' | 'shaped-logical';

const MODES: Record<string, ArabicMode> = {
    // Folia's existing first-strong RTL layout/text engines.
    classic: 'native',
    partita: 'native',
    monet: 'native',
    diorama: 'native',
    // Whole-run browser / Canvas text shaping; direction is handled by the patched renderer.
    fume: 'native',
    pendolo: 'native',
    still: 'native',
    // Each of these breaks a word into independently positioned glyphs / spans.
    cadenza: 'shaped-logical',
    cappella: 'shaped-logical',
    claddagh: 'shaped-logical',
    hanabi: 'shaped-logical',
    lumiere: 'shaped-logical',
    machi: 'shaped-logical',
    nebbia: 'shaped-logical',
    sonnet: 'shaped-logical',
    tempera: 'shaped-logical',
    tilt: 'shaped-logical',
};

export const arabicModeFor = (mode: string): ArabicMode => MODES[mode] ?? 'native';

const shapeWord = (word: Word): Word => ({
    ...word,
    text: shapeArabicText(word.text),
    ...(word.syllables ? {
        syllables: word.syllables.map(syllable => ({ ...syllable, text: shapeArabicText(syllable.text) })),
    } : {}),
});

const shapeAlternateText = <T extends { text: string; syllables?: Array<{ text: string }> }>(item: T): T => ({
    ...item,
    text: shapeArabicText(item.text),
    ...(item.syllables ? {
        syllables: item.syllables.map(syllable => ({ ...syllable, text: shapeArabicText(syllable.text) })),
    } : {}),
});

const shapeBackgroundVocal = (voice: NonNullable<Line['backgroundVocal']>) => ({
    ...voice,
    text: shapeArabicText(voice.text),
    translation: voice.translation ? shapeArabicText(voice.translation) : voice.translation,
    romanization: voice.romanization ? shapeArabicText(voice.romanization) : voice.romanization,
    words: voice.words.map(shapeWord),
    alternateTexts: voice.alternateTexts?.map(shapeAlternateText),
});

/** Preserve all lyric ordering, spacing, timing, punctuation and word boundaries. */
export const arabicLineFor = (line: Line, mode: ArabicMode): Line => {
    if (mode !== 'shaped-logical') return line;
    return {
        ...line,
        fullText: shapeArabicText(line.fullText),
        translation: line.translation ? shapeArabicText(line.translation) : line.translation,
        romanization: line.romanization ? shapeArabicText(line.romanization) : line.romanization,
        words: line.words.map(shapeWord),
        wordSegments: line.wordSegments?.map(shapeArabicText),
        autoWordSegments: line.autoWordSegments?.map(shapeArabicText),
        alternateTexts: line.alternateTexts?.map(shapeAlternateText),
        backgroundVocal: line.backgroundVocal ? shapeBackgroundVocal(line.backgroundVocal) : line.backgroundVocal,
        backgroundVocals: line.backgroundVocals?.map(shapeBackgroundVocal),
    };
};

// Test-only invariant: shaping must not change the number of grapheme timing units.
export const arabicGraphemeCount = (text: string): number => splitGraphemes(text).length;
