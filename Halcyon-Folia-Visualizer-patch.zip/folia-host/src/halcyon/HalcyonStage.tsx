import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useMotionValue } from 'framer-motion';
import VisualizerRenderer from '../components/visualizer/VisualizerRenderer';
import { NO_LYRIC_LINES } from '../utils/lyrics/noLyricLines';
import { buildVisualizerTheme } from '../components/app/presentation/buildVisualizerTheme';
import { findLatestActiveLineIndex } from '../utils/appPlaybackHelpers';
import { buildObsAppearanceFromShortcode } from '../utils/obsWebAppearance';
import { tickBeatFx } from '../services/beatFx/beatFxLive';
import { backgroundTuningConfig } from '../components/visualizer/tuningRegistry';
import { useVisualizerTunings } from '../components/visualizer/useVisualizerTunings';
import { useVisualizerSettingsStore } from '../stores/useVisualizerSettingsStore';
import HalcyonSettings from './HalcyonSettings';
import { closeHostSettings, getHostTimeSec, hostBands, reportToAndroid, useHostState } from './hostApi';

// src/halcyon/HalcyonStage.tsx
// Hosts Folia's VisualizerRenderer the way the OBS web source does, but driven by the Android app.
// A render error is shown on the page (and sent to Android) instead of leaving a black screen.

class StageBoundary extends React.Component<{ children: React.ReactNode }, { error: string | null }> {
    state: { error: string | null } = { error: null };

    static getDerivedStateFromError(error: unknown) {
        const e = error as { stack?: string; message?: string } | undefined;
        return { error: String((e && (e.stack || e.message)) || error) };
    }

    componentDidCatch(error: unknown) {
        const e = error as { message?: string } | undefined;
        reportToAndroid('render: ' + String((e && e.message) || error));
    }

    render() {
        if (this.state.error) {
            return (
                <pre style={{ color: '#ff9b8a', fontSize: 11, padding: 16, whiteSpace: 'pre-wrap', margin: 0, paddingTop: 96 }}>
                    {'Folia style failed to draw:\n' + this.state.error.slice(0, 900)}
                </pre>
            );
        }
        return this.props.children;
    }
}

const HalcyonStage: React.FC = () => {
    const state = useHostState();
    const [currentLineIndex, setCurrentLineIndex] = useState(-1);
    const currentTime = useMotionValue(0);
    const lineIndexRef = useRef(-1);
    const stateRef = useRef(state);
    stateRef.current = state;
    const tunings = useVisualizerTunings();
    const settingsState = useVisualizerSettingsStore();

    const audioBands = useMemo(() => ({
        bass: hostBands.bass,
        lowMid: hostBands.lowMid,
        mid: hostBands.mid,
        vocal: hostBands.vocal,
        treble: hostBands.treble,
        spectrum: hostBands.spectrum,
    }), []);

    useEffect(() => {
        document.body.style.backgroundColor = '#000';
        let frame = 0;
        let frames = 0;
        const fakeDeck = { paused: false, ended: false, currentTime: 0 };
        const tick = () => {
            const s = stateRef.current;
            const t = getHostTimeSec(Date.now());
            currentTime.set(t);
            const lines = s.lines;
            const next = lines.length > 0 ? findLatestActiveLineIndex(lines, t) : -1;
            if (next !== lineIndexRef.current) {
                lineIndexRef.current = next;
                setCurrentLineIndex(next);
            }
            if (s.beatFx) {
                if (s.clock.playing) {
                    fakeDeck.currentTime = t;
                    tickBeatFx(fakeDeck as unknown as HTMLMediaElement, null);
                } else {
                    tickBeatFx(null, null);
                }
            }
            frames += 1;
            if (frames === 6) {
                const host = (window as unknown as { AndroidHost?: { onFirstFrame?: () => void } }).AndroidHost;
                if (host && host.onFirstFrame) host.onFirstFrame();
            }
            frame = window.requestAnimationFrame(tick);
        };
        frame = window.requestAnimationFrame(tick);
        return () => window.cancelAnimationFrame(frame);
    }, [currentTime]);

    const appearance = useMemo(
        () => buildObsAppearanceFromShortcode(null, {
            isDaylight: state.daylight,
            transparent: false,
            visualizerOverride: state.mode,
            themeMode: null,
        }),
        [state.daylight, state.mode],
    );

    const background = useMemo(() => {
        const base = appearance.background as unknown as Record<string, unknown>;
        const merged: Record<string, unknown> = { ...base };
        const tuningConfig = backgroundTuningConfig(settingsState as unknown as Record<string, unknown>);
        Object.keys(tuningConfig).forEach(key => {
            merged[key] = { ...(base[key] as object | undefined), ...tuningConfig[key] };
        });
        if (state.background) merged.mode = state.background;
        return merged as unknown as typeof appearance.background;
    }, [appearance.background, settingsState, state.background]);

    const { visualizerTheme, visualizerSubtitleTheme } = buildVisualizerTheme({
        appStyle: {},
        theme: state.theme,
        lyricsFontStyle: state.theme.fontStyle,
        lyricsFontWeight: null,
        lyricsCustomFontFamily: null,
        visualizerMode: appearance.mode,
    });

    return (
        <div
            style={{
                position: 'fixed',
                inset: 0,
                overflow: 'hidden',
                backgroundColor: state.theme.backgroundColor,
                color: state.theme.primaryColor,
            }}
        >
            <StageBoundary key={appearance.mode + '|' + (state.background ?? '')}>
                <VisualizerRenderer
                    mode={appearance.mode}
                    visualizerTunings={tunings}
                    currentTime={currentTime}
                    duration={state.clock.durationSec}
                    currentLineIndex={currentLineIndex}
                    lines={state.lines.length > 0 ? state.lines : NO_LYRIC_LINES}
                    theme={visualizerTheme}
                    subtitleTheme={visualizerSubtitleTheme}
                    isDaylight={state.daylight}
                    audioPower={hostBands.audioPower}
                    audioBands={audioBands}
                    songTitle={state.track.name}
                    songArtist={state.track.artist}
                    coverUrl={state.track.coverUrl}
                    showText={true}
                    seed={state.track.seed}
                    paused={!state.clock.playing}
                    staticMode={state.staticMode}
                    visualizerOpacity={appearance.visualizerOpacity}
                    background={background}
                    lyricsFontScale={state.fontScale}
                    subtitleFontScale={appearance.subtitleFontScale}
                    hideTranslationSubtitle={!state.showTranslation}
                    showSubtitleTranslation={state.showTranslation}
                    isPlayerChromeHidden={true}
                />
            </StageBoundary>
            {state.debug && (
                <div style={{ position: 'absolute', left: 8, bottom: 120, right: 8, font: '11px monospace', color: '#9fe', background: 'rgba(0,0,0,0.55)', padding: 6, borderRadius: 6, pointerEvents: 'none' }}>
                    {`mode=${appearance.mode} bg=${state.background ?? 'default'} lines=${state.lines.length} idx=${currentLineIndex} t=${getHostTimeSec(Date.now()).toFixed(1)} playing=${state.clock.playing} dpr=${window.devicePixelRatio} size=${window.innerWidth}x${window.innerHeight} theme=${state.theme.backgroundColor}/${state.theme.primaryColor}`}
                </div>
            )}
            {state.settingsOpen && (
                <HalcyonSettings
                    mode={appearance.mode}
                    theme={state.theme}
                    isDaylight={state.daylight}
                    onClose={closeHostSettings}
                />
            )}
        </div>
    );
};

export default HalcyonStage;
