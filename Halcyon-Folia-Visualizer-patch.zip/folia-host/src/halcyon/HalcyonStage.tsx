import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useMotionValue } from 'framer-motion';
import VisualizerRenderer from '../components/visualizer/VisualizerRenderer';
import { NO_LYRIC_LINES } from '../utils/lyrics/noLyricLines';
import { buildVisualizerTheme } from '../components/app/presentation/buildVisualizerTheme';
import { findLatestActiveLineIndex } from '../utils/appPlaybackHelpers';
import { buildObsAppearanceFromShortcode } from '../utils/obsWebAppearance';
import { tickBeatFx } from '../services/beatFx/beatFxLive';
import { getHostTimeSec, hostBands, useHostState } from './hostApi';

// src/halcyon/HalcyonStage.tsx
// Hosts Folia's VisualizerRenderer exactly as the OBS web source does, but driven by the
// Android app instead of a network source.

const HalcyonStage: React.FC = () => {
    const state = useHostState();
    const [currentLineIndex, setCurrentLineIndex] = useState(-1);
    const currentTime = useMotionValue(0);
    const lineIndexRef = useRef(-1);
    const stateRef = useRef(state);
    stateRef.current = state;

    const audioBands = useMemo(() => ({
        bass: hostBands.bass,
        lowMid: hostBands.lowMid,
        mid: hostBands.mid,
        vocal: hostBands.vocal,
        treble: hostBands.treble,
        spectrum: hostBands.spectrum,
    }), []);

    useEffect(() => {
        document.body.style.backgroundColor = '#000';
        let frame = 0;
        let frames = 0;
        const fakeDeck = { paused: false, ended: false, currentTime: 0 };
        const tick = () => {
            const s = stateRef.current;
            const t = getHostTimeSec(Date.now());
            currentTime.set(t);
            const lines = s.lines;
            const next = lines.length > 0 ? findLatestActiveLineIndex(lines, t) : -1;
            if (next !== lineIndexRef.current) {
                lineIndexRef.current = next;
                setCurrentLineIndex(next);
            }
            if (s.beatFx) {
                if (s.clock.playing) {
                    fakeDeck.currentTime = t;
                    tickBeatFx(fakeDeck as unknown as HTMLMediaElement, null);
                } else {
                    tickBeatFx(null, null);
                }
            }
            frames += 1;
            if (frames === 6) {
                const host = (window as unknown as { AndroidHost?: { onFirstFrame?: () => void } }).AndroidHost;
                if (host && host.onFirstFrame) host.onFirstFrame();
            }
            frame = window.requestAnimationFrame(tick);
        };
        frame = window.requestAnimationFrame(tick);
        return () => window.cancelAnimationFrame(frame);
    }, [currentTime]);

    const appearance = useMemo(
        () => buildObsAppearanceFromShortcode(null, {
            isDaylight: state.daylight,
            transparent: false,
            visualizerOverride: state.mode,
            themeMode: null,
        }),
        [state.daylight, state.mode],
    );

    const background = useMemo(
        () => (state.background ? { ...appearance.background, mode: state.background as never } : appearance.background),
        [appearance.background, state.background],
    );

    const { visualizerTheme, visualizerSubtitleTheme } = buildVisualizerTheme({
        appStyle: {},
        theme: state.theme,
        lyricsFontStyle: state.theme.fontStyle,
        lyricsFontWeight: null,
        lyricsCustomFontFamily: null,
        visualizerMode: appearance.mode,
    });

    return (
        <div
            style={{
                width: '100vw',
                height: '100vh',
                overflow: 'hidden',
                backgroundColor: state.theme.backgroundColor,
                color: state.theme.primaryColor,
            }}
        >
            <VisualizerRenderer
                mode={appearance.mode}
                visualizerTunings={appearance.visualizerTunings}
                currentTime={currentTime}
                duration={state.clock.durationSec}
                currentLineIndex={currentLineIndex}
                lines={state.lines.length > 0 ? state.lines : NO_LYRIC_LINES}
                theme={visualizerTheme}
                subtitleTheme={visualizerSubtitleTheme}
                isDaylight={state.daylight}
                audioPower={hostBands.audioPower}
                audioBands={audioBands}
                songTitle={state.track.name}
                songArtist={state.track.artist}
                coverUrl={state.track.coverUrl}
                showText={true}
                seed={state.track.seed}
                paused={!state.clock.playing}
                staticMode={state.staticMode}
                visualizerOpacity={appearance.visualizerOpacity}
                background={background}
                lyricsFontScale={state.fontScale}
                subtitleFontScale={appearance.subtitleFontScale}
                hideTranslationSubtitle={!state.showTranslation}
                showSubtitleTranslation={state.showTranslation}
                isPlayerChromeHidden={true}
            />
        </div>
    );
};

export default HalcyonStage;
