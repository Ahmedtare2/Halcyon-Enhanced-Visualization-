import React, { useEffect, useMemo, useRef, useState } from 'react';
import { useMotionValue } from 'framer-motion';
import VisualizerRenderer from '../components/visualizer/VisualizerRenderer';
import { NO_LYRIC_LINES } from '../utils/lyrics/noLyricLines';
import { buildVisualizerTheme } from '../components/app/presentation/buildVisualizerTheme';
import { buildAppStyle } from '../components/app/presentation/buildAppStyle';
import { findLatestActiveLineIndex } from '../utils/appPlaybackHelpers';
import { buildObsAppearanceFromShortcode } from '../utils/obsWebAppearance';
import { tickBeatFx } from '../services/beatFx/beatFxLive';
import { backgroundTuningConfig } from '../components/visualizer/tuningRegistry';
import { useVisualizerTunings } from '../components/visualizer/useVisualizerTunings';
import { useVisualizerSettingsStore } from '../stores/useVisualizerSettingsStore';
import HalcyonSettings from './HalcyonSettings';
import { resolveLyricTextDirection } from '../utils/lyrics/textDirection';
import { annotateLyricLines } from '../utils/lyrics/renderHints';
import type { Line } from '../types';
import { closeHostSettings, getHostTimeSec, hostBands, pauseBeatEffectsForPerformance, reportToAndroid, useHostState } from './hostApi';

// src/halcyon/HalcyonStage.tsx
// Hosts Folia's VisualizerRenderer the way the OBS web source does, but driven by the Android app.
// A render error is shown on the page (and sent to Android) instead of leaving a black screen.

// Styles that handle right-to-left themselves (Folia's own RTL support); all others get Arabic lines
// with their words in visual order so reading runs from the right.
const RTL_READY = new Set(['classic', 'partita', 'monet', 'diorama']);

const reverseWords = (line: Line): Line => {
    const words = [...line.words].reverse();
    return { ...line, words, fullText: words.map(word => word.text).join('').trim() };
};

class StageBoundary extends React.Component<{ children: React.ReactNode }, { error: string | null }> {
    state: { error: string | null } = { error: null };

    static getDerivedStateFromError(error: unknown) {
        const e = error as { stack?: string; message?: string } | undefined;
        return { error: String((e && (e.stack || e.message)) || error) };
    }

    componentDidCatch(error: unknown) {
        const e = error as { message?: string } | undefined;
        reportToAndroid('render: ' + String((e && e.message) || error));
    }

    render() {
        if (this.state.error) {
            return (
                <pre style={{ color: '#ff9b8a', fontSize: 11, padding: 16, whiteSpace: 'pre-wrap', margin: 0, paddingTop: 96 }}>
                    {'Folia style failed to draw:\n' + this.state.error.slice(0, 900)}
                </pre>
            );
        }
        return this.props.children;
    }
}

const HalcyonStage: React.FC = () => {
    const state = useHostState();
    const [currentLineIndex, setCurrentLineIndex] = useState(-1);
    const currentTime = useMotionValue(0);
    const lineIndexRef = useRef(-1);
    const stateRef = useRef(state);
    stateRef.current = state;
    const tunings = useVisualizerTunings();
    const settingsState = useVisualizerSettingsStore();

    const audioBands = useMemo(() => ({
        bass: hostBands.bass,
        lowMid: hostBands.lowMid,
        mid: hostBands.mid,
        vocal: hostBands.vocal,
        treble: hostBands.treble,
        spectrum: hostBands.spectrum,
    }), []);

    useEffect(() => {
        document.body.style.backgroundColor = '#000';
        let frame = 0;
        let frames = 0;
        const fakeDeck = { paused: false, ended: false, currentTime: 0 };
        // Frame governor: if the page keeps missing its frame budget while beat effects run, the
        // effects are switched off for the session (Android is told) instead of leaving it laggy.
        let lastNow = 0;
        let windowMs = 0;
        let windowFrames = 0;
        let slowSeconds = 0;
        const tick = () => {
            const nowMs = performance.now();
            if (lastNow > 0 && stateRef.current.beatFx && stateRef.current.clock.playing) {
                windowMs += nowMs - lastNow;
                windowFrames += 1;
                if (windowMs >= 1000) {
                    const average = windowMs / windowFrames;
                    const frameMs = (window as unknown as { __halcyonFrameMs?: () => number }).__halcyonFrameMs?.() ?? 16.7;
                    slowSeconds = average > Math.max(frameMs * 1.6, 30) ? slowSeconds + 1 : 0;
                    windowMs = 0;
                    windowFrames = 0;
                    if (slowSeconds >= 3) {
                        slowSeconds = 0;
                        pauseBeatEffectsForPerformance();
                    }
                }
            } else {
                windowMs = 0;
                windowFrames = 0;
            }
            lastNow = nowMs;
            const s = stateRef.current;
            const t = getHostTimeSec(Date.now());
            currentTime.set(t);
            const lines = s.lines;
            const next = lines.length > 0 ? findLatestActiveLineIndex(lines, t) : -1;
            if (next !== lineIndexRef.current) {
                lineIndexRef.current = next;
                setCurrentLineIndex(next);
            }
            if (s.beatFx) {
                if (s.clock.playing) {
                    fakeDeck.currentTime = t;
                    tickBeatFx(fakeDeck as unknown as HTMLMediaElement, null);
                } else {
                    tickBeatFx(null, null);
                }
            }
            frames += 1;
            if (frames === 6) {
                const host = (window as unknown as { AndroidHost?: { onFirstFrame?: () => void } }).AndroidHost;
                if (host && host.onFirstFrame) host.onFirstFrame();
            }
            frame = window.requestAnimationFrame(tick);
        };
        frame = window.requestAnimationFrame(tick);
        return () => window.cancelAnimationFrame(frame);
    }, [currentTime]);

    const lines = useMemo(() => {
        const reorder = state.rtlFix && !RTL_READY.has(state.mode);
        const prepared = reorder
            ? state.lines.map(line => (resolveLyricTextDirection(line.fullText) === 'rtl' ? reverseWords(line) : line))
            : state.lines;
        return annotateLyricLines(prepared);
    }, [state.lines, state.mode, state.rtlFix]);

    const appearance = useMemo(
        () => buildObsAppearanceFromShortcode(null, {
            isDaylight: state.daylight,
            transparent: false,
            visualizerOverride: state.mode,
            themeMode: null,
        }),
        [state.daylight, state.mode],
    );

    const background = useMemo(() => {
        const base = appearance.background as unknown as Record<string, unknown>;
        const merged: Record<string, unknown> = { ...base };
        const tuningConfig = backgroundTuningConfig(settingsState as unknown as Record<string, unknown>);
        Object.keys(tuningConfig).forEach(key => {
            merged[key] = { ...(base[key] as object | undefined), ...tuningConfig[key] };
        });
        if (state.background) merged.mode = state.background;
        return merged as unknown as typeof appearance.background;
    }, [appearance.background, settingsState, state.background]);

    // The same root CSS variables Folia's own app sets (--bg-color, --text-primary, ...). The settings
    // kit (slider tracks, text colours) and the visualizer theme are derived from them.
    const appStyle = useMemo(() => buildAppStyle({
        bgMode: 'theme',
        isDaylight: state.daylight,
        theme: state.theme,
        daylightTheme: state.theme,
        defaultTheme: state.theme,
    }), [state.theme, state.daylight]);

    const { visualizerTheme, visualizerSubtitleTheme } = useMemo(() => buildVisualizerTheme({
        appStyle,
        theme: state.theme,
        lyricsFontStyle: state.theme.fontStyle,
        lyricsFontWeight: null,
        lyricsCustomFontFamily: null,
        visualizerMode: appearance.mode,
    }), [appStyle, state.theme, appearance.mode]);

    return (
        <div
            style={{
                ...appStyle,
                position: 'fixed',
                inset: 0,
                overflow: 'hidden',
            }}
        >
            <StageBoundary key={appearance.mode + '|' + (state.background ?? '')}>
                <VisualizerRenderer
                    mode={appearance.mode}
                    visualizerTunings={tunings}
                    currentTime={currentTime}
                    duration={state.clock.durationSec}
                    currentLineIndex={currentLineIndex}
                    lines={lines.length > 0 ? lines : NO_LYRIC_LINES}
                    theme={visualizerTheme}
                    subtitleTheme={visualizerSubtitleTheme}
                    isDaylight={state.daylight}
                    audioPower={hostBands.audioPower}
                    audioBands={audioBands}
                    songTitle={state.track.name}
                    songArtist={state.track.artist}
                    coverUrl={state.track.coverUrl}
                    showText={true}
                    seed={state.track.seed}
                    paused={!state.clock.playing}
                    staticMode={state.staticMode}
                    visualizerOpacity={appearance.visualizerOpacity}
                    background={background}
                    lyricsFontScale={state.fontScale}
                    subtitleFontScale={appearance.subtitleFontScale}
                    hideTranslationSubtitle={!state.showTranslation}
                    showSubtitleTranslation={state.showTranslation}
                    isPlayerChromeHidden={true}
                />
            </StageBoundary>
            {state.debug && (
                <div style={{ position: 'absolute', left: 8, bottom: 120, right: 8, font: '11px monospace', color: '#9fe', background: 'rgba(0,0,0,0.55)', padding: 6, borderRadius: 6, pointerEvents: 'none' }}>
                    {`mode=${appearance.mode} bg=${state.background ?? 'default'} lines=${state.lines.length} idx=${currentLineIndex} t=${getHostTimeSec(Date.now()).toFixed(1)} playing=${state.clock.playing} dpr=${window.devicePixelRatio} size=${window.innerWidth}x${window.innerHeight} theme=${state.theme.backgroundColor}/${state.theme.primaryColor}`}
                </div>
            )}
            {state.settingsOpen && (
                <HalcyonSettings
                    mode={appearance.mode}
                    theme={state.theme}
                    isDaylight={state.daylight}
                    onClose={closeHostSettings}
                />
            )}
        </div>
    );
};

export default HalcyonStage;
