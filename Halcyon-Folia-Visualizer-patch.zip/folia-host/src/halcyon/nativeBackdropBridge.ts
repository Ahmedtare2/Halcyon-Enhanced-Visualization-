// The native backdrop bridge is separate from hostApi to avoid a registry -> Latent -> hostApi cycle.

type AndroidNativeBackdrop = {
    onNativeBackdropDemand?: (enabled: boolean) => void;
    onNativeBackdropPalette?: (json: string) => void;
    onNativeBackdropTuning?: (json: string) => void;
};

const nativeBridge = (): AndroidNativeBackdrop | undefined => (
    (window as unknown as { AndroidHost?: AndroidNativeBackdrop }).AndroidHost
);

export const reportNativeBackdropDemand = (enabled: boolean) => {
    try { nativeBridge()?.onNativeBackdropDemand?.(enabled); } catch { /* native rendering is optional */ }
};

export const reportNativeBackdropPalette = (colors: string[]) => {
    if (colors.length < 6) return;
    try { nativeBridge()?.onNativeBackdropPalette?.(JSON.stringify(colors.slice(0, 6))); } catch { /* optional */ }
};

export const reportNativeBackdropTuning = (tuning: {
    meshSpeed: number; meshAudioSpeed: number; meshDistortion: number; meshSwirl: number;
    enhancedBeatResponse: boolean;
}) => {
    try { nativeBridge()?.onNativeBackdropTuning?.(JSON.stringify(tuning)); } catch { /* optional */ }
};
