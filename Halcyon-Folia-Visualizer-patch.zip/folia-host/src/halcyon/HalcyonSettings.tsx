import React from 'react';
import { useTranslation } from 'react-i18next';
import { getVisualizerRegistryEntry } from '../components/visualizer/registry';
import { getVisualizerTuning } from '../components/visualizer/tuningRegistry';
import { useVisualizerSettingsStore } from '../stores/useVisualizerSettingsStore';
import { SettingsKitThemeContext, settingsTokens } from '../components/modal/settings/kit/kitTheme';
import { kitMotionTokens } from '../components/modal/settings/kit/motion';
import type { Theme } from '../types';

// src/halcyon/HalcyonSettings.tsx
// Shows Folia's own settings panel for the current lyric style (the same controls, sections and
// ranges as Folia's "Lyrics Style" screen). Values live in Folia's settings store, which persists
// them (localStorage) and feeds the renderer, so every change is applied and remembered.

interface Props {
    mode: string;
    theme: Theme;
    isDaylight: boolean;
    onClose: () => void;
}

const rangeInputClass = 'w-full h-1.5 rounded-full appearance-none cursor-pointer bg-white/10';

const HalcyonSettings: React.FC<Props> = ({ mode, theme, isDaylight, onClose }) => {
    const { t } = useTranslation();
    const settings = useVisualizerSettingsStore();
    const store = settings as unknown as Record<string, unknown>;
    const entry = getVisualizerRegistryEntry(mode as never);
    const adapter = getVisualizerTuning(mode);
    const tuning = adapter ? (store[adapter.settingsKey] ?? adapter.defaults) : undefined;
    const setTuning = adapter ? (store[adapter.settingsSetterKey] as ((patch: unknown) => void) | undefined) : undefined;
    const reset = adapter && adapter.settingsResetterKey ? (store[adapter.settingsResetterKey] as (() => void) | undefined) : undefined;

    let panel: React.ReactNode = null;
    try {
        panel = entry.renderSettingsPanel
            ? entry.renderSettingsPanel({
                t: (key: string) => String(t(key)),
                isDaylight,
                theme,
                controlCardBg: isDaylight ? 'rgba(255,255,255,0.42)' : 'rgba(0,0,0,0.5)',
                rangeInputClass,
                tuning,
                onTuningChange: (patch: unknown) => setTuning?.(patch),
                settings: settings as never,
            })
            : null;
    } catch (error) {
        panel = <pre style={{ whiteSpace: 'pre-wrap', fontSize: 12 }}>{String(error)}</pre>;
    }

    const buttonStyle: React.CSSProperties = {
        border: 'none',
        borderRadius: 999,
        padding: '8px 16px',
        fontSize: 14,
        fontWeight: 600,
        background: 'var(--st-fill, rgba(255,255,255,0.12))',
        color: 'var(--st-t1, #fff)',
    };

    return (
        <div
            className="st-window"
            style={{
                position: 'fixed',
                inset: 0,
                zIndex: 50,
                display: 'flex',
                flexDirection: 'column',
                background: 'var(--st-win, #14161c)',
                color: 'var(--st-t1, #fff)',
                touchAction: 'pan-y',
                ...settingsTokens(isDaylight, theme),
                ...kitMotionTokens(true),
            }}
        >
            <SettingsKitThemeContext.Provider value={{ isDaylight, theme }}>
                <header style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '40px 16px 10px 20px' }}>
                    <div style={{ flex: 1, minWidth: 0 }}>
                        <div style={{ fontSize: 20, fontWeight: 700 }}>{String(t('options.lyricsStyleSettings'))}</div>
                        <div style={{ fontSize: 13, opacity: 0.6 }}>{entry.labelFallback}</div>
                    </div>
                    {reset && (
                        <button type="button" style={buttonStyle} onClick={() => reset()}>Default</button>
                    )}
                    <button type="button" style={{ ...buttonStyle, background: 'var(--st-accent, #e6b13a)', color: 'var(--st-on-accent, #14161c)' }} onClick={onClose}>Done</button>
                </header>
                <div style={{ flex: 1, minHeight: 0, overflowY: 'auto', padding: '4px 14px 60px', overscrollBehavior: 'contain' }}>
                    {panel ?? <div style={{ opacity: 0.6, padding: 16 }}>This style has no extra settings.</div>}
                </div>
            </SettingsKitThemeContext.Provider>
        </div>
    );
};

export default HalcyonSettings;
