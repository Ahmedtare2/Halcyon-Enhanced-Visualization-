import { Buffer } from 'buffer';
import React from 'react';
import ReactDOM from 'react-dom/client';
import '../i18n/config';
import '../index.css';
import HalcyonStage from './HalcyonStage';
import { installHalcyonHost } from './hostApi';

// src/halcyon/main.tsx
// Entry of the Halcyon host page: mounts Folia's own VisualizerRenderer (unchanged) and exposes
// window.HalcyonHost so the Android app can feed it lyrics, the clock, a theme and audio bands.

// @ts-ignore
globalThis.Buffer = Buffer;

installHalcyonHost();

const rootElement = document.getElementById('root');
if (!rootElement) throw new Error('Halcyon host: #root missing');
ReactDOM.createRoot(rootElement).render(<HalcyonStage />);
