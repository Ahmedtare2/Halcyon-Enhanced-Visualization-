// Mobile GPU/texture budgets ported from the v0.7.21 Android source overrides and extended
// for the three visualizer styles added in v0.7.25. Desktop/Electron render paths are unchanged.

export const MOBILE_MAX_CANVAS_DPR = 1.5;
export const MOBILE_MAX_PIXI_RESOLUTION = 1.25;
export const MOBILE_MAX_TEXTURE_AXIS_PX = 1536;

// Ambient backdrops sit behind blurred/diffused content. A low-resolution internal framebuffer
// is bilinearly enlarged by CSS, preserving the look while substantially reducing fragment work.
export const AMBIENT_BACKGROUND_DPR_SCALE = 0.3;
export const AMBIENT_BACKGROUND_MAX_DIMENSION_PX = 384;
export const AMBIENT_BACKGROUND_MAX_PIXELS = 384 * 256;

export const isMobileGpuConstrained = (options?: {
    viewportWidth?: number;
    viewportHeight?: number;
}): boolean => {
    if (typeof navigator === 'undefined') return false;
    const userAgent = navigator.userAgent || '';
    const mobileUserAgent = /Android|iPhone|iPad|iPod|Mobile/i.test(userAgent);
    if (mobileUserAgent) return true;
    // Electron desktop shells should not inherit the phone budget merely because their window
    // happens to be narrow. Touch-first browser/tablet windows are covered below.
    if (/\bElectron\b/i.test(userAgent)) return false;
    if (typeof window === 'undefined') return false;
    const width = options?.viewportWidth ?? window.innerWidth;
    const height = options?.viewportHeight ?? window.innerHeight;
    const coarsePointer = typeof window.matchMedia === 'function'
        && window.matchMedia('(pointer: coarse)').matches;
    const touchPoints = Number((navigator as Navigator & { maxTouchPoints?: number }).maxTouchPoints || 0);
    return (coarsePointer || touchPoints > 1) && Math.max(width || 0, height || 0) <= 1800;
};

/** Full-canvas DPR cap used by Canvas2D and WebGL styles such as Pendolo. */
export const resolveMobileCanvasDpr = (
    rawDpr?: number,
    isMobile: boolean = isMobileGpuConstrained(),
    maxMobileDpr: number = MOBILE_MAX_CANVAS_DPR,
): number => {
    const safeRaw = typeof rawDpr === 'number' && Number.isFinite(rawDpr) && rawDpr > 0
        ? rawDpr
        : (typeof window !== 'undefined' && Number.isFinite(window.devicePixelRatio) && window.devicePixelRatio > 0
            ? window.devicePixelRatio
            : 1);
    // Keep desktop's requested DPR exactly as the v0.7.25 renderer supplied it.
    return isMobile ? Math.min(maxMobileDpr, Math.max(1, safeRaw)) : safeRaw;
};

/**
 * Caps full-screen style render targets to 1.5x CSS pixels and a 1536px longest axis on phones.
 * The requested quality remains stored unchanged; only the physical render target is bounded.
 */
export const resolveMobileCanvasResolution = (
    requestedResolution: number,
    cssWidth = typeof window !== 'undefined' ? window.innerWidth : 0,
    cssHeight = typeof window !== 'undefined' ? window.innerHeight : 0,
    isMobile: boolean = isMobileGpuConstrained({ viewportWidth: cssWidth, viewportHeight: cssHeight }),
): number => {
    const safeRequested = Number.isFinite(requestedResolution) && requestedResolution > 0
        ? requestedResolution
        : 1;
    if (!isMobile) return safeRequested;
    const maxDimension = Math.max(cssWidth || 0, cssHeight || 0);
    const axisCap = maxDimension > 0 ? MOBILE_MAX_TEXTURE_AXIS_PX / maxDimension : MOBILE_MAX_CANVAS_DPR;
    return Math.max(0.5, Math.min(safeRequested, MOBILE_MAX_CANVAS_DPR, axisCap));
};

/** Caps Pixi render/filter resolution before its power-of-two texture-pool buckets grow. */
export const resolveMobilePixiResolution = (
    cssWidth: number,
    cssHeight: number,
    requestedResolution: number,
    isMobile: boolean = isMobileGpuConstrained({ viewportWidth: cssWidth, viewportHeight: cssHeight }),
): number => {
    const safeRequested = Number.isFinite(requestedResolution) && requestedResolution > 0
        ? requestedResolution
        : 1;
    if (!isMobile) return safeRequested;
    const maxDimension = Math.max(cssWidth || 0, cssHeight || 0);
    if (maxDimension <= 0 || !Number.isFinite(maxDimension)) {
        return Math.min(safeRequested, MOBILE_MAX_PIXI_RESOLUTION);
    }
    const axisCap = MOBILE_MAX_TEXTURE_AXIS_PX / maxDimension;
    return Math.max(0.75, Math.min(safeRequested, MOBILE_MAX_PIXI_RESOLUTION, axisCap));
};

/** Keeps glyph atlases and other single textures below conservative mobile GPU texture sizes. */
export const resolveMobileTextureLimit = (
    requestedLimit: number,
    isMobile: boolean = isMobileGpuConstrained(),
): number => {
    const safeLimit = Number.isFinite(requestedLimit) && requestedLimit > 0 ? requestedLimit : 1024;
    return isMobile ? Math.min(safeLimit, MOBILE_MAX_TEXTURE_AXIS_PX) : safeLimit;
};

/** Same low-resolution sizing used by the older Android backdrop renderers. */
export const resolveAmbientBackgroundCanvasSize = (
    cssWidth: number,
    cssHeight: number,
    maxDimensionPx: number = AMBIENT_BACKGROUND_MAX_DIMENSION_PX,
    dprScale: number = AMBIENT_BACKGROUND_DPR_SCALE,
): { width: number; height: number; scaleMultiplier: number } => {
    const safeWidth = Math.max(1, Math.round(cssWidth || 320));
    const safeHeight = Math.max(1, Math.round(cssHeight || 240));
    const maxCssSide = Math.max(safeWidth, safeHeight);
    const axisLimitScale = maxDimensionPx / maxCssSide;
    const scaleMultiplier = Math.max(0.1, Math.min(dprScale, axisLimitScale));
    return {
        width: Math.max(1, Math.round(safeWidth * scaleMultiplier)),
        height: Math.max(1, Math.round(safeHeight * scaleMultiplier)),
        scaleMultiplier,
    };
};

/** Mobile Hanabi uses the existing balanced glow/ambient profile unless the user chose low. */
export const resolveMobileHanabiQuality = <T extends 'full' | 'balanced' | 'low'>(
    requestedQuality: T,
    isMobile: boolean = isMobileGpuConstrained(),
): T | 'balanced' => (
    isMobile && requestedQuality === 'full' ? 'balanced' : requestedQuality
);
