#!/usr/bin/env python3
"""Patches the few existing Halcyon files that must know about the lyric visualizer.

Usage: apply.py <halcyon project root>
Every edit is anchored on exact existing text. If an anchor is missing the script stops with a
clear message instead of silently producing a half-patched app. Re-running is safe.
"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
base = root / "app/src/main/java/com/ella/music"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def fail(msg: str) -> None:
    print("PATCH ERROR: " + msg)
    sys.exit(1)


# --------------------------------------------------------------------------- lyric sidecars
utils = base / "data/repository/MusicRepositoryUtils.kt"
src = read(utils)
if "KrcDecoder" not in src:
    old_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc")\n    val baseName'
    new_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc", "yrc", "qrc", "krc")\n    val baseName'
    if src.count(old_ext) != 1:
        fail("sidecar extension list not found in MusicRepositoryUtils.kt")
    src = src.replace(old_ext, new_ext)
    old_read = "        if (!file.exists()) return null\n        file.readText()"
    if src.count(old_read) != 1:
        fail("readTextIfExists body not found in MusicRepositoryUtils.kt")
    src = src.replace(old_read, "        if (!file.exists()) return null\n        com.ella.music.data.parser.KrcDecoder.readLyricText(file)")
    write(utils, src)
    print("patched MusicRepositoryUtils.kt (yrc/qrc/krc sidecars, encrypted krc)")
else:
    print("MusicRepositoryUtils.kt already patched")

# --------------------------------------------------------------------------- player overlay
player = base / "ui/player/PlayerScreen.kt"
src = read(player)
if "VisOverlayHost" not in src:
    anchor = re.compile(
        r"(                    \.align\(androidx\.compose\.ui\.Alignment\.BottomCenter\)\s*\n\s*\n\s*\)\n)"
    )
    matches = list(anchor.finditer(src))
    if len(matches) != 1:
        fail("AudioVisualizer anchor not found exactly once in PlayerScreen.kt (found %d)" % len(matches))
    call = """            // Lyric visualizer page (opened from the button on the lyrics page).
            com.ella.music.ui.vis.VisOverlayHost(
                lyrics = lyrics,
                song = song,
                durationMs = duration,
                isPlaying = isPlaying,
                positionProvider = { playerViewModel.livePositionMs() },
                lyricOffsetMs = currentLyricOffsetMs,
                palette = palette,
                paletteBitmap = paletteBitmap,
                embeddedCover = embeddedCover,
                audioSessionId = audioSessionId,
                appFontPath = effectiveLyricFontPath,
                isLandscape = isLandscape,
                lyricsVisible = showLyrics && playerVisible,
                onSeek = { playerViewModel.seekTo(it) },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onPrevious = { playerViewModel.skipToPrevious() },
                onNext = { playerViewModel.skipToNext() },
                playerBackground = { bgModifier ->
                    SharedPlayerPageBackground(
                        song = song,
                        embeddedCover = embeddedCover,
                        paletteBitmap = paletteBitmap,
                        palette = palette,
                        currentPositionMs = currentPosition,
                        isPlaying = isPlaying,
                        playerBackgroundEnabled = playerBackgroundEnabled,
                        playerBackgroundUri = playerBackgroundUri,
                        playerBackgroundOpacity = playerBackgroundOpacity,
                        playerBackgroundDim = playerBackgroundDim,
                        beautifulLyricsBackground = beautifulLyricsBackground,
                        dynamicFlowEnabled = playerDynamicFlowEnabled,
                        useBlurBackground = false,
                        modifier = bgModifier
                    )
                }
            )
"""
    m = matches[0]
    src = src[: m.end()] + call + src[m.end():]
    write(player, src)
    print("patched PlayerScreen.kt (visualizer overlay mounted)")
else:
    print("PlayerScreen.kt already patched")


# --------------------------------------------------------------------------- R8 rules
rules = root / "app/proguard-rules.pro"
if rules.exists():
    text = read(rules)
    marker = "com.ella.music.ui.vis.FoliaBridge"
    if marker not in text:
        text += """

# Lyric visualizer: the Folia WebView page calls these by name.
-keep class com.ella.music.ui.vis.FoliaBridge { *; }
-keepclassmembers class com.ella.music.ui.vis.FoliaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
"""
        write(rules, text)
        print("patched proguard-rules.pro (FoliaBridge)")
    else:
        print("proguard-rules.pro already patched")
else:
    print("note: app/proguard-rules.pro not found, relying on @Keep")
