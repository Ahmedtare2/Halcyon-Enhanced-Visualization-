#!/usr/bin/env python3
"""Patches the few existing Halcyon files that must know about the lyric visualizer.

Usage: apply.py <halcyon project root>
Every edit is anchored on exact existing text. If an anchor is missing the script stops with a
clear message instead of silently producing a half-patched app. Re-running is safe.
"""
import re
import sys
from pathlib import Path

root = Path(sys.argv[1]).resolve()
base = root / "app/src/main/java/com/ella/music"


def read(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def write(path: Path, text: str) -> None:
    path.write_text(text, encoding="utf-8", newline="\n")


def fail(msg: str) -> None:
    print("PATCH ERROR: " + msg)
    sys.exit(1)


# --------------------------------------------------------------------------- lyric sidecars
utils = base / "data/repository/MusicRepositoryUtils.kt"
src = read(utils)
if "KrcDecoder" not in src:
    old_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc")\n    val baseName'
    new_ext = 'val extensions = if (preferTtml) listOf("ttml") else listOf("lrc", "elrc", "yrc", "qrc", "krc")\n    val baseName'
    if src.count(old_ext) != 1:
        fail("sidecar extension list not found in MusicRepositoryUtils.kt")
    src = src.replace(old_ext, new_ext)
    old_read = "        if (!file.exists()) return null\n        file.readText()"
    if src.count(old_read) != 1:
        fail("readTextIfExists body not found in MusicRepositoryUtils.kt")
    src = src.replace(old_read, "        if (!file.exists()) return null\n        com.ella.music.data.parser.KrcDecoder.readLyricText(file)")
    write(utils, src)
    print("patched MusicRepositoryUtils.kt (yrc/qrc/krc sidecars, encrypted krc)")
else:
    print("MusicRepositoryUtils.kt already patched")

# --------------------------------------------------------------------------- player overlay
player = base / "ui/player/PlayerScreen.kt"
src = read(player)
if "VisOverlayHost" not in src:
    anchor = re.compile(
        r"(                    \.align\(androidx\.compose\.ui\.Alignment\.BottomCenter\)\s*\n\s*\n\s*\)\n)"
    )
    matches = list(anchor.finditer(src))
    if len(matches) != 1:
        fail("AudioVisualizer anchor not found exactly once in PlayerScreen.kt (found %d)" % len(matches))
    call = """            // Lyric visualizer page (opened from the button on the lyrics page).
            com.ella.music.ui.vis.VisOverlayHost(
                lyrics = lyrics,
                song = song,
                durationMs = duration,
                isPlaying = isPlaying,
                positionProvider = { playerViewModel.livePositionMs() },
                lyricOffsetMs = currentLyricOffsetMs,
                palette = palette,
                paletteBitmap = paletteBitmap,
                embeddedCover = embeddedCover,
                audioSessionId = audioSessionId,
                appFontPath = effectiveLyricFontPath,
                isLandscape = isLandscape,
                lyricsVisible = showLyrics && playerVisible,
                onSeek = { playerViewModel.seekTo(it) },
                onPlayPause = { playerViewModel.togglePlayPause() },
                onPrevious = { playerViewModel.skipToPrevious() },
                onNext = { playerViewModel.skipToNext() },
                playerBackground = { bgModifier ->
                    SharedPlayerPageBackground(
                        song = song,
                        embeddedCover = embeddedCover,
                        paletteBitmap = paletteBitmap,
                        palette = palette,
                        currentPositionMs = currentPosition,
                        isPlaying = isPlaying,
                        playerBackgroundEnabled = playerBackgroundEnabled,
                        playerBackgroundUri = playerBackgroundUri,
                        playerBackgroundOpacity = playerBackgroundOpacity,
                        playerBackgroundDim = playerBackgroundDim,
                        beautifulLyricsBackground = beautifulLyricsBackground,
                        dynamicFlowEnabled = playerDynamicFlowEnabled,
                        useBlurBackground = false,
                        modifier = bgModifier
                    )
                }
            )
"""
    m = matches[0]
    src = src[: m.end()] + call + src[m.end():]
    write(player, src)
    print("patched PlayerScreen.kt (visualizer overlay mounted)")
else:
    print("PlayerScreen.kt already patched")


# --------------------------------------------------------------------------- R8 rules
rules = root / "app/proguard-rules.pro"
if rules.exists():
    text = read(rules)
    marker = "com.ella.music.ui.vis.FoliaBridge"
    if marker not in text:
        text += """

# Lyric visualizer: the Folia WebView page calls these by name.
-keep class com.ella.music.ui.vis.FoliaBridge { *; }
-keepclassmembers class com.ella.music.ui.vis.FoliaBridge {
    @android.webkit.JavascriptInterface <methods>;
}
"""
        write(rules, text)
        print("patched proguard-rules.pro (FoliaBridge)")
    else:
        print("proguard-rules.pro already patched")
else:
    print("note: app/proguard-rules.pro not found, relying on @Keep")


# --------------------------------------------------------------------------- lyrics page button
corner = base / "ui/player/LyricsCornerActions.kt"
src = read(corner)
if "VisController" not in src:
    anchor = """            AppleTranslationIcon(
                color = contentColor,
                active = showTranslation,
                modifier = Modifier.size(36.dp)
            )
        }
"""
    if src.count(anchor) != 1:
        fail("translation icon anchor not found exactly once in LyricsCornerActions.kt")
    button = """        Box(
            modifier = Modifier
                .size(44.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = { com.ella.music.ui.vis.VisController.show() }
                ),
            contentAlignment = Alignment.Center
        ) {
            com.ella.music.ui.vis.VisIcon(
                com.ella.music.ui.vis.VisIconKind.VIS,
                contentColor,
                26.dp
            )
        }
"""
    src = src.replace(anchor, anchor + button)
    write(corner, src)
    print("patched LyricsCornerActions.kt (visualizer button between translation and vocal buttons)")
else:
    print("LyricsCornerActions.kt already patched")


# --------------------------------------------------------------------------- visualizer playback-state compile guard
# The frame loop uses rememberUpdatedState because its LaunchedEffect(Unit) must not capture
# the initial play/pause value. Repair older merged ZIP revisions that shipped the stale name.
vis_page = base / "ui/vis/VisPage.kt"
if not vis_page.is_file():
    fail("VisPage.kt is missing from the visualizer patch")
vis_src = read(vis_page)
stale_playing_refs = vis_src.count("playingNow")
if stale_playing_refs:
    if "val latestPlaying by rememberUpdatedState(isPlaying)" not in vis_src:
        fail("VisPage.kt has stale playingNow references but no latestPlaying state")
    if stale_playing_refs != 4:
        fail("VisPage.kt expected exactly four stale playingNow references; found %d" % stale_playing_refs)
    vis_src = vis_src.replace("playingNow", "latestPlaying")
    write(vis_page, vis_src)
    print("fixed VisPage.kt (use latestPlaying in the long-lived frame loop)")
else:
    if "latestPlaying" not in vis_src:
        fail("VisPage.kt does not expose a live playback-state value")
    print("VisPage.kt playback-state references verified")

# --------------------------------------------------------------------------- Folia source (optional)
# The Folia sources sit next to the Halcyon project (../folia) when the workflow imported them.
folia = root.parent / "folia"
drum = folia / "src/services/analysis/drumHits.ts"
if drum.exists():
    text = read(drum)
    if "setExternalDrumHits" not in text:
        if "const settled = new Set<string>();" not in text or "const keep = (key: string, hits: DrumHits)" not in text:
            fail("drumHits.ts has changed: cannot add setExternalDrumHits")
        text = text.rstrip("\n") + """

/** Tracks whose drum source is supplied by Halcyon's decoded PCM tap, not htdemucs. */
const externalDrumKeys = new Set<string>();

/** Halcyon (the Android host) analyses the drums natively and hands the hits in here. */
export const setExternalDrumHits = (key: string, hits: DrumHits): void => {
    if (!externalDrumKeys.has(key) && stemTrackWanted(key)) setWantedStemTrack(null);
    externalDrumKeys.add(key);
    while (externalDrumKeys.size > MAX_SETTLED) {
        const oldest = externalDrumKeys.values().next().value;
        if (oldest === undefined) break;
        externalDrumKeys.delete(oldest);
    }
    keep(key, hits);
    settled.delete(key);
    settled.add(key);
    while (settled.size > MAX_SETTLED) {
        const oldest = settled.values().next().value;
        if (oldest === undefined) break;
        settled.delete(oldest);
    }
    dropStemDrums(key);
};
"""
        print("patched Folia drumHits.ts (native PCM drum source)")
    else:
        print("Folia drumHits.ts external drum source already patched")
    if "if (externalDrumKeys.has(key)) return Promise.resolve(null);" not in text:
        anchor = """export const loadTrackDrumHits = (key: string, readBytes: () => Promise<ArrayBuffer | null>): Promise<DrumAnalysis | null> => {
    const existing = runs.get(key);
"""
        replacement = """export const loadTrackDrumHits = (key: string, readBytes: () => Promise<ArrayBuffer | null>): Promise<DrumAnalysis | null> => {
    // A decoded-PCM source has already claimed this track; do not start/rejoin the GPU stem pass.
    if (externalDrumKeys.has(key)) return Promise.resolve(null);
    const existing = runs.get(key);
"""
        if text.count(anchor) != 1:
            fail("drumHits.ts loadTrackDrumHits anchor not found exactly once")
        text = text.replace(anchor, replacement)
        print("patched Folia drumHits.ts (skip redundant htdemucs for PCM-fed tracks)")
    write(drum, text)

else:
    print("note: Folia sources not found next to the project; skipping the Folia patch")

# Live PCM drums replace only the not-yet-fired portion of Folia's beat clock. This keeps the
# cursor, last heard time, fired prefix and decay envelopes stable while new sink-timestamped hits
# arrive in small batches from Halcyon.
beat_fx_live = folia / "src/services/beatFx/beatFxLive.ts"
if beat_fx_live.exists():
    text = read(beat_fx_live)
    if "export const replaceFutureBeatFxEvents" not in text:
        anchor = """/**
 * Whether the playing track's beat list is installed - or a track change is still inside its hold.
 * Until then (analysing, not cached, no model, a GPU that could not take it) a visualizer draws its
 * original frame rather than a beat FX frame with nothing driving it.
 */
"""
        addition = """/**
 * Replaces only the events that have not fired yet. Used by the Android PCM stream, which sends
 * real drum transients ahead of the audible playhead as the output sink accepts queued samples.
 * Unlike setBeatFxEvents this does not reset lastTime, envelopes, or the already-fired prefix.
 */
export const replaceFutureBeatFxEvents = (key: string, events: BeatFxEvent[]): void => {
    if (key !== trackKey) return;
    const fired = state.events.slice(0, state.cursor);
    const firedTimes = new Set(fired.map(event => event.t));
    const current = heardAt ?? state.lastTime;
    // A bounded late window covers the final WebView/bridge frame without replaying old hits.
    // The clock's normal lateMs decay attenuates these rather than restarting their envelope.
    const future = events
        .filter(event => !firedTimes.has(event.t) && (current === null || event.t > current - 0.12))
        .sort((a, b) => a.t - b.t);
    state.events = [...fired, ...future];
    state.cursor = fired.length;
    beatPeriod = resolveBeatFxBeatPeriod(events);
    if (debug) debug.eventCount = state.events.length;
};

"""
        if text.count(anchor) != 1:
            fail("beatFxLive.ts anchor not found exactly once: ready-state comment")
        text = text.replace(anchor, addition + anchor)
        write(beat_fx_live, text)
        print("patched Folia beatFxLive.ts (append live PCM events without clock reset)")
    else:
        print("Folia beatFxLive.ts already patched")
else:
    print("note: Folia beatFxLive.ts missing; skipping live beat-clock patch")


# Machi: right-to-left board. Lines in an RTL script are laid out from the right edge, and the lit
# sweep (a shader comparison against the pixel column) runs from the right as well.
machi_layout = folia / "src/components/visualizer/machi/engine/boardLayout.ts"
machi_screen = folia / "src/components/visualizer/machi/engine/lyricScreen.ts"
if machi_layout.exists() and machi_screen.exists():
    def replace_once(text: str, old: str, new: str, label: str) -> str:
        if text.count(old) != 1:
            fail("Machi patch anchor not found exactly once: " + label)
        return text.replace(old, new)

    layout_src = read(machi_layout)
    if "layout.rtl" not in layout_src:
        layout_src = replace_once(
            layout_src,
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\n",
            "import { buildLineGraphemeTimeline } from '../../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
            "import")
        layout_src = replace_once(
            layout_src,
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n}",
            "export interface MachiBoardLayout {\n    fontPx: number;\n    rows: MachiBoardRow[];\n    width: number;\n    height: number;\n    /** Laid out from the right edge and revealed from the right (Arabic, Hebrew). */\n    rtl?: boolean;\n}",
            "interface")
        layout_src = replace_once(
            layout_src,
            "    return placeRows(best.rows, best.fontPx, box, measure);",
            "    const rtl = resolveLyricTextDirection(line.fullText) === 'rtl';\n    return { ...placeRows(best.rows, best.fontPx, box, measure, rtl), rtl };",
            "placeRows call")
        layout_src = replace_once(
            layout_src,
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure): MachiBoardLayout => {",
            "const placeRows = (rows: Token[][], fontPx: number, box: MachiBoardBox, measure: MachiMeasure, rtl = false): MachiBoardLayout => {",
            "placeRows signature")
        layout_src = replace_once(
            layout_src,
            """            const placed = glyphs.map(glyph => {
                const x0 = left + measure(prefix) * scale;
                prefix += glyph.text;
                const x1 = left + measure(prefix) * scale;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            """            const right = left + width;
            const placed = glyphs.map(glyph => {
                const before = measure(prefix) * scale;
                prefix += glyph.text;
                const after = measure(prefix) * scale;
                const x0 = rtl ? right - after : left + before;
                const x1 = rtl ? right - before : left + after;
                return { ...glyph, length: glyph.text.length, x0, x1 };
            });""",
            "glyph placement")
        layout_src = replace_once(
            layout_src,
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            """export const resolveMachiBoardReveal = (layout: MachiBoardLayout, time: number): number[] => layout.rows.map(row => {
    if (layout.rtl) {
        // Mirrored coordinates: the distance of the lit edge from the right edge of the board.
        let mirrored = layout.width - (row.glyphs[0]?.x1 ?? 0);
        for (const glyph of row.glyphs) {
            if (time >= glyph.endTime) {
                mirrored = layout.width - glyph.x0;
                continue;
            }
            if (time > glyph.startTime) {
                const span = Math.max(1e-3, glyph.endTime - glyph.startTime);
                mirrored = layout.width - glyph.x1 + (glyph.x1 - glyph.x0) * Math.min(1, (time - glyph.startTime) / span);
            }
            break;
        }
        return mirrored;
    }
    let lit = row.glyphs[0]?.x0 ?? 0;""",
            "reveal")
        write(machi_layout, layout_src)

    screen_src = read(machi_screen)
    if "uRtl" not in screen_src:
        screen_src = replace_once(screen_src, "uniform float uSoft;\n", "uniform float uSoft;\nuniform float uRtl;\n", "uniform declaration")
        screen_src = replace_once(
            screen_src,
            "    float snapped = (floor(vUv.x * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(vUv.x, snapped, grid));",
            "    float ux = mix(vUv.x, 1.0 - vUv.x, uRtl);\n    float snapped = (floor(ux * uCells.x) + 0.5) / uCells.x;\n    float on = 1.0 - smoothstep(reveal - uSoft, reveal + uSoft, mix(ux, snapped, grid));",
            "shader reveal")
        screen_src = replace_once(screen_src, "                uSoft: { value: 0.004 },\n", "                uSoft: { value: 0.004 },\n                uRtl: { value: 0 },\n", "uniform value")
        screen_src = replace_once(
            screen_src,
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n",
            "            (reveal[2] ?? 0) / this.box.width,\n        );\n        this.material.uniforms.uRtl!.value = layout && layout.rtl ? 1 : 0;\n",
            "uniform update")
        write(machi_screen, screen_src)
    print("patched Folia Machi (right-to-left board)")

# --------------------------------------------------------------------------- Native Latent mesh hand-off
# Only Latent's full-screen mesh is moved to Halcyon's low-resolution GLES surface. The Dithering
# shader, all lyric visualizers, and every other background remain in Folia's WebView.
def patch_text(text: str, path: Path, old: str, new: str, label: str) -> str:
    if new in text:
        return text
    if text.count(old) != 1:
        fail("native backdrop anchor not found exactly once in %s: %s" % (path.relative_to(folia), label))
    return text.replace(old, new)

if folia.exists():
    bg_definition = folia / "src/components/visualizer/backgrounds/definition.ts"
    if bg_definition.exists():
        text = read(bg_definition)
        text = patch_text(
            text, bg_definition,
            "    transparent?: boolean;\n",
            "    transparent?: boolean;\n    /** Halcyon-only: the Latent mesh is drawn by its native low-resolution surface. */\n    halcyonNativeMesh?: boolean;\n",
            "background config native flag")
        write(bg_definition, text)

    latent = folia / "src/components/visualizer/backgrounds/latent/LatentBackground.tsx"
    if latent.exists():
        text = read(latent)
        if "reportNativeBackdropPalette" not in text:
            text = patch_text(
                text, latent,
                "import { BEAT_EFFECT_IDS } from '../../../../services/beatFx/beatEffects';\n",
                "import { BEAT_EFFECT_IDS } from '../../../../services/beatFx/beatEffects';\nimport { reportNativeBackdropPalette, reportNativeBackdropTuning } from '../../../../halcyon/nativeBackdropBridge';\n",
                "native bridge imports")
        text = patch_text(
            text, latent,
            "    blendProgress?: MotionValue<number>;\n}",
            "    blendProgress?: MotionValue<number>;\n    /** Replaces only the animated mesh layer with Halcyon's native surface. */\n    nativeMeshEnabled?: boolean;\n}",
            "native mesh prop")
        text = patch_text(
            text, latent,
            "    blendProgress,\n}) => {",
            "    blendProgress,\n    nativeMeshEnabled = false,\n}) => {",
            "native mesh prop destructuring")
        text = patch_text(
            text, latent,
            "    const showDithering = tuning.displayMode !== 'mesh';\n    const showMesh = tuning.displayMode !== 'dithering';",
            "    const showDithering = tuning.displayMode !== 'mesh';\n    const meshIsContributing = tuning.displayMode !== 'dithering';\n    const showMesh = meshIsContributing && !nativeMeshEnabled;",
            "native mesh render selection")
        text = patch_text(
            text, latent,
            "    const shaderColors = useMemo(\n        () => ({ ditheringBack, ditheringFront, mesh: blendedColors.slice(3) }),\n        [blendedColors, ditheringBack, ditheringFront],\n    );\n",
            "    const shaderColors = useMemo(\n        () => ({ ditheringBack, ditheringFront, mesh: blendedColors.slice(3) }),\n        [blendedColors, ditheringBack, ditheringFront],\n    );\n\n    useEffect(() => {\n        if (!nativeMeshEnabled) return;\n        reportNativeBackdropPalette(shaderColors.mesh);\n        reportNativeBackdropTuning({\n            meshSpeed: tuning.meshSpeed,\n            meshAudioSpeed: tuning.meshAudioSpeed,\n            meshDistortion: tuning.meshDistortion,\n            meshSwirl: tuning.meshSwirl,\n            enhancedBeatResponse: tuning.enhancedBeatResponse,\n        });\n    }, [nativeMeshEnabled, shaderColors.mesh, tuning.meshSpeed, tuning.meshAudioSpeed, tuning.meshDistortion, tuning.meshSwirl, tuning.enhancedBeatResponse]);\n",
            "native palette and tuning bridge")
        text = patch_text(
            text, latent,
            "writeLayerStyle(ditheringLayerRef.current, 'opacity', showMesh\n",
            "writeLayerStyle(ditheringLayerRef.current, 'opacity', meshIsContributing\n",
            "preserve dithering blend opacity")
        text = patch_text(
            text, latent,
            "mixBlendMode: showMesh ? 'soft-light' : 'normal',\n                        opacity: showMesh ? tuning.ditheringOpacity : 1,",
            "mixBlendMode: meshIsContributing ? 'soft-light' : 'normal',\n                        opacity: meshIsContributing ? tuning.ditheringOpacity : 1,",
            "preserve dithering blend mode")
        text = patch_text(
            text, latent,
            "style={{ backgroundColor, pointerEvents: 'none' }}",
            "style={{ backgroundColor: nativeMeshEnabled ? 'transparent' : backgroundColor, pointerEvents: 'none' }}",
            "transparent native mesh backing")
        write(latent, text)

    latent_entry = folia / "src/components/visualizer/backgrounds/latent/entry.tsx"
    if latent_entry.exists():
        text = read(latent_entry)
        text = patch_text(
            text, latent_entry,
            "            tuning={config?.latent?.tuning}\n            blendMs={blendMs}\n            blendProgress={blendProgress}\n",
            "            tuning={config?.latent?.tuning}\n            nativeMeshEnabled={Boolean(config?.halcyonNativeMesh)}\n            blendMs={blendMs}\n            blendProgress={blendProgress}\n",
            "pass native mesh flag to Latent")
        write(latent_entry, text)
    print("patched Folia Latent background (native mesh, palette/tuning bridge; web fallback retained)")
else:
    print("note: Folia source tree unavailable; skipping native Latent background integration")

# --------------------------------------------------------------------------- Arabic RTL layout/reveal (Task C)
# Keep the lyric data in source/logical order. Direction is handled by each renderer's own layout,
# and only glyph-at-a-time renderers receive presentation forms from folia-host/src/halcyon/arabic.ts.
def rtl_replace(path: Path, old: str, new: str, label: str) -> None:
    text = read(path)
    if new in text:
        return
    if text.count(old) != 1:
        fail("Arabic RTL anchor not found exactly once in %s: %s" % (path.relative_to(folia), label))
    write(path, text.replace(old, new))

if folia.exists():
    # Fume: Canvas 2D uses the same native shaping as the browser; mirror segment boxes and clip
    # the active word from the right edge for Arabic, while embedded Latin runs remain LTR.
    p = folia / "src/components/visualizer/fume/fumeTypes.ts"
    rtl_replace(p, "    width: number;\n}\n\nexport interface RenderSegmentSlice {", "    width: number;\n    rtl: boolean;\n}\n\nexport interface RenderSegmentSlice {", "Fume render-line direction")

    p = folia / "src/components/visualizer/fume/fumeArticleLayout.ts"
    rtl_replace(p, "import { getLineRenderEndTime } from '../../../utils/lyrics/renderHints';\n", "import { getLineRenderEndTime } from '../../../utils/lyrics/renderHints';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n", "Fume direction import")
    rtl_replace(p, "                    text: layoutLine.text,\n                    start,\n", "                    text: layoutLine.text,\n                    rtl: resolveLyricTextDirection(layoutLine.text) === 'rtl',\n                    start,\n", "Fume direction metadata")

    p = folia / "src/components/visualizer/fume/fumeCanvasText.ts"
    rtl_replace(p, "import { Theme } from '../../../types';\n", "import { Theme } from '../../../types';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n", "Fume canvas direction import")
    rtl_replace(p,
        "const roundShadowBlur = (px: number) => (Number.isFinite(px) ? Math.max(0, Math.round(px)) : 0);\n",
        "const roundShadowBlur = (px: number) => (Number.isFinite(px) ? Math.max(0, Math.round(px)) : 0);\n\nconst fumeSegmentDirection = (renderLine: RenderLineSlice, segment: RenderSegmentSlice) => {\n    const hasLetter = /\\p{L}/u.test(segment.text);\n    const rtl = hasLetter\n        ? resolveLyricTextDirection(segment.text) === 'rtl'\n        : renderLine.rtl;\n    const left = renderLine.rtl ? renderLine.width - segment.x - segment.width : segment.x;\n    return { left, right: left + segment.width, rtl, anchor: rtl ? left + segment.width : left };\n};\n",
        "Fume segment geometry helper")
    rtl_replace(p,
        "    context.save();\n    context.beginPath();\n    context.rect(\n        baseX + segment.x + clipLeft,\n        baseY - Math.max(clipWidth, 1) - 64,\n        clipWidth,\n        Math.max(128 + clipWidth * 2, 256),\n    );\n    context.clip();\n    context.fillText(segment.text, baseX + segment.x, baseY);\n    context.restore();",
        "    const geometry = fumeSegmentDirection(renderLine, segment);\n    const clipX = geometry.rtl ? geometry.right - clipRight : geometry.left + clipLeft;\n    context.save();\n    context.direction = geometry.rtl ? 'rtl' : 'ltr';\n    context.textAlign = geometry.rtl ? 'right' : 'left';\n    context.beginPath();\n    context.rect(\n        baseX + clipX,\n        baseY - Math.max(clipWidth, 1) - 64,\n        clipWidth,\n        Math.max(128 + clipWidth * 2, 256),\n    );\n    context.clip();\n    context.fillText(segment.text, baseX + geometry.anchor, baseY);\n    context.restore();",
        "Fume clipped RTL glyph run")
    rtl_replace(p,
        "    context.font = buildCanvasFont(block, theme);\n    context.textAlign = 'left';\n    context.textBaseline = 'middle';\n    context.fillStyle = fillStyle;\n",
        "    context.font = buildCanvasFont(block, theme);\n    context.textBaseline = 'middle';\n    context.fillStyle = fillStyle;\n",
        "Fume snapshot text alignment setup")
    rtl_replace(p,
        "    for (const renderLine of block.renderLines) {\n        context.fillText(\n            renderLine.text,\n            renderLine.left + padding,\n            renderLine.top + baselineOffset + padding,\n        );\n    }",
        "    for (const renderLine of block.renderLines) {\n        context.direction = renderLine.rtl ? 'rtl' : 'ltr';\n        context.textAlign = renderLine.rtl ? 'right' : 'left';\n        context.fillText(\n            renderLine.text,\n            renderLine.rtl ? renderLine.left + renderLine.width + padding : renderLine.left + padding,\n            renderLine.top + baselineOffset + padding,\n        );\n    }",
        "Fume static RTL line alignment")
    rtl_replace(p,
        "                fillGlowText(context, segment.text, glowBaseX + segment.x, glowBaseY);",
        "                const geometry = fumeSegmentDirection(renderLine, segment);\n                context.direction = geometry.rtl ? 'rtl' : 'ltr';\n                context.textAlign = geometry.rtl ? 'right' : 'left';\n                fillGlowText(context, segment.text, glowBaseX + geometry.anchor, glowBaseY);",
        "Fume live glow RTL alignment")

    # Hanabi: glyph sprites retain ascending source/time order; on horizontal rows each word is
    # moved to the mirrored block position, and only Arabic words reverse their inner x positions.
    p = folia / "src/components/visualizer/hanabi/text/layout.ts"
    rtl_replace(p,
        "    /** 字号倍率。 */\n    scale: number;\n}",
        "    /** 字号倍率。 */\n    scale: number;\n    /** The word's own bidi direction (mixed Latin runs remain LTR). */\n    rtl?: boolean;\n}",
        "Hanabi word direction metadata")
    rtl_replace(p,
        "    padding: number;\n}",
        "    padding: number;\n    /** Whole line is right-to-left; glyph timing indices remain logical. */\n    rtl?: boolean;\n}",
        "Hanabi line direction metadata")
    rtl_replace(p,
        "    const placed: PlacedGlyph[] = work.map((w, index) => ({",
        "    if (params.rtl && !vertical) {\n        const rtlRows = layout === 'scatter' ? [work.map((_, index) => index)] : rows.filter(Boolean);\n        for (const rowGlyphs of rtlRows) {\n            const visible = rowGlyphs.filter(index => !glyphInputs[index]!.blank);\n            if (visible.length < 2) continue;\n            const rowLeft = Math.min(...visible.map(index => work[index]!.x - work[index]!.advance / 2));\n            const rowRight = Math.max(...visible.map(index => work[index]!.x + work[index]!.advance / 2));\n            const groups = [...new Set(visible.map(index => glyphInputs[index]!.word))];\n            for (const wordIndex of groups) {\n                const indices = visible.filter(index => glyphInputs[index]!.word === wordIndex);\n                if (!indices.length) continue;\n                const left = Math.min(...indices.map(index => work[index]!.x - work[index]!.advance / 2));\n                const right = Math.max(...indices.map(index => work[index]!.x + work[index]!.advance / 2));\n                const center = (left + right) / 2;\n                const target = rowLeft + rowRight - center;\n                const arabicWord = Boolean(words[wordIndex]?.rtl);\n                for (const index of indices) {\n                    const oldX = work[index]!.x;\n                    work[index]!.x = arabicWord ? target - (oldX - center) : oldX + (target - center);\n                }\n            }\n        }\n    }\n\n    const placed: PlacedGlyph[] = work.map((w, index) => ({",
        "Hanabi RTL word/row mirroring")

    p = folia / "src/components/visualizer/hanabi/text/lyricText.ts"
    rtl_replace(p,
        "import { segmentLyricWords } from '../../../../utils/lyrics/wordSegmentation';\n",
        "import { segmentLyricWords } from '../../../../utils/lyrics/wordSegmentation';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
        "Hanabi direction import")
    rtl_replace(p,
        "words.push({ text: segment.segment, start: cursor, end: cursor + length, blank: space || !segment.isWordLike, space, scale: 1 });",
        "words.push({ text: segment.segment, start: cursor, end: cursor + length, blank: space || !segment.isWordLike, space, scale: 1, rtl: resolveLyricTextDirection(segment.segment) === 'rtl' });",
        "Hanabi word direction assignment")
    rtl_replace(p,
        "return { text: char, start: index, end: index + 1, blank: space || !/[\\p{L}\\p{N}]/u.test(char), space, scale: 1 };",
        "return { text: char, start: index, end: index + 1, blank: space || !/[\\p{L}\\p{N}]/u.test(char), space, scale: 1, rtl: resolveLyricTextDirection(char) === 'rtl' };",
        "Hanabi fallback grapheme direction")
    rtl_replace(p,
        "        ...layoutParams,\n    });",
        "        ...layoutParams,\n        rtl: resolveLyricTextDirection(line.fullText) === 'rtl',\n    });",
        "Hanabi RTL layout option")

    # Lumiere: same word-block mirroring on each horizontal wrapped row; vertical columns already
    # advance from the right edge and retain their original typographic treatment.
    p = folia / "src/components/visualizer/lumiere/text/lineWrap.ts"
    rtl_replace(p,
        "import { glyphFont } from './glyphLine';\n",
        "import { glyphFont } from './glyphLine';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
        "Lumiere direction import")
    rtl_replace(p,
        "    options: { heroPx: number; limits: { horizontal: number; vertical: number } },",
        "    options: { heroPx: number; limits: { horizontal: number; vertical: number }; rtl?: boolean },",
        "Lumiere RTL option type")
    rtl_replace(p,
        "            points.push(point);\n        });\n        return { points, spots, along, across: (count - 1) * pitch + heroPx, lines: count, inkWidth: inkX * 2, inkHeight: inkY * 2 };",
        "            points.push(point);\n        });\n        if (orient === 0 && options.rtl) {\n            for (let rowIndex = 0; rowIndex < count; rowIndex += 1) {\n                const rowGlyphs = glyphs.map((_, index) => index).filter(index => row[index] === rowIndex && glyphs[index]!.char.trim().length > 0);\n                if (rowGlyphs.length < 2) continue;\n                const rowLeft = Math.min(...rowGlyphs.map(index => points[index]!.x - advances[index]! / 2));\n                const rowRight = Math.max(...rowGlyphs.map(index => points[index]!.x + advances[index]! / 2));\n                for (const word of words) {\n                    const indices = rowGlyphs.filter(index => index >= word.start && index < word.end);\n                    if (!indices.length) continue;\n                    const left = Math.min(...indices.map(index => points[index]!.x - advances[index]! / 2));\n                    const right = Math.max(...indices.map(index => points[index]!.x + advances[index]! / 2));\n                    const center = (left + right) / 2;\n                    const target = rowLeft + rowRight - center;\n                    const arabicWord = resolveLyricTextDirection(word.text) === 'rtl';\n                    for (const index of indices) {\n                        const oldX = points[index]!.x;\n                        const nextX = arabicWord ? target - (oldX - center) : oldX + (target - center);\n                        points[index]!.x = nextX;\n                        spots[index]!.x += nextX - oldX;\n                    }\n                }\n            }\n        }\n        return { points, spots, along, across: (count - 1) * pitch + heroPx, lines: count, inkWidth: inkX * 2, inkHeight: inkY * 2 };",
        "Lumiere horizontal RTL word flow")

    p = folia / "src/components/visualizer/lumiere/text/windowLines.ts"
    rtl_replace(p,
        "import { splitLyricGraphemes } from '../../../../utils/lyrics/graphemeTiming';\n",
        "import { splitLyricGraphemes } from '../../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
        "Lumiere window direction import")
    rtl_replace(p,
        "        { heroPx, limits: context.limits },\n",
        "        { heroPx, limits: context.limits, rtl: resolveLyricTextDirection(line.fullText) === 'rtl' },\n",
        "Lumiere pass RTL layout flag")

    # Nebbia: each word block moves to the mirrored slot; Arabic word glyphs are mirrored inside
    # their own box, while Latin / number runs keep natural left-to-right internal order.
    p = folia / "src/components/visualizer/nebbia/nebbiaChars.ts"
    rtl_replace(p,
        "import { getLineRenderEndTime } from '../../../utils/lyrics/renderHints';\n",
        "import { getLineRenderEndTime } from '../../../utils/lyrics/renderHints';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Nebbia direction import")
    rtl_replace(p,
        "    chars: NebbiaChar[];\n    /** 一个词一组字的下标，按顺序；空格不在任何一组里。 */",
        "    chars: NebbiaChar[];\n    /** Source line's first-strong writing direction. */\n    rtl: boolean;\n    /** 一个词一组字的下标，按顺序；空格不在任何一组里。 */",
        "Nebbia source direction field")
    rtl_replace(p,
        "        return { chars, words, t: line.startTime, end, next };",
        "        return { chars, words, rtl: resolveLyricTextDirection(line.fullText) === 'rtl', t: line.startTime, end, next };",
        "Nebbia source direction assignment")
    p = folia / "src/components/visualizer/nebbia/nebbiaLayout.ts"
    rtl_replace(p,
        "        return chars.map((_, k) => {\n            const it = byK.get(k);\n            if (!it) return { ...lastPos, rot: 0 };\n            const x = cx + (it.x - (bb.x0 + bb.x1) / 2) * S, y0 = cy + (it.y - (bb.y0 + bb.y1) / 2) * S;\n            const s = it.s * S * (1 + (rnd() - 0.5) * 0.08 * jitter);\n            lastPos = {\n                x: x + (rnd() - 0.5) * S * 0.04 * jitter,\n                y: y0 + (x - cx) * tilt + (rnd() - 0.5) * S * 0.05 * jitter,\n                s,\n                rot: it.rot + (rnd() - 0.5) * 0.08 * jitter + tilt,\n            };\n            return lastPos;\n        });",
        "        const positions = chars.map((_, k) => {\n            const it = byK.get(k);\n            if (!it) return { ...lastPos, rot: 0 };\n            const x = cx + (it.x - (bb.x0 + bb.x1) / 2) * S, y0 = cy + (it.y - (bb.y0 + bb.y1) / 2) * S;\n            const s = it.s * S * (1 + (rnd() - 0.5) * 0.08 * jitter);\n            lastPos = {\n                x: x + (rnd() - 0.5) * S * 0.04 * jitter,\n                y: y0 + (x - cx) * tilt + (rnd() - 0.5) * S * 0.05 * jitter,\n                s,\n                rot: it.rot + (rnd() - 0.5) * 0.08 * jitter + tilt,\n            };\n            return lastPos;\n        });\n        if (!line.rtl) return positions;\n        const output = positions.map(position => ({ ...position }));\n        for (const indices of line.words) {\n            const visible = indices.filter(index => Boolean(chars[index]?.ch.trim()) && !isIconChar(chars[index]!.ch));\n            if (!visible.length) continue;\n            const center = visible.reduce((sum, index) => sum + positions[index]!.x, 0) / visible.length;\n            const target = 2 * cx - center;\n            const wordText = visible.map(index => chars[index]!.ch).join('');\n            const arabicWord = resolveLyricTextDirection(wordText) === 'rtl';\n            for (const index of visible) {\n                const dx = positions[index]!.x - center;\n                output[index]!.x = target + (arabicWord ? -dx : dx);\n            }\n        }\n        return output;",
        "Nebbia final RTL block placement")
    rtl_replace(p,
        "import { clamp } from './nebbiaConstants';\n",
        "import { clamp } from './nebbiaConstants';\nimport { isIconChar } from './nebbiaChars';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Nebbia layout script imports (icon helper + text direction)")

    # Sonnet: reverse placement of word blocks within each lyric line, and place each Arabic
    # grapheme from the right edge of its word toward the left without changing time order.
    p = folia / "src/components/visualizer/sonnet/sonnetTypographyLayout.ts"
    rtl_replace(p,
        "import { hashSonnetSeed } from './sonnetRandom';\n",
        "import { hashSonnetSeed } from './sonnetRandom';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Sonnet typography direction import")
    rtl_replace(p,
        "        }\n\n        heroBox.enterX = 0;",
        "        }\n\n        let lineBoxOffset = 0;\n        for (const lineSegments of lines) {\n            const lineBoxes = lineSegments.map(() => boxes[lineBoxOffset++]!).filter(Boolean);\n            const lineText = lineSegments.map(segment => segment.text).join('');\n            if (resolveLyricTextDirection(lineText) !== 'rtl' || lineBoxes.length < 2) continue;\n            const left = Math.min(...lineBoxes.map(box => box.x - box.measuredWidth / 2));\n            const right = Math.max(...lineBoxes.map(box => box.x + box.measuredWidth / 2));\n            const center = (left + right) / 2;\n            lineBoxes.forEach(box => { box.x = 2 * center - box.x; });\n        }\n\n        heroBox.enterX = 0;",
        "Sonnet RTL segment block placement")
    rtl_replace(p,
        "        // Non-CJK words use horizontal glyph advances and rotate as a block in vertical compositions.\n        // Resolve that writing mode before measuring so packing uses the rendered bounds.\n        const rotatesNonCjkSegment = shouldRotateNonCjkSegment(segment, vertical);",
        "        // Arabic cursive words stay horizontal even in styles that use vertical columns.\n        // Latin keeps the original vertical/rotated treatment.\n        const isArabicSegment = /\\p{Script=Arabic}/u.test(segment.text);\n        if (isArabicSegment) vertical = false;\n        const rotatesNonCjkSegment = !isArabicSegment && shouldRotateNonCjkSegment(segment, vertical);",
        "Sonnet Arabic horizontal word flow")
    p = folia / "src/components/visualizer/sonnet/sonnetGlyphLayout.ts"
    rtl_replace(p,
        "// Maps parser-derived grapheme timing to final glyph coordinates and entrance vectors.\n",
        "// Maps parser-derived grapheme timing to final glyph coordinates and entrance vectors.\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Sonnet glyph direction import")
    rtl_replace(p,
        "    const fallbackChars = Array.from(segment.text);\n",
        "    const motionDuration = resolveSonnetGlyphMotionDuration(motionWindow);\n    if (segment.isWordLike && /\\p{Script=Arabic}/u.test(segment.text)) {\n        // A single shaped Pixi Text object per Arabic word avoids grapheme-at-a-time rendering.\n        const wordText = segment.text.trim();\n        if (wordText.length > 0) {\n            const startTime = segment.startTime;\n            const angle = isSonnetEmphasisRole(placement.role) ? 0.055 : 0.035;\n            return [{ char: wordText, baseX: placement.x, baseY: placement.y, enterX: placement.enterX, enterY: placement.enterY, entryRotation: angle, startTime, settleTime: startTime + motionDuration }];\n        }\n    }\n    const fallbackChars = Array.from(segment.text);\n",
        "Sonnet Arabic word-level early path")
    rtl_replace(p,
        "    const motionDuration = resolveSonnetGlyphMotionDuration(motionWindow);\n    let cursor = -totalAdvance / 2;\n    return graphemes.map((grapheme, index) => {\n        const advance = advances[index];\n        const localX = placement.vertical ? 0 : cursor + advance / 2;\n        const localY = placement.vertical ? cursor + advance / 2 : 0;\n        cursor += advance;",
        "    const rtl = !placement.vertical && resolveLyricTextDirection(segment.text) === 'rtl';\n    let cursor = rtl ? totalAdvance / 2 : -totalAdvance / 2;\n    return graphemes.map((grapheme, index) => {\n        const advance = advances[index];\n        const localX = placement.vertical ? 0 : rtl ? cursor - advance / 2 : cursor + advance / 2;\n        const localY = placement.vertical ? cursor + advance / 2 : 0;\n        cursor += rtl ? -advance : advance;",
        "Sonnet RTL per-glyph sweep")


    # Tempera: mirror word-block order on each row; mirror only Arabic word internals so an embedded
    # English word still reads left-to-right. Row width, rotations and entrance choreography stay.
    p = folia / "src/components/visualizer/tempera/temperaMeasure.ts"
    rtl_replace(p,
        "    const scaledSize = fontSize * scale;\n    const raw = glyphs.map(grapheme => measureTemperaGrapheme(ctx, grapheme.char, scaledSize));",
        "    const scaledSize = fontSize * scale;\n    if (segment.isWordLike && /\\p{Script=Arabic}/u.test(segment.text)) {\n        // Render one complete Arabic word node rather than a Text object for every grapheme.\n        const wordText = segment.text.trim();\n        if (wordText.length > 0) {\n            const width = measureText(ctx, wordText, scaledSize);\n            const startTime = Math.min(segment.startTime, ...glyphs.map(grapheme => grapheme.startTime));\n            const endTime = Math.max(segment.endTime, ...glyphs.map(grapheme => grapheme.endTime));\n            return {\n                lineIndex, segmentIndex, text: wordText,\n                startOffset: segment.startOffset, endOffset: segment.endOffset,\n                leadingGap: 0, scale, width,\n                glyphs: [{ char: wordText, startTime, endTime, offset: 0, width }],\n                startTime, endTime,\n            };\n        }\n    }\n    const raw = glyphs.map(grapheme => measureTemperaGrapheme(ctx, grapheme.char, scaledSize));",
        "Tempera Arabic full-word unit")

    p = folia / "src/components/visualizer/tempera/temperaLayout.ts"
    rtl_replace(p,
        "import { temperaHash01 } from './temperaRandom';\n",
        "import { temperaHash01 } from './temperaRandom';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Tempera direction import")
    rtl_replace(p,
        "        let cursorX = rowLeft;\n        row.words.forEach((word, wordIndex) => {",
        "        const rowLineText = lines[row.words[0]?.lineIndex ?? 0]?.map(segment => segment.text).join('') ?? '';\n        const rowRtl = resolveLyricTextDirection(rowLineText) === 'rtl';\n        let cursorX = rowRtl ? rowLeft + row.width : rowLeft;\n        row.words.forEach((word, wordIndex) => {",
        "Tempera RTL row direction")
    rtl_replace(p,
        "            const wordLeft = cursorX + (wordIndex === 0 ? 0 : word.leadingGap);\n            cursorX = wordLeft + word.width;\n            const wordCenterX = wordLeft + word.width / 2;",
        "            const gap = wordIndex === 0 ? 0 : word.leadingGap;\n            const wordLeft = rowRtl ? cursorX - gap - word.width : cursorX + gap;\n            cursorX = rowRtl ? wordLeft : wordLeft + word.width;\n            const wordCenterX = wordLeft + word.width / 2;\n            const wordRtl = resolveLyricTextDirection(word.text) === 'rtl';",
        "Tempera RTL word slot")
    rtl_replace(p,
        "                const localX = wordLeft + glyph.offset + glyph.width / 2;",
        "                const localX = wordLeft + (wordRtl ? word.width - glyph.offset - glyph.width / 2 : glyph.offset + glyph.width / 2);",
        "Tempera RTL glyph direction")

    # Claddagh: its timeline remains ascending, but the ring angle runs in the opposite direction.
    p = folia / "src/components/visualizer/claddagh/CladdaghRingLine.tsx"
    rtl_replace(p,
        "import { buildLineGraphemeTimeline } from '../../../utils/lyrics/graphemeTiming';\n",
        "import { buildLineGraphemeTimeline } from '../../../utils/lyrics/graphemeTiming';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Claddagh direction import")
    rtl_replace(p,
        "                const nominalAngle = item.nominalAngle;\n",
        "                const nominalAngle = resolveLyricTextDirection(line.fullText) === 'rtl'\n                    ? -item.nominalAngle\n                    : item.nominalAngle;\n",
        "Claddagh RTL orbit direction")

    # Cadenza: mirror each wrapped word fragment about its row's right edge; its glyph glow spans
    # get dir=rtl so the first time-aligned Arabic grapheme appears at the right edge.
    p = folia / "src/components/visualizer/cadenza/cadenzaTypes.ts"
    rtl_replace(p,
        "    isInterlude: boolean;\n}\n\nexport interface AnimatedPlacementState {",
        "    isInterlude: boolean;\n    rtl: boolean;\n}\n\nexport interface AnimatedPlacementState {",
        "Cadenza placement direction")
    rtl_replace(p,
        "    text: string;\n    color: string;\n    opacity: string;\n",
        "    text: string;\n    color: string;\n    opacity: string;\n    rtl: boolean;\n",
        "Cadenza overlay frame direction")
    p = folia / "src/components/visualizer/cadenza/cadenzaPlacements.ts"
    rtl_replace(p,
        "import { type LayoutLine } from '@chenglou/pretext';\n",
        "import { type LayoutLine } from '@chenglou/pretext';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Cadenza direction import")
    rtl_replace(p,
        "        const lineLeft = -lineView.line.width / 2;\n        const baselineY = -totalHeight / 2 + fontPx + lineIndex * lineHeight;",
        "        const lineLeft = -lineView.line.width / 2;\n        const lineRtl = resolveLyricTextDirection(lineView.line.text) === 'rtl';\n        const baselineY = -totalHeight / 2 + fontPx + lineIndex * lineHeight;",
        "Cadenza wrapped line direction")
    rtl_replace(p,
        "                baseX: lineLeft + fragment.startX,\n                baseY: baselineY,",
        "                baseX: lineRtl ? lineView.line.width / 2 - fragment.endX : lineLeft + fragment.startX,\n                baseY: baselineY,\n                rtl: resolveLyricTextDirection(fragment.text) === 'rtl',",
        "Cadenza mirrored fragment position")
    rtl_replace(p,
        "            isInterlude,\n        });",
        "            isInterlude,\n            rtl: plan.rtl,\n        });",
        "Cadenza placement rtl field")
    p = folia / "src/components/visualizer/cadenza/cadenzaOverlayNodes.ts"
    rtl_replace(p,
        "        span.style.lineHeight = '1';\n        nodes.glow.appendChild(span);",
        "        span.style.lineHeight = 'inherit';\n        nodes.glow.appendChild(span);",
        "Cadenza glyph span inherited Arabic-safe line height")
    rtl_replace(p,
        "    if (written?.filter !== next.filter) nodes.body.style.filter = next.filter;\n    nodes.written = next;",
        "    if (written?.filter !== next.filter) nodes.body.style.filter = next.filter;\n    if (written?.rtl !== next.rtl) {\n        if (next.rtl) {\n            nodes.inner.style.direction = 'rtl';\n            nodes.inner.style.unicodeBidi = 'plaintext';\n            nodes.inner.style.lineHeight = '1.22';\n            nodes.body.style.direction = 'rtl';\n            nodes.body.style.textAlign = 'right';\n            nodes.body.style.lineHeight = '1.22';\n            nodes.glow.style.direction = 'rtl';\n            nodes.glow.style.textAlign = 'right';\n            nodes.glow.style.lineHeight = '1.22';\n            nodes.glow.style.unicodeBidi = 'plaintext';\n        } else {\n            nodes.inner.style.removeProperty('direction');\n            nodes.inner.style.removeProperty('unicode-bidi');\n            nodes.inner.style.lineHeight = '1';\n            nodes.body.style.removeProperty('direction');\n            nodes.body.style.removeProperty('text-align');\n            nodes.body.style.lineHeight = '1';\n            nodes.glow.style.removeProperty('direction');\n            nodes.glow.style.removeProperty('text-align');\n            nodes.glow.style.lineHeight = '1';\n            nodes.glow.style.removeProperty('unicode-bidi');\n        }\n    }\n    nodes.written = next;",
        "Cadenza RTL overlay direction update")
    p = folia / "src/components/visualizer/cadenza/VisualizerCadenza.tsx"
    rtl_replace(p,
        "                        opacity: animatedState.bodyAlpha.toString(),\n                        filter: animatedState.blur > 0.05 ? `blur(${animatedState.blur.toFixed(2)}px)` : 'none',",
        "                        opacity: animatedState.bodyAlpha.toString(),\n                        rtl: placement.rtl,\n                        filter: animatedState.blur > 0.05 ? `blur(${animatedState.blur.toFixed(2)}px)` : 'none',",
        "Cadenza overlay rtl state")

    # Cappella: reveal whole grapheme clusters (not UTF-16/code points) and let the bubble's normal
    # browser text flow shape Arabic and wrap from the right without affecting Latin.
    p = folia / "src/components/visualizer/cappella/cappellaReveal.ts"
    rtl_replace(p,
        "    const characters = Array.from(line.fullText);\n",
        "    const characters = splitLyricGraphemes(line.fullText);\n",
        "Cappella grapheme-safe reveal")
    p = folia / "src/components/visualizer/cappella/CappellaBubbleParts.tsx"
    rtl_replace(p,
        "                    overflowWrap: 'anywhere',\n                }}\n            >",
        "                    overflowWrap: 'anywhere',\n                }}\n                dir=\"auto\"\n            >",
        "Cappella bubble RTL wrapping")
    rtl_replace(p,
        "        <span>\n            {visibleCharacters.map((character, index) => (",
        "        <span dir=\"auto\">\n            {visibleCharacters.map((character, index) => (",
        "Cappella timed glyph direction")

    # Pendolo: preserve ascending grapheme timing, but move the CSS mask's leading edge to the
    # right for RTL text. Browser bidi keeps Latin/numeric runs internally LTR.
    p = folia / "src/components/visualizer/pendolo/PendoloActiveLyricSweep.tsx"
    rtl_replace(p,
        "import { type Line, type Theme } from '../../../types';\n",
        "import { type Line, type Theme } from '../../../types';\nimport { resolveLyricTextDirection } from '../../../utils/lyrics/textDirection';\n",
        "Pendolo direction import")
    rtl_replace(p,
        "}) => {\n    const graphemeOffsets = useMemo(\n        () => measureMonetGraphemeOffsets(layoutLine.text, fontPx, fontSpec),",
        "}) => {\n    const rtl = resolveLyricTextDirection(layoutLine.text) === 'rtl';\n    const graphemeOffsets = useMemo(\n        () => measureMonetGraphemeOffsets(layoutLine.text, fontPx, fontSpec),",
        "Pendolo direction state")
    rtl_replace(p,
        "        return `linear-gradient(90deg, #000 0px, #000 ${Math.max(paddedFillWidth - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${paddedFillWidth}px, transparent ${paddedFillWidth + edgeSoftness}px)`;",
        "        const angle = rtl ? '270deg' : '90deg';\n        return `linear-gradient(${angle}, #000 0px, #000 ${Math.max(paddedFillWidth - edgeSoftness, 0)}px, rgba(0, 0, 0, 0.84) ${paddedFillWidth}px, transparent ${paddedFillWidth + edgeSoftness}px)`;",
        "Pendolo RTL mask direction")
    rtl_replace(p,
        "        <span className=\"relative block whitespace-pre overflow-visible\" style={{ width: `${layoutLine.width}px`, height: `${lineHeight}px` }}>\n            <span style={{ color: colorWithAlpha(primaryTextColor, 0.52) }}>\n",
        "        <span dir={rtl ? 'rtl' : 'ltr'} className=\"relative block whitespace-pre overflow-visible\" style={{ width: `${layoutLine.width}px`, height: `${lineHeight}px`, direction: rtl ? 'rtl' : 'ltr', unicodeBidi: 'plaintext', textAlign: rtl ? 'right' : 'left' }}>\n            <span dir=\"auto\" style={{ color: colorWithAlpha(primaryTextColor, 0.52) }}>\n",
        "Pendolo text direction")
    rtl_replace(p,
        "            <span\n                aria-hidden\n                className=\"pointer-events-none absolute inset-0 block whitespace-pre overflow-visible\"",
        "            <span\n                aria-hidden\n                dir={rtl ? 'rtl' : 'ltr'}\n                className=\"pointer-events-none absolute inset-0 block whitespace-pre overflow-visible\"",
        "Pendolo sweep overlay direction")
    rtl_replace(p,
        "        <span className=\"block\" style={textLayoutStyle}>",
        "        <span className=\"block\" dir=\"auto\" style={{ ...textLayoutStyle, unicodeBidi: 'plaintext' }}>",
        "Pendolo wrapper direction")

    # Still: DOM text remains unmodified; dir=auto chooses RTL only for Arabic lines.
    p = folia / "src/components/visualizer/still/VisualizerStill.tsx"
    rtl_replace(p,
        "                                    <div\n                                        className={`drop-shadow-md text-center tracking-[0.02em] ${isCurrent ? 'text-[2.5rem] opacity-100 leading-tight' : 'text-3xl opacity-30'}`}\n",
        "                                    <div\n                                        dir=\"auto\"\n                                        className={`drop-shadow-md text-center tracking-[0.02em] ${isCurrent ? 'text-[2.5rem] opacity-100 leading-tight' : 'text-3xl opacity-30'}`}\n",
        "Still lyric auto direction")
    rtl_replace(p,
        "                                    <div\n                                        className={`drop-shadow-sm text-center tracking-wide ${isCurrent ? 'text-2xl opacity-80 mt-3' : 'text-xl opacity-30 mt-2'}`}\n",
        "                                    <div\n                                        dir=\"auto\"\n                                        className={`drop-shadow-sm text-center tracking-wide ${isCurrent ? 'text-2xl opacity-80 mt-3' : 'text-xl opacity-30 mt-2'}`}\n",
        "Still translation auto direction")

    # Tilt: characters stay in source/timing order; dir=auto makes the first Arabic glyph start at
    # the right and keeps Latin runs LTR. The existing line-height leaves room for Arabic marks.
    p = folia / "src/components/visualizer/tilt/VisualizerTilt.tsx"
    rtl_replace(p,
        "                className=\"whitespace-nowrap\"\n                style={{\n                    fontSize: normalFontSize,",
        "                dir=\"auto\"\n                className=\"whitespace-nowrap\"\n                style={{\n                    unicodeBidi: 'plaintext',\n                    fontSize: normalFontSize,",
        "Tilt normal text direction")
    rtl_replace(p,
        "            className=\"whitespace-nowrap\"\n            style={{\n                fontSize: tiltFontSize,",
        "            dir=\"auto\"\n            className=\"whitespace-nowrap\"\n            style={{\n                unicodeBidi: 'plaintext',\n                fontSize: tiltFontSize,",
        "Tilt italic text direction")

    # Arabic is cursive, so vertical glyph-column variants cannot be used without breaking
    # letter joining. Keep each style's palette/motion, but select its horizontal text flow only
    # for RTL Arabic. Latin continues to use every original vertical variant unchanged.
    p = folia / "src/components/visualizer/hanabi/text/layout.ts"
    rtl_replace(p,
        "    const { layout, regionWidth: W, regionHeight: H, fontPx } = params;",
        "    const requestedLayout = params.layout;\n    const layout: TextLayout = params.rtl && (requestedLayout === 'vertical' || requestedLayout === 'vertical-split')\n        ? 'center'\n        : requestedLayout;\n    const { regionWidth: W, regionHeight: H, fontPx } = params;",
        "Hanabi Arabic joined fallback for vertical modes")

    p = folia / "src/components/visualizer/lumiere/text/windowGeometry.ts"
    rtl_replace(p,
        "import type { LineTransform, WindowTypography } from './windowTypes';\n",
        "import type { LineTransform, WindowTypography } from './windowTypes';\nimport { resolveLyricTextDirection } from '../../../../utils/lyrics/textDirection';\n",
        "Lumiere geometry RTL direction import")
    rtl_replace(p,
        "    const typographyAt = (c: number): WindowTypography => (\n        options.typographyOf ? options.typographyOf(Math.max(0, Math.min(lineCount - 1, c))) : typography\n    );\n",
        "    const typographyAt = (c: number): WindowTypography => (\n        options.typographyOf ? options.typographyOf(Math.max(0, Math.min(lineCount - 1, c))) : typography\n    );\n    const isRtlLine = (index: number) => index >= 0 && index < lineCount\n        && resolveLyricTextDirection(lineOf(index).line.fullText) === 'rtl';\n    const orientationFor = (index: number, requested: 0 | 1): 0 | 1 => (isRtlLine(index) ? 0 : requested);\n",
        "Lumiere RTL line orientation policy")
    rtl_replace(p,
        "        const flow = lineOf(index).flow[orient];\n        const budget = orient === 1 ? columnCap : maxWidthOf(kind);",
        "        const effectiveOrient = orientationFor(index, orient);\n        const flow = lineOf(index).flow[effectiveOrient];\n        const budget = effectiveOrient === 1 ? columnCap : maxWidthOf(isRtlLine(index) ? 'horizontal' : kind);",
        "Lumiere RTL horizontal fit policy")
    rtl_replace(p,
        "        const orient = kind === 'vertical' ? 1 : 0;\n        const { variant, scale } = settle(current, kind, orient, 1);",
        "        const orient = orientationFor(current, kind === 'vertical' ? 1 : 0);\n        const { variant, scale } = settle(current, kind, orient, 1);",
        "Lumiere RTL window shift orientation")
    rtl_replace(p,
        "            const baseOrient = base.orient >= 0.5 ? 1 : 0;",
        "            const baseOrient = orientationFor(index, base.orient >= 0.5 ? 1 : 0);",
        "Lumiere RTL crossed neighbour orientation")
    rtl_replace(p,
        "            const budget = baseOrient === 1 ? columnCap : maxWidthOf(kind);",
        "            const budget = baseOrient === 1 ? columnCap : maxWidthOf(isRtlLine(index) ? 'horizontal' : kind);",
        "Lumiere RTL crossed width budget")
    rtl_replace(p,
        "            slot = { ...base, scale, dy, dx: base.dx + Math.sign(base.dx) * wider };",
        "            slot = { ...base, scale, dy, dx: base.dx + Math.sign(base.dx) * wider, orient: baseOrient };",
        "Lumiere RTL crossed slot orientation")
    rtl_replace(p,
        "            const orient = kind === 'vertical' ? 1 : 0;\n            slot = fixedSlot(kind === 'crossed' ? 'horizontal' : kind, clamped, region, fontH, nextAlpha, (offset, scale) => (\n                acrossOf(offset === clamped ? index : current + offset, kind, orient, scale)\n            ));",
        "            const orient = orientationFor(index, kind === 'vertical' ? 1 : 0);\n            const slotKind = kind === 'crossed' || orient === 0 ? 'horizontal' : kind;\n            slot = fixedSlot(slotKind, clamped, region, fontH, nextAlpha, (offset, scale) => (\n                acrossOf(offset === clamped ? index : current + offset, kind, orient, scale)\n            ));",
        "Lumiere RTL fixed slot orientation")

    print("patched Folia Task C Arabic RTL layout/reveal across all 17 styles")
else:
    print("note: Folia source tree unavailable; skipping Task C Arabic RTL integration")

# --------------------------------------------------------------------------- Task D: v0.7.21 Android mobile GPU budgets on v0.7.25
# Shared mobile budgets are supplied by folia-host/src/utils/mobileVisualizerBudget.ts and copied
# into the Folia root by the workflow before apply.py runs. All overrides are narrow, anchored,
# mobile-only, and leave desktop render paths / stored quality selections unchanged.
if folia.exists():
    mobile_budget = folia / "src/utils/mobileVisualizerBudget.ts"
    if not mobile_budget.exists():
        fail("Task D mobileVisualizerBudget.ts missing; ensure folia-host/ is copied before apply.py")

    # Hanabi (new in v0.7.25): cap Pixi render/filter resolution and glyph atlas texture size.
    p = folia / "src/components/visualizer/hanabi/createHanabiPixiRuntime.ts"
    text = read(p)
    text = patch_text(text, p,
        "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\n",
        "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\nimport { resolveMobilePixiResolution, resolveMobileTextureLimit } from '../../../utils/mobileVisualizerBudget';\n",
        "Hanabi mobile budget import")
    text = patch_text(text, p,
        "const resolveRenderResolution = (devicePixelRatio: number, scale: LyricRenderScale) => (\n    resolveLyricPixelRatio(resolveHanabiBaseResolution(devicePixelRatio), scale)\n);",
        "const resolveRenderResolution = (devicePixelRatio: number, scale: LyricRenderScale, width: number, height: number) => (\n    resolveMobilePixiResolution(\n        width, height,\n        resolveLyricPixelRatio(resolveHanabiBaseResolution(devicePixelRatio), scale),\n    )\n);",
        "Hanabi mobile Pixi resolution cap")
    text = patch_text(text, p,
        "resolveRenderResolution(window.devicePixelRatio, options.renderScale)",
        "resolveRenderResolution(window.devicePixelRatio, options.renderScale, width, height)",
        "Hanabi initial render resolution")
    text = patch_text(text, p,
        "resolveRenderResolution(window.devicePixelRatio, this.options.renderScale)",
        "resolveRenderResolution(window.devicePixelRatio, this.options.renderScale, width, height)",
        "Hanabi resized render resolution")
    text = patch_text(text, p,
        "if (gl) setHanabiGlyphTextureLimit(gl.getParameter(gl.MAX_TEXTURE_SIZE) as number);",
        "if (gl) setHanabiGlyphTextureLimit(resolveMobileTextureLimit(gl.getParameter(gl.MAX_TEXTURE_SIZE) as number));",
        "Hanabi mobile glyph atlas cap")
    write(p, text)

    # Hanabi's full profile creates a full-resolution bloom target. On phones, use the existing
    # balanced profile's 0.7x glow (49% filter pixels) while retaining low when explicitly chosen.
    p = folia / "src/components/visualizer/hanabi/scene.ts"
    text = read(p)
    text = patch_text(text, p,
        "import { HANABI_QUALITY_PROFILES, resolveHanabiGlowQuality } from './hanabiTuning';\n",
        "import { HANABI_QUALITY_PROFILES, resolveHanabiGlowQuality } from './hanabiTuning';\nimport { resolveMobileHanabiQuality } from '../../../utils/mobileVisualizerBudget';\n",
        "Hanabi scene mobile quality import")
    text = patch_text(text, p,
        "HANABI_QUALITY_PROFILES[tuning.renderQuality] ?? HANABI_QUALITY_PROFILES.full",
        "HANABI_QUALITY_PROFILES[resolveMobileHanabiQuality(tuning.renderQuality)] ?? HANABI_QUALITY_PROFILES.full",
        "Hanabi mobile ambient profile")
    text = patch_text(text, p,
        "resolveHanabiGlowQuality(width, height, options.resolution, tuning.renderQuality)",
        "resolveHanabiGlowQuality(width, height, options.resolution, resolveMobileHanabiQuality(tuning.renderQuality))",
        "Hanabi mobile glow profile")
    write(p, text)

    p = folia / "src/components/visualizer/hanabi/credits.ts"
    text = read(p)
    text = patch_text(text, p,
        "import { resolveHanabiGlowQuality } from './hanabiTuning';\n",
        "import { resolveHanabiGlowQuality } from './hanabiTuning';\nimport { resolveMobileHanabiQuality } from '../../../utils/mobileVisualizerBudget';\n",
        "Hanabi credits mobile quality import")
    text = patch_text(text, p,
        "resolveHanabiGlowQuality(width, height, options.resolution, tuning.renderQuality)",
        "resolveHanabiGlowQuality(width, height, options.resolution, resolveMobileHanabiQuality(tuning.renderQuality))",
        "Hanabi credits mobile glow profile")
    write(p, text)

    # Machi (new in v0.7.25): cap the full-scene target, high shadow map and wet-road reflection
    # targets. Existing quality choices remain stored; only the mobile runtime values are bounded.
    p = folia / "src/components/visualizer/machi/engine/quality.ts"
    text = read(p)
    text = patch_text(text, p,
        "import { DEFAULT_LYRIC_RENDER_QUALITY, MAX_LYRIC_PIXEL_RATIO } from '../../../../utils/lyricRenderQuality';\n",
        "import { DEFAULT_LYRIC_RENDER_QUALITY, MAX_LYRIC_PIXEL_RATIO } from '../../../../utils/lyricRenderQuality';\nimport { isMobileGpuConstrained, resolveMobileCanvasResolution } from '../../../../utils/mobileVisualizerBudget';\n",
        "Machi mobile quality import")
    text = patch_text(text, p,
        "    previewMode: boolean;\n    /** 歌词画布的全局挡位：分辨率、抗锯齿选了「跟随全局」时用它。 */",
        "    previewMode: boolean;\n    /** Host CSS size, used only to enforce the mobile texture-axis budget. */\n    viewportWidth?: number;\n    viewportHeight?: number;\n    /** 歌词画布的全局挡位：分辨率、抗锯齿选了「跟随全局」时用它。 */",
        "Machi viewport quality options")
    text = patch_text(text, p,
        "    const pixelRatio = antialias === 'ssaa' ? Math.max(scaled, Math.min(scaled * SUPERSAMPLE, MAX_SUPERSAMPLED_RATIO)) : scaled;\n    return {\n        pixelRatio,",
        "    const requestedPixelRatio = antialias === 'ssaa' ? Math.max(scaled, Math.min(scaled * SUPERSAMPLE, MAX_SUPERSAMPLED_RATIO)) : scaled;\n    const mobile = isMobileGpuConstrained({ viewportWidth: options.viewportWidth, viewportHeight: options.viewportHeight });\n    const pixelRatio = resolveMobileCanvasResolution(requestedPixelRatio, options.viewportWidth, options.viewportHeight, mobile);\n    const shadowMapSize = mobile ? Math.min(SHADOW_MAP_SIZES[shadows], 1536) : SHADOW_MAP_SIZES[shadows];\n    const reflectionScale = mobile ? Math.min(REFLECTION_SCALES[settled.reflections], 0.3) : REFLECTION_SCALES[settled.reflections];\n    return {\n        pixelRatio,",
        "Machi mobile target/shadow/reflection caps")
    text = patch_text(text, p,
        "        shadowMapSize: SHADOW_MAP_SIZES[shadows],\n        reflectionScale: REFLECTION_SCALES[settled.reflections],",
        "        shadowMapSize,\n        reflectionScale,",
        "Machi mobile quality output")
    write(p, text)

    p = folia / "src/components/visualizer/machi/createMachiRuntime.ts"
    text = read(p)
    text = patch_text(text, p,
        "            previewMode: this.options.previewMode,\n            global: this.globalQuality,",
        "            previewMode: this.options.previewMode,\n            viewportWidth: this.options.host.clientWidth,\n            viewportHeight: this.options.host.clientHeight,\n            global: this.globalQuality,",
        "Machi host viewport quality input")
    write(p, text)

    # Nebbia (new in v0.7.25): the WebGL2 canvas, fog and noise targets share this resolution.
    p = folia / "src/components/visualizer/nebbia/createNebbiaRuntime.ts"
    text = read(p)
    text = patch_text(text, p,
        "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\n",
        "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\nimport { resolveMobileCanvasResolution } from '../../../utils/mobileVisualizerBudget';\n",
        "Nebbia mobile resolution import")
    text = patch_text(text, p,
        "        const dpr = resolveLyricPixelRatio(Math.min(2, window.devicePixelRatio || 1), this.renderScale);",
        "        const requestedDpr = resolveLyricPixelRatio(Math.min(2, window.devicePixelRatio || 1), this.renderScale);\n        const dpr = resolveMobileCanvasResolution(requestedDpr, this.W, this.H);",
        "Nebbia mobile canvas cap")
    write(p, text)

    # Monet (shared background, but v0.7.25 raised its canvas back to 1920x1080): restore the
    # Android v0.7.21 384x256 worker canvas and scale blur in the same ratio so the CSS-upscaled
    # artwork keeps the same perceived softness on phone screens.
    p = folia / "src/components/visualizer/monet/monetBackgroundPaint.ts"
    text = read(p)
    text = patch_text(text, p,
        "import type { MonetBackgroundTuning, Theme } from '../../../types';\n",
        "import type { MonetBackgroundTuning, Theme } from '../../../types';\nimport { isMobileGpuConstrained } from '../../../utils/mobileVisualizerBudget';\n",
        "Monet mobile canvas import")
    text = patch_text(text, p,
        "export const MONET_BACKGROUND_WIDTH = 1920;\nexport const MONET_BACKGROUND_HEIGHT = 1080;",
        "const mobileAmbientBuffer = isMobileGpuConstrained();\nexport const MONET_BACKGROUND_WIDTH = mobileAmbientBuffer ? 384 : 1920;\nexport const MONET_BACKGROUND_HEIGHT = mobileAmbientBuffer ? 256 : 1080;",
        "Monet mobile worker canvas dimensions")
    text = patch_text(text, p,
        "    if (blurPx !== null) {\n        context.filter = `blur(${blurPx}px)`;\n    }",
        "    if (blurPx !== null) {\n        const scaledBlur = Math.max(0.5, (blurPx * width) / 1920);\n        context.filter = `blur(${scaledBlur.toFixed(2)}px)`;\n    }",
        "Monet mobile proportional blur")
    write(p, text)

    # Restore the v0.7.21 ambient shader budget on the shared backgrounds. It is mobile-only here,
    # so desktop/large touchless browser rendering remains at the original source resolution.
    p = folia / "src/components/visualizer/backgrounds/latent/LatentBackground.tsx"
    text = read(p)
    text = patch_text(text, p,
        "import { extractRepresentativeColors } from '../../../../utils/colorExtractor';\n",
        "import { extractRepresentativeColors } from '../../../../utils/colorExtractor';\nimport { AMBIENT_BACKGROUND_DPR_SCALE, AMBIENT_BACKGROUND_MAX_PIXELS, isMobileGpuConstrained } from '../../../../utils/mobileVisualizerBudget';\n",
        "Latent mobile ambient import")
    text = patch_text(text, p,
        "    const tuning = tuningOverride ?? DEFAULT_LATENT_BACKGROUND_TUNING;\n",
        "    const tuning = tuningOverride ?? DEFAULT_LATENT_BACKGROUND_TUNING;\n    const mobileGpu = isMobileGpuConstrained();\n",
        "Latent mobile detection")
    old_shader_budget = "                        minPixelRatio={1}\n                        maxPixelCount={MAX_SHADER_PIXELS}"
    new_shader_budget = "                        minPixelRatio={mobileGpu ? AMBIENT_BACKGROUND_DPR_SCALE : 1}\n                        maxPixelCount={mobileGpu ? AMBIENT_BACKGROUND_MAX_PIXELS : MAX_SHADER_PIXELS}"
    if new_shader_budget not in text:
        if text.count(old_shader_budget) != 2:
            fail("Latent shader budget anchor not found exactly twice")
        text = text.replace(old_shader_budget, new_shader_budget)
    write(p, text)

    p = folia / "src/components/visualizer/backgrounds/nomand/NomandBackgroundLayer.tsx"
    text = read(p)
    text = patch_text(text, p,
        "import { PAPER_SHADER_CONTEXT_ATTRIBUTES } from '../../../../utils/paperShaderContext';\n",
        "import { PAPER_SHADER_CONTEXT_ATTRIBUTES } from '../../../../utils/paperShaderContext';\nimport { AMBIENT_BACKGROUND_DPR_SCALE, AMBIENT_BACKGROUND_MAX_DIMENSION_PX, isMobileGpuConstrained } from '../../../../utils/mobileVisualizerBudget';\n",
        "Nomand mobile ambient import")
    text = patch_text(text, p,
        "    const tuning = { ...DEFAULT_NOMAND_BACKGROUND_TUNING, ...tuningOverride };\n",
        "    const tuning = { ...DEFAULT_NOMAND_BACKGROUND_TUNING, ...tuningOverride };\n    const mobileGpu = isMobileGpuConstrained();\n",
        "Nomand mobile detection")
    text = patch_text(text, p,
        "            minPixelRatio: 1,\n            maxPixelCount: 1920 * 1080,",
        "            minPixelRatio: mobileGpu ? AMBIENT_BACKGROUND_DPR_SCALE : 1,\n            maxPixelCount: mobileGpu ? AMBIENT_BACKGROUND_MAX_DIMENSION_PX * AMBIENT_BACKGROUND_MAX_DIMENSION_PX : 1920 * 1080,",
        "Nomand mobile framebuffer")
    write(p, text)

    p = folia / "src/components/visualizer/backgrounds/sora/SoraBackground.tsx"
    text = read(p)
    text = patch_text(text, p,
        "import { Theme } from '../../../../types';\n",
        "import { Theme } from '../../../../types';\nimport { AMBIENT_BACKGROUND_DPR_SCALE, AMBIENT_BACKGROUND_MAX_DIMENSION_PX, isMobileGpuConstrained } from '../../../../utils/mobileVisualizerBudget';\n",
        "Sora mobile ambient import")
    text = patch_text(text, p,
        "const PARTICLE_COUNT = 150;\n",
        "const PARTICLE_COUNT = 150;\n\nconst resolveSoraBufferScale = (canvas: HTMLCanvasElement): number | undefined => {\n  if (!isMobileGpuConstrained()) return undefined;\n  const maxCssSide = Math.max(canvas.clientWidth || 0, canvas.clientHeight || 0);\n  if (maxCssSide <= 0) return undefined;\n  return Math.max(0.25, Math.min(AMBIENT_BACKGROUND_DPR_SCALE, AMBIENT_BACKGROUND_MAX_DIMENSION_PX / maxCssSide));\n};\n",
        "Sora mobile ambient scale helper")
    text = patch_text(text, p,
        "      twgl.resizeCanvasToDisplaySize(canvas);\n      gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);",
        "      const scaleMultiplier = resolveSoraBufferScale(canvas);\n      if (scaleMultiplier !== undefined) twgl.resizeCanvasToDisplaySize(canvas, scaleMultiplier);\n      else twgl.resizeCanvasToDisplaySize(canvas);\n      gl.viewport(0, 0, gl.canvas.width, gl.canvas.height);",
        "Sora mobile framebuffer scale")
    write(p, text)

    # The older Android build also bounded Pendolo's Canvas2D/WebGL drawing DPR. This is a shared
    # style and restores the same phone cap while preserving desktop resolution.
    p = folia / "src/components/visualizer/pendolo/PendoloClockworkCanvas.tsx"
    text = read(p)
    text = patch_text(text, p,
        "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\n",
        "import { resolveLyricPixelRatio } from '../../../utils/lyricRenderQuality';\nimport { resolveMobileCanvasDpr } from '../../../utils/mobileVisualizerBudget';\n",
        "Pendolo mobile DPR import")
    text = patch_text(text, p,
        "            const dpr = resolveLyricPixelRatio(window.devicePixelRatio || 1, p.renderScale);",
        "            const requestedDpr = resolveLyricPixelRatio(window.devicePixelRatio || 1, p.renderScale);\n            const dpr = resolveMobileCanvasDpr(requestedDpr);",
        "Pendolo mobile DPR cap")
    write(p, text)

    print("patched Folia Task D mobile budgets (Hanabi, Machi, Nebbia, Pendolo and ambient backgrounds)")
else:
    print("note: Folia source tree unavailable; skipping Task D mobile GPU budgets")

