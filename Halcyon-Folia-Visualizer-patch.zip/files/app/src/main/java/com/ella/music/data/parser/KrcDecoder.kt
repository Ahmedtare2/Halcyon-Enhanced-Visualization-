package com.ella.music.data.parser

import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.Inflater

/**
 * Reads lyric sidecar files. Kugou ".krc" files are stored as "krc1" + XOR-masked zlib data;
 * everything else is plain UTF-8 text.
 */
internal object KrcDecoder {
    private val KEY = intArrayOf(64, 71, 97, 119, 94, 50, 116, 71, 81, 54, 49, 45, 206, 210, 110, 105)

    fun isEncrypted(bytes: ByteArray): Boolean =
        bytes.size > 4 && bytes[0] == 'k'.code.toByte() && bytes[1] == 'r'.code.toByte() &&
            bytes[2] == 'c'.code.toByte() && bytes[3] == '1'.code.toByte()

    /** Returns the decoded KRC text, or null when [bytes] is not a valid encrypted KRC payload. */
    fun decode(bytes: ByteArray): String? {
        if (!isEncrypted(bytes)) return null
        return runCatching {
            val masked = ByteArray(bytes.size - 4)
            for (i in masked.indices) {
                masked[i] = (bytes[i + 4].toInt() xor KEY[i % KEY.size]).toByte()
            }
            val inflater = Inflater()
            try {
                inflater.setInput(masked)
                val out = ByteArrayOutputStream(masked.size * 3)
                val buffer = ByteArray(8192)
                while (!inflater.finished()) {
                    val n = inflater.inflate(buffer)
                    if (n <= 0) {
                        if (inflater.needsInput() || inflater.needsDictionary()) break
                    } else {
                        out.write(buffer, 0, n)
                    }
                }
                String(out.toByteArray(), Charsets.UTF_8).removePrefix("\uFEFF")
            } finally {
                inflater.end()
            }
        }.getOrNull()
    }

    /** Reads a lyric file as text, transparently decoding encrypted KRC files. */
    fun readLyricText(file: File): String {
        val bytes = file.readBytes()
        if (isEncrypted(bytes)) {
            decode(bytes)?.let { return it }
        }
        return String(bytes, Charsets.UTF_8)
    }
}
