package com.ella.music.ui.vis

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.audiofx.Visualizer
import android.net.Uri
import java.io.File
import java.nio.ByteOrder
import java.security.MessageDigest
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Per-frame audio-reactive values shared with every style and background.
 * Written from a worker coroutine (bands) and the frame loop (beat pulses), read while drawing.
 */
internal class AudioDrive {
    @Volatile var bass = 0f
    @Volatile var mid = 0f
    @Volatile var vocal = 0f
    @Volatile var treble = 0f
    @Volatile var liveKickImpulse = 0f
    @Volatile var hasLiveBands = false

    /** Smoothed 0..1 loudness blend. */
    var energy = 0f
    /** 1 on a beat, decays towards 0. */
    var beat = 0f
    /** 0..1 position between two beats. */
    var beatPhase = 0f
    /** Pulse on the low-frequency hits (kick drum). */
    var kick = 0f
    var bpm = 0f
    var downbeat = false
    var beatIndex = 0
    /** True while pulses come from an analysed beat grid (swing/lock effects may rely on beatPhase). */
    var locked = false

    private var lastBeatIdx = -1
    private var lastLiveBeatSec = -10f
    private var beatPulseLive = 0f

    fun reset() {
        energy = 0f; beat = 0f; beatPhase = 0f; kick = 0f; bpm = 0f; downbeat = false
        lastBeatIdx = -1; beatPulseLive = 0f
    }

    /**
     * @param map analysed beat grid for the current song, if any
     * @param reactive master switch for audio reactive values
     * @param beatFx master switch for beat pulses
     * @param offsetMs user timing offset applied to the beat grid
     */
    fun step(
        posMs: Long, dt: Float, timeSec: Float, playing: Boolean,
        map: BeatMap?, reactive: Boolean, beatFx: Boolean, offsetMs: Int
    ) {
        if (!playing) {
            energy *= 0.92f; beat *= 0.9f; kick *= 0.9f
            return
        }
        val target = if (reactive && hasLiveBands) (0.5f * bass + 0.3f * mid + 0.2f * treble) else 0f
        energy += (target - energy) * min(1f, dt * 8f)

        if (!beatFx) { beat *= 0.85f; kick *= 0.85f; return }
        val t = posMs - offsetMs
        var mapBeat = 0f
        var mapKick = 0f
        var usedMap = false
        locked = false
        if (map != null) {
            bpm = map.bpm
            if (map.confident && map.beatsMs.isNotEmpty()) {
                val i = map.beatIndexAt(t)
                if (i >= 0) {
                    val t0 = map.beatsMs[i]
                    val t1 = if (i + 1 < map.beatsMs.size) map.beatsMs[i + 1] else t0 + (60000f / max(60f, map.bpm)).toInt()
                    val span = max(1, t1 - t0).toFloat()
                    val ph = ((t - t0) / span).coerceIn(0f, 1f)
                    beatPhase = ph
                    mapBeat = exp(-ph * 3.4f) * map.beatStrength[i]
                    if (i != lastBeatIdx) { lastBeatIdx = i; beatIndex = i; downbeat = map.isDownbeat(i) }
                    usedMap = true
                    locked = true
                }
            }
            if (map.kicksMs.isNotEmpty()) {
                val k = map.kickIndexAt(t)
                if (k >= 0) {
                    val ageMs = (t - map.kicksMs[k]).coerceAtLeast(0)
                    mapKick = exp(-ageMs / 120f)
                    usedMap = true
                }
            }
        }
        // Live fallback: bass flux from the FFT feed when there is no usable beat grid.
        val impulse = liveKickImpulse
        if (impulse > 0f) {
            liveKickImpulse = 0f
            if (timeSec - lastLiveBeatSec > 0.16f) { beatPulseLive = max(beatPulseLive, impulse); lastLiveBeatSec = timeSec }
        }
        beatPulseLive *= exp(-dt * 7f)
        val liveBeat = if (reactive) beatPulseLive else 0f
        val b = if (usedMap) mapBeat else liveBeat
        val k = if (usedMap) mapKick else liveBeat
        beat = max(b, beat * exp(-dt * 9f))
        kick = max(k, kick * exp(-dt * 11f))
    }
}

/** Beat grid and kick onsets for one song. All times in milliseconds. */
internal class BeatMap(
    val beatsMs: IntArray,
    val beatStrength: FloatArray,
    val kicksMs: IntArray,
    val bpm: Float,
    val confident: Boolean,
    val downbeat: Int
) {
    fun beatIndexAt(tMs: Long): Int = lastAtOrBefore(beatsMs, tMs)
    fun kickIndexAt(tMs: Long): Int = lastAtOrBefore(kicksMs, tMs)
    fun isDownbeat(i: Int): Boolean = (i - downbeat) % 4 == 0

    private fun lastAtOrBefore(arr: IntArray, t: Long): Int {
        var lo = 0
        var hi = arr.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (arr[mid] <= t) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    fun toJson(): String {
        val o = JSONObject()
        o.put("v", 2)
        o.put("bpm", bpm.toDouble())
        o.put("conf", confident)
        o.put("db", downbeat)
        o.put("beats", JSONArray().also { a -> beatsMs.forEach { a.put(it) } })
        o.put("str", JSONArray().also { a -> beatStrength.forEach { a.put(it.toDouble()) } })
        o.put("kicks", JSONArray().also { a -> kicksMs.forEach { a.put(it) } })
        return o.toString()
    }

    companion object {
        fun fromJson(raw: String): BeatMap? = runCatching {
            val o = JSONObject(raw)
            if (o.optInt("v") != 2) return@runCatching null
            val beats = o.getJSONArray("beats")
            val str = o.getJSONArray("str")
            val kicks = o.getJSONArray("kicks")
            BeatMap(
                IntArray(beats.length()) { beats.getInt(it) },
                FloatArray(str.length()) { str.getDouble(it).toFloat() },
                IntArray(kicks.length()) { kicks.getInt(it) },
                o.optDouble("bpm", 0.0).toFloat(),
                o.optBoolean("conf", false),
                o.optInt("db", 0)
            )
        }.getOrNull()
    }
}

/** Reads the FFT of the player's audio session and turns it into band levels and kick impulses. */
internal object VisBands {
    suspend fun run(drive: AudioDrive, sessionId: Int, isPlaying: () -> Boolean) {
        val visualizer = runCatching {
            Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                scalingMode = Visualizer.SCALING_MODE_NORMALIZED
                enabled = true
            }
        }.getOrNull() ?: return
        val buffer = ByteArray(visualizer.captureSize)
        val sampleRateHz = (visualizer.samplingRate / 1000).coerceAtLeast(8000)
        val binHz = sampleRateHz.toFloat() / visualizer.captureSize.toFloat()
        var peakBass = 1f
        var peakMid = 1f
        var peakVocal = 1f
        var peakTreble = 1f
        var bassSlow = 0f
        var bassSm = 0f
        var midSm = 0f
        var vocalSm = 0f
        var trebleSm = 0f
        try {
            drive.hasLiveBands = true
            while (currentCoroutineContext().isActive) {
                if (!isPlaying()) {
                    bassSm *= 0.8f; midSm *= 0.8f; vocalSm *= 0.8f; trebleSm *= 0.8f
                    drive.bass = bassSm; drive.mid = midSm; drive.vocal = vocalSm; drive.treble = trebleSm
                    delay(120L)
                    continue
                }
                if (visualizer.getFft(buffer) == Visualizer.SUCCESS) {
                    val bins = buffer.size / 2
                    var bass = 0f; var bassN = 0
                    var mid = 0f; var midN = 0
                    var vocal = 0f; var vocalN = 0
                    var treble = 0f; var trebleN = 0
                    for (k in 1 until bins) {
                        val re = buffer[2 * k].toInt().toFloat()
                        val im = buffer[2 * k + 1].toInt().toFloat()
                        val mag = sqrt(re * re + im * im)
                        val hz = k * binHz
                        if (hz in 30f..150f) { bass += mag; bassN++ }
                        if (hz in 400f..2500f) { mid += mag; midN++ }
                        if (hz in 250f..3500f) { vocal += mag; vocalN++ }
                        if (hz in 4000f..14000f) { treble += mag; trebleN++ }
                    }
                    val rawBass = if (bassN > 0) bass / bassN else 0f
                    val rawMid = if (midN > 0) mid / midN else 0f
                    val rawVocal = if (vocalN > 0) vocal / vocalN else 0f
                    val rawTreble = if (trebleN > 0) treble / trebleN else 0f
                    peakBass = max(peakBass * 0.997f, rawBass).coerceAtLeast(4f)
                    peakMid = max(peakMid * 0.997f, rawMid).coerceAtLeast(4f)
                    peakVocal = max(peakVocal * 0.997f, rawVocal).coerceAtLeast(4f)
                    peakTreble = max(peakTreble * 0.997f, rawTreble).coerceAtLeast(3f)
                    val nb = (rawBass / peakBass).coerceIn(0f, 1f)
                    val nm = (rawMid / peakMid).coerceIn(0f, 1f)
                    val nv = (rawVocal / peakVocal).coerceIn(0f, 1f)
                    val nt = (rawTreble / peakTreble).coerceIn(0f, 1f)
                    bassSm += (nb - bassSm) * (if (nb > bassSm) 0.65f else 0.18f)
                    midSm += (nm - midSm) * (if (nm > midSm) 0.55f else 0.16f)
                    vocalSm += (nv - vocalSm) * (if (nv > vocalSm) 0.5f else 0.14f)
                    trebleSm += (nt - trebleSm) * (if (nt > trebleSm) 0.6f else 0.2f)
                    // Kick: sudden rise of the bass above its slow average.
                    bassSlow += (nb - bassSlow) * 0.04f
                    val rise = nb - bassSlow * 1.15f - 0.12f
                    if (rise > 0.08f) drive.liveKickImpulse = max(drive.liveKickImpulse, (rise * 3f).coerceIn(0.35f, 1f))
                    drive.bass = bassSm; drive.mid = midSm; drive.vocal = vocalSm; drive.treble = trebleSm
                }
                delay(36L)
            }
        } finally {
            drive.hasLiveBands = false
            runCatching { visualizer.enabled = false }
            runCatching { visualizer.release() }
        }
    }
}

/** Spectral-flux front end: 1024-point FFT every 256 samples, log-compressed positive flux. */
internal class FluxExtractor(private val sampleRate: Int) {
    private val n = 1024
    private val hop = 256
    private val ring = FloatArray(n)
    private var pos = 0
    private var count = 0
    private var filled = 0
    private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val fft = Fft(n)
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val prev = FloatArray(n / 2)
    private val kMax = min(n / 2 - 1, (10000.0 * n / sampleRate).toInt())
    private val kLow = max(2, (250.0 * n / sampleRate).toInt())
    val all = FloatArrayBuilder(32768)
    val low = FloatArrayBuilder(32768)
    val hopMs: Float get() = hop * 1000f / sampleRate
    /** A flux peak lags the window centre by roughly a quarter window; this brings it to the onset. */
    val frameOffsetMs: Float get() = (n * 0.75f) * 1000f / sampleRate

    fun add(x: Float) {
        ring[pos] = x
        pos = (pos + 1) % n
        if (filled < n) filled++
        count++
        if (count >= hop) {
            count = 0
            if (filled >= n) frame()
        }
    }

    private fun frame() {
        for (i in 0 until n) {
            re[i] = ring[(pos + i) % n] * window[i]
            im[i] = 0f
        }
        fft.transform(re, im)
        var fa = 0f
        var fl = 0f
        val scale = 1f / (n / 8f)
        for (k in 1..kMax) {
            val mag = sqrt(re[k] * re[k] + im[k] * im[k]) * scale
            val lm = ln(1f + 30f * mag)
            val d = lm - prev[k]
            if (d > 0f) {
                fa += d
                if (k <= kLow) fl += d
            }
            prev[k] = lm
        }
        all.add(fa)
        low.add(fl)
    }
}

internal class Fft(private val n: Int) {
    private val cosT = FloatArray(n / 2) { cos(2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { (-sin(2.0 * PI * it / n)).toFloat() }
    private val rev = IntArray(n)

    init {
        var bits = 0
        while ((1 shl bits) < n) bits++
        for (i in 0 until n) {
            var r = 0
            var x = i
            for (b in 0 until bits) {
                r = (r shl 1) or (x and 1)
                x = x shr 1
            }
            rev[i] = r
        }
    }

    fun transform(re: FloatArray, im: FloatArray) {
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val tr = re[i]; re[i] = re[j]; re[j] = tr
                val ti = im[i]; im[i] = im[j]; im[j] = ti
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                var k = 0
                for (j in i until i + half) {
                    val tr = re[j + half] * cosT[k] - im[j + half] * sinT[k]
                    val ti = re[j + half] * sinT[k] + im[j + half] * cosT[k]
                    re[j + half] = re[j] - tr
                    im[j + half] = im[j] - ti
                    re[j] += tr
                    im[j] += ti
                    k += step
                }
                i += size
            }
            size *= 2
        }
    }
}

/** Offline beat/kick analysis: decodes the song once with MediaCodec and caches the result. */
internal object BeatAnalyzer {
    private const val MAX_SECONDS = 15 * 60

    fun cacheKey(path: String, size: Long, modified: Long): String {
        val md = MessageDigest.getInstance("SHA-1")
        val bytes = md.digest("$path|$size|$modified|v2".toByteArray())
        val sb = StringBuilder()
        for (b in bytes) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun loadCached(dir: File, key: String): BeatMap? {
        val f = File(dir, "$key.json")
        if (!f.exists()) return null
        return runCatching { BeatMap.fromJson(f.readText()) }.getOrNull()
    }

    fun saveCached(dir: File, key: String, map: BeatMap) {
        runCatching {
            dir.mkdirs()
            val files = dir.listFiles()
            if (files != null && files.size > 80) {
                files.sortedBy { it.lastModified() }.take(files.size - 60).forEach { it.delete() }
            }
            File(dir, "$key.json").writeText(map.toJson())
        }
    }

    /** Blocking. Call from a background dispatcher. Returns null when the source cannot be decoded. */
    fun analyze(context: Context, path: String, shouldContinue: () -> Boolean): BeatMap? {
        if (path.isBlank() || path.startsWith("http", ignoreCase = true)) return null
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            when {
                path.startsWith("content://") -> extractor.setDataSource(context, Uri.parse(path), null)
                path.startsWith("file://") -> extractor.setDataSource(Uri.parse(path).path ?: return null)
                else -> extractor.setDataSource(path)
            }
            var track = -1
            var mime = ""
            for (i in 0 until extractor.trackCount) {
                val m = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
                if (m.startsWith("audio/")) { track = i; mime = m; break }
            }
            if (track < 0) return null
            extractor.selectTrack(track)
            val inFormat = extractor.getTrackFormat(track)
            var sampleRate = if (inFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (inFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var encoding = AudioFormat.ENCODING_PCM_16BIT
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(inFormat, null, null, 0)
            dec.start()

            var flux = FluxExtractor(sampleRate)
            var totalFrames = 0L
            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                if (!shouldContinue()) return null
                if (!inputDone) {
                    val inIdx = dec.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        val buf = dec.getInputBuffer(inIdx)
                        val size = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (size < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = dec.dequeueOutputBuffer(info, 5_000L)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = dec.outputFormat
                    var rate = sampleRate
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) encoding = f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    if (rate != sampleRate && totalFrames == 0L) {
                        sampleRate = rate
                        flux = FluxExtractor(sampleRate)
                    }
                } else if (outIdx >= 0) {
                    val out = dec.getOutputBuffer(outIdx)
                    if (out != null && info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val ch = max(1, channels)
                        if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val fb = out.order(ByteOrder.nativeOrder()).asFloatBuffer()
                            while (fb.remaining() >= ch) {
                                var s = 0f
                                for (c in 0 until ch) s += fb.get()
                                flux.add(s / ch)
                                totalFrames++
                            }
                        } else {
                            val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            while (sb.remaining() >= ch) {
                                var s = 0
                                for (c in 0 until ch) s += sb.get().toInt()
                                flux.add(s / (32768f * ch))
                                totalFrames++
                            }
                        }
                    }
                    dec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    if (totalFrames > sampleRate.toLong() * MAX_SECONDS) outputDone = true
                }
            }
            return computeMap(flux.all.toArray(), flux.low.toArray(), flux.hopMs, flux.frameOffsetMs)
        } catch (t: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    /**
     * Onset envelope -> tempo (autocorrelation) -> beat positions by dynamic programming, which keeps
     * following tempo drift and ignores off-beat hits. Frame times are returned in milliseconds.
     */
    internal fun computeMap(allRaw: FloatArray, lowRaw: FloatArray, hopMs: Float, offsetMs: Float): BeatMap? {
        val n = min(allRaw.size, lowRaw.size)
        if (n * hopMs < 8000f) return null
        var meanA = 0f
        var meanL = 0f
        for (t in 0 until n) { meanA += allRaw[t]; meanL += lowRaw[t] }
        meanA = (meanA / n).coerceAtLeast(1e-6f)
        meanL = (meanL / n).coerceAtLeast(1e-6f)
        val lowN = FloatArray(n)
        val onset = FloatArray(n)
        for (t in 0 until n) {
            lowN[t] = lowRaw[t] / meanL
            onset[t] = 0.6f * allRaw[t] / meanA + 0.5f * lowN[t]
        }
        var m = 0f
        for (v in onset) m += v
        m = (m / n).coerceAtLeast(1e-6f)
        for (t in 0 until n) onset[t] /= m

        val minLag = max(2, (300f / hopMs).toInt())
        val maxLag = (1000f / hopMs).toInt()
        val acf = FloatArray(maxLag + 2)
        for (lag in minLag..maxLag) {
            var s = 0f
            var t = 0
            while (t + lag < n) { s += onset[t] * onset[t + lag]; t++ }
            acf[lag] = s / (n - lag)
        }
        var bestLag = minLag
        var bestScore = -1f
        var meanAcf = 0f
        var cnt = 0
        for (lag in minLag..maxLag) {
            val bpm = 60000f / (lag * hopMs)
            val z = ln(bpm / 120f) / 0.75f
            val score = acf[lag] * (0.55f + 0.45f * exp(-0.5f * z * z))
            meanAcf += acf[lag]; cnt++
            if (score > bestScore) { bestScore = score; bestLag = lag }
        }
        meanAcf /= max(1, cnt)
        var period = bestLag.toFloat()
        if (bestLag > minLag && bestLag < maxLag) {
            val y0 = acf[bestLag - 1]; val y1 = acf[bestLag]; val y2 = acf[bestLag + 1]
            val denom = y0 - 2f * y1 + y2
            if (denom < -1e-9f) period += (0.5f * (y0 - y2) / denom).coerceIn(-0.5f, 0.5f)
        }
        val bpm = 60000f / (period * hopMs)

        // Dynamic programming: best-scoring chain of onsets spaced about one period apart.
        val w0 = max(1, (period * 0.5f).roundToInt())
        val w1 = max(w0 + 1, (period * 2f).roundToInt())
        val cost = FloatArray(w1 + 1)
        for (d in w0..w1) {
            val z = ln(d / period)
            cost[d] = -300f * z * z
        }
        val cum = onset.copyOf()
        val back = IntArray(n) { -1 }
        for (t in 0 until n) {
            val lo = max(0, t - w1)
            val hi = t - w0
            if (hi < lo) continue
            var bestV = -1e9f
            var bestP = -1
            for (p in lo..hi) {
                val v = cum[p] + cost[t - p]
                if (v > bestV) { bestV = v; bestP = p }
            }
            if (bestV > 0f) { cum[t] = onset[t] + bestV; back[t] = bestP }
        }
        val tail = max(0, n - (period * 1.5f).toInt())
        var end = tail
        for (t in tail until n) if (cum[t] > cum[end]) end = t
        val frames = ArrayList<Int>()
        var cur = end
        while (cur >= 0) { frames.add(cur); cur = back[cur] }
        frames.reverse()
        while (frames.size > 6 && onset[frames[0]] < 0.8f) frames.removeAt(0)
        while (frames.size > 6 && onset[frames[frames.size - 1]] < 0.8f) frames.removeAt(frames.size - 1)
        if (frames.size < 4) return null

        val beats = ArrayList<Int>()
        val strengths = ArrayList<Float>()
        val beatFrames = ArrayList<Int>()
        for (f in frames) {
            var bi = f
            for (j in max(0, f - 2)..min(n - 1, f + 2)) if (onset[j] > onset[bi]) bi = j
            beats += (bi * hopMs + offsetMs).toInt()
            beatFrames += bi
            strengths += 0.45f + 0.55f * (onset[bi] / 3f).coerceIn(0f, 1f)
        }
        val confident = acf[bestLag] > meanAcf * 1.35f && beats.size >= 8

        val barSum = FloatArray(4)
        for (i in beatFrames.indices) barSum[i % 4] += lowN[beatFrames[i]]
        var downOffset = 0
        for (o in 1 until 4) if (barSum[o] > barSum[downOffset]) downOffset = o
        for (i in beats.indices) if ((i - downOffset) % 4 != 0) strengths[i] = strengths[i] * 0.78f

        var lm = 0f
        for (v in lowN) lm += v
        lm /= n
        var varSum = 0f
        for (v in lowN) varSum += (v - lm) * (v - lm)
        val thr = lm + 1.8f * sqrt(varSum / n)
        val minGap = max(2, (150f / hopMs).toInt())
        val kicks = ArrayList<Int>()
        var lastKick = -minGap
        for (t in 2 until n - 2) {
            val v = lowN[t]
            if (v > thr && v >= lowN[t - 1] && v >= lowN[t + 1] && t - lastKick >= minGap) {
                kicks += (t * hopMs + offsetMs).toInt()
                lastKick = t
            }
        }
        return BeatMap(beats.toIntArray(), strengths.toFloatArray(), kicks.toIntArray(), bpm, confident, downOffset)
    }
}

internal class FloatArrayBuilder(initial: Int) {
    private var data = FloatArray(max(16, initial))
    var size = 0
        private set

    fun add(v: Float) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }

    fun toArray(): FloatArray = data.copyOf(size)
}
