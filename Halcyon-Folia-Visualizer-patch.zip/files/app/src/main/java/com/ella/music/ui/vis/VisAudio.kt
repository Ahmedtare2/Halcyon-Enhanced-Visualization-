package com.ella.music.ui.vis

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.audiofx.Visualizer
import android.net.Uri
import java.io.File
import java.nio.ByteOrder
import java.security.MessageDigest
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.currentCoroutineContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * Per-frame audio-reactive values shared with every style and background.
 * Written from a worker coroutine (bands) and the frame loop (beat pulses), read while drawing.
 */
internal class AudioDrive {
    @Volatile var bass = 0f
    @Volatile var mid = 0f
    @Volatile var vocal = 0f
    @Volatile var treble = 0f
    @Volatile var liveKickImpulse = 0f
    @Volatile var hasLiveBands = false

    /** Smoothed 0..1 loudness blend. */
    var energy = 0f
    /** 1 on a beat, decays towards 0. */
    var beat = 0f
    /** 0..1 position between two beats. */
    var beatPhase = 0f
    /** Pulse on the low-frequency hits (kick drum). */
    var kick = 0f
    var bpm = 0f
    var downbeat = false
    var beatIndex = 0
    /** True while pulses come from an analysed beat grid (swing/lock effects may rely on beatPhase). */
    var locked = false

    private var lastBeatIdx = -1
    private var lastLiveBeatSec = -10f
    private var beatPulseLive = 0f

    fun reset() {
        energy = 0f; beat = 0f; beatPhase = 0f; kick = 0f; bpm = 0f; downbeat = false
        lastBeatIdx = -1; beatPulseLive = 0f
    }

    /**
     * @param map analysed beat grid for the current song, if any
     * @param reactive master switch for audio reactive values
     * @param beatFx master switch for beat pulses
     * @param offsetMs user timing offset applied to the beat grid
     */
    fun step(
        posMs: Long, dt: Float, timeSec: Float, playing: Boolean,
        map: BeatMap?, reactive: Boolean, beatFx: Boolean, offsetMs: Int
    ) {
        if (!playing) {
            energy *= 0.92f; beat *= 0.9f; kick *= 0.9f
            return
        }
        val target = if (reactive && hasLiveBands) (0.5f * bass + 0.3f * mid + 0.2f * treble) else 0f
        energy += (target - energy) * min(1f, dt * 8f)

        if (!beatFx) { beat *= 0.85f; kick *= 0.85f; return }
        val t = posMs - offsetMs
        var mapBeat = 0f
        var mapKick = 0f
        var usedMap = false
        locked = false
        if (map != null) {
            bpm = map.bpm
            if (map.confident && map.beatsMs.isNotEmpty()) {
                val i = map.beatIndexAt(t)
                if (i >= 0) {
                    val t0 = map.beatsMs[i]
                    val t1 = if (i + 1 < map.beatsMs.size) map.beatsMs[i + 1] else t0 + (60000f / max(60f, map.bpm)).toInt()
                    val span = max(1, t1 - t0).toFloat()
                    val ph = ((t - t0) / span).coerceIn(0f, 1f)
                    beatPhase = ph
                    mapBeat = exp(-ph * 3.4f) * map.beatStrength[i]
                    if (i != lastBeatIdx) { lastBeatIdx = i; beatIndex = i; downbeat = map.isDownbeat(i) }
                    usedMap = true
                    locked = true
                }
            }
            if (map.kicksMs.isNotEmpty()) {
                val k = map.kickIndexAt(t)
                if (k >= 0) {
                    val ageMs = (t - map.kicksMs[k]).coerceAtLeast(0)
                    mapKick = exp(-ageMs / 120f)
                    usedMap = true
                }
            }
        }
        // Live fallback: bass flux from the FFT feed when there is no usable beat grid.
        val impulse = liveKickImpulse
        if (impulse > 0f) {
            liveKickImpulse = 0f
            if (timeSec - lastLiveBeatSec > 0.16f) { beatPulseLive = max(beatPulseLive, impulse); lastLiveBeatSec = timeSec }
        }
        beatPulseLive *= exp(-dt * 7f)
        val liveBeat = if (reactive) beatPulseLive else 0f
        val b = if (usedMap) mapBeat else liveBeat
        val k = if (usedMap) mapKick else liveBeat
        beat = max(b, beat * exp(-dt * 9f))
        kick = max(k, kick * exp(-dt * 11f))
    }
}

/** Beat grid and kick onsets for one song. All times in milliseconds. */
internal class BeatMap(
    val beatsMs: IntArray,
    val beatStrength: FloatArray,
    val kicksMs: IntArray,
    val bpm: Float,
    val confident: Boolean,
    private val downbeatOffset: Int
) {
    fun beatIndexAt(tMs: Long): Int = lastAtOrBefore(beatsMs, tMs)
    fun kickIndexAt(tMs: Long): Int = lastAtOrBefore(kicksMs, tMs)
    fun isDownbeat(i: Int): Boolean = (i - downbeatOffset) % 4 == 0

    private fun lastAtOrBefore(arr: IntArray, t: Long): Int {
        var lo = 0
        var hi = arr.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (arr[mid] <= t) { ans = mid; lo = mid + 1 } else hi = mid - 1
        }
        return ans
    }

    fun toJson(): String {
        val o = JSONObject()
        o.put("v", 1)
        o.put("bpm", bpm.toDouble())
        o.put("conf", confident)
        o.put("db", downbeatOffset)
        o.put("beats", JSONArray().also { a -> beatsMs.forEach { a.put(it) } })
        o.put("str", JSONArray().also { a -> beatStrength.forEach { a.put(it.toDouble()) } })
        o.put("kicks", JSONArray().also { a -> kicksMs.forEach { a.put(it) } })
        return o.toString()
    }

    companion object {
        fun fromJson(raw: String): BeatMap? = runCatching {
            val o = JSONObject(raw)
            if (o.optInt("v") != 1) return@runCatching null
            val beats = o.getJSONArray("beats")
            val str = o.getJSONArray("str")
            val kicks = o.getJSONArray("kicks")
            BeatMap(
                IntArray(beats.length()) { beats.getInt(it) },
                FloatArray(str.length()) { str.getDouble(it).toFloat() },
                IntArray(kicks.length()) { kicks.getInt(it) },
                o.optDouble("bpm", 0.0).toFloat(),
                o.optBoolean("conf", false),
                o.optInt("db", 0)
            )
        }.getOrNull()
    }
}

/** Reads the FFT of the player's audio session and turns it into band levels and kick impulses. */
internal object VisBands {
    suspend fun run(drive: AudioDrive, sessionId: Int, isPlaying: () -> Boolean) {
        val visualizer = runCatching {
            Visualizer(sessionId).apply {
                captureSize = Visualizer.getCaptureSizeRange()[1].coerceAtMost(1024)
                scalingMode = Visualizer.SCALING_MODE_NORMALIZED
                enabled = true
            }
        }.getOrNull() ?: return
        val buffer = ByteArray(visualizer.captureSize)
        val sampleRateHz = (visualizer.samplingRate / 1000).coerceAtLeast(8000)
        val binHz = sampleRateHz.toFloat() / visualizer.captureSize.toFloat()
        var peakBass = 1f
        var peakMid = 1f
        var peakVocal = 1f
        var peakTreble = 1f
        var bassSlow = 0f
        var bassSm = 0f
        var midSm = 0f
        var vocalSm = 0f
        var trebleSm = 0f
        try {
            drive.hasLiveBands = true
            while (currentCoroutineContext().isActive) {
                if (!isPlaying()) {
                    bassSm *= 0.8f; midSm *= 0.8f; vocalSm *= 0.8f; trebleSm *= 0.8f
                    drive.bass = bassSm; drive.mid = midSm; drive.vocal = vocalSm; drive.treble = trebleSm
                    delay(120L)
                    continue
                }
                if (visualizer.getFft(buffer) == Visualizer.SUCCESS) {
                    val bins = buffer.size / 2
                    var bass = 0f; var bassN = 0
                    var mid = 0f; var midN = 0
                    var vocal = 0f; var vocalN = 0
                    var treble = 0f; var trebleN = 0
                    for (k in 1 until bins) {
                        val re = buffer[2 * k].toInt().toFloat()
                        val im = buffer[2 * k + 1].toInt().toFloat()
                        val mag = sqrt(re * re + im * im)
                        val hz = k * binHz
                        if (hz in 30f..150f) { bass += mag; bassN++ }
                        if (hz in 400f..2500f) { mid += mag; midN++ }
                        if (hz in 250f..3500f) { vocal += mag; vocalN++ }
                        if (hz in 4000f..14000f) { treble += mag; trebleN++ }
                    }
                    val rawBass = if (bassN > 0) bass / bassN else 0f
                    val rawMid = if (midN > 0) mid / midN else 0f
                    val rawVocal = if (vocalN > 0) vocal / vocalN else 0f
                    val rawTreble = if (trebleN > 0) treble / trebleN else 0f
                    peakBass = max(peakBass * 0.997f, rawBass).coerceAtLeast(4f)
                    peakMid = max(peakMid * 0.997f, rawMid).coerceAtLeast(4f)
                    peakVocal = max(peakVocal * 0.997f, rawVocal).coerceAtLeast(4f)
                    peakTreble = max(peakTreble * 0.997f, rawTreble).coerceAtLeast(3f)
                    val nb = (rawBass / peakBass).coerceIn(0f, 1f)
                    val nm = (rawMid / peakMid).coerceIn(0f, 1f)
                    val nv = (rawVocal / peakVocal).coerceIn(0f, 1f)
                    val nt = (rawTreble / peakTreble).coerceIn(0f, 1f)
                    bassSm += (nb - bassSm) * (if (nb > bassSm) 0.65f else 0.18f)
                    midSm += (nm - midSm) * (if (nm > midSm) 0.55f else 0.16f)
                    vocalSm += (nv - vocalSm) * (if (nv > vocalSm) 0.5f else 0.14f)
                    trebleSm += (nt - trebleSm) * (if (nt > trebleSm) 0.6f else 0.2f)
                    // Kick: sudden rise of the bass above its slow average.
                    bassSlow += (nb - bassSlow) * 0.04f
                    val rise = nb - bassSlow * 1.15f - 0.12f
                    if (rise > 0.08f) drive.liveKickImpulse = max(drive.liveKickImpulse, (rise * 3f).coerceIn(0.35f, 1f))
                    drive.bass = bassSm; drive.mid = midSm; drive.vocal = vocalSm; drive.treble = trebleSm
                }
                delay(24L)
            }
        } finally {
            drive.hasLiveBands = false
            runCatching { visualizer.enabled = false }
            runCatching { visualizer.release() }
        }
    }
}

/** Offline beat/kick analysis: decodes the song once with MediaCodec and caches the result. */
internal object BeatAnalyzer {
    private const val HOPS_PER_SEC = 100
    private const val MAX_SECONDS = 15 * 60

    fun cacheKey(path: String, size: Long, modified: Long): String {
        val md = MessageDigest.getInstance("SHA-1")
        val bytes = md.digest("$path|$size|$modified".toByteArray())
        val sb = StringBuilder()
        for (b in bytes) sb.append(String.format("%02x", b))
        return sb.toString()
    }

    fun loadCached(dir: File, key: String): BeatMap? {
        val f = File(dir, "$key.json")
        if (!f.exists()) return null
        return runCatching { BeatMap.fromJson(f.readText()) }.getOrNull()
    }

    fun saveCached(dir: File, key: String, map: BeatMap) {
        runCatching {
            dir.mkdirs()
            val files = dir.listFiles()
            if (files != null && files.size > 80) {
                files.sortedBy { it.lastModified() }.take(files.size - 60).forEach { it.delete() }
            }
            File(dir, "$key.json").writeText(map.toJson())
        }
    }

    /** Blocking. Call from a background dispatcher. Returns null when the source cannot be decoded. */
    fun analyze(context: Context, path: String, shouldContinue: () -> Boolean): BeatMap? {
        if (path.isBlank() || path.startsWith("http", ignoreCase = true)) return null
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        try {
            when {
                path.startsWith("content://") -> extractor.setDataSource(context, Uri.parse(path), null)
                path.startsWith("file://") -> extractor.setDataSource(Uri.parse(path).path ?: return null)
                else -> extractor.setDataSource(path)
            }
            var track = -1
            var mime = ""
            for (i in 0 until extractor.trackCount) {
                val m = extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME).orEmpty()
                if (m.startsWith("audio/")) { track = i; mime = m; break }
            }
            if (track < 0) return null
            extractor.selectTrack(track)
            val inFormat = extractor.getTrackFormat(track)
            var sampleRate = if (inFormat.containsKey(MediaFormat.KEY_SAMPLE_RATE)) inFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
            var channels = if (inFormat.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) inFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
            var encoding = AudioFormat.ENCODING_PCM_16BIT
            val dec = MediaCodec.createDecoderByType(mime)
            codec = dec
            dec.configure(inFormat, null, null, 0)
            dec.start()

            val low = FloatArrayBuilder(24000)
            val high = FloatArrayBuilder(24000)
            var hop = sampleRate / HOPS_PER_SEC
            var lp1 = 0f
            var lp2 = 0f
            var a1 = 1f - exp(-2f * Math.PI.toFloat() * 150f / sampleRate)
            var a2 = 1f - exp(-2f * Math.PI.toFloat() * 2000f / sampleRate)
            var accLow = 0f
            var accHigh = 0f
            var accN = 0
            var totalFrames = 0L

            val info = MediaCodec.BufferInfo()
            var inputDone = false
            var outputDone = false
            while (!outputDone) {
                if (!shouldContinue()) return null
                if (!inputDone) {
                    val inIdx = dec.dequeueInputBuffer(5_000L)
                    if (inIdx >= 0) {
                        val buf = dec.getInputBuffer(inIdx)
                        val size = if (buf != null) extractor.readSampleData(buf, 0) else -1
                        if (size < 0) {
                            dec.queueInputBuffer(inIdx, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            dec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }
                val outIdx = dec.dequeueOutputBuffer(info, 5_000L)
                if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val f = dec.outputFormat
                    if (f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    if (f.containsKey(MediaFormat.KEY_PCM_ENCODING)) encoding = f.getInteger(MediaFormat.KEY_PCM_ENCODING)
                    hop = sampleRate / HOPS_PER_SEC
                    a1 = 1f - exp(-2f * Math.PI.toFloat() * 150f / sampleRate)
                    a2 = 1f - exp(-2f * Math.PI.toFloat() * 2000f / sampleRate)
                } else if (outIdx >= 0) {
                    val out = dec.getOutputBuffer(outIdx)
                    if (out != null && info.size > 0) {
                        out.position(info.offset)
                        out.limit(info.offset + info.size)
                        val ch = max(1, channels)
                        if (encoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            val fb = out.order(ByteOrder.nativeOrder()).asFloatBuffer()
                            while (fb.remaining() >= ch) {
                                var s = 0f
                                for (c in 0 until ch) s += fb.get()
                                val mono = s / ch
                                lp1 += a1 * (mono - lp1)
                                lp2 += a2 * (mono - lp2)
                                val hp = mono - lp2
                                accLow += lp1 * lp1; accHigh += hp * hp; accN++
                                if (accN >= hop) {
                                    low.add(sqrt(accLow / accN)); high.add(sqrt(accHigh / accN))
                                    accLow = 0f; accHigh = 0f; accN = 0
                                }
                                totalFrames++
                            }
                        } else {
                            val sb = out.order(ByteOrder.nativeOrder()).asShortBuffer()
                            while (sb.remaining() >= ch) {
                                var s = 0
                                for (c in 0 until ch) s += sb.get().toInt()
                                val mono = s / (32768f * ch)
                                lp1 += a1 * (mono - lp1)
                                lp2 += a2 * (mono - lp2)
                                val hp = mono - lp2
                                accLow += lp1 * lp1; accHigh += hp * hp; accN++
                                if (accN >= hop) {
                                    low.add(sqrt(accLow / accN)); high.add(sqrt(accHigh / accN))
                                    accLow = 0f; accHigh = 0f; accN = 0
                                }
                                totalFrames++
                            }
                        }
                    }
                    dec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                    if (totalFrames > sampleRate.toLong() * MAX_SECONDS) outputDone = true
                }
            }
            return computeMap(low.toArray(), high.toArray())
        } catch (t: Throwable) {
            return null
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    internal fun computeMap(low: FloatArray, high: FloatArray): BeatMap? {
        val n = min(low.size, high.size)
        if (n < HOPS_PER_SEC * 8) return null
        val fluxLow = FloatArray(n)
        val onset = FloatArray(n)
        var prevL = ln(1f + 80f * low[0])
        var prevH = ln(1f + 60f * high[0])
        for (t in 1 until n) {
            val l = ln(1f + 80f * low[t])
            val h = ln(1f + 60f * high[t])
            val fl = max(0f, l - prevL)
            val fh = max(0f, h - prevH)
            fluxLow[t] = fl
            onset[t] = fl + 0.6f * fh
            prevL = l; prevH = h
        }
        // 3-tap smoothing and normalisation
        val sm = FloatArray(n)
        for (t in 1 until n - 1) sm[t] = (onset[t - 1] + 2f * onset[t] + onset[t + 1]) * 0.25f
        var mean = 0f
        for (v in sm) mean += v
        mean = (mean / n).coerceAtLeast(1e-6f)
        for (t in 0 until n) sm[t] /= mean

        // Tempo: autocorrelation over 60..200 BPM with a soft prior around 120 BPM.
        val minLag = HOPS_PER_SEC * 60 / 200
        val maxLag = HOPS_PER_SEC * 60 / 60
        val acf = FloatArray(maxLag + 2)
        for (lag in minLag..maxLag) {
            var s = 0f
            var t = 0
            while (t + lag < n) { s += sm[t] * sm[t + lag]; t++ }
            acf[lag] = s / (n - lag)
        }
        var bestLag = minLag
        var bestScore = -1f
        var meanAcf = 0f
        var cnt = 0
        for (lag in minLag..maxLag) {
            val bpm = 6000f / lag
            val prior = exp(-0.5f * (ln(bpm / 120f) / 0.75f) * (ln(bpm / 120f) / 0.75f))
            val score = acf[lag] * (0.55f + 0.45f * prior)
            meanAcf += acf[lag]; cnt++
            if (score > bestScore) { bestScore = score; bestLag = lag }
        }
        meanAcf /= max(1, cnt)
        val confident = acf[bestLag] > meanAcf * 1.35f
        // Parabolic refinement of the period.
        var period = bestLag.toFloat()
        if (bestLag > minLag && bestLag < maxLag) {
            val y0 = acf[bestLag - 1]; val y1 = acf[bestLag]; val y2 = acf[bestLag + 1]
            val denom = y0 - 2f * y1 + y2
            if (denom < -1e-9f) period += (0.5f * (y0 - y2) / denom).coerceIn(-0.5f, 0.5f)
        }
        val bpm = 6000f / period

        // Phase: choose the offset whose comb sums the most onset energy.
        val lagInt = max(1, period.toInt())
        var bestPhase = 0
        var bestPhaseScore = -1f
        for (p in 0 until lagInt) {
            var s = 0f
            var k = 0
            while (true) {
                val idx = p + (k * period).toInt()
                if (idx >= n) break
                s += sm[idx]
                k++
            }
            if (s > bestPhaseScore) { bestPhaseScore = s; bestPhase = p }
        }
        val beats = ArrayList<Int>()
        val strengths = ArrayList<Float>()
        var cur = bestPhase.toFloat()
        val win = max(1, (period * 0.18f).toInt())
        while (cur < n) {
            val c = cur.toInt()
            var bi = c
            var bv = -1f
            for (j in max(0, c - win)..min(n - 1, c + win)) {
                if (sm[j] > bv) { bv = sm[j]; bi = j }
            }
            beats += bi * 1000 / HOPS_PER_SEC
            strengths += (0.45f + 0.55f * (bv / 3f).coerceIn(0f, 1f))
            cur = 0.7f * (bi + period) + 0.3f * (cur + period)
        }
        // Downbeat: the offset in a 4-beat bar with the most low-frequency flux.
        val barSum = FloatArray(4)
        for (i in beats.indices) {
            val h = (beats[i] * HOPS_PER_SEC / 1000).coerceIn(0, n - 1)
            barSum[i % 4] += fluxLow[h]
        }
        var downOffset = 0
        for (o in 1 until 4) if (barSum[o] > barSum[downOffset]) downOffset = o
        for (i in beats.indices) if ((i - downOffset) % 4 != 0) strengths[i] = strengths[i] * 0.78f

        // Kicks: local maxima of low-band flux above an adaptive threshold.
        var m = 0f
        for (v in fluxLow) m += v
        m /= n
        var varSum = 0f
        for (v in fluxLow) varSum += (v - m) * (v - m)
        val thr = m + 1.8f * sqrt(varSum / n)
        val kicks = ArrayList<Int>()
        var lastKick = -100
        for (t in 2 until n - 2) {
            val v = fluxLow[t]
            if (v > thr && v >= fluxLow[t - 1] && v >= fluxLow[t + 1] && t - lastKick >= 15) {
                kicks += t * 1000 / HOPS_PER_SEC
                lastKick = t
            }
        }
        return BeatMap(
            beats.toIntArray(), strengths.toFloatArray(), kicks.toIntArray(),
            bpm, confident, downOffset
        )
    }
}

internal class FloatArrayBuilder(initial: Int) {
    private var data = FloatArray(max(16, initial))
    var size = 0
        private set

    fun add(v: Float) {
        if (size == data.size) data = data.copyOf(data.size * 2)
        data[size++] = v
    }

    fun toArray(): FloatArray = data.copyOf(size)
}
