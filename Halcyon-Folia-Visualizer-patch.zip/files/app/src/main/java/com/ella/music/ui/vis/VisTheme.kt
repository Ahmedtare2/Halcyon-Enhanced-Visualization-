package com.ella.music.ui.vis

import android.graphics.Typeface
import org.json.JSONArray
import org.json.JSONObject

internal enum class VisFont(val label: String) {
    SANS("Sans"),
    SERIF("Serif"),
    CONDENSED("Condensed"),
    MONO("Mono"),
    SCRIPT("Script"),
    HALCYON("App font");

    companion object {
        fun fromName(name: String?): VisFont =
            values().firstOrNull { it.name.equals(name, ignoreCase = true) } ?: SANS
    }
}

/** Resolved colour/typography theme every style and background draws with. */
internal class VisTheme(
    val id: String,
    val name: String,
    val bgTop: Int,
    val bgMid: Int,
    val bgBottom: Int,
    val text: Int,
    val accent: Int,
    val accent2: Int,
    val font: VisFont = VisFont.SANS,
    /** 0.5 calm … 1.5 energetic; scales motion amplitude in styles. */
    val intensity: Float = 1f,
    val light: Boolean = false
) {
    val textDim: Int get() = withAlpha(text, 0.34f)
    val textSoft: Int get() = withAlpha(text, 0.62f)

    fun withFont(f: VisFont): VisTheme =
        VisTheme(id, name, bgTop, bgMid, bgBottom, text, accent, accent2, f, intensity, light)

    fun toJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("name", name)
        .put("bgTop", bgTop)
        .put("bgMid", bgMid)
        .put("bgBottom", bgBottom)
        .put("text", text)
        .put("accent", accent)
        .put("accent2", accent2)
        .put("font", font.name)
        .put("intensity", intensity.toDouble())
        .put("light", light)

    companion object {
        fun fromJson(o: JSONObject): VisTheme? = runCatching {
            VisTheme(
                id = o.optString("id").ifBlank { "custom-" + System.currentTimeMillis() },
                name = o.optString("name").ifBlank { "Custom" },
                bgTop = o.getInt("bgTop"),
                bgMid = o.getInt("bgMid"),
                bgBottom = o.getInt("bgBottom"),
                text = o.getInt("text"),
                accent = o.getInt("accent"),
                accent2 = o.optInt("accent2", o.getInt("accent")),
                font = VisFont.fromName(o.optString("font")),
                intensity = o.optDouble("intensity", 1.0).toFloat().coerceIn(0.4f, 1.6f),
                light = o.optBoolean("light", false)
            )
        }.getOrNull()

        fun listToJson(list: List<VisTheme>): String {
            val arr = JSONArray()
            list.forEach { arr.put(it.toJson()) }
            return arr.toString()
        }

        fun listFromJson(raw: String?): List<VisTheme> {
            if (raw.isNullOrBlank()) return emptyList()
            return runCatching {
                val arr = JSONArray(raw)
                val out = ArrayList<VisTheme>()
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    fromJson(o)?.let { out += it }
                }
                out
            }.getOrDefault(emptyList())
        }

        /** Parses "#RRGGBB" / "#AARRGGBB"; returns null when invalid. */
        fun parseColor(raw: String?): Int? {
            if (raw.isNullOrBlank()) return null
            return runCatching { android.graphics.Color.parseColor(raw.trim()) }.getOrNull()
        }
    }
}

internal object VisThemes {
    const val COVER_ID = "cover"

    val presets: List<VisTheme> = listOf(
        VisTheme("midnight", "Midnight",
            argb(14, 20, 40), argb(10, 14, 30), argb(4, 6, 16),
            argb(236, 240, 250), argb(255, 196, 64), argb(96, 170, 255), VisFont.SANS, 1f),
        VisTheme("sunset", "Sunset",
            argb(72, 28, 64), argb(150, 52, 70), argb(30, 12, 30),
            argb(255, 240, 228), argb(255, 170, 80), argb(255, 96, 140), VisFont.SERIF, 1.1f),
        VisTheme("aurora", "Aurora",
            argb(6, 30, 40), argb(8, 50, 60), argb(4, 12, 24),
            argb(230, 255, 248), argb(110, 255, 200), argb(140, 120, 255), VisFont.SANS, 1f),
        VisTheme("sakura", "Sakura",
            argb(70, 30, 52), argb(110, 44, 72), argb(34, 14, 28),
            argb(255, 238, 244), argb(255, 150, 190), argb(255, 210, 120), VisFont.SERIF, 0.9f),
        VisTheme("neon", "Neon",
            argb(18, 6, 36), argb(30, 8, 54), argb(6, 2, 16),
            argb(246, 240, 255), argb(0, 240, 255), argb(255, 60, 200), VisFont.CONDENSED, 1.35f),
        VisTheme("forest", "Forest",
            argb(12, 36, 28), argb(10, 52, 38), argb(4, 16, 12),
            argb(236, 250, 238), argb(170, 240, 110), argb(255, 214, 120), VisFont.SERIF, 0.85f),
        VisTheme("ember", "Ember",
            argb(40, 10, 8), argb(70, 16, 10), argb(14, 4, 4),
            argb(255, 238, 224), argb(255, 120, 50), argb(255, 200, 90), VisFont.CONDENSED, 1.25f),
        VisTheme("paper", "Paper",
            argb(246, 240, 228), argb(238, 230, 214), argb(222, 212, 194),
            argb(34, 30, 26), argb(196, 70, 40), argb(40, 110, 160), VisFont.SERIF, 0.8f, light = true),
        VisTheme("mono", "Mono",
            argb(24, 24, 26), argb(14, 14, 16), argb(4, 4, 6),
            argb(244, 244, 244), argb(255, 255, 255), argb(160, 160, 170), VisFont.MONO, 1f)
    )

    fun byId(id: String, custom: List<VisTheme>): VisTheme? =
        presets.firstOrNull { it.id == id } ?: custom.firstOrNull { it.id == id }

    /** Builds the dynamic theme from the player's cover palette (ARGB ints). */
    fun fromCover(top: Int, middle: Int, bottom: Int, accent: Int, onBackground: Int, isLight: Boolean): VisTheme {
        val textColor = if (isLight) argb(24, 24, 28) else argb(250, 250, 252)
        val acc = if (isLight) accent else vivid(accent, 0.62f)
        val acc2 = if (isLight) vivid(middle, 0.2f) else vivid(lerpColor(top, accent, 0.5f), 0.66f)
        return VisTheme(
            id = COVER_ID,
            name = "Cover colours",
            bgTop = withAlpha(top, 1f),
            bgMid = withAlpha(middle, 1f),
            bgBottom = withAlpha(bottom, 1f),
            text = if (onBackground != 0) withAlpha(onBackground, 1f) else textColor,
            accent = acc,
            accent2 = acc2,
            font = VisFont.SANS,
            intensity = 1f,
            light = isLight
        )
    }
}

internal object VisTypefaces {
    private val cache = HashMap<String, Typeface>()

    fun get(font: VisFont, appFontPath: String): Typeface {
        val key = font.name + "|" + (if (font == VisFont.HALCYON) appFontPath else "")
        cache[key]?.let { return it }
        val tf: Typeface = when (font) {
            VisFont.SANS -> Typeface.create("sans-serif-medium", Typeface.BOLD)
            VisFont.SERIF -> Typeface.create("serif", Typeface.BOLD)
            VisFont.CONDENSED -> Typeface.create("sans-serif-condensed", Typeface.BOLD)
            VisFont.MONO -> Typeface.create("monospace", Typeface.BOLD)
            VisFont.SCRIPT -> Typeface.create("cursive", Typeface.NORMAL)
            VisFont.HALCYON -> {
                val custom = if (appFontPath.isNotBlank()) {
                    runCatching { Typeface.createFromFile(appFontPath) }.getOrNull()
                } else null
                custom ?: Typeface.create("sans-serif-medium", Typeface.BOLD)
            }
        }
        if (cache.size > 24) cache.clear()
        cache[key] = tf
        return tf
    }
}
