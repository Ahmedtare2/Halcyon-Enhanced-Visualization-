package com.ella.music.ui.vis

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

internal class BackgroundOption(val id: String, val label: String)

internal object VisBackgroundIds {
    const val HALCYON = "halcyon"
    val options = listOf(
        BackgroundOption(HALCYON, "Player"),
        BackgroundOption("fluid", "Fluid"),
        BackgroundOption("aurora", "Aurora"),
        BackgroundOption("cover", "Cover"),
        BackgroundOption("stars", "Stars"),
        BackgroundOption("waves", "Waves"),
        BackgroundOption("grid", "Grid"),
        BackgroundOption("solid", "Solid")
    )
}

/** Draws the animated backdrop. One instance per page; every buffer is reused between frames. */
internal class VisBackground {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val matrix = Matrix()
    private val rectF = RectF()
    private val blobShaders = arrayOfNulls<RadialGradient>(6)
    private val blobColors = IntArray(6)
    private var baseShader: LinearGradient? = null
    private var baseKey = 0L
    private var vignette: RadialGradient? = null
    private var vignetteSize = 0
    private var coverSmall: Bitmap? = null
    private var coverSource: Bitmap? = null
    private var starPts = FloatArray(0)
    private val starPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }
    private var auroraShader: LinearGradient? = null
    private var auroraKey = 0L

    fun setCover(bitmap: Bitmap?) {
        if (bitmap === coverSource) return
        coverSource = bitmap
        coverSmall = null
        if (bitmap == null || bitmap.isRecycled) return
        coverSmall = runCatching {
            val small = Bitmap.createScaledBitmap(bitmap, 24, 24, true)
            if (small.config == Bitmap.Config.HARDWARE) null else small
        }.getOrNull()
    }

    fun draw(
        c: Canvas, w: Float, h: Float, id: String, theme: VisTheme, t: Float,
        drive: AudioDrive, quality: Float, dim: Float, react: Float
    ) {
        if (id == VisBackgroundIds.HALCYON) {
            // The page composes the player's own background underneath; only add a contrast scrim.
            paint.shader = null
            paint.color = withAlpha(theme.bgBottom, 0.35f + dim * 0.5f)
            c.drawRect(0f, 0f, w, h, paint)
            return
        }
        drawBase(c, w, h, theme)
        val bass = drive.bass * react
        val beat = drive.beat * react
        when (id) {
            "fluid" -> drawFluid(c, w, h, theme, t, bass, beat, quality)
            "aurora" -> drawAurora(c, w, h, theme, t, bass, quality)
            "cover" -> drawCover(c, w, h, theme, t, bass)
            "stars" -> drawStars(c, w, h, theme, t, beat, quality)
            "waves" -> drawWaves(c, w, h, theme, t, bass, quality)
            "grid" -> drawGrid(c, w, h, theme, t, beat)
            else -> Unit
        }
        if (dim > 0.01f) {
            paint.shader = null
            paint.color = withAlpha(if (theme.light) argb(255, 255, 255) else argb(0, 0, 0), dim)
            c.drawRect(0f, 0f, w, h, paint)
        }
        drawVignette(c, w, h, theme)
    }

    private fun drawBase(c: Canvas, w: Float, h: Float, theme: VisTheme) {
        val key = (theme.bgTop.toLong() * 31L + theme.bgMid) * 31L + theme.bgBottom + (h.toLong() shl 40)
        if (baseShader == null || key != baseKey) {
            baseKey = key
            baseShader = LinearGradient(
                0f, 0f, 0f, h,
                intArrayOf(theme.bgTop, theme.bgMid, theme.bgBottom), floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        paint.shader = baseShader
        paint.color = argb(0, 0, 0)
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    private fun drawVignette(c: Canvas, w: Float, h: Float, theme: VisTheme) {
        val size = (max(w, h)).toInt()
        if (vignette == null || size != vignetteSize) {
            vignetteSize = size
            vignette = RadialGradient(
                0f, 0f, 1f,
                intArrayOf(argb(0, 0, 0, 0), argb(0, 0, 0, 0), argb(0, 0, 0, 120)),
                floatArrayOf(0f, 0.55f, 1f), Shader.TileMode.CLAMP
            )
        }
        if (theme.light) return
        val r = max(w, h) * 0.75f
        matrix.reset()
        matrix.postScale(r, r)
        matrix.postTranslate(w * 0.5f, h * 0.5f)
        vignette?.setLocalMatrix(matrix)
        paint.shader = vignette
        c.drawRect(0f, 0f, w, h, paint)
        paint.shader = null
    }

    private fun blobShader(index: Int, color: Int): RadialGradient {
        val existing = blobShaders[index]
        if (existing != null && blobColors[index] == color) return existing
        val s = RadialGradient(
            0f, 0f, 1f, intArrayOf(color, withAlpha(color, 0f)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        blobShaders[index] = s
        blobColors[index] = color
        return s
    }

    private fun blob(c: Canvas, s: RadialGradient, x: Float, y: Float, r: Float) {
        matrix.reset()
        matrix.postScale(r, r)
        matrix.postTranslate(x, y)
        s.setLocalMatrix(matrix)
        paint.shader = s
        c.drawCircle(x, y, r, paint)
    }

    private fun drawFluid(c: Canvas, w: Float, h: Float, th: VisTheme, t: Float, bass: Float, beat: Float, q: Float) {
        val count = if (q < 0.6f) 3 else if (q < 0.85f) 4 else 5
        val base = max(w, h)
        val a = if (th.light) 0.42f else 0.55f
        for (i in 0 until count) {
            val color = when (i % 3) {
                0 -> withAlpha(th.accent, a * 0.9f)
                1 -> withAlpha(th.accent2, a)
                else -> withAlpha(lerpColor(th.bgTop, th.accent, 0.55f), a)
            }
            val s = blobShader(i, color)
            val sp = 0.045f + i * 0.013f
            val x = w * (0.5f + 0.42f * sin(t * sp * 2f * PI.toFloat() + i * 1.7f))
            val y = h * (0.5f + 0.40f * sin(t * (sp * 0.8f) * 2f * PI.toFloat() + i * 2.3f + 1f))
            val r = base * (0.42f + 0.06f * i) * (1f + 0.18f * bass + 0.10f * beat)
            blob(c, s, x, y, r)
        }
        paint.shader = null
    }

    private fun drawAurora(c: Canvas, w: Float, h: Float, th: VisTheme, t: Float, bass: Float, q: Float) {
        val key = th.accent.toLong() * 31L + th.accent2 + (h.toLong() shl 40)
        if (auroraShader == null || key != auroraKey) {
            auroraKey = key
            auroraShader = LinearGradient(
                0f, 0f, 0f, h * 0.7f,
                intArrayOf(withAlpha(th.accent, 0f), withAlpha(th.accent, 0.5f), withAlpha(th.accent2, 0.0f)),
                floatArrayOf(0f, 0.35f, 1f), Shader.TileMode.CLAMP
            )
        }
        val ribbons = if (q < 0.6f) 2 else 3
        paint.shader = auroraShader
        for (r in 0 until ribbons) {
            path.reset()
            val baseY = h * (0.18f + 0.16f * r)
            val amp = h * (0.05f + 0.03f * r) * (1f + 0.5f * bass)
            val steps = 18
            path.moveTo(0f, baseY)
            for (i in 0..steps) {
                val x = w * i / steps
                val y = baseY + amp * sin(i * 0.55f + t * (0.16f + 0.05f * r) * 2f + r * 2f)
                path.lineTo(x, y)
            }
            path.lineTo(w, h * 0.9f)
            path.lineTo(0f, h * 0.9f)
            path.close()
            paint.alpha = (255 * (0.55f - 0.12f * r)).toInt()
            c.drawPath(path, paint)
        }
        paint.alpha = 255
        paint.shader = null
    }

    private fun drawCover(c: Canvas, w: Float, h: Float, th: VisTheme, t: Float, bass: Float) {
        val bmp = coverSmall
        if (bmp == null || bmp.isRecycled) {
            drawFluid(c, w, h, th, t, bass, 0f, 1f)
            return
        }
        val scale = 1.35f + 0.06f * sin(t * 0.05f * 2f * PI.toFloat()) + 0.03f * bass
        val dw = max(w, h) * scale
        val cx = w * 0.5f + w * 0.04f * sin(t * 0.03f * 2f * PI.toFloat())
        val cy = h * 0.5f + h * 0.03f * sin(t * 0.041f * 2f * PI.toFloat() + 1f)
        rectF.set(cx - dw / 2f, cy - dw / 2f, cx + dw / 2f, cy + dw / 2f)
        paint.isFilterBitmap = true
        paint.alpha = 235
        c.drawBitmap(bmp, null, rectF, paint)
        paint.alpha = 255
        paint.color = withAlpha(th.bgBottom, 0.38f)
        c.drawRect(0f, 0f, w, h, paint)
    }

    private fun drawStars(c: Canvas, w: Float, h: Float, th: VisTheme, t: Float, beat: Float, q: Float) {
        val count = (140 * q).toInt().coerceIn(40, 160)
        if (starPts.size != count * 2) starPts = FloatArray(count * 2)
        starPaint.color = withAlpha(th.text, 0.85f)
        for (layer in 0 until 3) {
            var n = 0
            val per = count / 3
            for (i in 0 until per) {
                val seed = layer * 1000 + i
                val speed = 4f + layer * 6f
                val x = ((hash01(seed) * w + t * speed) % w)
                val y = hash01(seed + 77) * h
                val tw = 0.6f + 0.4f * sin(t * (0.5f + hash01(seed + 5)) * 2f + i.toFloat())
                if (tw > 0.2f) {
                    starPts[n++] = x
                    starPts[n++] = y
                }
            }
            starPaint.strokeWidth = (1.4f + layer * 1.3f) * (1f + 0.5f * beat)
            starPaint.alpha = (110 + layer * 50).coerceAtMost(255)
            c.drawPoints(starPts, 0, n, starPaint)
        }
    }

    private fun drawWaves(c: Canvas, w: Float, h: Float, th: VisTheme, t: Float, bass: Float, q: Float) {
        val layers = if (q < 0.6f) 2 else 3
        val steps = if (q < 0.6f) 20 else 28
        for (l in 0 until layers) {
            path.reset()
            val baseY = h * (0.68f + 0.1f * l)
            val amp = h * (0.025f + 0.012f * l) * (1f + 0.9f * bass)
            path.moveTo(0f, h)
            for (i in 0..steps) {
                val x = w * i / steps
                val y = baseY + amp * sin(i * 0.5f + t * (0.22f + 0.07f * l) * 2f + l * 1.9f)
                path.lineTo(x, y)
            }
            path.lineTo(w, h)
            path.close()
            paint.shader = null
            paint.color = withAlpha(if (l % 2 == 0) th.accent else th.accent2, 0.20f + 0.06f * l)
            c.drawPath(path, paint)
        }
    }

    private fun drawGrid(c: Canvas, w: Float, h: Float, th: VisTheme, t: Float, beat: Float) {
        val horizon = h * 0.58f
        // sun
        val sunS = blobShader(5, withAlpha(th.accent2, 0.6f))
        blob(c, sunS, w * 0.5f, horizon - h * 0.05f, min(w, h) * (0.34f + 0.03f * beat))
        paint.shader = null
        val lineColor = withAlpha(th.accent, 0.35f + 0.35f * beat)
        starPaint.color = lineColor
        starPaint.strokeWidth = 2f
        starPaint.alpha = (255 * (0.35f + 0.35f * beat)).toInt().coerceAtMost(255)
        val rows = 12
        val scroll = (t * 0.35f) % 1f
        for (i in 0 until rows) {
            val k = (i + scroll) / rows
            val y = horizon + (h - horizon) * k * k
            c.drawLine(0f, y, w, y, starPaint)
        }
        val cols = 16
        for (i in -cols..cols) {
            val xb = w * 0.5f + i * w * 0.16f
            val xt = w * 0.5f + i * w * 0.012f
            c.drawLine(xt, horizon, xb, h, starPaint)
        }
        starPaint.alpha = 255
    }
}
