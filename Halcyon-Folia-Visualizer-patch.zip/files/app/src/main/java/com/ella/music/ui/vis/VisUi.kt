package com.ella.music.ui.vis

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

internal enum class VisIconKind { CLOSE, STYLE, THEME, TUNE, PLAY, PAUSE, PREV, NEXT, VIS }

@Composable
internal fun Modifier.tap(onClick: () -> Unit): Modifier = this.clickable(
    interactionSource = remember { MutableInteractionSource() },
    indication = null,
    onClick = onClick
)

@Composable
internal fun VisIcon(kind: VisIconKind, color: Color, size: androidx.compose.ui.unit.Dp = 24.dp, modifier: Modifier = Modifier) {
    Canvas(modifier.size(size)) { drawVisIcon(kind, color) }
}

private fun DrawScope.drawVisIcon(kind: VisIconKind, color: Color) {
    val u = this.size.minDimension / 24f
    val stroke = Stroke(width = 2.2f * u, cap = StrokeCap.Round)
    when (kind) {
        VisIconKind.CLOSE -> {
            drawLine(color, Offset(6f * u, 6f * u), Offset(18f * u, 18f * u), strokeWidth = 2.4f * u, cap = StrokeCap.Round)
            drawLine(color, Offset(18f * u, 6f * u), Offset(6f * u, 18f * u), strokeWidth = 2.4f * u, cap = StrokeCap.Round)
        }
        VisIconKind.STYLE -> {
            val s = Size(7f * u, 7f * u)
            val r = CornerRadius(2f * u, 2f * u)
            drawRoundRect(color, Offset(4f * u, 4f * u), s, r)
            drawRoundRect(color, Offset(13f * u, 4f * u), s, r)
            drawRoundRect(color, Offset(4f * u, 13f * u), s, r)
            drawRoundRect(color, Offset(13f * u, 13f * u), s, r)
        }
        VisIconKind.THEME -> {
            drawCircle(color, radius = 8.5f * u, center = Offset(12f * u, 12f * u), style = stroke)
            drawCircle(color, radius = 1.6f * u, center = Offset(9f * u, 10f * u))
            drawCircle(color, radius = 1.6f * u, center = Offset(14f * u, 9f * u))
            drawCircle(color, radius = 1.6f * u, center = Offset(15f * u, 14f * u))
        }
        VisIconKind.TUNE -> {
            val ys = floatArrayOf(6f, 12f, 18f)
            val ks = floatArrayOf(8f, 16f, 11f)
            for (i in 0 until 3) {
                drawLine(color, Offset(4f * u, ys[i] * u), Offset(20f * u, ys[i] * u), strokeWidth = 2f * u, cap = StrokeCap.Round)
                drawCircle(Color(0xFF14181F), radius = 3.1f * u, center = Offset(ks[i] * u, ys[i] * u))
                drawCircle(color, radius = 2.6f * u, center = Offset(ks[i] * u, ys[i] * u), style = Stroke(width = 1.8f * u))
            }
        }
        VisIconKind.PLAY -> {
            val p = Path()
            p.moveTo(8f * u, 5f * u); p.lineTo(8f * u, 19f * u); p.lineTo(19f * u, 12f * u); p.close()
            drawPath(p, color)
        }
        VisIconKind.PAUSE -> {
            drawRoundRect(color, Offset(7f * u, 5f * u), Size(3.6f * u, 14f * u), CornerRadius(1.2f * u, 1.2f * u))
            drawRoundRect(color, Offset(13.4f * u, 5f * u), Size(3.6f * u, 14f * u), CornerRadius(1.2f * u, 1.2f * u))
        }
        VisIconKind.PREV -> {
            drawRoundRect(color, Offset(5f * u, 5f * u), Size(2.6f * u, 14f * u), CornerRadius(1f * u, 1f * u))
            val p = Path()
            p.moveTo(19f * u, 5f * u); p.lineTo(19f * u, 19f * u); p.lineTo(9f * u, 12f * u); p.close()
            drawPath(p, color)
        }
        VisIconKind.NEXT -> {
            drawRoundRect(color, Offset(16.4f * u, 5f * u), Size(2.6f * u, 14f * u), CornerRadius(1f * u, 1f * u))
            val p = Path()
            p.moveTo(5f * u, 5f * u); p.lineTo(5f * u, 19f * u); p.lineTo(15f * u, 12f * u); p.close()
            drawPath(p, color)
        }
        VisIconKind.VIS -> {
            val hs = floatArrayOf(6f, 12f, 18f, 10f, 6f)
            for (i in 0 until 5) {
                val h = hs[i] * u
                drawRoundRect(color, Offset((3.5f + i * 4f) * u, 12f * u - h / 2f), Size(2.4f * u, h), CornerRadius(1.2f * u, 1.2f * u))
            }
        }
    }
}

@Composable
internal fun VisChip(text: String, selected: Boolean, accent: Color, onClick: () -> Unit) {
    val bg = if (selected) accent.copy(alpha = 0.9f) else Color(0x22FFFFFF)
    val fg = if (selected) readableColor(accent) else Color(0xDDFFFFFF)
    Box(
        Modifier
            .padding(end = 8.dp, bottom = 8.dp)
            .clip(RoundedCornerShape(50))
            .background(bg)
            .tap(onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        BasicText(text, style = TextStyle(color = fg, fontSize = 13.sp, fontWeight = FontWeight.Medium))
    }
}

internal fun readableColor(c: Color): Color {
    val l = 0.2126f * c.red + 0.7152f * c.green + 0.0722f * c.blue
    return if (l > 0.55f) Color(0xFF14161C) else Color.White
}

@Composable
internal fun VisSection(title: String) {
    BasicText(
        title.uppercase(),
        style = TextStyle(color = Color(0x99FFFFFF), fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp),
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)
    )
}

@Composable
internal fun VisToggleRow(label: String, checked: Boolean, accent: Color, onChange: (Boolean) -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .tap { onChange(!checked) }
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(
            label,
            style = TextStyle(color = Color(0xEEFFFFFF), fontSize = 14.sp),
            modifier = Modifier.weight(1f)
        )
        Box(
            Modifier
                .width(44.dp)
                .height(26.dp)
                .clip(RoundedCornerShape(50))
                .background(if (checked) accent else Color(0x33FFFFFF))
        ) {
            Box(
                Modifier
                    .padding(3.dp)
                    .size(20.dp)
                    .align(if (checked) Alignment.CenterEnd else Alignment.CenterStart)
                    .clip(RoundedCornerShape(50))
                    .background(Color.White)
            )
        }
    }
}

@Composable
internal fun VisSliderRow(
    label: String, value: Float, min: Float, max: Float, accent: Color,
    format: (Float) -> String, onChange: (Float) -> Unit
) {
    Box(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            BasicText(label, style = TextStyle(color = Color(0xEEFFFFFF), fontSize = 13.sp), modifier = Modifier.width(112.dp))
            VisSlider(value, min, max, accent, onChange, Modifier.weight(1f))
            BasicText(
                format(value),
                style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 12.sp),
                modifier = Modifier.width(52.dp).padding(start = 8.dp)
            )
        }
    }
}

@Composable
internal fun VisSlider(value: Float, min: Float, max: Float, accent: Color, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    var width by remember { mutableFloatStateOf(1f) }
    val latest by rememberUpdatedState(onChange)
    val span = (max - min).coerceAtLeast(0.0001f)
    Box(
        modifier
            .height(34.dp)
            .onSizeChanged { width = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(min, max) {
                detectTapGestures { off -> latest(min + span * (off.x / width).coerceIn(0f, 1f)) }
            }
            .pointerInput(min, max) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    latest(min + span * (change.position.x / width).coerceIn(0f, 1f))
                }
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val cy = this.size.height / 2f
            val frac = ((value - min) / span).coerceIn(0f, 1f)
            val x = frac * this.size.width
            drawLine(Color(0x33FFFFFF), Offset(0f, cy), Offset(this.size.width, cy), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
            drawLine(accent, Offset(0f, cy), Offset(x, cy), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
            drawCircle(Color.White, radius = 8.dp.toPx(), center = Offset(x, cy))
        }
    }
}
