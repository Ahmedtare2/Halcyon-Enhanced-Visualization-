package com.ella.music.ui.vis

import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Mindscape: words float in from the haze, gather into the line, then drift away again. */
internal class MindscapeStyle : LyricStyle(
    "mindscape", "Mindscape", "Words drift in from thought and gather into the line",
    listOf(StyleParam("scatter", "Scatter", 0f, 2f, 1f), StyleParam("links", "Links", 0f, 2f, 1f))
) {
    private val blobs = SoftBlobs()

    override fun draw(f: VisFrame) {
        drawMotes(f)
        val idx = focus(f)
        if (idx < 0) return
        val lines = f.track.lines
        val cur = lines[idx]
        val next = lines.getOrNull(idx + 1)
        val ended = f.posMs > cur.endMs
        val disperse = if (ended) smoothstep((f.posMs - cur.endMs) / 800f) else 0f
        if (disperse < 0.98f) drawLine(f, cur, 1f, disperse, 1f - disperse * 0.4f)
        if (next != null && (ended || next.startMs - f.posMs < 1100L)) {
            val from = max(cur.endMs, next.startMs - 1100L)
            val span = max(1L, next.startMs - from).toFloat()
            val gather = smoothstep((f.posMs - from) / span)
            drawLine(f, next, gather, 0f, 0.25f + 0.75f * gather)
        }
    }

    private fun drawLine(f: VisFrame, line: VisLine, gather: Float, disperse: Float, alpha: Float) {
        val th = f.theme
        val c = f.c
        val size = f.heroPx
        val lay = layoutOf(f, line, size, f.maxTextW, 3)
        val ox = f.cx - lay.width / 2f
        val oy = f.cy - lay.height / 2f
        val words = line.words
        val p = f.pen.fill
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(1f, size * 0.015f)
        var prevX = 0f
        var prevY = 0f
        for (i in words.indices) {
            val w = words[i]
            val seed = line.index * 17 + i * 3
            val sx = (hash01(seed + 1) - 0.5f) * f.contentW * 0.9f * f.params[0]
            val sy = (hash01(seed + 2) - 0.5f) * f.contentH * 0.55f * f.params[0]
            val drift = sin(f.t * (0.4f + hash01(seed + 3)) + i.toFloat()) * size * 0.25f * (1f - gather)
            val fx = ox + lay.wordX[i]
            val fy = oy + lay.baseline(lay.wordRow[i])
            val x = fx + (1f - gather) * sx + disperse * sx * 0.35f + drift
            val y = fy + (1f - gather) * sy - disperse * f.contentH * 0.18f + drift * 0.5f
            val a = alpha * (0.2f + 0.8f * gather) * (1f - disperse)
            if (a < 0.02f) continue
            if (gather < 0.97f && i > 0 && f.params[1] > 0.01f) {
                stroke.color = withAlpha(f.theme.accent, 0.35f * (1f - gather) * a * f.params[1])
                c.drawLine(prevX, prevY - size * 0.3f, x + lay.wordWidth[i] / 2f, y - size * 0.3f, stroke)
            }
            prevX = x + lay.wordWidth[i] / 2f
            prevY = y
            val scale = 0.72f + 0.28f * gather
            c.save()
            c.scale(scale, scale, x + lay.wordWidth[i] / 2f, y - size * 0.3f)
            var prog = w.progress(f.posMs)
            if (gather < 1f) prog = 0f
            VisDraw.word(
                c, p, w.text, x, y, lay.wordWidth[i], lay.sizePx, prog,
                th.textDim, th.text, th.accent, th.accent, size * 0.25f, a
            )
            c.restore()
        }
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.62f, size * 0.42f, f.maxTextW, th.textSoft, alpha * gather * (1f - disperse))
    }

    private fun drawMotes(f: VisFrame) {
        val n = (16f * f.quality).toInt().coerceIn(4, 18)
        for (i in 0 until n) {
            val h1 = hash01(i * 5 + 1)
            val h2 = hash01(i * 5 + 2)
            val h3 = hash01(i * 5 + 3)
            val x = f.w * (h1 + 0.05f * sin(f.t * (0.1f + h3 * 0.1f) + i.toFloat()))
            val y = f.h * (((h2 - f.t * (0.006f + h3 * 0.008f)) % 1f + 1f) % 1f)
            val r = min(f.w, f.h) * (0.03f + 0.07f * h3) * (1f + 0.25f * f.bass)
            blobs.draw(f.c, x, y, r, if (i % 2 == 0) f.theme.accent else f.theme.accent2, 0.10f + 0.06f * h3, add = true)
        }
    }
}

/** Fume: big serif lines that smoulder; passed lines dissolve into drifting smoke. */
internal class FumeStyle : LyricStyle(
    "fume", "Fume", "Smoky lines that dissolve as they pass",
    listOf(StyleParam("smoke", "Smoke", 0f, 2f, 1f), StyleParam("warmth", "Warmth", 0f, 1f, 0.8f))
) {
    private val stack = LineStack(2, 4)
    private val smoke = ParticlePool(56)
    private val blobs = SoftBlobs()
    private var emit = 0f

    override fun reset() { super.reset(); stack.fol.snap(0f); smoke.clear() }

    override fun draw(f: VisFrame) {
        val idx = focus(f)
        val th = f.theme
        val c = f.c
        if (idx < 0) { drawSmoke(f); return }
        val size = f.heroPx * 0.92f
        stack.build(f, cache, size, f.maxTextW, 2, idx, 7f, size * 0.30f, 1.08f, 0.6f)
        val gold = lerpColor(th.text, th.accent, f.params[1])
        var headX = f.cx
        var headY = f.cy
        var haveHead = false
        for (i in 0 until stack.count) {
            val lay = stack.lay[i] ?: continue
            val d = stack.dist[i]
            val s = stack.scale[i]
            val a = (1f - 0.8f * smoothstep(abs(d) / 3f)).coerceIn(0.06f, 1f)
            val shiftX = d * size * 0.28f
            val ox = f.cx - lay.width * s / 2f + shiftX
            val oy = f.cy + stack.y[i] - lay.height * s / 2f
            c.save()
            c.translate(ox, oy)
            c.scale(s, s)
            if (abs(d) < 0.6f) {
                VisDraw.sweep(c, f.pen, lay, 0f, 0f, f.posMs, th.textDim, th.text, gold, gold, size * 0.4f, size * 0.07f, a)
                if (stack.lay[i]?.line?.index == idx) {
                    val line = lay.line
                    for (k in line.words.indices) {
                        val pr = line.words[k].progress(f.posMs)
                        if (pr > 0f && pr < 1f) {
                            headX = ox + (lay.wordX[k] + lay.wordWidth[k] * pr) * s
                            headY = oy + lay.baseline(lay.wordRow[k]) * s - size * 0.2f
                            haveHead = true
                        }
                    }
                }
            } else if (d < 0f) {
                // dissolving: stacked, fading, rising copies
                val k = smoothstep(min(1f, -d / 2f))
                VisDraw.flat(c, f.pen, lay, 0f, -size * 0.25f * k, th.text, a * 0.35f)
                VisDraw.flat(c, f.pen, lay, size * 0.06f * k, -size * 0.5f * k, th.text, a * 0.15f)
            } else {
                VisDraw.flat(c, f.pen, lay, 0f, 0f, th.text, a * 0.6f)
            }
            c.restore()
        }
        if (haveHead && f.playing) {
            emit += f.dt * 22f * f.params[0] * f.quality * (1f + f.energy)
            while (emit >= 1f) {
                emit -= 1f
                val j = smoke.life.size
                smoke.spawn(
                    headX + (hash01((f.t * 977f).toInt() + j) - 0.5f) * size * 0.4f,
                    headY,
                    (hash01((f.t * 613f).toInt()) - 0.5f) * 30f,
                    -(34f + hash01((f.t * 389f).toInt()) * 46f),
                    1.7f + hash01((f.t * 131f).toInt()), size * (0.35f + hash01((f.t * 71f).toInt()) * 0.35f), th.text
                )
            }
        }
        drawSmoke(f)
    }

    private fun drawSmoke(f: VisFrame) {
        val p = smoke
        for (i in 0 until p.capacity) {
            if (p.life[i] <= 0f) continue
            p.life[i] -= f.dt
            p.x[i] += p.vx[i] * f.dt + sin(f.t * 1.3f + i) * 12f * f.dt
            p.y[i] += p.vy[i] * f.dt
            val k = p.life[i] / p.maxLife[i]
            val r = p.size[i] * (1f + (1f - k) * 1.8f)
            blobs.draw(f.c, p.x[i], p.y[i], r, p.color[i], 0.13f * k * f.params[0].coerceAtMost(1.5f), 1.3f, 1f)
        }
    }
}

/** Pendolo: the line hangs from a pivot and swings in time with the beat. */
internal class PendoloStyle : LyricStyle(
    "pendolo", "Pendolo", "The line swings like a pendulum in time with the beat",
    listOf(StyleParam("swing", "Swing", 0f, 2f, 1f), StyleParam("string", "String", 0.5f, 1.4f, 1f))
) {
    private var amp = 0f

    override fun reset() { super.reset(); amp = 0f }

    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        val c = f.c
        val th = f.theme
        val lines = f.track.lines
        val line = lines[idx]
        val size = f.heroPx * 0.9f
        val pivotX = f.cx
        val pivotY = f.safeT + f.contentH * 0.03f
        val len = f.contentH * 0.34f * f.params[1]
        val targetAmp = (if (f.playing) 13f else 2f) * f.params[0] * (0.6f + 0.4f * th.intensity)
        amp += (targetAmp - amp) * min(1f, f.dt * 2.5f)
        val angle: Float = if (f.drive.locked) {
            amp * cos(PI.toFloat() * (f.drive.beatIndex + f.drive.beatPhase))
        } else {
            val bpm = if (f.drive.bpm > 40f) f.drive.bpm else 96f
            amp * sin(2f * PI.toFloat() * f.t * bpm / 120f)
        }
        val sinceStart = f.posMs - line.startMs
        // pivot and swing arc
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(1.5f, size * 0.02f)
        stroke.color = withAlpha(th.text, 0.12f)
        f.pen.rect.set(pivotX - len, pivotY - len, pivotX + len, pivotY + len)
        c.drawArc(f.pen.rect, 90f - amp * 1.3f, amp * 2.6f, false, stroke)
        if (idx > 0) {
            val a = 1f - smoothstep(sinceStart / 380f)
            if (a > 0.02f) drawBob(f, lines[idx - 1], pivotX, pivotY, len, angle, a * 0.9f, size * 3f * (1f - a) * (1f - a), size, false)
        }
        val enter = easeOutCubic(sinceStart / 480f + 0.1f)
        drawBob(f, line, pivotX, pivotY, len, angle, enter, -size * 2.2f * (1f - enter), size, true)
        val fill = f.pen.shape
        fill.color = withAlpha(th.accent, 0.9f)
        c.drawCircle(pivotX, pivotY, size * 0.08f, fill)
    }

    private fun drawBob(
        f: VisFrame, line: VisLine, px: Float, py: Float, len: Float, angle: Float,
        alpha: Float, dy: Float, size: Float, current: Boolean
    ) {
        val th = f.theme
        val c = f.c
        val lay = layoutOf(f, line, size, f.maxTextW * 0.9f, 3)
        val stroke = f.pen.stroke
        c.save()
        c.rotate(angle, px, py)
        c.translate(0f, dy)
        stroke.strokeWidth = max(1.5f, size * 0.02f)
        stroke.color = withAlpha(th.text, 0.45f * alpha)
        val top = py + len - lay.height / 2f
        c.drawLine(px, py, px - lay.width * 0.35f, top - size * 0.1f, stroke)
        c.drawLine(px, py, px + lay.width * 0.35f, top - size * 0.1f, stroke)
        val fill = f.pen.shape
        fill.color = withAlpha(th.text, 0.07f * alpha)
        f.pen.rect.set(px - lay.width / 2f - size * 0.4f, top - size * 0.1f, px + lay.width / 2f + size * 0.4f, top + lay.height + size * 0.15f)
        c.drawRoundRect(f.pen.rect, size * 0.3f, size * 0.3f, fill)
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.sweep(
            c, f.pen, lay, px - lay.width / 2f, top, f.posMs, th.textDim, th.text,
            th.accent, th.accent, if (current) size * 0.25f else 0f, 0f, alpha
        )
        VisDraw.secondary(c, f.pen, sec, px, top + lay.height + size * 0.75f, size * 0.4f, f.maxTextW, th.textSoft, alpha)
        c.restore()
    }
}

/** Monet: lines sit on a horizontal rail; sung words are painted with soft dabs and water ripples. */
internal class MonetStyle : LyricStyle(
    "monet", "Monet", "A rail of lines painted with soft dabs and ripples",
    listOf(StyleParam("paint", "Paint", 0f, 2f, 1f), StyleParam("ripple", "Ripples", 0f, 2f, 1f))
) {
    private val cam = Follower()
    private val blobs = SoftBlobs()
    private val ringX = FloatArray(6)
    private val ringY = FloatArray(6)
    private val ringAge = FloatArray(6) { 9f }
    private var ringNext = 0
    private var lastWordKey = -1
    private var lastActive = -99
    private val oval = RectF()

    override fun reset() { super.reset(); cam.snap(0f); lastWordKey = -1; lastActive = -99; for (i in ringAge.indices) ringAge[i] = 9f }

    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        if (abs(idx - lastActive) > 5) cam.snap(idx.toFloat())
        lastActive = idx
        val fa = cam.step(idx.toFloat(), f.dt, 6f)
        val c = f.c
        val th = f.theme
        val lines = f.track.lines
        val size = f.heroPx * 0.86f
        val spacing = f.contentW * 0.95f
        val lo = max(0, idx - 2)
        val hi = min(lines.size - 1, idx + 3)
        var headX = f.cx
        var headY = f.cy
        for (k in lo..hi) {
            val d = k - fa
            val lay = layoutOf(f, lines[k], size, f.maxTextW * 0.9f, 3)
            val s = 0.55f + 0.45f * (1f - smoothstep(abs(d) / 1.6f))
            val a = (1f - 0.8f * smoothstep(abs(d) / 1.8f)).coerceIn(0.05f, 1f)
            val cxk = f.cx + d * spacing
            val ox = cxk - lay.width * s / 2f
            val oy = f.cy - lay.height * s / 2f
            c.save()
            c.translate(ox, oy)
            c.scale(s, s)
            if (k == idx) {
                val line = lines[k]
                for (i in line.words.indices) {
                    val pr = line.words[i].progress(f.posMs)
                    if (pr <= 0f) continue
                    val wx = lay.wordX[i] + lay.wordWidth[i] / 2f
                    val wy = lay.baseline(lay.wordRow[i]) - size * 0.35f
                    val r = (lay.wordWidth[i] * 0.55f + size * 0.45f) * (0.55f + 0.45f * min(1f, pr * 2f)) * f.params[0]
                    val col = palette(f, i)
                    blobs.draw(c, wx, wy, r, col, 0.22f * a, 1.5f, 0.8f)
                    if (pr < 1f) {
                        headX = ox + (lay.wordX[i] + lay.wordWidth[i] * pr) * s
                        headY = oy + wy * s
                    }
                }
                VisDraw.sweep(c, f.pen, lay, 0f, 0f, f.posMs, th.textDim, th.text, th.text, th.accent, size * 0.2f, size * 0.06f, a)
                val key = line.index * 1000 + wordsStarted(line, f.posMs)
                if (key != lastWordKey) {
                    lastWordKey = key
                    if (f.params[1] > 0.05f && f.playing) spawnRing(headX, headY)
                }
            } else {
                VisDraw.flat(c, f.pen, lay, 0f, 0f, th.text, a * 0.55f)
            }
            c.restore()
        }
        drawRings(f, size)
    }

    private fun wordsStarted(line: VisLine, pos: Long): Int {
        var n = 0
        for (w in line.words) if (w.startMs <= pos) n++
        return n
    }

    private fun spawnRing(x: Float, y: Float) {
        ringX[ringNext] = x; ringY[ringNext] = y; ringAge[ringNext] = 0f
        ringNext = (ringNext + 1) % ringAge.size
    }

    private fun drawRings(f: VisFrame, size: Float) {
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(1.5f, size * 0.025f)
        for (i in ringAge.indices) {
            if (ringAge[i] > 1.6f) continue
            ringAge[i] += f.dt
            val k = ringAge[i] / 1.6f
            val r = size * (0.4f + 3.2f * easeOutCubic(k)) * f.params[1].coerceAtLeast(0.2f)
            stroke.color = withAlpha(f.theme.accent2, 0.5f * (1f - k) * f.params[1].coerceAtMost(1.5f))
            oval.set(ringX[i] - r, ringY[i] - r * 0.38f, ringX[i] + r, ringY[i] + r * 0.38f)
            f.c.drawOval(oval, stroke)
        }
    }
}
