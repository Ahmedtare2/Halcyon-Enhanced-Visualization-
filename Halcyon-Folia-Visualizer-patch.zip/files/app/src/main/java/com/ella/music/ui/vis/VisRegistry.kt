package com.ella.music.ui.vis

internal object VisStyles {
    /** Fresh instances (styles keep their own particle/scroll state). */
    fun createAll(): List<LyricStyle> = listOf(
        LuminousStyle(),
        StillStyle(),
        PartitaStyle(),
        TiltStyle(),
        CappellaStyle(),
        CladdaghStyle(),
        MindscapeStyle(),
        FumeStyle(),
        PendoloStyle(),
        MonetStyle(),
        SonnetStyle(),
        LumiereStyle(),
        HanabiStyle(),
        TemperaStyle(),
        NebbiaStyle(),
        DioramaStyle(),
        MachiStyle()
    )
}

/** Short sample lyric used for the live style previews in the picker. */
internal fun sampleTrack(): VisTrack {
    val texts = listOf(
        "Every light is singing",
        "Softly through the night",
        "Hold the colours close",
        "Let the morning rise"
    )
    val lines = ArrayList<VisLine>()
    var start = 0L
    for ((i, text) in texts.withIndex()) {
        val end = start + 2400L
        lines += VisLine(
            index = i, startMs = start, endMs = end, text = text,
            words = synthesizeWords(text, start, end), translation = "", romanization = "",
            backing = "", singer = i % 2, wordTimed = true
        )
        start = end + 100L
    }
    return VisTrack(lines, start)
}
