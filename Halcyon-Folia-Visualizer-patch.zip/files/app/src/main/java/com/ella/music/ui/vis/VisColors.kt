package com.ella.music.ui.vis

import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.floor
import kotlin.math.sin

internal fun withAlpha(color: Int, alpha: Float): Int {
    val a = (((color ushr 24) and 0xFF) * alpha.coerceIn(0f, 1f)).toInt()
    return (a shl 24) or (color and 0x00FFFFFF)
}

internal fun scaleAlpha(color: Int, k: Float): Int = withAlpha(color, k)

internal fun lerpColor(a: Int, b: Int, t: Float): Int {
    val k = t.coerceIn(0f, 1f)
    val aa = ((a ushr 24) and 0xFF) + ((((b ushr 24) and 0xFF) - ((a ushr 24) and 0xFF)) * k).toInt()
    val ar = ((a shr 16) and 0xFF) + ((((b shr 16) and 0xFF) - ((a shr 16) and 0xFF)) * k).toInt()
    val ag = ((a shr 8) and 0xFF) + ((((b shr 8) and 0xFF) - ((a shr 8) and 0xFF)) * k).toInt()
    val ab = (a and 0xFF) + (((b and 0xFF) - (a and 0xFF)) * k).toInt()
    return (aa shl 24) or (ar shl 16) or (ag shl 8) or ab
}

internal fun argb(r: Int, g: Int, b: Int, a: Int = 255): Int =
    (a shl 24) or (r.coerceIn(0, 255) shl 16) or (g.coerceIn(0, 255) shl 8) or b.coerceIn(0, 255)

internal fun luminance(color: Int): Float {
    val r = ((color shr 16) and 0xFF) / 255f
    val g = ((color shr 8) and 0xFF) / 255f
    val b = (color and 0xFF) / 255f
    return 0.2126f * r + 0.7152f * g + 0.0722f * b
}

/** Boosts saturation/brightness so a muted cover colour still works as a text accent. */
internal fun vivid(color: Int, minLum: Float = 0.55f): Int {
    var r = (color shr 16) and 0xFF
    var g = (color shr 8) and 0xFF
    var b = color and 0xFF
    val lum = luminance(color)
    if (lum < minLum) {
        val k = (minLum - lum) / (1f - lum).coerceAtLeast(0.01f)
        r += ((255 - r) * k).toInt()
        g += ((255 - g) * k).toInt()
        b += ((255 - b) * k).toInt()
    }
    return argb(r, g, b)
}

internal fun hueToColor(hue: Float, sat: Float = 0.75f, value: Float = 1f, alpha: Int = 255): Int {
    val h = ((hue % 360f) + 360f) % 360f / 60f
    val c = value * sat
    val x = c * (1f - kotlin.math.abs(h % 2f - 1f))
    val m = value - c
    val (r, g, b) = when (floor(h).toInt()) {
        0 -> Triple(c, x, 0f)
        1 -> Triple(x, c, 0f)
        2 -> Triple(0f, c, x)
        3 -> Triple(0f, x, c)
        4 -> Triple(x, 0f, c)
        else -> Triple(c, 0f, x)
    }
    return argb(((r + m) * 255f).toInt(), ((g + m) * 255f).toInt(), ((b + m) * 255f).toInt(), alpha)
}

internal fun smoothstep(t: Float): Float {
    val k = t.coerceIn(0f, 1f)
    return k * k * (3f - 2f * k)
}

internal fun easeOutCubic(t: Float): Float {
    val k = 1f - t.coerceIn(0f, 1f)
    return 1f - k * k * k
}

internal fun easeOutBack(t: Float): Float {
    val k = t.coerceIn(0f, 1f) - 1f
    val s = 1.70158f
    return 1f + (s + 1f) * k * k * k + s * k * k
}

internal fun lerpF(a: Float, b: Float, t: Float): Float = a + (b - a) * t

/** Cheap deterministic hash noise in [0,1) – avoids allocating a Random per frame. */
internal fun hash01(seed: Int): Float {
    var x = seed * 374761393 + 668265263
    x = (x xor (x ushr 13)) * 1274126177
    x = x xor (x ushr 16)
    return (x and 0xFFFFFF) / 16777216f
}

internal fun hash01(a: Int, b: Int): Float = hash01(a * 73856093 xor b * 19349663)

internal fun wave(t: Float, speed: Float, phase: Float): Float = sin(t * speed * 2f * PI.toFloat() + phase)

internal fun cosWave(t: Float, speed: Float, phase: Float): Float = cos(t * speed * 2f * PI.toFloat() + phase)

/** Black or white text, whichever reads better on [bg]. */
internal fun readableOn(bg: Int): Int = if (luminance(bg) > 0.55f) argb(18, 18, 24) else argb(255, 255, 255)
