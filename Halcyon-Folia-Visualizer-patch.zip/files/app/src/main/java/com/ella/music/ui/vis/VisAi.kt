package com.ella.music.ui.vis

import android.content.Context
import com.ella.music.data.SettingsManager
import com.ella.music.data.ai.AiProviderClient
import com.ella.music.data.ai.OpenAiSongInterpretationConfig
import com.ella.music.data.ai.resolveAiApiProtocol
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import org.json.JSONObject

/** Generates a [VisTheme] from a text prompt using the AI provider configured in Halcyon's settings. */
internal object VisAi {
    private const val SYSTEM = "You design colour themes for a music lyric visualizer. " +
        "Reply with ONE JSON object and nothing else. Keys: name (short), bgTop, bgMid, bgBottom, text, accent, " +
        "accent2 (all \"#RRGGBB\"), font (one of SANS, SERIF, CONDENSED, MONO, SCRIPT), intensity (number 0.5-1.5, " +
        "higher = more energetic motion), light (true only for a light background). " +
        "The text colour must have strong contrast against the background colours."

    class MissingKeyException : Exception("Set up an AI provider and API key in Halcyon's settings first.")

    suspend fun generate(context: Context, prompt: String, songHint: String): VisTheme {
        val settings = SettingsManager.getInstance(context)
        val baseUrl = settings.openAiBaseUrl.first()
        val key = settings.openAiApiKey.first()
        if (key.isBlank()) throw MissingKeyException()
        val config = OpenAiSongInterpretationConfig(
            apiKey = key,
            baseUrl = baseUrl,
            model = settings.openAiModel.first(),
            protocol = resolveAiApiProtocol(settings.aiApiProtocol.first(), baseUrl)
        )
        val user = "Mood / style request: " + prompt.trim() +
            (if (songHint.isNotBlank()) "\nSong: $songHint" else "")
        val raw = withContext(Dispatchers.IO) {
            AiProviderClient(context).completeChat(
                config = config,
                systemPrompt = SYSTEM,
                userPrompt = user,
                temperature = 0.8,
                topP = 0.95,
                maxTokens = 500
            )
        }
        return parse(raw) ?: throw IllegalStateException("The AI reply did not contain a usable theme.")
    }

    internal fun parse(raw: String): VisTheme? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        if (start < 0 || end <= start) return null
        val o = runCatching { JSONObject(raw.substring(start, end + 1)) }.getOrNull() ?: return null
        val top = VisTheme.parseColor(o.optString("bgTop")) ?: return null
        val mid = VisTheme.parseColor(o.optString("bgMid")) ?: top
        val bottom = VisTheme.parseColor(o.optString("bgBottom")) ?: mid
        val accent = VisTheme.parseColor(o.optString("accent")) ?: return null
        val accent2 = VisTheme.parseColor(o.optString("accent2")) ?: accent
        var text = VisTheme.parseColor(o.optString("text")) ?: readableOn(mid)
        val bgLum = (luminance(top) + luminance(mid) + luminance(bottom)) / 3f
        if (kotlin.math.abs(luminance(text) - bgLum) < 0.4f) text = readableOn(mid)
        return VisTheme(
            id = "ai-" + System.currentTimeMillis(),
            name = o.optString("name").ifBlank { "AI theme" }.take(24),
            bgTop = withAlpha(top, 1f), bgMid = withAlpha(mid, 1f), bgBottom = withAlpha(bottom, 1f),
            text = withAlpha(text, 1f), accent = withAlpha(accent, 1f), accent2 = withAlpha(accent2, 1f),
            font = VisFont.fromName(o.optString("font")),
            intensity = o.optDouble("intensity", 1.0).toFloat().coerceIn(0.5f, 1.5f),
            light = o.optBoolean("light", bgLum > 0.6f)
        )
    }
}
