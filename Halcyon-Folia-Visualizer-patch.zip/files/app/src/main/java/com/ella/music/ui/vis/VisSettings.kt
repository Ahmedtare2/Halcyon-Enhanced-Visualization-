package com.ella.music.ui.vis

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

/** Entry point other parts of the app use to open/close the lyric visualizer page. */
internal object VisController {
    var open by mutableStateOf(false)
    var beatStatus by mutableStateOf("")

    fun show() { open = true }
    fun hide() { open = false }
}

/** All user-facing options of the visualizer, backed by SharedPreferences and observable by Compose. */
internal object VisPrefs {
    private var prefs: SharedPreferences? = null

    var styleId by mutableStateOf("luminous")
    var themeId by mutableStateOf(VisThemes.COVER_ID)
    var customThemes by mutableStateOf<List<VisTheme>>(emptyList())
    var backgroundId by mutableStateOf("fluid")
    var bgDim by mutableFloatStateOf(0.2f)
    var textScale by mutableFloatStateOf(1f)
    var align by mutableIntStateOf(1)
    var showTranslation by mutableStateOf(true)
    var showRomanization by mutableStateOf(false)
    var audioReactive by mutableStateOf(true)
    var reactStrength by mutableFloatStateOf(1f)
    var beatFx by mutableStateOf(true)
    var beatStrength by mutableFloatStateOf(1f)
    var beatOffsetMs by mutableIntStateOf(0)
    /** 0 auto, 1 high, 2 balanced, 3 battery. */
    var quality by mutableIntStateOf(0)
    /** 0 auto (60), otherwise 30 / 60 / 90 / 120. */
    var fpsCap by mutableIntStateOf(0)
    /** Empty = use the theme font, otherwise a [VisFont] name. */
    var fontOverride by mutableStateOf("")
    var showButton by mutableStateOf(true)
    var keepScreenOn by mutableStateOf(true)
    var autoHideHud by mutableStateOf(true)
    val tunings = mutableStateMapOf<String, Float>()

    private var loaded = false

    fun init(context: Context) {
        if (loaded) return
        loaded = true
        val p = context.applicationContext.getSharedPreferences("halcyon_vis", Context.MODE_PRIVATE)
        prefs = p
        styleId = p.getString("style", styleId) ?: styleId
        themeId = p.getString("theme", themeId) ?: themeId
        customThemes = VisTheme.listFromJson(p.getString("customThemes", null))
        backgroundId = p.getString("background", backgroundId) ?: backgroundId
        bgDim = p.getFloat("bgDim", bgDim)
        textScale = p.getFloat("textScale", textScale)
        align = p.getInt("align", align)
        showTranslation = p.getBoolean("showTranslation", showTranslation)
        showRomanization = p.getBoolean("showRomanization", showRomanization)
        audioReactive = p.getBoolean("audioReactive", audioReactive)
        reactStrength = p.getFloat("reactStrength", reactStrength)
        beatFx = p.getBoolean("beatFx", beatFx)
        beatStrength = p.getFloat("beatStrength", beatStrength)
        beatOffsetMs = p.getInt("beatOffsetMs", beatOffsetMs)
        quality = p.getInt("quality", quality)
        fpsCap = p.getInt("fpsCap", fpsCap)
        fontOverride = p.getString("fontOverride", fontOverride) ?: fontOverride
        showButton = p.getBoolean("showButton", showButton)
        keepScreenOn = p.getBoolean("keepScreenOn", keepScreenOn)
        autoHideHud = p.getBoolean("autoHideHud", autoHideHud)
        runCatching {
            val raw = p.getString("tunings", null)
            if (!raw.isNullOrBlank()) {
                val o = JSONObject(raw)
                val keys = o.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    tunings[k] = o.getDouble(k).toFloat()
                }
            }
        }
    }

    fun save() {
        val p = prefs ?: return
        val tuneJson = JSONObject()
        for ((k, v) in tunings) tuneJson.put(k, v.toDouble())
        p.edit()
            .putString("style", styleId)
            .putString("theme", themeId)
            .putString("customThemes", VisTheme.listToJson(customThemes))
            .putString("background", backgroundId)
            .putFloat("bgDim", bgDim)
            .putFloat("textScale", textScale)
            .putInt("align", align)
            .putBoolean("showTranslation", showTranslation)
            .putBoolean("showRomanization", showRomanization)
            .putBoolean("audioReactive", audioReactive)
            .putFloat("reactStrength", reactStrength)
            .putBoolean("beatFx", beatFx)
            .putFloat("beatStrength", beatStrength)
            .putInt("beatOffsetMs", beatOffsetMs)
            .putInt("quality", quality)
            .putInt("fpsCap", fpsCap)
            .putString("fontOverride", fontOverride)
            .putBoolean("showButton", showButton)
            .putBoolean("keepScreenOn", keepScreenOn)
            .putBoolean("autoHideHud", autoHideHud)
            .putString("tunings", tuneJson.toString())
            .apply()
    }

    fun tune(styleId: String, key: String, default: Float): Float = tunings["$styleId.$key"] ?: default

    fun setTune(styleId: String, key: String, value: Float) {
        tunings["$styleId.$key"] = value
        save()
    }

    fun addCustomTheme(theme: VisTheme) {
        customThemes = customThemes.filter { it.id != theme.id } + theme
        themeId = theme.id
        save()
    }

    fun deleteCustomTheme(id: String) {
        customThemes = customThemes.filter { it.id != id }
        if (themeId == id) themeId = VisThemes.COVER_ID
        save()
    }
}
