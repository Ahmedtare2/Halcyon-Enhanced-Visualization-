package com.ella.music.ui.vis

import com.ella.music.data.model.LyricLine
import com.ella.music.data.model.primaryEndMs

/** One timed unit of a lyric line (a word, a syllable, or a single CJK character). */
internal class VisWord(val text: String, val startMs: Long, val endMs: Long) {
    val durationMs: Long get() = (endMs - startMs).coerceAtLeast(1L)

    fun progress(posMs: Long): Float {
        if (posMs <= startMs) return 0f
        if (posMs >= endMs) return 1f
        return (posMs - startMs).toFloat() / durationMs.toFloat()
    }
}

/** A lyric line prepared for rendering. Independent of the app's own lyric model. */
internal class VisLine(
    val index: Int,
    val startMs: Long,
    val endMs: Long,
    val text: String,
    val words: List<VisWord>,
    val translation: String,
    val romanization: String,
    val backing: String,
    val singer: Int,
    val wordTimed: Boolean
) {
    val durationMs: Long get() = (endMs - startMs).coerceAtLeast(1L)

    fun progress(posMs: Long): Float {
        if (posMs <= startMs) return 0f
        if (posMs >= endMs) return 1f
        return (posMs - startMs).toFloat() / durationMs.toFloat()
    }

    /** Short lines are revealed quickly instead of crawling over their whole duration. */
    val isShort: Boolean get() = text.length <= 6 || durationMs < 1_400L
}

internal class VisTrack(val lines: List<VisLine>, val durationMs: Long) {
    val isEmpty: Boolean get() = lines.isEmpty()

    /** Index of the last line that has started at [posMs], or -1 before the first line. */
    fun indexAt(posMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var ans = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].startMs <= posMs) {
                ans = mid
                lo = mid + 1
            } else {
                hi = mid - 1
            }
        }
        return ans
    }

    companion object {
        val Empty = VisTrack(emptyList(), 0L)
    }
}

internal fun isCjkChar(c: Char): Boolean {
    val code = c.code
    return code in 0x2E80..0x9FFF || code in 0xAC00..0xD7AF || code in 0xF900..0xFAFF ||
        code in 0xFF00..0xFFEF || code in 0x3000..0x303F
}

private const val NO_LINE_START = "，。、！？；：）】》」』”’…—,.!?;:)]}%・ー、。"
private const val NO_LINE_END = "（【《「『“‘([{"

/** Whether a line may wrap between two timed units. Keeps Latin words and CJK punctuation intact. */
internal fun canBreakBetween(prev: String, cur: String): Boolean {
    if (prev.isEmpty() || cur.isEmpty()) return false
    val a = prev.last()
    val b = cur.first()
    if (a.isWhitespace() || b.isWhitespace()) return true
    if (NO_LINE_START.indexOf(b) >= 0) return false
    if (NO_LINE_END.indexOf(a) >= 0) return false
    return isCjkChar(a) || isCjkChar(b)
}

/** Splits untimed text into units and spreads them over the line's duration. */
internal fun synthesizeWords(text: String, startMs: Long, endMs: Long): List<VisWord> {
    val tokens = ArrayList<String>()
    val sb = StringBuilder()
    var i = 0
    while (i < text.length) {
        val ch = text[i]
        if (isCjkChar(ch)) {
            if (sb.isNotEmpty()) { tokens += sb.toString(); sb.setLength(0) }
            tokens += ch.toString()
            i++
        } else {
            sb.append(ch)
            i++
            if (ch.isWhitespace()) {
                // include the whole trailing run of whitespace in this token
                while (i < text.length && text[i].isWhitespace()) { sb.append(text[i]); i++ }
                tokens += sb.toString(); sb.setLength(0)
            }
        }
    }
    if (sb.isNotEmpty()) tokens += sb.toString()
    if (tokens.isEmpty()) return emptyList()
    val weights = FloatArray(tokens.size) { k ->
        val t = tokens[k]
        if (t.length == 1 && isCjkChar(t[0])) 1f else (t.trim().length * 0.6f).coerceAtLeast(1f)
    }
    val total = weights.sum().coerceAtLeast(1f)
    val span = (endMs - startMs).coerceAtLeast(1L).toFloat()
    val usable = span * 0.92f
    val out = ArrayList<VisWord>(tokens.size)
    var acc = 0f
    for (k in tokens.indices) {
        val s = startMs + (usable * acc / total).toLong()
        acc += weights[k]
        val e = startMs + (usable * acc / total).toLong()
        out += VisWord(tokens[k], s, maxOf(e, s + 1L))
    }
    return out
}

/** Converts Halcyon's lyric lines to the render model. */
internal fun buildVisTrack(
    lyrics: List<LyricLine>,
    durationMs: Long,
    includeTranslation: Boolean,
    includeRomanization: Boolean
): VisTrack {
    val out = ArrayList<VisLine>(lyrics.size)
    for (i in lyrics.indices) {
        val src = lyrics[i]
        if (src.isOpeningMetadata) continue
        val main = src.text.trim()
        val backgroundOnly = main.isEmpty()
        val mainText = if (backgroundOnly) (src.backgroundText ?: "").trim() else main
        if (mainText.isEmpty()) continue
        val next = lyrics.getOrNull(i + 1)
        val start = src.timeMs
        val end = src.primaryEndMs(nextLine = next).coerceAtLeast(start + 1L)
        val srcWords = if (backgroundOnly) src.backgroundWords else src.words
        val timed = srcWords.size > 1 || (srcWords.isNotEmpty() && src.hasExplicitWordTiming)
        val words: List<VisWord> = if (timed) {
            val list = ArrayList<VisWord>(srcWords.size)
            for (w in srcWords) {
                if (w.text.isEmpty()) continue
                list += VisWord(w.text, w.startMs, maxOf(w.endMs, w.startMs + 1L))
            }
            if (list.isEmpty()) synthesizeWords(mainText, start, end) else list
        } else {
            synthesizeWords(mainText, start, end)
        }
        if (words.isEmpty()) continue
        val lineEnd = maxOf(end, words.last().endMs)
        val agent = src.agent?.trim()?.lowercase().orEmpty()
        val singer = if (agent.isNotEmpty() && agent.endsWith("2")) 1 else 0
        out += VisLine(
            index = out.size,
            startMs = start,
            endMs = lineEnd,
            text = mainText,
            words = words,
            translation = if (includeTranslation) (src.translation ?: "").trim() else "",
            romanization = if (includeRomanization) (src.pronunciation ?: "").trim() else "",
            backing = if (backgroundOnly) "" else (src.backgroundText ?: "").trim(),
            singer = singer,
            wordTimed = timed
        )
    }
    return VisTrack(out, durationMs)
}
