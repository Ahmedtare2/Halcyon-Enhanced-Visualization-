package com.ella.music.ui.vis

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.webkit.JavascriptInterface
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.Keep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Whether the Folia web bundle was built into this APK (see the import-and-build workflow). */
internal object FoliaAssets {
    const val HOST = "appassets.androidplatform.net"
    const val PAGE = "halcyon-host.html"

    fun available(context: Context): Boolean = runCatching {
        context.assets.list("folia")?.contains(PAGE) == true
    }.getOrDefault(false)
}

/** Folia styles that lay text out right to left and keep Arabic/Hebrew words whole. */
internal val RTL_READY_MODES = setOf("classic", "partita", "monet", "diorama")

internal val FALLBACK_FOLIA_MODES = listOf(
    "classic" to "Luminous", "still" to "Still", "partita" to "Partita", "tilt" to "Tilt",
    "cappella" to "Cappella", "claddagh" to "Claddagh", "cadenza" to "Mindscape", "fume" to "Fume",
    "pendolo" to "Pendolo", "monet" to "Monet", "sonnet" to "Sonnet", "lumiere" to "Lumière",
    "hanabi" to "Hanabi", "tempera" to "Tempera", "nebbia" to "Nebbia", "diorama" to "Diorama",
    "machi" to "Machi"
)

/** Owns the WebView that runs Folia's visualizer and everything Android pushes into it. */
internal class FoliaController {
    var webView: WebView? = null
    var ready by mutableStateOf(false)
    var firstFrame by mutableStateOf(false)
    var error by mutableStateOf("")
    var settingsOpen by mutableStateOf(false)
    /** Last page messages (console errors, failed asset loads) for the diagnostics view. */
    val diag = mutableStateListOf<String>()
    private val main = Handler(Looper.getMainLooper())
    var modes by mutableStateOf(FALLBACK_FOLIA_MODES)
    var backgrounds by mutableStateOf<List<Pair<String, String>>>(emptyList())
    @Volatile var coverBytes: ByteArray? = null
    var coverVersion = 0

    fun reset() {
        ready = false
        firstFrame = false
        error = ""
        settingsOpen = false
    }

    /** Thread-safe: asset requests arrive on WebView worker threads. */
    fun note(line: String) {
        main.post {
            if (diag.size >= 14) diag.removeAt(0)
            diag.add(line.take(220))
        }
    }

    /** Runs a script in the page. Silently ignored until the page announced itself. */
    fun call(script: String) {
        val w = webView ?: return
        if (!ready) return
        w.evaluateJavascript(script, null)
    }

    fun handleReady(json: String) {
        runCatching {
            val o = JSONObject(json)
            fun pairs(a: JSONArray?): List<Pair<String, String>> {
                if (a == null) return emptyList()
                val out = ArrayList<Pair<String, String>>()
                for (i in 0 until a.length()) {
                    val e = a.getJSONObject(i)
                    out += e.getString("id") to e.optString("label", e.getString("id"))
                }
                return out
            }
            val m = pairs(o.optJSONArray("modes"))
            if (m.isNotEmpty()) modes = m
            backgrounds = pairs(o.optJSONArray("backgrounds"))
        }
        ready = true
    }

    fun setCover(bitmap: Bitmap?) {
        coverVersion++
        coverBytes = if (bitmap == null || bitmap.isRecycled) null else runCatching {
            val max = 512
            val scale = max.toFloat() / maxOf(bitmap.width, bitmap.height).coerceAtLeast(1)
            val src = if (scale < 1f) {
                Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
            } else bitmap
            val out = ByteArrayOutputStream()
            src.compress(Bitmap.CompressFormat.JPEG, 86, out)
            out.toByteArray()
        }.getOrNull()
    }
}

/** JavaScript -> Android calls. Kept by name so release (R8) builds still expose them. */
@Keep
internal class FoliaBridge(private val controller: FoliaController) {
    private val main = Handler(Looper.getMainLooper())

    @Keep
    @JavascriptInterface
    fun onReady(json: String) { main.post { controller.handleReady(json) } }

    @Keep
    @JavascriptInterface
    fun onFirstFrame() { main.post { controller.firstFrame = true } }

    @Keep
    @JavascriptInterface
    fun onError(message: String) {
        main.post {
            controller.error = message.take(200)
            controller.note("js: " + message)
        }
    }

    @Keep
    @JavascriptInterface
    fun onInfo(message: String) { main.post { controller.note("info: " + message) } }

    @Keep
    @JavascriptInterface
    fun onSettingsClosed() { main.post { controller.settingsOpen = false } }
}

private fun mimeFor(path: String): String {
    val p = path.lowercase(Locale.US)
    return when {
        p.endsWith(".html") -> "text/html"
        p.endsWith(".js") || p.endsWith(".mjs") -> "text/javascript"
        p.endsWith(".css") -> "text/css"
        p.endsWith(".json") -> "application/json"
        p.endsWith(".svg") -> "image/svg+xml"
        p.endsWith(".png") -> "image/png"
        p.endsWith(".jpg") || p.endsWith(".jpeg") -> "image/jpeg"
        p.endsWith(".webp") -> "image/webp"
        p.endsWith(".woff2") -> "font/woff2"
        p.endsWith(".woff") -> "font/woff"
        p.endsWith(".ttf") -> "font/ttf"
        p.endsWith(".wasm") -> "application/wasm"
        else -> "application/octet-stream"
    }
}

private fun response(code: Int, reason: String, mime: String, data: ByteArray): WebResourceResponse {
    val headers = HashMap<String, String>()
    headers["Access-Control-Allow-Origin"] = "*"
    headers["Cache-Control"] = "max-age=3600"
    return WebResourceResponse(mime, "utf-8", code, reason, headers, ByteArrayInputStream(data))
}

@SuppressLint("SetJavaScriptEnabled")
private fun createFoliaWebView(context: Context, controller: FoliaController, dpr: Float, fps: Int): WebView {
    val wv = WebView(context)
    wv.setBackgroundColor(AndroidColor.BLACK)
    wv.overScrollMode = View.OVER_SCROLL_NEVER
    wv.isVerticalScrollBarEnabled = false
    wv.isHorizontalScrollBarEnabled = false
    wv.isFocusable = false
    wv.isClickable = false
    val s = wv.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.mediaPlaybackRequiresUserGesture = false
    s.cacheMode = WebSettings.LOAD_DEFAULT
    s.setSupportZoom(false)
    s.builtInZoomControls = false
    s.textZoom = 100
    // While the page scrolls (its own settings screen) no ancestor may steal the drag.
    wv.setOnTouchListener { v, ev ->
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) v.parent?.requestDisallowInterceptTouchEvent(true)
        false
    }
    wv.addJavascriptInterface(FoliaBridge(controller), "AndroidHost")
    val assets = context.applicationContext.assets
    wv.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val url = request.url
            if (url.host != FoliaAssets.HOST) {
                // Everything outside the bundled page stays offline (battery, privacy, no stray fonts/CDNs).
                controller.note("blocked " + url.host)
                return response(403, "Blocked", "text/plain", ByteArray(0))
            }
            val path = (url.path ?: "/").trimStart('/')
            if (path.startsWith("__cover/")) {
                val bytes = controller.coverBytes
                return if (bytes != null) response(200, "OK", "image/jpeg", bytes) else response(404, "Not Found", "text/plain", ByteArray(0))
            }
            val name = if (path.isEmpty()) FoliaAssets.PAGE else path
            return try {
                val data = assets.open("folia/$name").use { it.readBytes() }
                response(200, "OK", mimeFor(name), data)
            } catch (e: Exception) {
                controller.note("404 /" + name)
                response(404, "Not Found", "text/plain", ByteArray(0))
            }
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            controller.error = "The web renderer stopped (out of memory?)"
            return true
        }
    }
    wv.webChromeClient = object : WebChromeClient() {
        override fun onConsoleMessage(message: ConsoleMessage): Boolean {
            val level = message.messageLevel()
            if (level == ConsoleMessage.MessageLevel.ERROR || level == ConsoleMessage.MessageLevel.WARNING) {
                controller.note((if (level == ConsoleMessage.MessageLevel.ERROR) "err " else "warn ") + message.message())
            }
            return true
        }
    }
    controller.webView = wv
    wv.loadUrl("https://${FoliaAssets.HOST}/${FoliaAssets.PAGE}?dpr=${"%.2f".format(Locale.US, dpr)}&fps=$fps")
    return wv
}

/**
 * The GPU-accelerated renderer: Folia's real visualizer running in a hardware-accelerated WebView.
 * [dpr] caps the render resolution (the biggest GPU/battery lever); changing it reloads the page.
 */
@Composable
internal fun FoliaStage(controller: FoliaController, dpr: Float, fps: Int, modifier: Modifier = Modifier) {
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            val w = controller.webView
            if (w != null) {
                when (event) {
                    Lifecycle.Event.ON_PAUSE -> { w.onPause(); w.pauseTimers() }
                    Lifecycle.Event.ON_RESUME -> { w.onResume(); w.resumeTimers() }
                    else -> Unit
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    key(dpr) {
        AndroidView(
            modifier = modifier,
            factory = { ctx ->
                controller.reset()
                createFoliaWebView(ctx, controller, dpr, fps)
            },
            onRelease = { view ->
                controller.ready = false
                controller.webView = null
                view.stopLoading()
                view.removeJavascriptInterface("AndroidHost")
                view.destroy()
            }
        )
    }
}

// ------------------------------------------------------------------ data pushed into the page

internal fun hexColor(c: Int): String = String.format(Locale.US, "#%06X", c and 0xFFFFFF)

internal fun foliaThemeJson(t: VisTheme): String = JSONObject()
    .put("name", t.name)
    .put("backgroundColor", hexColor(t.bgMid))
    .put("primaryColor", hexColor(t.text))
    .put("accentColor", hexColor(t.accent))
    .put("secondaryColor", hexColor(t.accent2))
    .put("fontStyle", when (t.font) { VisFont.SERIF -> "serif"; VisFont.MONO -> "mono"; else -> "sans" })
    .put("animationIntensity", if (t.intensity < 0.8f) "calm" else if (t.intensity > 1.2f) "chaotic" else "normal")
    .toString()

internal fun foliaLyricsJson(track: VisTrack): String {
    val arr = JSONArray()
    for (line in track.lines) {
        val o = JSONObject()
        o.put("s", line.startMs / 1000.0)
        o.put("e", line.endMs / 1000.0)
        o.put("t", line.text)
        val words = JSONArray()
        for (w in line.words) {
            words.put(JSONArray().put(w.text).put(w.startMs / 1000.0).put(w.endMs / 1000.0))
        }
        o.put("w", words)
        if (line.translation.isNotEmpty()) o.put("tr", line.translation)
        if (line.romanization.isNotEmpty()) o.put("ro", line.romanization)
        o.put("a", if (line.singer == 1) "v2" else "v1")
        arr.put(o)
    }
    return arr.toString()
}

/** Roughly two display frames: effects are triggered this much early so they land on the beat. */
private const val DISPLAY_LATENCY_MS = 40

/**
 * Beat times are sent in the page's lyric time (audio position minus the lyric offset), shifted by the
 * user's timing and the display latency, so effects land on the sound regardless of the lyric offset.
 */
internal fun foliaBeatsJson(key: String, map: BeatMap?, offsetMs: Int, light: Boolean, lyricOffsetMs: Long): String {
    if (map == null) return "{}"
    val ms = JSONArray()
    val impact = JSONArray()
    val downbeat: Int
    if (map.confident && map.beatsMs.isNotEmpty()) {
        for (i in map.beatsMs.indices) {
            // Light mode: only the bar-starting beats, a quarter of the triggers.
            if (light && !map.isDownbeat(i)) continue
            ms.put(map.beatsMs[i] + offsetMs - lyricOffsetMs - DISPLAY_LATENCY_MS)
            impact.put(map.beatStrength[i].toDouble())
        }
        downbeat = map.downbeat
    } else {
        for (n in map.kicksMs.indices) {
            if (light && n % 2 == 1) continue
            ms.put(map.kicksMs[n] + offsetMs - lyricOffsetMs - DISPLAY_LATENCY_MS)
            impact.put(0.8)
        }
        downbeat = -1
    }
    return JSONObject().put("key", key).put("beats", ms).put("impact", impact).put("downbeat", downbeat)
        .put("allDown", light && map.confident).toString()
}

private fun js(s: String): String = JSONObject.quote(s)

/**
 * Keeps the page in sync with the player. Everything here is event-driven or low-rate:
 * the page runs its own clock between the occasional position anchors.
 */
@Composable
internal fun FoliaSync(
    controller: FoliaController,
    track: VisTrack,
    theme: VisTheme,
    mode: String,
    background: String,
    songKey: String,
    songTitle: String,
    songArtist: String,
    cover: Bitmap?,
    beatMap: BeatMap?,
    drive: AudioDrive,
    playing: Boolean,
    durationMs: Long,
    positionProvider: () -> Long,
    lyricOffsetMs: Long,
    fps: Int
) {
    val ready = controller.ready
    val fontScale = VisPrefs.textScale
    val showTr = VisPrefs.showTranslation || VisPrefs.showRomanization
    val beatFx = VisPrefs.beatFx
    val beatStrength = VisPrefs.beatStrength
    val beatOffset = VisPrefs.beatOffsetMs
    val reactive = VisPrefs.audioReactive
    val beatLight = VisPrefs.beatLight

    LaunchedEffect(ready, theme) {
        if (ready) {
            controller.call("HalcyonHost.setTheme(" + js(foliaThemeJson(theme)) + ")")
            controller.call("HalcyonHost.setOptions(" + js(JSONObject().put("daylight", theme.light).toString()) + ")")
        }
    }
    LaunchedEffect(ready, VisPrefs.foliaDebug) { if (ready) controller.call("HalcyonHost.setDebug(${VisPrefs.foliaDebug})") }
    LaunchedEffect(ready, fps) { if (ready) controller.call("HalcyonHost.setFps($fps)") }
    LaunchedEffect(ready, mode) { if (ready) controller.call("HalcyonHost.setMode(" + js(mode) + ")") }
    LaunchedEffect(ready, background) { if (ready) controller.call("HalcyonHost.setBackground(" + js(background) + ")") }
    LaunchedEffect(ready, track) { if (ready) controller.call("HalcyonHost.setLyrics(" + js(foliaLyricsJson(track)) + ")") }
    LaunchedEffect(ready, songKey, cover) {
        if (ready) {
            controller.setCover(cover)
            val url = if (controller.coverBytes != null) "https://${FoliaAssets.HOST}/__cover/current.jpg?v=${controller.coverVersion}" else ""
            val o = JSONObject().put("name", songTitle).put("artist", songArtist).put("seed", songKey)
            if (url.isNotEmpty()) o.put("cover", url)
            controller.call("HalcyonHost.setSong(" + js(o.toString()) + ")")
        }
    }
    val rtlFix = VisPrefs.foliaRtlFix
    LaunchedEffect(ready, fontScale, showTr, beatFx, beatStrength, beatLight, rtlFix) {
        if (ready) {
            val o = JSONObject()
                .put("fontScale", fontScale.toDouble())
                .put("showTranslation", showTr)
                .put("beatFx", beatFx)
                .put("rtlFix", rtlFix)
                .put("beatStrength", (beatStrength * (if (beatLight) 0.7f else 1f)).toDouble())
            controller.call("HalcyonHost.setOptions(" + js(o.toString()) + ")")
        }
    }
    LaunchedEffect(ready, beatMap, beatOffset, beatFx, beatLight, lyricOffsetMs) {
        if (ready) controller.call("HalcyonHost.setBeats(" + js(foliaBeatsJson(songKey, if (beatFx) beatMap else null, beatOffset, beatLight, lyricOffsetMs)) + ")")
    }

    // clock anchors
    LaunchedEffect(ready, playing, durationMs) {
        if (!ready) return@LaunchedEffect
        var lastPos = -1L
        var lastAt = 0L
        var lastPlaying = !playing
        while (true) {
            val pos = (positionProvider() - lyricOffsetMs).coerceAtLeast(0L)
            val now = System.currentTimeMillis()
            val expected = if (lastPlaying && lastPos >= 0) lastPos + (now - lastAt) else lastPos
            val drifted = kotlin.math.abs(pos - expected) > 180L || now - lastAt > 2000L
            if (drifted || lastPlaying != playing) {
                controller.call("HalcyonHost.setClock($pos,$durationMs,$playing,$now)")
                lastPos = pos; lastAt = now; lastPlaying = playing
            }
            delay(120L)
        }
    }

    // audio bands (only while the music is playing and the feature is on)
    LaunchedEffect(ready, playing, reactive) {
        if (!ready) return@LaunchedEffect
        if (!reactive || !playing) {
            controller.call("HalcyonHost.setBands(0,0,0,0,0,0)")
            return@LaunchedEffect
        }
        while (true) {
            if (drive.hasLiveBands) {
                val b = drive.bass; val m = drive.mid; val v = drive.vocal; val t = drive.treble
                val lm = (b + m) * 0.5f
                val power = (b + m + t) / 3f
                controller.call(
                    String.format(Locale.US, "HalcyonHost.setBands(%.3f,%.3f,%.3f,%.3f,%.3f,%.3f)", b, lm, m, v, t, power)
                )
            }
            delay(66L)
        }
    }
}
