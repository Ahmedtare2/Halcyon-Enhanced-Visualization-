package com.ella.music.ui.vis

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.os.Handler
import android.os.Looper
import android.view.MotionEvent
import android.view.View
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.webkit.JavascriptInterface
import android.webkit.ConsoleMessage
import android.webkit.RenderProcessGoneDetail
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.annotation.Keep
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.viewinterop.AndroidView
import com.ella.music.player.PlaybackPcmDrumCapture
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.util.Locale
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject

/** Whether the Folia web bundle was built into this APK (see the import-and-build workflow). */
internal object FoliaAssets {
    const val HOST = "appassets.androidplatform.net"
    const val PAGE = "halcyon-host.html"

    fun available(context: Context): Boolean = runCatching {
        context.assets.list("folia")?.contains(PAGE) == true
    }.getOrDefault(false)
}

/** Folia styles that lay text out right to left and keep Arabic/Hebrew words whole. */
internal val RTL_READY_MODES = setOf("classic", "partita", "monet", "diorama")

internal val FALLBACK_FOLIA_MODES = listOf(
    "classic" to "Luminous", "still" to "Still", "partita" to "Partita", "tilt" to "Tilt",
    "cappella" to "Cappella", "claddagh" to "Claddagh", "cadenza" to "Mindscape", "fume" to "Fume",
    "pendolo" to "Pendolo", "monet" to "Monet", "sonnet" to "Sonnet", "lumiere" to "Lumière",
    "hanabi" to "Hanabi", "tempera" to "Tempera", "nebbia" to "Nebbia", "diorama" to "Diorama",
    "machi" to "Machi"
)

/** Owns the WebView that runs Folia's visualizer and everything Android pushes into it. */
internal class FoliaController {
    var webView: WebView? = null
    var ready by mutableStateOf(false)
    var firstFrame by mutableStateOf(false)
    var error by mutableStateOf("")
    var settingsOpen by mutableStateOf(false)
    /** Last page messages (console errors, failed asset loads) for the diagnostics view. */
    val diag = mutableStateListOf<String>()
    private val main = Handler(Looper.getMainLooper())
    var modes by mutableStateOf(FALLBACK_FOLIA_MODES)
    var backgrounds by mutableStateOf<List<Pair<String, String>>>(emptyList())
    @Volatile var coverBytes: ByteArray? = null
    var coverVersion = 0
    @Volatile var nativeBackdropReady = false
        private set
    @Volatile var nativeBackdropDemand = false
        private set
    @Volatile private var nativeBackdropFps = 30
    var nativeBackdrop: VisNativeBackdrop? = null

    fun reset() {
        ready = false
        nativeBackdropReady = false
        nativeBackdropDemand = false
        firstFrame = false
        error = ""
        settingsOpen = false
    }

    /** Thread-safe: asset requests arrive on WebView worker threads. */
    fun note(line: String) {
        main.post {
            if (diag.size >= 14) diag.removeAt(0)
            diag.add(line.take(220))
        }
    }

    /** Runs a script in the page. Silently ignored until the page announced itself. */
    fun call(script: String) {
        val w = webView ?: return
        if (!ready) return
        w.evaluateJavascript(script, null)
    }

    fun handleReady(json: String) {
        runCatching {
            val o = JSONObject(json)
            fun pairs(a: JSONArray?): List<Pair<String, String>> {
                if (a == null) return emptyList()
                val out = ArrayList<Pair<String, String>>()
                for (i in 0 until a.length()) {
                    val e = a.getJSONObject(i)
                    out += e.getString("id") to e.optString("label", e.getString("id"))
                }
                return out
            }
            val m = pairs(o.optJSONArray("modes"))
            if (m.isNotEmpty()) modes = m
            backgrounds = pairs(o.optJSONArray("backgrounds"))
        }
        ready = true
        call("HalcyonHost.setNativeBackdropAvailable($nativeBackdropReady)")
    }

    fun setNativeBackdropReady(available: Boolean) {
        nativeBackdropReady = available
        applyNativeBackdropState()
        if (ready) call("HalcyonHost.setNativeBackdropAvailable($available)")
    }

    fun setNativeBackdropDemand(enabled: Boolean) {
        nativeBackdropDemand = enabled
        applyNativeBackdropState()
    }

    fun setNativeBackdropFps(fps: Int) {
        nativeBackdropFps = fps.coerceIn(1, 120)
        applyNativeBackdropState()
    }

    private fun applyNativeBackdropState() {
        nativeBackdrop?.setVisualizerState(nativeBackdropReady && nativeBackdropDemand, nativeBackdropFps)
    }

    fun setNativeBackdropPalette(colors: List<String>, transitionMs: Int = 800) {
        nativeBackdrop?.setPalette(colors, transitionMs)
    }

    fun setNativeBackdropTuning(meshSpeed: Float, audioSpeed: Float, distortion: Float, swirl: Float, enhancedBeatResponse: Boolean) {
        nativeBackdrop?.setTuning(meshSpeed, audioSpeed, distortion, swirl, enhancedBeatResponse)
    }

    fun setNativeBackdropEnergy(bass: Float, mid: Float, high: Float, playing: Boolean) {
        nativeBackdrop?.setAudioEnergy(bass, mid, high, playing)
    }

    fun setCover(bitmap: Bitmap?) {
        coverVersion++
        coverBytes = if (bitmap == null || bitmap.isRecycled) null else runCatching {
            val max = 512
            val scale = max.toFloat() / maxOf(bitmap.width, bitmap.height).coerceAtLeast(1)
            val src = if (scale < 1f) {
                Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
            } else bitmap
            val out = ByteArrayOutputStream()
            src.compress(Bitmap.CompressFormat.JPEG, 86, out)
            out.toByteArray()
        }.getOrNull()
    }
}

/** JavaScript -> Android calls. Kept by name so release (R8) builds still expose them. */
@Keep
internal class FoliaBridge(private val controller: FoliaController) {
    private val main = Handler(Looper.getMainLooper())

    @Keep
    @JavascriptInterface
    fun onReady(json: String) { main.post { controller.handleReady(json) } }

    @Keep
    @JavascriptInterface
    fun onFirstFrame() { main.post { controller.firstFrame = true } }

    @Keep
    @JavascriptInterface
    fun onError(message: String) {
        main.post {
            controller.error = message.take(200)
            controller.note("js: " + message)
        }
    }

    @Keep
    @JavascriptInterface
    fun onInfo(message: String) { main.post { controller.note("info: " + message) } }

    @Keep
    @JavascriptInterface
    fun onSettingsClosed() { main.post { controller.settingsOpen = false } }

    @Keep
    @JavascriptInterface
    fun onNativeBackdropDemand(enabled: Boolean) { main.post { controller.setNativeBackdropDemand(enabled) } }

    @Keep
    @JavascriptInterface
    fun onNativeBackdropPalette(json: String) {
        main.post {
            runCatching {
                val array = JSONArray(json)
                val colors = ArrayList<String>(array.length())
                for (i in 0 until array.length()) colors += array.getString(i)
                if (colors.size >= 6) controller.setNativeBackdropPalette(colors.take(6))
            }.onFailure { controller.note("native palette: " + it.message.orEmpty()) }
        }
    }

    @Keep
    @JavascriptInterface
    fun onNativeBackdropTuning(json: String) {
        main.post {
            runCatching {
                val o = JSONObject(json)
                controller.setNativeBackdropTuning(
                    o.optDouble("meshSpeed", 0.3).toFloat(),
                    o.optDouble("meshAudioSpeed", 2.0).toFloat(),
                    o.optDouble("meshDistortion", 0.8).toFloat(),
                    o.optDouble("meshSwirl", 0.1).toFloat(),
                    o.optBoolean("enhancedBeatResponse", true)
                )
            }.onFailure { controller.note("native tuning: " + it.message.orEmpty()) }
        }
    }
}

private fun mimeFor(path: String): String {
    val p = path.lowercase(Locale.US)
    return when {
        p.endsWith(".html") -> "text/html"
        p.endsWith(".js") || p.endsWith(".mjs") -> "text/javascript"
        p.endsWith(".css") -> "text/css"
        p.endsWith(".json") -> "application/json"
        p.endsWith(".svg") -> "image/svg+xml"
        p.endsWith(".png") -> "image/png"
        p.endsWith(".jpg") || p.endsWith(".jpeg") -> "image/jpeg"
        p.endsWith(".webp") -> "image/webp"
        p.endsWith(".woff2") -> "font/woff2"
        p.endsWith(".woff") -> "font/woff"
        p.endsWith(".ttf") -> "font/ttf"
        p.endsWith(".wasm") -> "application/wasm"
        else -> "application/octet-stream"
    }
}

private fun response(code: Int, reason: String, mime: String, data: ByteArray): WebResourceResponse {
    val headers = HashMap<String, String>()
    headers["Access-Control-Allow-Origin"] = "*"
    headers["Cache-Control"] = "max-age=3600"
    return WebResourceResponse(mime, "utf-8", code, reason, headers, ByteArrayInputStream(data))
}

@SuppressLint("SetJavaScriptEnabled")
private fun createFoliaWebView(context: Context, controller: FoliaController, dpr: Float, fps: Int): WebView {
    val wv = WebView(context)
    wv.setBackgroundColor(AndroidColor.TRANSPARENT)
    wv.overScrollMode = View.OVER_SCROLL_NEVER
    wv.isVerticalScrollBarEnabled = false
    wv.isHorizontalScrollBarEnabled = false
    wv.isFocusable = false
    wv.isClickable = false
    val s = wv.settings
    s.javaScriptEnabled = true
    s.domStorageEnabled = true
    s.allowFileAccess = false
    s.allowContentAccess = false
    s.mediaPlaybackRequiresUserGesture = false
    s.cacheMode = WebSettings.LOAD_DEFAULT
    s.setSupportZoom(false)
    s.builtInZoomControls = false
    s.textZoom = 100
    // While the page scrolls (its own settings screen) no ancestor may steal the drag.
    wv.setOnTouchListener { v, ev ->
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) v.parent?.requestDisallowInterceptTouchEvent(true)
        false
    }
    wv.addJavascriptInterface(FoliaBridge(controller), "AndroidHost")
    val assets = context.applicationContext.assets
    wv.webViewClient = object : WebViewClient() {
        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? {
            val url = request.url
            if (url.host != FoliaAssets.HOST) {
                // Everything outside the bundled page stays offline (battery, privacy, no stray fonts/CDNs).
                controller.note("blocked " + url.host)
                return response(403, "Blocked", "text/plain", ByteArray(0))
            }
            val path = (url.path ?: "/").trimStart('/')
            if (path.startsWith("__cover/")) {
                val bytes = controller.coverBytes
                return if (bytes != null) response(200, "OK", "image/jpeg", bytes) else response(404, "Not Found", "text/plain", ByteArray(0))
            }
            val name = if (path.isEmpty()) FoliaAssets.PAGE else path
            return try {
                val data = assets.open("folia/$name").use { it.readBytes() }
                response(200, "OK", mimeFor(name), data)
            } catch (e: Exception) {
                controller.note("404 /" + name)
                response(404, "Not Found", "text/plain", ByteArray(0))
            }
        }

        override fun onRenderProcessGone(view: WebView, detail: RenderProcessGoneDetail): Boolean {
            controller.error = "The web renderer stopped (out of memory?)"
            return true
        }
    }
    wv.webChromeClient = object : WebChromeClient() {
        override fun onConsoleMessage(message: ConsoleMessage): Boolean {
            val level = message.messageLevel()
            if (level == ConsoleMessage.MessageLevel.ERROR || level == ConsoleMessage.MessageLevel.WARNING) {
                controller.note((if (level == ConsoleMessage.MessageLevel.ERROR) "err " else "warn ") + message.message())
            }
            return true
        }
    }
    controller.webView = wv
    wv.loadUrl("https://${FoliaAssets.HOST}/${FoliaAssets.PAGE}?dpr=${"%.2f".format(Locale.US, dpr)}&fps=$fps")
    return wv
}

/**
 * Folia remains the full-screen hardware-accelerated WebView. For Latent only, an original
 * low-resolution native mesh surface is layered behind it; every lyric style and the dithering
 * shader stay in the WebView. If GLES initialization fails, JS is told to restore the web mesh.
 */
@Composable
internal fun FoliaStage(controller: FoliaController, dpr: Float, fps: Int, modifier: Modifier = Modifier) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val hostView = LocalView.current
    LaunchedEffect(controller, fps) { controller.setNativeBackdropFps(fps) }
    DisposableEffect(lifecycleOwner, hostView) {
        val observer = LifecycleEventObserver { _, event ->
            val w = controller.webView
            val native = controller.nativeBackdrop
            when (event) {
                Lifecycle.Event.ON_PAUSE -> {
                    if (w != null) { w.onPause(); w.pauseTimers() }
                    native?.onHostPause()
                }
                Lifecycle.Event.ON_RESUME -> {
                    if (w != null) { w.onResume(); w.resumeTimers() }
                    native?.onHostResume()
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        val viewTree = hostView.viewTreeObserver
        val focusListener = ViewTreeObserver.OnWindowFocusChangeListener { focused ->
            controller.nativeBackdrop?.onHostWindowFocusChanged(focused)
        }
        viewTree.addOnWindowFocusChangeListener(focusListener)
        controller.nativeBackdrop?.onHostWindowFocusChanged(hostView.hasWindowFocus())
        if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
            controller.webView?.let { it.onResume(); it.resumeTimers() }
            controller.nativeBackdrop?.onHostResume()
        }
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            if (viewTree.isAlive) viewTree.removeOnWindowFocusChangeListener(focusListener)
        }
    }
    key(dpr) {
        AndroidView(
            modifier = modifier,
            factory = { ctx ->
                controller.reset()
                val root = FrameLayout(ctx).apply { setBackgroundColor(AndroidColor.TRANSPARENT) }
                val native = VisNativeBackdrop(
                    context = ctx,
                    onReady = { controller.setNativeBackdropReady(true) },
                    onUnavailable = { reason ->
                        controller.note(reason)
                        controller.setNativeBackdropReady(false)
                    }
                )
                controller.nativeBackdrop = native
                controller.setNativeBackdropFps(fps)
                native.onHostWindowFocusChanged(hostView.hasWindowFocus())
                if (lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                    native.onHostResume()
                }
                root.addView(native, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
                val web = createFoliaWebView(ctx, controller, dpr, fps)
                root.addView(web, FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                ))
                root
            },
            onRelease = { root ->
                controller.ready = false
                controller.setNativeBackdropDemand(false)
                controller.setNativeBackdropReady(false)
                controller.nativeBackdrop?.shutdown()
                controller.nativeBackdrop = null
                controller.webView = null
                if (root is FrameLayout) {
                    for (i in 0 until root.childCount) {
                        val child = root.getChildAt(i)
                        if (child is WebView) {
                            child.stopLoading()
                            child.removeJavascriptInterface("AndroidHost")
                            child.destroy()
                        }
                    }
                    root.removeAllViews()
                }
            }
        )
    }
}

// ------------------------------------------------------------------ data pushed into the page

internal fun hexColor(c: Int): String = String.format(Locale.US, "#%06X", c and 0xFFFFFF)

internal fun foliaThemeJson(t: VisTheme): String = JSONObject()
    .put("name", t.name)
    .put("backgroundColor", hexColor(t.bgMid))
    .put("primaryColor", hexColor(t.text))
    .put("accentColor", hexColor(t.accent))
    .put("secondaryColor", hexColor(t.accent2))
    .put("fontStyle", when (t.font) { VisFont.SERIF -> "serif"; VisFont.MONO -> "mono"; else -> "sans" })
    .put("animationIntensity", if (t.intensity < 0.8f) "calm" else if (t.intensity > 1.2f) "chaotic" else "normal")
    .toString()

internal fun foliaLyricsJson(track: VisTrack): String {
    val arr = JSONArray()
    for (line in track.lines) {
        val o = JSONObject()
        o.put("s", line.startMs / 1000.0)
        o.put("e", line.endMs / 1000.0)
        o.put("t", line.text)
        val words = JSONArray()
        for (w in line.words) {
            words.put(JSONArray().put(w.text).put(w.startMs / 1000.0).put(w.endMs / 1000.0))
        }
        o.put("w", words)
        if (line.translation.isNotEmpty()) o.put("tr", line.translation)
        if (line.romanization.isNotEmpty()) o.put("ro", line.romanization)
        o.put("a", if (line.singer == 1) "v2" else "v1")
        arr.put(o)
    }
    return arr.toString()
}

/** One scheduled display frame plus a small main-thread hand-off allowance. */
internal fun displayLeadMs(fps: Int): Int =
    ((1000.0 / fps.coerceIn(15, 120)) + 3.0).toInt().coerceAtLeast(8)

/**
 * What the page gets to react to. All times are in the page's lyric time (audio position minus the
 * lyric offset), shifted by the user's timing and the display latency, so effects land on the sound
 * whatever the lyric offset is.
 *
 * [source] 0: kick hits drive the native beat response; 1: the beat grid. Native PCM drum hits
 * are still handed to Folia's drum effects whenever beat effects are enabled. [light] keeps only
 * the strong hits / bar-starting beats.
 */
internal fun foliaBeatsJson(key: String, map: BeatMap?, offsetMs: Int, light: Boolean, lyricOffsetMs: Long, source: Int, fps: Int): String {
    val shift = offsetMs - lyricOffsetMs - displayLeadMs(fps)
    val ms = JSONArray()
    val impact = JSONArray()
    var downbeat = -1
    var allDown = false
    var downAbove = -1.0
    if (map != null && source == 0 && map.kicksMs.isNotEmpty()) {
        for (n in map.kicksMs.indices) {
            val strength = if (n < map.kickStrength.size) map.kickStrength[n] else 0.8f
            if (light && strength < 0.6f) continue
            ms.put(map.kicksMs[n] + shift)
            impact.put(strength.toDouble())
        }
        downAbove = 0.85
    } else if (map != null && map.confident && map.beatsMs.isNotEmpty()) {
        for (i in map.beatsMs.indices) {
            if (light && !map.isDownbeat(i)) continue
            ms.put(map.beatsMs[i] + shift)
            impact.put(map.beatStrength[i].toDouble())
        }
        downbeat = map.downbeat
        allDown = light
    }
    val o = JSONObject().put("key", key).put("source", source).put("shiftMs", shift)
        .put("beats", ms).put("impact", impact)
        .put("downbeat", downbeat).put("allDown", allDown).put("downAbove", downAbove)
    if (map != null && map.drumMs.isNotEmpty()) {
        val times = JSONArray()
        val kinds = JSONArray()
        val strengths = JSONArray()
        for (i in map.drumMs.indices) {
            val kind = map.drumKinds[i].toInt()
            if (light && kind == 2) continue
            times.put((map.drumMs[i] + shift) / 1000.0)
            kinds.put(kind)
            strengths.put(map.drumStrength[i].toDouble())
        }
        o.put("drums", JSONObject().put("times", times).put("kinds", kinds).put("strengths", strengths))
    }
    return o.toString()
}

private fun js(s: String): String = JSONObject.quote(s)

/**
 * Keeps the page in sync with the player. Everything here is event-driven or low-rate:
 * the page runs its own clock between the occasional position anchors.
 */
@Composable
internal fun FoliaSync(
    controller: FoliaController,
    track: VisTrack,
    theme: VisTheme,
    mode: String,
    background: String,
    songKey: String,
    songTitle: String,
    songArtist: String,
    cover: Bitmap?,
    beatMap: BeatMap?,
    drive: AudioDrive,
    playing: Boolean,
    durationMs: Long,
    positionProvider: () -> Long,
    lyricOffsetMs: Long,
    fps: Int,
    batteryProfile: Boolean
) {
    val ready = controller.ready
    val fontScale = VisPrefs.textScale
    val showTr = VisPrefs.showTranslation || VisPrefs.showRomanization
    val beatFx = VisPrefs.beatFx
    val beatStrength = VisPrefs.beatStrength
    val beatOffset = VisPrefs.beatOffsetMs
    val reactive = VisPrefs.audioReactive
    val beatLight = VisPrefs.beatLight
    val latestPlaying by rememberUpdatedState(playing)

    LaunchedEffect(ready, theme) {
        if (ready) {
            controller.call("HalcyonHost.setTheme(" + js(foliaThemeJson(theme)) + ")")
            controller.call("HalcyonHost.setOptions(" + js(JSONObject().put("daylight", theme.light).toString()) + ")")
            controller.setNativeBackdropPalette(listOf(
                hexColor(theme.bgTop), hexColor(theme.bgMid), hexColor(theme.accent),
                hexColor(theme.accent2), hexColor(theme.bgBottom), hexColor(theme.bgTop)
            ))
        }
    }
    LaunchedEffect(ready, VisPrefs.foliaDebug) { if (ready) controller.call("HalcyonHost.setDebug(${VisPrefs.foliaDebug})") }
    LaunchedEffect(ready, fps) { if (ready) controller.call("HalcyonHost.setFps($fps)") }
    LaunchedEffect(ready, batteryProfile) { if (ready) controller.call("HalcyonHost.setBatteryProfile($batteryProfile)") }
    LaunchedEffect(ready, mode) { if (ready) controller.call("HalcyonHost.setMode(" + js(mode) + ")") }
    LaunchedEffect(ready, background) { if (ready) controller.call("HalcyonHost.setBackground(" + js(background) + ")") }
    LaunchedEffect(ready, track) { if (ready) controller.call("HalcyonHost.setLyrics(" + js(foliaLyricsJson(track)) + ")") }
    LaunchedEffect(ready, songKey, cover) {
        if (ready) {
            controller.setCover(cover)
            val url = if (controller.coverBytes != null) "https://${FoliaAssets.HOST}/__cover/current.jpg?v=${controller.coverVersion}" else ""
            val o = JSONObject().put("name", songTitle).put("artist", songArtist).put("seed", songKey)
            if (url.isNotEmpty()) o.put("cover", url)
            controller.call("HalcyonHost.setSong(" + js(o.toString()) + ")")
        }
    }
    val rtlFix = VisPrefs.foliaRtlFix
    LaunchedEffect(ready, fontScale, showTr, beatFx, beatStrength, beatLight, rtlFix) {
        if (ready) {
            val o = JSONObject()
                .put("fontScale", fontScale.toDouble())
                .put("showTranslation", showTr)
                .put("beatFx", beatFx)
                .put("rtlFix", rtlFix)
                .put("beatStrength", (beatStrength * (if (beatLight) 0.7f else 1f)).toDouble())
            controller.call("HalcyonHost.setOptions(" + js(o.toString()) + ")")
        }
    }
    val beatSource = VisPrefs.beatSource
    LaunchedEffect(ready, beatMap, beatOffset, beatFx, beatLight, lyricOffsetMs, beatSource, fps, songKey) {
        if (ready) controller.call("HalcyonHost.setBeats(" + js(foliaBeatsJson(songKey, if (beatFx) beatMap else null, beatOffset, beatLight, lyricOffsetMs, beatSource, fps)) + ")")
    }

    // PCM hits arrive ahead of the audible playhead because Media3 supplies the sink's PTS while
    // buffers are queued. Append only new hits and let Folia's existing clock schedule them one
    // display frame early; never re-install/reset the beat clock per hit.
    LaunchedEffect(ready, songKey, beatFx, beatLight, beatSource, beatOffset, lyricOffsetMs, fps) {
        if (!ready || songKey.isBlank()) return@LaunchedEffect
        val shiftMs = beatOffset - lyricOffsetMs - displayLeadMs(fps)
        val enabled = beatFx
        controller.call(
            "HalcyonHost.setLiveDrums(" + js(JSONObject().put("key", songKey).put("reset", true)
                .put("enabled", enabled).put("offsetMs", shiftMs).put("light", beatLight).toString()) + ")"
        )
        if (!enabled) return@LaunchedEffect
        var lastSequence = 0L
        var wasReady = false
        while (true) {
            val snapshot = PlaybackPcmDrumCapture.snapshot(songKey, lastSequence)
            val hits = JSONArray()
            snapshot.hits.forEach { hit ->
                lastSequence = maxOf(lastSequence, hit.sequence)
                hits.put(JSONObject().put("t", hit.timeUs / 1_000_000.0).put("k", hit.kind).put("s", hit.strength.toDouble()))
            }
            val nowReady = snapshot.warm
            if (hits.length() > 0 || nowReady != wasReady) {
                controller.call(
                    "HalcyonHost.setLiveDrums(" + js(JSONObject().put("key", songKey)
                        .put("enabled", true).put("ready", nowReady).put("offsetMs", shiftMs)
                        .put("light", beatLight).put("hits", hits).toString()) + ")"
                )
            }
            wasReady = nowReady
            delay(if (latestPlaying) 10L else 100L)
        }
    }

    // clock anchors
    LaunchedEffect(ready, playing, durationMs) {
        if (!ready) return@LaunchedEffect
        var lastPos = -1L
        var lastAt = 0L
        var lastPlaying = !playing
        while (true) {
            val pos = (positionProvider() - lyricOffsetMs).coerceAtLeast(0L)
            val now = System.currentTimeMillis()
            val expected = if (lastPlaying && lastPos >= 0) lastPos + (now - lastAt) else lastPos
            val drifted = kotlin.math.abs(pos - expected) > 180L || now - lastAt > 2000L
            if (drifted || lastPlaying != playing) {
                controller.call("HalcyonHost.setClock($pos,$durationMs,$playing,$now)")
                lastPos = pos; lastAt = now; lastPlaying = playing
            }
            delay(120L)
        }
    }

    // audio bands (only while the music is playing and the feature is on)
    LaunchedEffect(ready, playing, reactive) {
        if (!ready) return@LaunchedEffect
        if (!reactive || !playing) {
            controller.call("HalcyonHost.setBands(0,0,0,0,0,0)")
            // `playing` is separate from audio reactivity: without live bands, Latent still
            // moves at its normal base speed while the track plays.
            controller.setNativeBackdropEnergy(0f, 0f, 0f, playing)
            return@LaunchedEffect
        }
        while (true) {
            if (drive.hasLiveBands) {
                val b = drive.bass; val m = drive.mid; val v = drive.vocal; val t = drive.treble
                controller.setNativeBackdropEnergy(b, m, t, true)
                val lm = (b + m) * 0.5f
                val power = (b + m + t) / 3f
                controller.call(
                    String.format(Locale.US, "HalcyonHost.setBands(%.3f,%.3f,%.3f,%.3f,%.3f,%.3f)", b, lm, m, v, t, power)
                )
            } else {
                controller.setNativeBackdropEnergy(0f, 0f, 0f, true)
            }
            delay(66L)
        }
    }
}
