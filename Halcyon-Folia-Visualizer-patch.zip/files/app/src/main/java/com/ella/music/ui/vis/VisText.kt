package com.ella.music.ui.vis

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import kotlin.math.max
import kotlin.math.min

/** Result of wrapping a [VisLine] into rows. Positions are relative to the block's top-left. */
internal class LineLayout(
    val line: VisLine,
    val sizePx: Float,
    val rowCount: Int,
    val width: Float,
    val rowHeight: Float,
    val wordX: FloatArray,
    val wordRow: IntArray,
    val wordWidth: FloatArray,
    val rowStart: IntArray,
    val rowEnd: IntArray,
    val rowWidth: FloatArray,
    val rowOffset: FloatArray
) {
    val height: Float get() = rowHeight * rowCount

    /** Baseline of [row] relative to the block's top. */
    fun baseline(row: Int): Float = rowHeight * row + sizePx * 0.98f

    /** Centre of the word on its row (x). */
    fun wordCenterX(i: Int): Float = wordX[i] + wordWidth[i] * 0.5f
}

/** Paint holder shared by styles. Everything here is reused every frame (no per-frame allocation). */
internal class VisPen {
    val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeCap = Paint.Cap.ROUND }
    val shape = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    val rect = RectF()
    var typeface: Typeface = Typeface.DEFAULT_BOLD
        private set

    fun setFont(tf: Typeface) {
        typeface = tf
        fill.typeface = tf
    }

    fun setSize(px: Float) {
        fill.textSize = px
    }

    fun measure(text: String): Float = fill.measureText(text)
}

internal object VisLayoutEngine {
    private const val ROW_LEADING = 1.24f

    /**
     * Greedy wrap with CJK-aware break rules, followed by a balancing pass so the last row is
     * not a single orphan word. [align]: 0 start, 1 centre, 2 end.
     */
    fun layout(line: VisLine, pen: VisPen, sizePx: Float, maxWidth: Float, align: Int): LineLayout {
        pen.setSize(sizePx)
        val words = line.words
        val n = words.size
        val full = FloatArray(n)
        val trimmed = FloatArray(n)
        for (i in 0 until n) {
            val t = words[i].text
            full[i] = pen.measure(t)
            trimmed[i] = pen.measure(t.trimEnd())
        }
        // Wrap groups: units that must stay on the same row.
        val groupStart = IntArray(n)
        var groupCount = 0
        for (i in 0 until n) {
            if (i == 0 || canBreakBetween(words[i - 1].text, words[i].text)) {
                groupStart[groupCount++] = i
            }
        }
        val groupWidth = FloatArray(groupCount)
        val groupTrimmed = FloatArray(groupCount)
        for (g in 0 until groupCount) {
            val s = groupStart[g]
            val e = if (g + 1 < groupCount) groupStart[g + 1] - 1 else n - 1
            var w = 0f
            for (k in s..e) w += full[k]
            groupWidth[g] = w
            groupTrimmed[g] = w - (full[e] - trimmed[e])
        }
        var total = 0f
        var widest = 0f
        for (g in 0 until groupCount) {
            total += groupWidth[g]
            widest = max(widest, groupTrimmed[g])
        }
        var rows = wrapCount(groupWidth, groupTrimmed, groupCount, maxWidth)
        var effectiveMax = maxWidth
        if (rows > 1) {
            val target = max(total / rows * 1.14f, widest)
            effectiveMax = min(maxWidth, target)
            val balanced = wrapCount(groupWidth, groupTrimmed, groupCount, effectiveMax)
            if (balanced > rows) effectiveMax = maxWidth // balancing must never add rows
            rows = wrapCount(groupWidth, groupTrimmed, groupCount, effectiveMax)
        }
        val wordX = FloatArray(n)
        val wordRow = IntArray(n)
        val rowStart = IntArray(rows)
        val rowEnd = IntArray(rows)
        val rowWidth = FloatArray(rows)
        var row = 0
        var cursor = 0f
        rowStart[0] = 0
        for (g in 0 until groupCount) {
            val s = groupStart[g]
            val e = if (g + 1 < groupCount) groupStart[g + 1] - 1 else n - 1
            if (cursor > 0f && cursor + groupTrimmed[g] > effectiveMax + 0.5f && row + 1 < rows) {
                rowWidth[row] = cursor
                rowEnd[row] = s - 1
                row++
                rowStart[row] = s
                cursor = 0f
            }
            var x = cursor
            for (k in s..e) {
                wordX[k] = x
                wordRow[k] = row
                x += full[k]
            }
            cursor += groupWidth[g]
        }
        rowEnd[row] = n - 1
        rowWidth[row] = cursor - (full[n - 1] - trimmed[n - 1])
        var width = 0f
        for (r in 0..row) width = max(width, rowWidth[r])
        val rowOffset = FloatArray(rows)
        for (r in 0 until rows) {
            rowOffset[r] = when (align) {
                1 -> (width - rowWidth[r]) * 0.5f
                2 -> width - rowWidth[r]
                else -> 0f
            }
        }
        for (i in 0 until n) wordX[i] += rowOffset[wordRow[i]]
        return LineLayout(
            line, sizePx, rows, width, sizePx * ROW_LEADING,
            wordX, wordRow, trimmed, rowStart, rowEnd, rowWidth, rowOffset
        )
    }

    private fun wrapCount(w: FloatArray, trimmed: FloatArray, count: Int, maxWidth: Float): Int {
        var rows = 1
        var cursor = 0f
        for (g in 0 until count) {
            if (cursor > 0f && cursor + trimmed[g] > maxWidth + 0.5f) {
                rows++
                cursor = 0f
            }
            cursor += w[g]
        }
        return rows
    }

    /** Shrinks the size until the line fits [maxRows] rows, never below [minScale] of [sizePx]. */
    fun layoutFit(
        line: VisLine, pen: VisPen, sizePx: Float, maxWidth: Float, align: Int,
        maxRows: Int, minScale: Float = 0.62f
    ): LineLayout {
        var size = sizePx
        var lay = layout(line, pen, size, maxWidth, align)
        val floor = sizePx * minScale
        while (lay.rowCount > maxRows && size > floor) {
            size = max(floor, size * 0.9f)
            lay = layout(line, pen, size, maxWidth, align)
        }
        return lay
    }
}

/** Layout cache for one text size / width / alignment combination. */
internal class LayoutCache {
    private val map = HashMap<Int, LineLayout>()
    private var sizeKey = 0
    private var widthKey = 0
    private var alignKey = -1
    private var fontKey = 0
    private var rowsKey = 0

    fun get(
        line: VisLine, pen: VisPen, sizePx: Float, maxWidth: Float, align: Int, maxRows: Int, fontId: Int
    ): LineLayout {
        val sk = (sizePx * 4f).toInt()
        val wk = maxWidth.toInt()
        if (sk != sizeKey || wk != widthKey || align != alignKey || fontId != fontKey || maxRows != rowsKey) {
            map.clear()
            sizeKey = sk; widthKey = wk; alignKey = align; fontKey = fontId; rowsKey = maxRows
        }
        map[line.index]?.let { return it }
        if (map.size > 160) map.clear()
        val lay = VisLayoutEngine.layoutFit(line, pen, sizePx, maxWidth, align, maxRows)
        map[line.index] = lay
        return lay
    }

    fun clear() = map.clear()
}

/** Draws a laid-out line with a per-word sweep highlight. */
internal object VisDraw {
    private val clip = RectF()

    /**
     * @param ox,oy top-left of the block
     * @param liftPx how far a sung word rises (0 disables)
     * @param glowPx shadow-layer radius for the active word (0 disables)
     */
    fun sweep(
        c: Canvas, pen: VisPen, lay: LineLayout, ox: Float, oy: Float, posMs: Long,
        dim: Int, lit: Int, active: Int, glow: Int, glowPx: Float, liftPx: Float, alpha: Float
    ) {
        val p = pen.fill
        p.textSize = lay.sizePx
        val words = lay.line.words
        val shortLine = lay.line.isShort
        for (i in words.indices) {
            val w = words[i]
            var prog = w.progress(posMs)
            if (shortLine && prog > 0f) prog = min(1f, prog * 1.6f + 0.1f)
            val x = ox + lay.wordX[i]
            val row = lay.wordRow[i]
            val baseY = oy + lay.baseline(row) - liftPx * smoothstep(prog)
            val text = w.text
            if (prog <= 0f) {
                p.color = withAlpha(dim, alpha)
                c.drawText(text, x, baseY, p)
            } else if (prog >= 1f) {
                p.color = withAlpha(lit, alpha)
                c.drawText(text, x, baseY, p)
            } else {
                p.color = withAlpha(dim, alpha)
                c.drawText(text, x, baseY, p)
                val width = lay.wordWidth[i]
                clip.set(x - 2f, baseY - lay.sizePx * 1.1f, x + width * prog, baseY + lay.sizePx * 0.4f)
                c.save()
                c.clipRect(clip)
                if (glowPx > 0f) p.setShadowLayer(glowPx, 0f, 0f, withAlpha(glow, alpha))
                p.color = withAlpha(active, alpha)
                c.drawText(text, x, baseY, p)
                if (glowPx > 0f) p.clearShadowLayer()
                c.restore()
            }
        }
    }

    /** Draws a single word with the sweep highlight at an arbitrary position. */
    fun word(
        c: Canvas, p: Paint, text: String, x: Float, y: Float, width: Float, size: Float, prog: Float,
        dim: Int, lit: Int, active: Int, glow: Int, glowPx: Float, alpha: Float
    ) {
        p.textSize = size
        if (prog <= 0f) {
            p.color = withAlpha(dim, alpha)
            c.drawText(text, x, y, p)
        } else if (prog >= 1f) {
            p.color = withAlpha(lit, alpha)
            c.drawText(text, x, y, p)
        } else {
            p.color = withAlpha(dim, alpha)
            c.drawText(text, x, y, p)
            clip.set(x - 2f, y - size * 1.1f, x + width * prog, y + size * 0.4f)
            c.save()
            c.clipRect(clip)
            if (glowPx > 0f) p.setShadowLayer(glowPx, 0f, 0f, withAlpha(glow, alpha))
            p.color = withAlpha(active, alpha)
            c.drawText(text, x, y, p)
            if (glowPx > 0f) p.clearShadowLayer()
            c.restore()
        }
    }

    /** Draws every word in one colour with a soft shadow (used by fade/typographic styles). */
    fun flat(
        c: Canvas, pen: VisPen, lay: LineLayout, ox: Float, oy: Float,
        color: Int, alpha: Float, glow: Int = 0, glowPx: Float = 0f
    ) {
        val p = pen.fill
        p.textSize = lay.sizePx
        p.color = withAlpha(color, alpha)
        if (glowPx > 0f) p.setShadowLayer(glowPx, 0f, 0f, withAlpha(glow, alpha))
        val words = lay.line.words
        for (i in words.indices) {
            c.drawText(words[i].text, ox + lay.wordX[i], oy + lay.baseline(lay.wordRow[i]), p)
        }
        if (glowPx > 0f) p.clearShadowLayer()
    }

    /** One small centred line (translation / romanization), shrunk to fit [maxWidth]. */
    fun secondary(
        c: Canvas, pen: VisPen, text: String, cx: Float, baseline: Float,
        sizePx: Float, maxWidth: Float, color: Int, alpha: Float
    ) {
        if (text.isEmpty() || alpha <= 0.01f) return
        val p = pen.fill
        p.textSize = sizePx
        var w = p.measureText(text)
        if (w > maxWidth && w > 0f) {
            p.textSize = sizePx * (maxWidth / w).coerceAtLeast(0.55f)
            w = p.measureText(text)
        }
        p.color = withAlpha(color, alpha)
        c.drawText(text, cx - min(w, maxWidth) * 0.5f, baseline, p)
        p.textSize = sizePx
    }

}
