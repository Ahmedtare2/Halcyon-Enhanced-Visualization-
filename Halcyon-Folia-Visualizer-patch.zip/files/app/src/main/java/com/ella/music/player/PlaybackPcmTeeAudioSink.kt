package com.ella.music.player

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.ForwardingAudioSink
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Transparent Media3 sink decorator. It analyses each decoded PCM buffer once immediately before
 * submission, preserving AudioSink.handleBuffer's PTS across partial writes. The delegate alone
 * retains ownership of the original buffer and playback output.
 */
@UnstableApi
internal class PlaybackPcmTeeAudioSink(
    delegate: AudioSink,
    private val tap: PlaybackPcmDrumTap
) : ForwardingAudioSink(delegate) {
    private var inputFormat: Format? = null
    private var pendingBuffer: ByteBuffer? = null
    private var pendingStartPosition = 0
    private var pendingPresentationTimeUs = 0L
    private var lastTimingSampleNs = 0L

    override fun configure(audioSinkConfig: AudioSink.AudioSinkConfig) {
        inputFormat = audioSinkConfig.format
        clearPending()
        super.configure(audioSinkConfig)
    }

    override fun handleBuffer(buffer: ByteBuffer, presentationTimeUs: Long, encodedAccessUnitCount: Int): Boolean {
        val format = inputFormat
        val before = buffer.position()
        val observing = PlaybackPcmDrumCapture.enabled && format != null && format.pcmEncoding != C.ENCODING_INVALID
        if (observing && format != null && pendingBuffer !== buffer) {
            pendingBuffer = buffer
            pendingStartPosition = before
            pendingPresentationTimeUs = presentationTimeUs
            // Analyse the decoded block before a blocking Oboe write can wait for the output
            // device. The detector is causal (one 20 ms frame), so this gives the visual clock
            // the maximum available PCM lead without changing the audio or adding a decoder.
            val copy = buffer.duplicate().order(ByteOrder.LITTLE_ENDIAN)
            copy.position(before)
            copy.limit(buffer.limit())
            tap.accept(copy.slice().order(ByteOrder.LITTLE_ENDIAN), format, presentationTimeUs)
        }

        // The delegate alone owns output and advances the original buffer. Its accepted region is
        // used only for the sink-queue diagnostic; repeated partial writes never re-run analysis.
        val fullyHandled = super.handleBuffer(buffer, presentationTimeUs, encodedAccessUnitCount)
        val after = buffer.position()
        if (observing && after > before && format != null && pendingBuffer === buffer) {
            val channels = format.channelCount
            val bytesPerSample = when (format.pcmEncoding) {
                C.ENCODING_PCM_8BIT -> 1
                C.ENCODING_PCM_16BIT -> 2
                C.ENCODING_PCM_24BIT -> 3
                C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 4
                else -> 0
            }
            val bytesPerFrame = bytesPerSample * channels
            if (bytesPerFrame > 0 && channels > 0) {
                val frameOffset = ((before - pendingStartPosition).coerceAtLeast(0) / bytesPerFrame).toLong()
                val slicePtsUs = pendingPresentationTimeUs + frameOffset * 1_000_000L / format.sampleRate.coerceAtLeast(1)
                val nowNs = System.nanoTime()
                if (nowNs - lastTimingSampleNs >= 100_000_000L) {
                    lastTimingSampleNs = nowNs
                    val outputPositionUs = try { super.getCurrentPositionUs(false) } catch (_: RuntimeException) { AudioSink.CURRENT_POSITION_NOT_SET }
                    val bufferSizeUs = try { super.getAudioTrackBufferSizeUs() } catch (_: RuntimeException) { C.TIME_UNSET }
                    val acceptedFrames = (after - before) / bytesPerFrame
                    val endPtsUs = slicePtsUs + acceptedFrames.toLong() * 1_000_000L / format.sampleRate.coerceAtLeast(1)
                    tap.reportOutputTiming(endPtsUs, outputPositionUs, bufferSizeUs)
                }
            }
        }
        if (fullyHandled) clearPending()
        return fullyHandled
    }

    override fun handleDiscontinuity() {
        clearPending()
        tap.resetSignal()
        super.handleDiscontinuity()
    }

    override fun flush() {
        clearPending()
        tap.resetSignal()
        super.flush()
    }

    override fun reset() {
        clearPending()
        tap.resetSignal()
        super.reset()
    }

    private fun clearPending() {
        pendingBuffer = null
        pendingStartPosition = 0
        pendingPresentationTimeUs = 0L
    }
}
