package com.ella.music.ui.vis

import android.graphics.Typeface
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.max
import kotlin.math.sin
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** What the sheets need to know about the running page. */
internal class VisSheetEnv(
    val theme: VisTheme,
    val coverTheme: VisTheme,
    val style: LyricStyle,
    val previewStyles: List<LyricStyle>,
    val songHint: String,
    val hasAudioPermission: Boolean,
    val requestAudioPermission: () -> Unit,
    val landscape: Boolean,
    val typeface: Typeface,
    val engine: String,
    val foliaAvailable: Boolean,
    val foliaModes: List<Pair<String, String>>,
    val foliaBackgrounds: List<Pair<String, String>>,
    val foliaStatus: String,
    val foliaRtlSong: Boolean,
    val foliaEffectiveMode: String,
    val foliaError: String,
    val foliaDiag: List<String>
)

@Composable
internal fun BoxScope.VisSheetPanel(
    visible: Boolean,
    landscape: Boolean,
    onDismiss: () -> Unit,
    content: @Composable ColumnScope.() -> Unit
) {
    AnimatedVisibility(visible = visible, enter = fadeIn(), exit = fadeOut(), modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().background(Color(0x66000000)).tap(onDismiss))
    }
    val align = if (landscape) Alignment.CenterEnd else Alignment.BottomCenter
    AnimatedVisibility(
        visible = visible,
        enter = if (landscape) slideInHorizontally { it } + fadeIn() else slideInVertically { it } + fadeIn(),
        exit = if (landscape) slideOutHorizontally { it } + fadeOut() else slideOutVertically { it } + fadeOut(),
        modifier = Modifier.align(align)
    ) {
        val size = if (landscape) Modifier.fillMaxHeight().width(400.dp) else Modifier.fillMaxWidth().fillMaxHeight(0.62f)
        Column(
            size
                .clip(RoundedCornerShape(topStart = 24.dp, topEnd = if (landscape) 0.dp else 24.dp))
                .background(Color(0xF2141824))
                .tap { }
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            content = content
        )
    }
}

// ---------------------------------------------------------------- styles

@Composable
internal fun StyleSheetContent(env: VisSheetEnv, onPick: (LyricStyle) -> Unit, onFoliaSettings: () -> Unit) {
    val accent = Color(env.theme.accent)
    BasicText("Lyric styles", style = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold))
    BasicText(
        "Swipe left or right on the lyric page to flip through them.",
        style = TextStyle(color = Color(0x99FFFFFF), fontSize = 12.sp),
        modifier = Modifier.padding(top = 2.dp, bottom = 8.dp)
    )
    VisSection("Engine")
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        VisChip("Folia (GPU)", env.engine == "folia", accent) { VisPrefs.engine = "folia"; VisPrefs.save() }
        VisChip("Native (lightest)", env.engine != "folia", accent) { VisPrefs.engine = "native"; VisPrefs.save() }
    }
    if (!env.foliaAvailable) {
        BasicText(
            "The Folia bundle is not part of this APK, so the native engine is used. Rebuild with the Folia source zip in the repository.",
            style = TextStyle(color = Color(0xCCFFB4A8), fontSize = 12.sp),
            modifier = Modifier.padding(bottom = 6.dp)
        )
    } else if (env.foliaStatus.isNotEmpty()) {
        BasicText(env.foliaStatus, style = TextStyle(color = Color(0xCCFFB4A8), fontSize = 12.sp), modifier = Modifier.padding(bottom = 6.dp))
    }
    if (env.engine == "folia") {
        VisSection("Folia style")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            for ((id, label) in env.foliaModes) {
                VisChip(label, VisPrefs.foliaMode == id, accent) { VisPrefs.foliaMode = id; VisPrefs.save() }
            }
        }
        if (env.foliaBackgrounds.isNotEmpty()) {
            VisSection("Folia background")
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                VisChip("Default", VisPrefs.foliaBackground.isEmpty(), accent) { VisPrefs.foliaBackground = ""; VisPrefs.save() }
                for ((id, label) in env.foliaBackgrounds) {
                    VisChip(label, VisPrefs.foliaBackground == id, accent) { VisPrefs.foliaBackground = id; VisPrefs.save() }
                }
            }
        }
        VisSection("Right-to-left songs (Arabic, Hebrew)")
        VisToggleRow("Use an RTL-ready style for these songs", VisPrefs.foliaRtlAuto, accent) { VisPrefs.foliaRtlAuto = it; VisPrefs.save() }
        if (VisPrefs.foliaRtlAuto) {
            Row(Modifier.horizontalScroll(rememberScrollState())) {
                for ((id, label) in env.foliaModes) {
                    if (id in RTL_READY_MODES) VisChip(label, VisPrefs.foliaRtlMode == id, accent) { VisPrefs.foliaRtlMode = id; VisPrefs.save() }
                }
            }
        }
        BasicText(
            if (env.foliaRtlSong && env.foliaEffectiveMode != VisPrefs.foliaMode) "This song is right-to-left, so it is using the style above instead of your pick."
            else "Most Folia styles draw letter by letter from the left, which breaks Arabic. Luminous, Partita, Monet and Diorama keep words whole and read right to left.",
            style = TextStyle(color = Color(0x88FFFFFF), fontSize = 11.sp),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Spacer(Modifier.height(10.dp))
        VisChip("Style settings…", false, accent) { onFoliaSettings() }
        BasicText(
            "These run Folia's own visualizers on the GPU. Lower the render scale in Tune if your phone gets warm.",
            style = TextStyle(color = Color(0x88FFFFFF), fontSize = 11.sp),
            modifier = Modifier.padding(top = 4.dp, bottom = 12.dp)
        )
    } else {
        VisSection("Native style")
        NativeStylePreviews(env, onPick)
    }
}

@Composable
private fun NativeStylePreviews(env: VisSheetEnv, onPick: (LyricStyle) -> Unit) {
    val accent = Color(env.theme.accent)
    val tick = remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        val start = System.nanoTime()
        while (true) {
            delay(66L)
            tick.longValue = System.nanoTime() - start
        }
    }
    val pen = remember { VisPen() }
    val frame = remember { VisFrame() }
    val bg = remember { VisBackground() }
    val drive = remember { AudioDrive() }
    val track = remember { sampleTrack() }
    LazyRow(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
        items(env.previewStyles, key = { it.id }) { st ->
            val selected = st.id == VisPrefs.styleId
            Column(Modifier.width(158.dp).tap { onPick(st) }) {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(110.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .border(if (selected) 2.dp else 1.dp, if (selected) accent else Color(0x33FFFFFF), RoundedCornerShape(14.dp))
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        tick.longValue
                        drawIntoCanvas { cv ->
                            val c = cv.nativeCanvas
                            if (pen.typeface !== env.typeface) pen.setFont(env.typeface)
                            val t = tick.longValue / 1_000_000_000f
                            val loop = track.durationMs.coerceAtLeast(1L)
                            val pos = ((t * 1000f).toLong()) % loop
                            drive.beat = max(0f, sin(t * 3.4f)).let { it * it * it * it }
                            drive.kick = drive.beat
                            drive.bass = 0.4f + 0.3f * drive.beat
                            drive.energy = 0.5f
                            frame.c = c
                            frame.pen = pen
                            frame.w = size.width; frame.h = size.height
                            frame.safeL = 0f; frame.safeT = 0f; frame.safeR = 0f; frame.safeB = 0f
                            frame.posMs = pos; frame.t = t; frame.dt = 0.066f; frame.playing = true
                            frame.track = track; frame.theme = env.theme; frame.drive = drive
                            frame.quality = 0.5f; frame.landscape = false; frame.textScale = 1f; frame.align = 1
                            frame.react = 1f; frame.beatK = 1f; frame.active = track.indexAt(pos)
                            frame.fontId = env.theme.font.ordinal
                            for (i in st.params.indices) if (i < frame.params.size) frame.params[i] = st.params[i].def
                            c.save()
                            c.clipRect(0f, 0f, size.width, size.height)
                            bg.draw(c, size.width, size.height, "solid", env.theme, t, drive, 0.5f, 0f, 0f)
                            st.draw(frame)
                            c.restore()
                        }
                    }
                }
                BasicText(
                    st.title,
                    style = TextStyle(color = if (selected) accent else Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold),
                    modifier = Modifier.padding(top = 6.dp)
                )
                BasicText(
                    st.blurb,
                    style = TextStyle(color = Color(0x88FFFFFF), fontSize = 11.sp),
                    maxLines = 2,
                    modifier = Modifier.padding(bottom = 6.dp)
                )
            }
        }
    }
    Spacer(Modifier.height(12.dp))
}

// ---------------------------------------------------------------- themes

@Composable
private fun ThemeSwatch(theme: VisTheme, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Column(Modifier.width(76.dp).tap(onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(58.dp)
                .clip(CircleShape)
                .background(Brush.verticalGradient(listOf(Color(theme.bgTop), Color(theme.bgMid), Color(theme.bgBottom))))
                .border(if (selected) 2.5.dp else 1.dp, if (selected) accent else Color(0x44FFFFFF), CircleShape)
        ) {
            Box(Modifier.align(Alignment.Center).size(16.dp).clip(CircleShape).background(Color(theme.accent)))
            Box(Modifier.align(Alignment.BottomEnd).padding(10.dp).size(9.dp).clip(CircleShape).background(Color(theme.accent2)))
        }
        BasicText(
            theme.name,
            style = TextStyle(color = if (selected) accent else Color(0xCCFFFFFF), fontSize = 11.sp),
            maxLines = 1,
            modifier = Modifier.padding(top = 4.dp)
        )
    }
}

@Composable
internal fun ThemeSheetContent(env: VisSheetEnv) {
    val accent = Color(env.theme.accent)
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    BasicText("Theme", style = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold))
    VisSection("Colours")
    LazyRow(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp)) {
        item(key = "cover") {
            ThemeSwatch(env.coverTheme, VisPrefs.themeId == VisThemes.COVER_ID, accent) {
                VisPrefs.themeId = VisThemes.COVER_ID; VisPrefs.save()
            }
        }
        items(VisThemes.presets, key = { it.id }) { t ->
            ThemeSwatch(t, VisPrefs.themeId == t.id, accent) { VisPrefs.themeId = t.id; VisPrefs.save() }
        }
        items(VisPrefs.customThemes, key = { it.id }) { t ->
            ThemeSwatch(t, VisPrefs.themeId == t.id, accent) { VisPrefs.themeId = t.id; VisPrefs.save() }
        }
    }
    val selectedCustom = VisPrefs.customThemes.firstOrNull { it.id == VisPrefs.themeId }
    if (selectedCustom != null) {
        Spacer(Modifier.height(8.dp))
        VisChip("Delete “" + selectedCustom.name + "”", false, accent) { VisPrefs.deleteCustomTheme(selectedCustom.id) }
    }
    VisSection("Font")
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        VisChip("Theme default", VisPrefs.fontOverride.isEmpty(), accent) { VisPrefs.fontOverride = ""; VisPrefs.save() }
        for (font in VisFont.values()) {
            VisChip(font.label, VisPrefs.fontOverride == font.name, accent) { VisPrefs.fontOverride = font.name; VisPrefs.save() }
        }
    }
    VisSection("AI theme")
    var prompt by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(Color(0x1FFFFFFF))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        BasicTextField(
            value = prompt,
            onValueChange = { prompt = it.take(120) },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth()
        )
        if (prompt.isEmpty()) {
            BasicText("Describe a mood, e.g. “warm sunset, vintage film”", style = TextStyle(color = Color(0x77FFFFFF), fontSize = 14.sp))
        }
    }
    Spacer(Modifier.height(8.dp))
    VisChip(if (busy) "Generating…" else "Generate theme", false, accent) {
        if (!busy && prompt.isNotBlank()) {
            scope.launch {
                busy = true
                message = ""
                try {
                    val t = VisAi.generate(context, prompt, env.songHint)
                    VisPrefs.addCustomTheme(t)
                    message = "Saved “" + t.name + "”"
                } catch (e: Exception) {
                    message = e.message ?: "Could not generate a theme."
                } finally {
                    busy = false
                }
            }
        }
    }
    if (message.isNotEmpty()) {
        BasicText(message, style = TextStyle(color = Color(0xBBFFFFFF), fontSize = 12.sp))
    }
    Spacer(Modifier.height(12.dp))
}

// ---------------------------------------------------------------- tune

@Composable
internal fun TuneSheetContent(env: VisSheetEnv) {
    val accent = Color(env.theme.accent)
    val style = env.style
    BasicText("Tune", style = TextStyle(color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold))

    if (env.engine != "folia" && style.params.isNotEmpty()) {
        VisSection(style.title)
        for (i in style.params.indices) {
            val p = style.params[i]
            val v = VisPrefs.tunings[style.paramKeys[i]] ?: p.def
            VisSliderRow(p.label, v, p.min, p.max, accent, { "%.2f".format(it) }) { VisPrefs.setTune(style.id, p.key, it) }
        }
    }

    VisSection("Text")
    VisSliderRow("Size", VisPrefs.textScale, 0.6f, 1.6f, accent, { "%.2fx".format(it) }) { VisPrefs.textScale = it; VisPrefs.save() }
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 6.dp)) {
        VisChip("Left", VisPrefs.align == 0, accent) { VisPrefs.align = 0; VisPrefs.save() }
        VisChip("Centre", VisPrefs.align == 1, accent) { VisPrefs.align = 1; VisPrefs.save() }
        VisChip("Right", VisPrefs.align == 2, accent) { VisPrefs.align = 2; VisPrefs.save() }
    }
    VisToggleRow("Show translation", VisPrefs.showTranslation, accent) { VisPrefs.showTranslation = it; VisPrefs.save() }
    VisToggleRow("Show romanization", VisPrefs.showRomanization, accent) { VisPrefs.showRomanization = it; VisPrefs.save() }

    if (env.engine != "folia") {
        VisSection("Background")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            for (o in VisBackgroundIds.options) {
                VisChip(o.label, VisPrefs.backgroundId == o.id, accent) { VisPrefs.backgroundId = o.id; VisPrefs.save() }
            }
        }
        VisSliderRow("Dim", VisPrefs.bgDim, 0f, 0.8f, accent, { "%.0f%%".format(it * 100f) }) { VisPrefs.bgDim = it; VisPrefs.save() }
    }

    VisSection("Audio reactive")
    VisToggleRow("React to the music", VisPrefs.audioReactive, accent) { VisPrefs.audioReactive = it; VisPrefs.save() }
    VisSliderRow("Strength", VisPrefs.reactStrength, 0f, 2f, accent, { "%.2f".format(it) }) { VisPrefs.reactStrength = it; VisPrefs.save() }
    if (VisPrefs.audioReactive && !env.hasAudioPermission) {
        BasicText(
            "Live spectrum needs the microphone/audio permission (same one the player visualizer uses). Beat analysis works without it.",
            style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 12.sp),
            modifier = Modifier.padding(vertical = 4.dp)
        )
        VisChip("Allow live spectrum", false, accent) { env.requestAudioPermission() }
    }

    VisSection("Beat effects")
    VisToggleRow("Beat effects", VisPrefs.beatFx, accent) { VisPrefs.beatFx = it; VisPrefs.save() }
    VisToggleRow("Light mode (fewer, gentler beats)", VisPrefs.beatLight, accent) { VisPrefs.beatLight = it; VisPrefs.save() }
    VisSliderRow("Strength", VisPrefs.beatStrength, 0f, 2f, accent, { "%.2f".format(it) }) { VisPrefs.beatStrength = it; VisPrefs.save() }
    VisSliderRow("Timing", VisPrefs.beatOffsetMs.toFloat(), -250f, 250f, accent, { "%+.0f ms".format(it) }) {
        VisPrefs.beatOffsetMs = it.toInt(); VisPrefs.save()
    }
    if (VisController.beatStatus.isNotEmpty()) {
        BasicText(VisController.beatStatus, style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 12.sp), modifier = Modifier.padding(top = 2.dp))
    }

    VisSection("Performance")
    if (env.engine == "folia") {
        BasicText(
            "Render scale is the biggest GPU and battery lever. Lower = sharper text costs less power.",
            style = TextStyle(color = Color(0x88FFFFFF), fontSize = 11.sp),
            modifier = Modifier.padding(bottom = 6.dp)
        )
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            for (v in listOf(0f, 1f, 1.25f, 1.5f, 2f, 3f)) {
                VisChip(if (v == 0f) "Auto" else "${v}x", VisPrefs.foliaDpr == v, accent) { VisPrefs.foliaDpr = v; VisPrefs.save() }
            }
        }
    }
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        val names = listOf("Auto", "High", "Balanced", "Battery")
        for (i in names.indices) VisChip(names[i], VisPrefs.quality == i, accent) { VisPrefs.quality = i; VisPrefs.save() }
    }
    Row(Modifier.horizontalScroll(rememberScrollState())) {
        for (fps in listOf(0, 30, 60, 90, 120)) {
            VisChip(if (fps == 0) "Auto fps" else "$fps fps", VisPrefs.fpsCap == fps, accent) { VisPrefs.fpsCap = fps; VisPrefs.save() }
        }
    }

    if (env.engine == "folia") {
        VisSection("Folia diagnostics")
        VisToggleRow("Show an info line on the page", VisPrefs.foliaDebug, accent) { VisPrefs.foliaDebug = it; VisPrefs.save() }
        if (env.foliaError.isNotEmpty()) {
            BasicText("Last error: " + env.foliaError, style = TextStyle(color = Color(0xFFFFB4A8), fontSize = 12.sp), modifier = Modifier.padding(vertical = 4.dp))
        }
        for (line in env.foliaDiag) {
            BasicText(line, style = TextStyle(color = Color(0x99FFFFFF), fontSize = 11.sp), modifier = Modifier.padding(vertical = 1.dp))
        }
    }

    VisSection("Page")
    VisToggleRow("Extra floating open button", VisPrefs.showButton, accent) { VisPrefs.showButton = it; VisPrefs.save() }
    VisToggleRow("Keep the screen on", VisPrefs.keepScreenOn, accent) { VisPrefs.keepScreenOn = it; VisPrefs.save() }
    VisToggleRow("Auto-hide controls", VisPrefs.autoHideHud, accent) { VisPrefs.autoHideHud = it; VisPrefs.save() }
    Spacer(Modifier.height(16.dp))
}
