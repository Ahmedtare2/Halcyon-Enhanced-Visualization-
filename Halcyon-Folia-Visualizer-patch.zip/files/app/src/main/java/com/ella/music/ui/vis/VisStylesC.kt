package com.ella.music.ui.vis

import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RectF
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private val ADD_MODE = PorterDuffXfermode(PorterDuff.Mode.ADD)

/** Sonnet: kinetic poster typography – every row is stretched to the full width of the screen. */
internal class SonnetStyle : LyricStyle(
    "sonnet", "Sonnet", "Poster typography that fills the whole screen",
    listOf(StyleParam("punch", "Beat punch", 0f, 2f, 1f), StyleParam("block", "Highlight block", 0f, 1f, 1f))
) {
    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        val c = f.c
        val th = f.theme
        val line = f.track.lines[idx]
        val size = f.heroPx * 1.55f
        val maxW = f.contentW * 0.92f
        val lay = layoutOf(f, line, size, maxW, 4)
        val since = f.posMs - line.startMs
        val rows = lay.rowCount
        var totalH = 0f
        val scales = FloatArray(rows)
        for (r in 0 until rows) {
            val rw = max(1f, lay.rowWidth[r])
            val s = (maxW / rw).coerceIn(0.85f, 1.9f)
            scales[r] = s
            totalH += lay.rowHeight * s
        }
        val maxH = f.contentH * 0.82f
        val fit = if (totalH > maxH) maxH / totalH else 1f
        totalH *= fit
        val punch = 1f + 0.035f * f.beat * f.params[0]
        c.save()
        c.scale(punch, punch, f.cx, f.cy)
        var y = f.cy - totalH / 2f
        val blockColor = th.accent
        val onBlock = readableOn(blockColor)
        val p = f.pen.fill
        val fill = f.pen.shape
        for (r in 0 until rows) {
            val s = scales[r] * fit
            val rowW = lay.rowWidth[r] * s
            val slide = (1f - easeOutBack(since / (260f + r * 80f) + 0.1f)).coerceAtLeast(0f) *
                f.contentW * 0.5f * (if (r % 2 == 0) -1f else 1f)
            c.save()
            c.translate(f.cx - rowW / 2f + slide, y)
            c.scale(s, s)
            for (i in lay.rowStart[r]..lay.rowEnd[r]) {
                val w = line.words[i]
                val x = lay.wordX[i] - lay.rowOffset[r]
                val base = lay.sizePx * 0.98f
                val prog = w.progress(f.posMs)
                val width = lay.wordWidth[i]
                if (prog > 0f && f.params[1] > 0.02f) {
                    val fade = 1f - smoothstep((f.posMs - w.endMs) / 500f)
                    if (fade > 0.01f) {
                        fill.color = withAlpha(blockColor, fade * f.params[1])
                        val bw = width * (if (prog < 1f) prog else 1f)
                        f.pen.rect.set(x - lay.sizePx * 0.05f, base - lay.sizePx * 0.92f, x + bw + lay.sizePx * 0.05f, base + lay.sizePx * 0.2f)
                        c.drawRect(f.pen.rect, fill)
                        c.save()
                        c.clipRect(f.pen.rect)
                        p.textSize = lay.sizePx
                        p.color = withAlpha(onBlock, fade)
                        c.drawText(w.text, x, base, p)
                        c.restore()
                        if (prog >= 1f && fade < 0.99f) {
                            VisDraw.word(c, p, w.text, x, base, width, lay.sizePx, 1f, th.textDim, th.text, th.text, 0, 0f, 1f - fade)
                        }
                        if (prog < 1f) {
                            c.save()
                            f.pen.rect.set(x + bw, base - lay.sizePx * 1.1f, x + width + lay.sizePx, base + lay.sizePx * 0.4f)
                            c.clipRect(f.pen.rect)
                            VisDraw.word(c, p, w.text, x, base, width, lay.sizePx, 0f, th.textDim, th.text, th.text, 0, 0f, 1f)
                            c.restore()
                        }
                        continue
                    }
                }
                VisDraw.word(c, p, w.text, x, base, width, lay.sizePx, if (prog >= 1f) 1f else 0f, th.textDim, th.text, th.text, 0, 0f, 1f)
            }
            c.restore()
            y += lay.rowHeight * s
        }
        c.restore()
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, f.safeT + f.contentH * 0.93f, size * 0.26f, f.maxTextW, th.textSoft, 1f)
    }
}

/** Lumière: bloom and light rays centred on the word being sung, with soft bokeh. */
internal class LumiereStyle : LyricStyle(
    "lumiere", "Lumière", "Bloom, light rays and bokeh around the sung word",
    listOf(StyleParam("rays", "Light rays", 0f, 2f, 1f), StyleParam("bokeh", "Bokeh", 0f, 2f, 1f))
) {
    private val blobs = SoftBlobs()
    private var hx = 0f
    private var hy = 0f
    private var init = false

    override fun reset() { super.reset(); init = false }

    override fun draw(f: VisFrame) {
        val c = f.c
        val th = f.theme
        drawBokeh(f)
        val idx = focus(f)
        if (idx < 0) return
        val line = f.track.lines[idx]
        val size = f.heroPx * 1.05f
        val lay = layoutOf(f, line, size, f.maxTextW, 3)
        val ox = f.cx - lay.width / 2f
        val oy = f.cy - lay.height / 2f
        var tx = f.cx
        var ty = f.cy
        for (i in line.words.indices) {
            val pr = line.words[i].progress(f.posMs)
            if (pr > 0f && pr < 1f) {
                tx = ox + lay.wordX[i] + lay.wordWidth[i] * pr
                ty = oy + lay.baseline(lay.wordRow[i]) - size * 0.35f
            }
        }
        if (!init) { hx = tx; hy = ty; init = true }
        val k = min(1f, f.dt * 9f)
        hx += (tx - hx) * k
        hy += (ty - hy) * k
        val rays = (7f * f.params[0] * f.quality).toInt().coerceIn(0, 10)
        val shape = f.pen.shape
        if (rays > 0) {
            shape.xfermode = ADD_MODE
            val len = f.contentW * 0.9f
            for (i in 0 until rays) {
                val a = f.t * 0.12f * (if (i % 2 == 0) 1f else -0.7f) + i * (2f * PI.toFloat() / rays)
                val half = 0.03f + 0.02f * hash01(i)
                val rayLen = len * (0.6f + 0.4f * hash01(i + 40))
                shape.color = withAlpha(if (i % 2 == 0) th.accent else th.accent2, 0.045f + 0.05f * f.beat)
                val path = rayPath
                path.reset()
                path.moveTo(hx, hy)
                path.lineTo(hx + cos(a - half) * rayLen, hy + sin(a - half) * rayLen)
                path.lineTo(hx + cos(a + half) * rayLen, hy + sin(a + half) * rayLen)
                path.close()
                c.drawPath(path, shape)
            }
            shape.xfermode = null
        }
        blobs.draw(c, hx, hy, size * (1.7f + 0.3f * f.beat), th.accent, 0.5f, add = true)
        blobs.draw(c, hx, hy, size * 0.55f, argb(255, 255, 255), 0.55f, add = true)
        VisDraw.sweep(c, f.pen, lay, ox, oy, f.posMs, th.textDim, th.text, argb(255, 255, 255), th.accent, size * 0.6f, size * 0.06f, 1f)
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.65f, size * 0.4f, f.maxTextW, th.textSoft, 1f)
    }

    private val rayPath = android.graphics.Path()

    private fun drawBokeh(f: VisFrame) {
        val n = (14f * f.params[1] * f.quality).toInt().coerceIn(0, 18)
        for (i in 0 until n) {
            val h1 = hash01(i * 3 + 1)
            val h2 = hash01(i * 3 + 2)
            val h3 = hash01(i * 3 + 3)
            val x = f.w * (h1 + 0.04f * sin(f.t * (0.1f + h3 * 0.15f) + i.toFloat()))
            val y = f.h * (((h2 - f.t * (0.01f + h3 * 0.015f)) % 1f + 1f) % 1f)
            val r = min(f.w, f.h) * (0.025f + 0.06f * h3) * (1f + 0.3f * f.treble)
            blobs.draw(f.c, x, y, r, if (i % 2 == 0) f.theme.accent else f.theme.text, 0.14f, add = true)
        }
    }
}

/** Hanabi: fireworks burst from each finished word and rockets launch on the kick drum. */
internal class HanabiStyle : LyricStyle(
    "hanabi", "Hanabi", "Fireworks on every word and on the beat",
    listOf(StyleParam("burst", "Burst size", 0.5f, 1.6f, 1f), StyleParam("launch", "Rockets", 0f, 2f, 1f))
) {
    private val pool = ParticlePool(420)
    private val rx = FloatArray(4)
    private val ry = FloatArray(4)
    private val rtx = FloatArray(4)
    private val rty = FloatArray(4)
    private val rage = FloatArray(4) { 9f }
    private var lastKey = -1
    private var lastRocketT = -10f
    private val blobs = SoftBlobs()

    override fun reset() {
        super.reset(); pool.clear(); lastKey = -1
        for (i in rage.indices) rage[i] = 9f
    }

    override fun draw(f: VisFrame) {
        val c = f.c
        val th = f.theme
        val idx = focus(f)
        var oy = f.cy
        var ox = f.cx
        var lay: LineLayout? = null
        if (idx >= 0) {
            val line = f.track.lines[idx]
            val size = f.heroPx
            val l = layoutOf(f, line, size, f.maxTextW, 3)
            lay = l
            ox = f.cx - l.width / 2f
            oy = f.cy - l.height / 2f
            if (f.playing) {
                var done = 0
                for (w in line.words) if (w.endMs <= f.posMs) done++
                val key = line.index * 1000 + done
                if (key != lastKey) {
                    val sameLine = lastKey / 1000 == line.index
                    lastKey = key
                    if (sameLine && done > 0) {
                        val wi = done - 1
                        val bx = ox + l.wordX[wi] + l.wordWidth[wi] / 2f
                        val by = oy + l.baseline(l.wordRow[wi]) - size * 0.9f
                        burst(f, bx, by, (16f * f.params[0] * f.quality).toInt().coerceAtLeast(6), 170f * f.params[0])
                    }
                }
            }
        }
        if (f.playing && f.params[1] > 0.05f && f.kick > 0.75f && f.t - lastRocketT > 0.5f / f.params[1].coerceAtLeast(0.3f)) {
            lastRocketT = f.t
            launch(f)
        }
        updateRockets(f)
        updateParticles(f)
        if (lay != null && idx >= 0) {
            val size = lay.sizePx
            VisDraw.sweep(c, f.pen, lay, ox, oy, f.posMs, th.textDim, th.text, th.accent, th.accent, size * 0.3f, size * 0.07f, 1f)
            val line = lay.line
            val sec = line.translation.ifEmpty { line.romanization }
            VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.65f, size * 0.4f, f.maxTextW, th.textSoft, 1f)
        }
    }

    private fun launch(f: VisFrame) {
        for (i in rage.indices) {
            if (rage[i] > 1f) {
                val s = (f.t * 1000f).toInt() + i * 17
                rx[i] = f.safeL + f.contentW * (0.2f + 0.6f * hash01(s))
                ry[i] = f.h
                rtx[i] = f.safeL + f.contentW * (0.12f + 0.76f * hash01(s + 1))
                rty[i] = f.safeT + f.contentH * (0.1f + 0.3f * hash01(s + 2))
                rage[i] = 0f
                return
            }
        }
    }

    private fun updateRockets(f: VisFrame) {
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(2f, f.w * 0.004f)
        for (i in rage.indices) {
            if (rage[i] > 1f) continue
            val prev = rage[i]
            rage[i] += f.dt / 0.7f
            val k = easeOutCubic(rage[i])
            val x = lerpF(rx[i], rtx[i], k)
            val y = lerpF(ry[i], rty[i], k)
            val kp = easeOutCubic(prev)
            stroke.color = withAlpha(f.theme.text, 0.8f)
            f.c.drawLine(lerpF(rx[i], rtx[i], kp), lerpF(ry[i], rty[i], kp), x, y, stroke)
            if (rage[i] >= 1f) {
                burst(f, x, y, (34f * f.params[0] * f.quality).toInt().coerceAtLeast(10), 230f * f.params[0])
                rage[i] = 9f
            }
        }
    }

    private fun burst(f: VisFrame, x: Float, y: Float, n: Int, speed: Float) {
        val seed = (f.t * 997f).toInt()
        val scale = f.h / 1920f * 1.6f + 0.2f
        for (i in 0 until n) {
            val a = 2f * PI.toFloat() * i / n + hash01(seed + i) * 0.4f
            val sp = speed * scale * (0.5f + 0.5f * hash01(seed + i * 3 + 1))
            val col = when (i % 3) { 0 -> f.theme.accent; 1 -> f.theme.accent2; else -> lerpColor(f.theme.text, f.theme.accent, 0.4f) }
            pool.spawn(x, y, cos(a) * sp, sin(a) * sp, 0.9f + 0.7f * hash01(seed + i * 5 + 2), max(2f, f.w * 0.004f), col)
        }
    }

    private fun updateParticles(f: VisFrame) {
        val stroke = f.pen.stroke
        val g = f.h * 0.12f
        val drag = Math.pow(0.12, f.dt.toDouble()).toFloat()
        for (i in 0 until pool.capacity) {
            if (pool.life[i] <= 0f) continue
            pool.life[i] -= f.dt
            pool.px[i] = pool.x[i]; pool.py[i] = pool.y[i]
            pool.vx[i] *= drag
            pool.vy[i] = pool.vy[i] * drag + g * f.dt
            pool.x[i] += pool.vx[i] * f.dt
            pool.y[i] += pool.vy[i] * f.dt
            val k = (pool.life[i] / pool.maxLife[i]).coerceIn(0f, 1f)
            stroke.strokeWidth = pool.size[i] * (0.4f + 0.8f * k)
            stroke.color = withAlpha(pool.color[i], k)
            f.c.drawLine(pool.px[i], pool.py[i], pool.x[i], pool.y[i], stroke)
            if (k > 0.55f) blobs.draw(f.c, pool.x[i], pool.y[i], pool.size[i] * 4f, pool.color[i], 0.35f * k, add = true)
        }
    }
}

/** Tempera: every sung word leaves a bleeding watercolour blot behind the text. */
internal class TemperaStyle : LyricStyle(
    "tempera", "Tempera", "Watercolour blots that bloom behind every word",
    listOf(StyleParam("bleed", "Bleed", 0f, 2f, 1f), StyleParam("grain", "Paper grain", 0f, 2f, 1f))
) {
    private val cap = 28
    private val bx = FloatArray(cap)
    private val by = FloatArray(cap)
    private val br = FloatArray(cap)
    private val bt = FloatArray(cap) { -99f }
    private val bc = IntArray(cap)
    private var next = 0
    private var lastKey = -1
    private val blobs = SoftBlobs()
    private var grain = FloatArray(0)
    private var grainW = 0f
    private var grainH = 0f

    override fun reset() { super.reset(); lastKey = -1; for (i in bt.indices) bt[i] = -99f }

    override fun draw(f: VisFrame) {
        val c = f.c
        val th = f.theme
        drawGrain(f)
        val idx = focus(f)
        var lay: LineLayout? = null
        var ox = 0f
        var oy = 0f
        if (idx >= 0) {
            val line = f.track.lines[idx]
            val size = f.heroPx * 0.98f
            val l = layoutOf(f, line, size, f.maxTextW, 3)
            lay = l
            ox = f.cx - l.width / 2f
            oy = f.cy - l.height / 2f
            var started = 0
            for (w in line.words) if (w.startMs <= f.posMs) started++
            val key = line.index * 1000 + started
            if (key != lastKey) {
                val sameLine = lastKey / 1000 == line.index
                lastKey = key
                if (f.playing && (sameLine || started > 0) && started > 0) {
                    val wi = started - 1
                    spawn(f, ox + l.wordX[wi] + l.wordWidth[wi] / 2f, oy + l.baseline(l.wordRow[wi]) - size * 0.32f, l.wordWidth[wi] * 0.55f + size * 0.5f, wi)
                }
            }
        }
        for (i in 0 until cap) {
            val age = f.t - bt[i]
            if (age < 0f || age > 11f) continue
            val grow = easeOutCubic(min(1f, age / 0.8f))
            val r = br[i] * (0.45f + 0.55f * grow) * (1f + 0.04f * age * f.params[0])
            val fade = 1f - smoothstep((age - 5f) / 6f)
            val a = 0.32f * fade
            blobs.draw(c, bx[i], by[i], r, bc[i], a, 1.25f, 0.85f)
            blobs.draw(c, bx[i] + r * 0.25f, by[i] - r * 0.1f, r * 0.6f, bc[i], a * 0.8f, 1.1f, 1f)
            val stroke = f.pen.stroke
            stroke.strokeWidth = max(1.5f, r * 0.03f)
            stroke.color = withAlpha(bc[i], 0.16f * fade)
            f.pen.rect.set(bx[i] - r * 1.1f, by[i] - r * 0.8f, bx[i] + r * 1.1f, by[i] + r * 0.8f)
            c.drawOval(f.pen.rect, stroke)
        }
        if (lay != null) {
            val size = lay.sizePx
            VisDraw.sweep(c, f.pen, lay, ox, oy, f.posMs, th.textDim, th.text, th.text, 0, 0f, size * 0.05f, 1f)
            val line = lay.line
            val sec = line.translation.ifEmpty { line.romanization }
            VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.65f, size * 0.4f, f.maxTextW, th.textSoft, 1f)
        }
    }

    private fun spawn(f: VisFrame, x: Float, y: Float, r: Float, wordIndex: Int) {
        bx[next] = x; by[next] = y; br[next] = r; bt[next] = f.t
        bc[next] = when (wordIndex % 3) { 0 -> f.theme.accent; 1 -> f.theme.accent2; else -> lerpColor(f.theme.accent, f.theme.accent2, 0.5f) }
        next = (next + 1) % cap
    }

    private fun drawGrain(f: VisFrame) {
        if (f.params[1] < 0.05f) return
        if (grainW != f.w || grainH != f.h) {
            grainW = f.w; grainH = f.h
            grain = FloatArray(2 * 260)
            for (i in 0 until 260) { grain[2 * i] = hash01(i * 2 + 5) * f.w; grain[2 * i + 1] = hash01(i * 2 + 6) * f.h }
        }
        val p = f.pen.stroke
        p.strokeWidth = max(1.2f, f.w * 0.0025f)
        p.color = withAlpha(f.theme.text, 0.07f * f.params[1])
        f.c.drawPoints(grain, 0, grain.size, p)
    }
}

/** Nebbia: text condenses out of drifting fog, one word at a time. */
internal class NebbiaStyle : LyricStyle(
    "nebbia", "Nebbia", "Words condense out of drifting fog",
    listOf(StyleParam("fog", "Fog", 0f, 2f, 1f), StyleParam("soft", "Softness", 0f, 2f, 1f))
) {
    private val blobs = SoftBlobs()

    override fun draw(f: VisFrame) {
        val c = f.c
        val th = f.theme
        drawFog(f, 0)
        val idx = focus(f)
        if (idx >= 0) {
            val line = f.track.lines[idx]
            val size = f.heroPx * 1.02f
            val lay = layoutOf(f, line, size, f.maxTextW, 3)
            val ox = f.cx - lay.width / 2f
            val oy = f.cy - lay.height / 2f
            val p = f.pen.fill
            val after = if (f.posMs > line.endMs) 1f - smoothstep((f.posMs - line.endMs) / 1400f) else 1f
            for (i in line.words.indices) {
                val w = line.words[i]
                val prog = w.progress(f.posMs)
                val rev = smoothstep(min(1f, prog * 1.6f))
                val x = ox + lay.wordX[i]
                val y = oy + lay.baseline(lay.wordRow[i]) - size * 0.05f * rev
                val soft = (1f - rev) * size * 0.12f * f.params[1]
                val base = (0.16f + 0.84f * rev) * after
                if (soft > 0.8f) {
                    val a4 = base * 0.22f
                    VisDraw.word(c, p, w.text, x - soft, y, lay.wordWidth[i], lay.sizePx, 1f, th.textDim, th.text, th.text, 0, 0f, a4)
                    VisDraw.word(c, p, w.text, x + soft, y, lay.wordWidth[i], lay.sizePx, 1f, th.textDim, th.text, th.text, 0, 0f, a4)
                    VisDraw.word(c, p, w.text, x, y - soft, lay.wordWidth[i], lay.sizePx, 1f, th.textDim, th.text, th.text, 0, 0f, a4)
                    VisDraw.word(c, p, w.text, x, y + soft, lay.wordWidth[i], lay.sizePx, 1f, th.textDim, th.text, th.text, 0, 0f, a4)
                }
                val litGlow = if (prog > 0f && prog < 1f) size * 0.3f else 0f
                VisDraw.word(
                    c, p, w.text, x, y, lay.wordWidth[i], lay.sizePx, if (prog >= 1f) 1f else prog,
                    th.textDim, th.text, th.accent, th.accent, litGlow, base
                )
            }
            val sec = line.translation.ifEmpty { line.romanization }
            VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.65f, size * 0.4f, f.maxTextW, th.textSoft, after)
        }
        drawFog(f, 1)
    }

    private fun drawFog(f: VisFrame, layer: Int) {
        val n = if (layer == 0) 4 else 2
        val dens = f.params[0] * (1f + 0.7f * f.bass)
        for (i in 0 until n) {
            val k = i + layer * 4
            val speed = 0.012f + 0.01f * hash01(k + 9)
            val x = f.w * (((hash01(k + 1) + f.t * speed) % 1.5f) - 0.25f)
            val y = f.h * (0.22f + 0.5f * hash01(k + 2) + 0.03f * sin(f.t * 0.2f + k))
            val r = f.w * (0.45f + 0.25f * hash01(k + 3))
            blobs.draw(f.c, x, y, r, f.theme.text, (if (layer == 0) 0.07f else 0.045f) * dens, 2.2f, 0.75f)
        }
    }
}

/** Diorama: dotted 3D objects float in depth around the line, swaying on the beat. */
internal class DioramaStyle : LyricStyle(
    "diorama", "Diorama", "Dotted 3D objects drifting in depth",
    listOf(StyleParam("objects", "Objects", 0.3f, 1.6f, 1f), StyleParam("depth", "Depth sway", 0f, 2f, 1f))
) {
    private val maxObjects = 12
    private val ptsPer = 56
    private val local = FloatArray(maxObjects * ptsPer * 3)
    private val ox = FloatArray(maxObjects)
    private val oy = FloatArray(maxObjects)
    private val oz = FloatArray(maxObjects)
    private val orbit = FloatArray(maxObjects)
    private val buf = FloatArray(ptsPer * 2)
    private val blobs = SoftBlobs()
    private var built = false

    private fun build() {
        for (o in 0 until maxObjects) {
            val type = o % 3
            ox[o] = (hash01(o * 11 + 1) - 0.5f) * 2.6f
            oy[o] = (hash01(o * 11 + 2) - 0.5f) * 1.7f
            oz[o] = 0.7f + hash01(o * 11 + 3) * 1.7f
            orbit[o] = 0.25f + hash01(o * 11 + 4) * 0.6f
            for (p in 0 until ptsPer) {
                val b = (o * ptsPer + p) * 3
                val u = p.toFloat() / ptsPer
                when (type) {
                    0 -> { // sphere on a golden-angle spiral
                        val y = 1f - 2f * u
                        val r = sqrt(max(0f, 1f - y * y))
                        val th = p * 2.39996f
                        local[b] = cos(th) * r; local[b + 1] = y; local[b + 2] = sin(th) * r
                    }
                    1 -> { // cylinder
                        val th = (p % 14) * (2f * PI.toFloat() / 14f)
                        local[b] = cos(th); local[b + 1] = (p / 14) / 3f - 0.65f; local[b + 2] = sin(th)
                    }
                    else -> { // cube lattice
                        local[b] = ((p % 4) - 1.5f) / 1.5f
                        local[b + 1] = (((p / 4) % 4) - 1.5f) / 1.5f
                        local[b + 2] = ((p / 16) - 1.5f) / 1.5f
                    }
                }
            }
        }
        built = true
    }

    override fun draw(f: VisFrame) {
        if (!built) build()
        val c = f.c
        val th = f.theme
        val focal = f.contentH * 0.62f
        val n = (maxObjects * f.params[0] * f.quality).toInt().coerceIn(3, maxObjects)
        val sway = f.params[1]
        val camX = 0.25f * sin(f.t * 0.17f) * sway
        val camY = 0.12f * sin(f.t * 0.23f + 1f) * sway
        val camZ = -0.12f * f.kick * sway
        val dot = f.pen.stroke
        for (o in 0 until n) {
            val z0 = oz[o] + camZ + 0.18f * sin(f.t * 0.3f + o)
            if (z0 < 0.25f) continue
            val spin = f.t * orbit[o] + o
            val cs = cos(spin)
            val sn = sin(spin)
            val scale = 0.30f * (1f + 0.22f * f.kick)
            var cnt = 0
            for (p in 0 until ptsPer) {
                val b = (o * ptsPer + p) * 3
                val x = local[b] * scale
                val y = local[b + 1] * scale
                val z = local[b + 2] * scale
                val rx = x * cs + z * sn
                val rz = -x * sn + z * cs
                val zz = z0 + rz
                if (zz < 0.2f) continue
                buf[2 * cnt] = f.cx + (ox[o] + rx - camX) / zz * focal
                buf[2 * cnt + 1] = f.cy + (oy[o] + y - camY) / zz * focal
                cnt++
            }
            val depthAlpha = (1.2f - z0 * 0.4f).coerceIn(0.25f, 1f)
            dot.strokeWidth = max(1.6f, focal * 0.011f / z0)
            dot.color = withAlpha(if (o % 2 == 0) th.text else th.accent, 0.8f * depthAlpha)
            c.drawPoints(buf, 0, cnt * 2, dot)
            val sx = f.cx + (ox[o] - camX) / z0 * focal
            val sy = f.cy + (oy[o] - camY) / z0 * focal
            blobs.draw(c, sx, sy, focal * 0.13f / z0 * (1f + 0.4f * f.bass), if (o % 2 == 0) th.accent2 else th.accent, 0.5f * depthAlpha, add = true)
        }
        val idx = focus(f)
        if (idx < 0) return
        val line = f.track.lines[idx]
        val size = f.heroPx * 0.95f
        val lay = layoutOf(f, line, size, f.maxTextW, 3)
        val s = 1f + 0.02f * f.beat
        c.save()
        c.scale(s, s, f.cx, f.cy)
        val tox = f.cx - lay.width / 2f
        val toy = f.cy - lay.height / 2f + f.contentH * 0.14f
        VisDraw.sweep(c, f.pen, lay, tox, toy, f.posMs, th.textDim, th.text, th.accent, th.accent, size * 0.3f, size * 0.07f, 1f)
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, toy + lay.height + size * 0.65f, size * 0.4f, f.maxTextW, th.textSoft, 1f)
        c.restore()
    }
}

/** Machi: a neon city – the lyric is the sign, and windows light up as words are sung. */
internal class MachiStyle : LyricStyle(
    "machi", "Machi", "A night city where windows light up with each word",
    listOf(StyleParam("windows", "Windows", 0f, 2f, 1f), StyleParam("neon", "Neon", 0f, 2f, 1f))
) {
    private val blobs = SoftBlobs()
    private val neon = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND }
    private var bw = FloatArray(0)
    private var bh = FloatArray(0)
    private var bxs = FloatArray(0)
    private var bl = IntArray(0)
    private var builtW = 0f
    private var builtH = 0f
    private val rect = RectF()

    private fun build(f: VisFrame) {
        builtW = f.w; builtH = f.h
        val count = 26
        bw = FloatArray(count); bh = FloatArray(count); bxs = FloatArray(count); bl = IntArray(count)
        var xFar = -f.w * 0.05f
        var xNear = -f.w * 0.05f
        for (i in 0 until count) {
            val layer = if (i % 2 == 0) 0 else 1
            val w = f.w * (0.06f + 0.07f * hash01(i * 3 + 1))
            val h = f.contentH * (if (layer == 0) 0.22f + 0.22f * hash01(i * 3 + 2) else 0.12f + 0.18f * hash01(i * 3 + 2))
            bw[i] = w; bh[i] = h; bl[i] = layer
            if (layer == 0) { bxs[i] = xFar; xFar += w * 0.92f } else { bxs[i] = xNear; xNear += w * 0.96f }
        }
    }

    override fun draw(f: VisFrame) {
        if (builtW != f.w || builtH != f.h) build(f)
        val c = f.c
        val th = f.theme
        val idx = focus(f)
        val line = if (idx >= 0) f.track.lines[idx] else null
        var sung = 0
        var total = 1
        if (line != null) {
            total = line.words.size
            for (w in line.words) if (w.startMs <= f.posMs) sung++
        }
        val activity = (0.12f + 0.55f * (sung.toFloat() / total) + 0.3f * f.energy) * f.params[0]
        blobs.draw(c, f.safeL + f.contentW * 0.78f, f.safeT + f.contentH * 0.2f, min(f.w, f.h) * 0.35f, th.accent2, 0.35f, add = true)
        val ground = f.h - f.safeB * 0.0f
        val fill = f.pen.shape
        for (layer in 0..1) {
            val par = (if (layer == 0) 0.012f else 0.03f) * f.w * sin(f.t * 0.05f)
            for (i in bw.indices) {
                if (bl[i] != layer) continue
                val x = bxs[i] + par
                val top = ground - bh[i]
                fill.color = if (layer == 0) withAlpha(lerpColor(th.bgBottom, th.accent2, 0.15f), 0.92f) else withAlpha(lerpColor(th.bgBottom, th.bgTop, 0.4f), 0.97f)
                rect.set(x, top, x + bw[i], ground)
                c.drawRect(rect, fill)
                val cols = max(2, (bw[i] / (f.w * 0.018f)).toInt())
                val rows = max(2, (bh[i] / (f.w * 0.026f)).toInt())
                val ww = bw[i] / (cols * 1.9f)
                val wh = f.w * 0.012f
                val maxRows = (rows * f.quality).toInt().coerceAtLeast(2)
                for (r in 0 until maxRows) for (cc in 0 until cols) {
                    val h1 = hash01(i * 131 + r * 17 + cc)
                    val lit = h1 < activity * (if (layer == 0) 0.7f else 1f)
                    if (!lit) continue
                    val flick = 0.75f + 0.25f * sin(f.t * (1.5f + h1 * 4f) + h1 * 20f)
                    fill.color = withAlpha(if (h1 < activity * 0.4f) th.accent else lerpColor(th.text, th.accent2, 0.3f), 0.8f * flick)
                    val wx = x + bw[i] * 0.1f + cc * (bw[i] * 0.8f / cols)
                    val wy = top + f.w * 0.012f + r * (wh * 2.1f)
                    if (wy + wh < ground) {
                        rect.set(wx, wy, wx + ww, wy + wh)
                        c.drawRect(rect, fill)
                    }
                }
            }
        }
        if (line == null) return
        val size = f.heroPx * 0.95f
        val lay = layoutOf(f, line, size, f.maxTextW, 3)
        val ox = f.cx - lay.width / 2f
        val oy = f.safeT + f.contentH * 0.30f - lay.height / 2f
        neon.typeface = f.pen.typeface
        neon.textSize = lay.sizePx
        neon.strokeWidth = max(1.6f, lay.sizePx * 0.045f)
        val flicker = 0.93f + 0.07f * sin(f.t * 37f + hash01(idx) * 10f) * (if (f.beat > 0.5f) 1f else 0.5f)
        for (i in line.words.indices) {
            val w = line.words[i]
            val prog = w.progress(f.posMs)
            val x = ox + lay.wordX[i]
            val y = oy + lay.baseline(lay.wordRow[i])
            val a = (0.35f + 0.65f * min(1f, prog * 2f)) * flicker * f.params[1].coerceAtMost(1.5f).coerceAtLeast(0.2f)
            neon.color = withAlpha(if (i % 2 == 0) th.accent else th.accent2, a)
            neon.setShadowLayer(lay.sizePx * 0.35f * f.params[1], 0f, 0f, withAlpha(neon.color, 0.9f))
            c.drawText(w.text.trimEnd(), x, y, neon)
            neon.clearShadowLayer()
        }
        VisDraw.sweep(c, f.pen, lay, ox, oy, f.posMs, withAlpha(th.text, 0.12f), argb(255, 255, 255), argb(255, 255, 255), th.accent, 0f, 0f, flicker)
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.62f, size * 0.4f, f.maxTextW, th.textSoft, 1f)
    }
}
