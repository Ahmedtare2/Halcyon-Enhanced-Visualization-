package com.ella.music.ui.vis

import android.content.Context
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.SurfaceHolder
import android.view.View
import android.view.WindowManager
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.ceil
import kotlin.math.max

/**
 * Halcyon's own low-resolution ambient mesh surface for Folia's Latent background.
 * It deliberately owns no lyric/style drawing: the transparent WebView remains in front.
 *
 * The design follows the measured architecture of the older Folia Android player (low-resolution
 * surface + Choreographer pacing), but this renderer and shader are original Halcyon code.
 */
internal class VisNativeBackdrop(
    context: Context,
    private val onReady: () -> Unit,
    private val onUnavailable: (String) -> Unit
) : GLSurfaceView(context), Choreographer.FrameCallback {

    private val main = Handler(Looper.getMainLooper())
    private val nativeRenderer = MeshRenderer()
    @Volatile private var rendererReady = false
    @Volatile private var rendererFailed = false
    @Volatile private var requestedVisible = false
    @Volatile private var hostResumed = false
    @Volatile private var hostFocused = true
    @Volatile private var targetFps = DEFAULT_FPS
    @Volatile private var displayRefreshHz = 60.0
    private var glThreadResumed = false
    private var frameCallbackPosted = false
    private var vsyncCount = 0L
    private var shutDown = false

    init {
        setEGLContextClientVersion(2)
        setEGLConfigChooser(8, 8, 8, 8, 0, 0)
        holder.setFormat(PixelFormat.RGBA_8888)
        holder.setFixedSize(BUFFER_WIDTH, BUFFER_HEIGHT)
        displayRefreshHz = readDisplayRefreshRate()
        setPreserveEGLContextOnPause(true)
        setRenderer(nativeRenderer)
        renderMode = RENDERMODE_WHEN_DIRTY
        // Keep a real surface alive long enough to validate the shader. It is alpha-hidden until
        // the web host explicitly asks for the Latent mesh.
        visibility = View.VISIBLE
        alpha = 0f
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        holder.setFixedSize(BUFFER_WIDTH, BUFFER_HEIGHT)
        super.surfaceCreated(holder)
        requestRender()
    }

    fun onHostResume() {
        hostResumed = true
        updatePacingState()
    }

    fun onHostPause() {
        hostResumed = false
        updatePacingState()
    }

    fun onHostWindowFocusChanged(hasFocus: Boolean) {
        hostFocused = hasFocus
        updatePacingState()
    }

    fun setVisualizerState(enabled: Boolean, fps: Int) {
        requestedVisible = enabled
        targetFps = fps.coerceIn(1, 120)
        main.post { updatePacingState() }
    }

    fun setPalette(colors: List<String>, transitionMs: Int = 800) {
        nativeRenderer.setPalette(colors, transitionMs)
        main.post {
            if (isActive()) {
                updatePacingState()
                requestRender()
            }
        }
    }

    fun setTuning(meshSpeed: Float, audioSpeed: Float, distortion: Float, swirl: Float, enhancedBeatResponse: Boolean) {
        nativeRenderer.setTuning(meshSpeed, audioSpeed, distortion, swirl, enhancedBeatResponse)
        main.post { if (isActive()) requestRender() }
    }

    fun setAudioEnergy(bass: Float, mid: Float, high: Float, playing: Boolean) {
        nativeRenderer.setAudioEnergy(bass, mid, high, playing)
        main.post { updatePacingState() }
    }

    fun shutdown() {
        shutDown = true
        requestedVisible = false
        hostResumed = false
        val cleanup = {
            stopFrameCallbacks()
            pauseGlThread()
            alpha = 0f
            visibility = View.INVISIBLE
        }
        if (Looper.myLooper() == Looper.getMainLooper()) cleanup() else main.post { cleanup() }
    }

    private fun pauseGlThread() {
        if (glThreadResumed) {
            super.onPause()
            glThreadResumed = false
        }
    }

    private fun readDisplayRefreshRate(): Double = runCatching {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.refreshRate.toDouble()
    }.getOrDefault(60.0).coerceIn(30.0, 240.0)

    private fun isActive(): Boolean = requestedVisible && hostResumed && hostFocused && !rendererFailed && !shutDown

    private fun updatePacingState() {
        if (shutDown || rendererFailed) {
            stopFrameCallbacks()
            pauseGlThread()
            alpha = 0f
            visibility = View.INVISIBLE
            return
        }

        // The first GL resume is also used to compile/check the shader, even before JS selects Latent.
        val shouldInitialize = !rendererReady && hostResumed
        val active = isActive()
        if (!active && !shouldInitialize) {
            stopFrameCallbacks()
            pauseGlThread()
            alpha = 0f
            visibility = View.INVISIBLE
            return
        }

        visibility = View.VISIBLE
        alpha = if (active) 1f else 0f
        if (!glThreadResumed) {
            super.onResume()
            glThreadResumed = true
            requestRender()
        }
        if (active && nativeRenderer.shouldAnimate()) {
            startFrameCallbacksIfNeeded()
        } else {
            stopFrameCallbacks()
            // RENDERMODE_WHEN_DIRTY leaves a paused/static mesh on screen without a continuous
            // Choreographer loop or fragment-shader work.
            requestRender()
        }
    }

    private fun startFrameCallbacksIfNeeded() {
        if (!frameCallbackPosted && isActive()) {
            frameCallbackPosted = true
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun stopFrameCallbacks() {
        if (frameCallbackPosted) {
            Choreographer.getInstance().removeFrameCallback(this)
            frameCallbackPosted = false
        }
    }

    override fun doFrame(frameTimeNanos: Long) {
        frameCallbackPosted = false
        if (!isActive() || !glThreadResumed) return
        if (!nativeRenderer.shouldAnimate()) {
            requestRender()
            return
        }

        val divider = ceil(displayRefreshHz / targetFps.coerceAtLeast(1)).toInt().coerceIn(1, 12)
        vsyncCount++
        if (vsyncCount % divider == 0L) requestRender()
        startFrameCallbacksIfNeeded()
    }

    private inner class MeshRenderer : GLSurfaceView.Renderer {
        private val vertexBuffer: FloatBuffer = ByteBuffer.allocateDirect(8 * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
                put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f))
                position(0)
            }
        @Volatile private var bass = 0f
        @Volatile private var mid = 0f
        @Volatile private var high = 0f
        @Volatile private var playing = false
        @Volatile private var baseSpeed = 0.30f
        @Volatile private var audioSpeed = 2.0f
        @Volatile private var baseDistortion = 0.8f
        @Volatile private var baseSwirl = 0.1f
        @Volatile private var enhancedBeatResponse = true
        private var program = 0
        private var positionHandle = -1
        private var timeHandle = -1
        private var resolutionHandle = -1
        private var bassHandle = -1
        private var midHandle = -1
        private var highHandle = -1
        private var energyHandle = -1
        private var distortionHandle = -1
        private var swirlHandle = -1
        private var dimHandle = -1
        private val colorHandles = IntArray(6)
        private var shaderTime = 0f
        private var lastFrameNs = 0L
        private var smoothedBass = 0f
        private var smoothedMid = 0f
        private var smoothedHigh = 0f
        private var smoothedEnergy = 0f
        private var lastEnergySample = 0f
        private var onset = 0f
        private val paletteLock = Any()
        private var fromPalette = DEFAULT_PALETTE.copyOf()
        private var toPalette = DEFAULT_PALETTE.copyOf()
        private var paletteStartedNs = 0L
        private var paletteDurationNs = 0L
        private val currentPalette = DEFAULT_PALETTE.copyOf()

        fun setPalette(colors: List<String>, transitionMs: Int) {
            val parsed = FloatArray(18)
            for (i in 0 until 6) {
                val color = colors.getOrNull(i)?.let { runCatching { AndroidColor.parseColor(it) }.getOrNull() }
                    ?: AndroidColor.BLACK
                parsed[i * 3] = AndroidColor.red(color) / 255f
                parsed[i * 3 + 1] = AndroidColor.green(color) / 255f
                parsed[i * 3 + 2] = AndroidColor.blue(color) / 255f
            }
            synchronized(paletteLock) {
                fromPalette = currentPalette.copyOf()
                toPalette = parsed
                paletteStartedNs = System.nanoTime()
                paletteDurationNs = transitionMs.coerceAtLeast(0).toLong() * 1_000_000L
                if (paletteDurationNs == 0L) {
                    for (i in currentPalette.indices) currentPalette[i] = toPalette[i]
                    fromPalette = toPalette.copyOf()
                }
            }
        }

        fun setTuning(meshSpeed: Float, audioSpeed: Float, distortion: Float, swirl: Float, enhanced: Boolean) {
            baseSpeed = meshSpeed.coerceIn(0f, 2f)
            this.audioSpeed = audioSpeed.coerceIn(0f, 2f)
            baseDistortion = distortion.coerceIn(0f, 2f)
            baseSwirl = swirl.coerceIn(0f, 1f)
            enhancedBeatResponse = enhanced
        }

        fun setAudioEnergy(bassValue: Float, midValue: Float, highValue: Float, isPlaying: Boolean) {
            bass = bassValue.coerceIn(0f, 1f)
            mid = midValue.coerceIn(0f, 1f)
            high = highValue.coerceIn(0f, 1f)
            playing = isPlaying
        }

        fun shouldAnimate(): Boolean {
            if (playing) return true
            synchronized(paletteLock) {
                return paletteDurationNs > 0L && System.nanoTime() - paletteStartedNs < paletteDurationNs
            }
        }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glClearColor(0f, 0f, 0f, 1f)
            program = buildProgram(VERTEX_SHADER, FRAGMENT_SHADER)
            if (program == 0) {
                rendererFailed = true
                main.post { onUnavailable("Native mesh shader could not be linked; using the original web background") }
                return
            }
            positionHandle = GLES20.glGetAttribLocation(program, "aPosition")
            timeHandle = GLES20.glGetUniformLocation(program, "uTime")
            resolutionHandle = GLES20.glGetUniformLocation(program, "uResolution")
            bassHandle = GLES20.glGetUniformLocation(program, "uBass")
            midHandle = GLES20.glGetUniformLocation(program, "uMid")
            highHandle = GLES20.glGetUniformLocation(program, "uHigh")
            energyHandle = GLES20.glGetUniformLocation(program, "uEnergy")
            distortionHandle = GLES20.glGetUniformLocation(program, "uDistortion")
            swirlHandle = GLES20.glGetUniformLocation(program, "uSwirl")
            dimHandle = GLES20.glGetUniformLocation(program, "uDim")
            for (i in 0 until 6) colorHandles[i] = GLES20.glGetUniformLocation(program, "uColor$i")
            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            rendererReady = true
            main.post {
                onReady()
                updatePacingState()
            }
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
        }

        override fun onDrawFrame(gl: GL10?) {
            if (program == 0) return
            val now = System.nanoTime()
            val dt = if (lastFrameNs == 0L) 1f / 30f else ((now - lastFrameNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
            lastFrameNs = now
            val rawBass = bass
            val rawMid = mid
            val rawHigh = high
            val energy = (rawBass * 0.36f + rawMid * 0.42f + rawHigh * 0.22f).coerceIn(0f, 1f)
            val smoothing = 1f - kotlin.math.exp(-dt * 7.5f)
            smoothedBass += (rawBass - smoothedBass) * smoothing
            smoothedMid += (rawMid - smoothedMid) * smoothing
            smoothedHigh += (rawHigh - smoothedHigh) * smoothing
            smoothedEnergy += (energy - smoothedEnergy) * smoothing
            onset = max(onset * 0.84f, ((energy - lastEnergySample) * 7f).coerceIn(0f, 1f))
            lastEnergySample = energy
            val beatAmount = if (enhancedBeatResponse) {
                (smoothedEnergy * 0.42f + onset * 0.85f).coerceIn(0f, 1f)
            } else smoothedEnergy.coerceIn(0f, 1f)
            val speed = if (playing) baseSpeed + (audioSpeed - baseSpeed) * beatAmount else baseSpeed * 0.12f
            shaderTime += dt * speed.coerceIn(0f, 2f)

            updatePalette(now)
            GLES20.glUseProgram(program)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
            GLES20.glUniform1f(timeHandle, shaderTime)
            GLES20.glUniform2f(resolutionHandle, BUFFER_WIDTH.toFloat(), BUFFER_HEIGHT.toFloat())
            GLES20.glUniform1f(bassHandle, smoothedBass)
            GLES20.glUniform1f(midHandle, smoothedMid)
            GLES20.glUniform1f(highHandle, smoothedHigh)
            GLES20.glUniform1f(energyHandle, smoothedEnergy)
            GLES20.glUniform1f(distortionHandle, baseDistortion + smoothedEnergy * 0.62f)
            GLES20.glUniform1f(swirlHandle, baseSwirl + smoothedMid * 0.38f)
            GLES20.glUniform1f(dimHandle, 1f)
            for (i in 0 until 6) {
                val p = i * 3
                GLES20.glUniform3f(colorHandles[i], currentPalette[p], currentPalette[p + 1], currentPalette[p + 2])
            }
            vertexBuffer.position(0)
            GLES20.glEnableVertexAttribArray(positionHandle)
            GLES20.glVertexAttribPointer(positionHandle, 2, GLES20.GL_FLOAT, false, 0, vertexBuffer)
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
            GLES20.glDisableVertexAttribArray(positionHandle)
        }

        private fun updatePalette(now: Long) {
            synchronized(paletteLock) {
                val duration = paletteDurationNs
                val t = if (duration <= 0L) 1f else ((now - paletteStartedNs).toFloat() / duration).coerceIn(0f, 1f)
                for (i in currentPalette.indices) currentPalette[i] = fromPalette[i] + (toPalette[i] - fromPalette[i]) * t
                if (t >= 1f) {
                    paletteDurationNs = 0L
                    fromPalette = toPalette.copyOf()
                }
            }
        }

        private fun buildProgram(vertexSource: String, fragmentSource: String): Int {
            val vertex = compileShader(GLES20.GL_VERTEX_SHADER, vertexSource)
            if (vertex == 0) return 0
            val fragment = compileShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource)
            if (fragment == 0) {
                GLES20.glDeleteShader(vertex)
                return 0
            }
            val linked = GLES20.glCreateProgram()
            GLES20.glAttachShader(linked, vertex)
            GLES20.glAttachShader(linked, fragment)
            GLES20.glLinkProgram(linked)
            val status = IntArray(1)
            GLES20.glGetProgramiv(linked, GLES20.GL_LINK_STATUS, status, 0)
            GLES20.glDeleteShader(vertex)
            GLES20.glDeleteShader(fragment)
            if (status[0] == 0) {
                GLES20.glDeleteProgram(linked)
                return 0
            }
            return linked
        }

        private fun compileShader(type: Int, source: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, source)
            GLES20.glCompileShader(shader)
            val status = IntArray(1)
            GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, status, 0)
            if (status[0] == 0) {
                GLES20.glDeleteShader(shader)
                return 0
            }
            return shader
        }
    }

    private companion object ShaderSources {
        const val BUFFER_WIDTH = 180
        const val BUFFER_HEIGHT = 400
        const val DEFAULT_FPS = 30
        const val VERTEX_SHADER = """
            attribute vec2 aPosition;
            varying vec2 vUv;
            void main() {
                vUv = aPosition * 0.5 + 0.5;
                gl_Position = vec4(aPosition, 0.0, 1.0);
            }
        """
        const val FRAGMENT_SHADER = """
            precision mediump float;
            varying vec2 vUv;
            uniform vec2 uResolution;
            uniform float uTime;
            uniform float uBass;
            uniform float uMid;
            uniform float uHigh;
            uniform float uEnergy;
            uniform float uDistortion;
            uniform float uSwirl;
            uniform float uDim;
            uniform vec3 uColor0;
            uniform vec3 uColor1;
            uniform vec3 uColor2;
            uniform vec3 uColor3;
            uniform vec3 uColor4;
            uniform vec3 uColor5;

            float hash21(vec2 p) {
                p = fract(p * vec2(127.1, 311.7));
                p += dot(p, p + 19.19);
                return fract(p.x * p.y);
            }
            float noise2(vec2 p) {
                vec2 i = floor(p);
                vec2 f = fract(p);
                vec2 u = f * f * (3.0 - 2.0 * f);
                float a = hash21(i);
                float b = hash21(i + vec2(1.0, 0.0));
                float c = hash21(i + vec2(0.0, 1.0));
                float d = hash21(i + vec2(1.0, 1.0));
                return mix(mix(a, b, u.x), mix(c, d, u.x), u.y);
            }
            void main() {
                vec2 uv = vUv;
                vec2 p = uv - 0.5;
                float t = uTime;
                float amount = 0.12 + uDistortion * 0.10 + uEnergy * 0.12;
                vec2 warp = vec2(
                    noise2(p * 3.0 + vec2(t * 0.17, -t * 0.13)),
                    noise2(p * 3.0 + vec2(-t * 0.15, t * 0.19) + vec2(4.2, 2.7))
                ) - 0.5;
                vec2 q = p + warp * amount;
                q.x *= uResolution.x / max(1.0, uResolution.y);
                float pulse = 1.0 + uBass * 0.32;
                float turn = uSwirl * 0.35;
                vec2 c0 = vec2(-0.20 + sin(t * 0.37) * 0.18, -0.28 + cos(t * 0.29) * 0.16);
                vec2 c1 = vec2( 0.21 + cos(t * 0.31 + 1.1) * 0.18, -0.18 + sin(t * 0.39) * 0.20);
                vec2 c2 = vec2(-0.18 + sin(t * 0.27 + 2.2) * 0.18,  0.22 + cos(t * 0.34) * 0.18);
                vec2 c3 = vec2( 0.18 + cos(t * 0.33 + 3.4) * 0.18,  0.27 + sin(t * 0.31) * 0.18);
                vec2 c4 = vec2(sin(t * 0.24 + turn) * 0.25, -0.34 + cos(t * 0.36) * 0.14);
                vec2 c5 = vec2(cos(t * 0.22 + 0.8) * 0.25,  0.34 + sin(t * 0.32) * 0.14);
                float w0 = exp(-dot(q-c0, q-c0) * 13.0 / pulse) * (1.25 + uBass * 0.38);
                float w1 = exp(-dot(q-c1, q-c1) * 14.0 / pulse) * (1.15 + uMid * 0.35);
                float w2 = exp(-dot(q-c2, q-c2) * 12.0 / pulse) * (1.05 + uHigh * 0.35);
                float w3 = exp(-dot(q-c3, q-c3) * 13.0 / pulse) * 0.95;
                float w4 = exp(-dot(q-c4, q-c4) * 15.0 / pulse) * (0.95 + uEnergy * 0.3);
                float w5 = exp(-dot(q-c5, q-c5) * 14.0 / pulse) * 0.90;
                float total = w0+w1+w2+w3+w4+w5+0.45;
                vec3 color = (uColor0*w0 + uColor1*w1 + uColor2*w2 + uColor3*w3 + uColor4*w4 + uColor5*w5) / total;
                vec3 deep = mix(uColor5, uColor0, 0.22) * 0.28;
                color = mix(deep, color, clamp(total * 0.78, 0.0, 1.0));
                float vignette = 1.0 - smoothstep(0.35, 0.90, length(p) * 1.25) * 0.18;
                float luminance = dot(color, vec3(0.2126, 0.7152, 0.0722));
                color = mix(vec3(luminance), color, 1.04 + uMid * 0.34);
                color *= (0.94 + uEnergy * 0.16) * vignette * uDim;
                gl_FragColor = vec4(color, 1.0);
            }
        """
        val DEFAULT_PALETTE = floatArrayOf(
            0.04f, 0.07f, 0.12f,
            0.11f, 0.16f, 0.28f,
            0.28f, 0.36f, 0.55f,
            0.05f, 0.48f, 0.72f,
            0.60f, 0.32f, 0.65f,
            0.04f, 0.07f, 0.12f
        )
    }
}
