package com.ella.music.ui.vis

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.platform.LocalContext

/**
 * Frame-rate ceiling imposed by the phone itself: battery saver, a low battery and heat all lower it,
 * and it lifts again by itself. 0 means no limit. The picture is the same, only the refresh rate drops.
 */
@Composable
internal fun rememberPowerFrameCap(): State<Int> {
    val context = LocalContext.current
    val cap = remember { mutableIntStateOf(0) }
    DisposableEffect(context) {
        val power = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        var thermalCap = 0
        fun recompute(intent: Intent?) {
            var result = 0
            if (power != null && power.isPowerSaveMode) result = 30
            val battery = intent ?: context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (battery != null) {
                val level = battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                val scale = battery.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                val status = battery.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                if (level >= 0 && scale > 0 && !charging) {
                    val pct = level * 100 / scale
                    if (pct <= 15) result = if (result == 0) 30 else minOf(result, 30)
                }
            }
            if (thermalCap > 0) result = if (result == 0) thermalCap else minOf(result, thermalCap)
            cap.intValue = result
        }
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, intent: Intent?) { recompute(null) }
        }
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(PowerManager.ACTION_POWER_SAVE_MODE_CHANGED)
        }
        runCatching { context.registerReceiver(receiver, filter) }
        val thermalListener: PowerManager.OnThermalStatusChangedListener? =
            if (power != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                PowerManager.OnThermalStatusChangedListener { status ->
                    thermalCap = when {
                        status >= PowerManager.THERMAL_STATUS_SEVERE -> 20
                        status >= PowerManager.THERMAL_STATUS_MODERATE -> 30
                        else -> 0
                    }
                    recompute(null)
                }
            } else null
        if (power != null && thermalListener != null) runCatching { power.addThermalStatusListener(thermalListener) }
        recompute(null)
        onDispose {
            runCatching { context.unregisterReceiver(receiver) }
            if (power != null && thermalListener != null) runCatching { power.removeThermalStatusListener(thermalListener) }
        }
    }
    return cap
}
