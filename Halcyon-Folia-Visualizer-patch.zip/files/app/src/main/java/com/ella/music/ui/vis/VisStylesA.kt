package com.ella.music.ui.vis

import android.graphics.Camera
import android.graphics.Matrix
import android.graphics.Path
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/** Luminous: one glowing line at a time over slowly drifting geometric shapes. */
internal class LuminousStyle : LyricStyle(
    "luminous", "Luminous", "One glowing line at a time over drifting shapes",
    listOf(
        StyleParam("glow", "Glow", 0f, 2f, 1f),
        StyleParam("shapes", "Shapes", 0f, 2f, 1f),
        StyleParam("lift", "Word lift", 0f, 2f, 1f)
    )
) {
    private val tri = Path()

    override fun draw(f: VisFrame) {
        drawShapes(f)
        val idx = focus(f)
        if (idx < 0) return
        val lines = f.track.lines
        val line = lines[idx]
        val since = f.posMs - line.startMs
        if (idx > 0) {
            val a = 1f - smoothstep(since / 280f)
            if (a > 0.02f) drawHero(f, lines[idx - 1], a * 0.8f, -f.heroPx * 0.5f * (1f - a), false)
        }
        val enter = easeOutCubic(since / 360f + 0.15f)
        drawHero(f, line, enter, f.heroPx * 0.4f * (1f - enter), true)
        val next = lines.getOrNull(idx + 1)
        if (next != null && f.posMs > line.startMs) {
            val lay = layoutB(f, next, f.heroPx * 0.44f, f.maxTextW, 2)
            VisDraw.flat(
                f.c, f.pen, lay, f.cx - lay.width / 2f,
                f.safeT + f.contentH * 0.88f - lay.height, f.theme.text, 0.28f * enter
            )
        }
    }

    private fun drawHero(f: VisFrame, line: VisLine, alpha: Float, dy: Float, current: Boolean) {
        val size = f.heroPx
        val lay = layoutOf(f, line, size, f.maxTextW, 3)
        val th = f.theme
        val c = f.c
        val ox = f.cx - lay.width / 2f
        val sec = line.translation.ifEmpty { line.romanization }
        val total = lay.height + (if (sec.isEmpty()) 0f else size * 0.8f)
        val oy = f.cy - total / 2f + dy
        val s = 1f + (if (current) 0.022f * f.beat else 0f)
        c.save()
        c.scale(s, s, f.cx, f.cy)
        VisDraw.sweep(
            c, f.pen, lay, ox, oy, f.posMs, th.textDim, th.text, th.accent, th.accent,
            size * 0.3f * f.params[0], size * 0.1f * f.params[2], alpha
        )
        VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.62f, size * 0.42f, f.maxTextW, th.textSoft, alpha)
        c.restore()
    }

    private fun drawShapes(f: VisFrame) {
        val count = (12f * f.params[1] * f.quality).toInt().coerceIn(0, 16)
        if (count == 0) return
        val c = f.c
        val th = f.theme
        val m = min(f.w, f.h)
        val stroke = f.pen.stroke
        val fill = f.pen.shape
        stroke.strokeWidth = max(1.5f, m * 0.003f)
        for (i in 0 until count) {
            val r1 = hash01(i * 7 + 1)
            val r2 = hash01(i * 7 + 2)
            val r3 = hash01(i * 7 + 3)
            val r4 = hash01(i * 7 + 4)
            val x = f.w * (r1 + 0.06f * wave(f.t, 0.02f + r4 * 0.03f, r2 * 6f))
            val y = f.h * (r2 + 0.05f * cosWave(f.t, 0.02f + r3 * 0.03f, r1 * 6f))
            val s = m * (0.035f + 0.09f * r3) * (1f + 0.22f * f.beat)
            val rot = f.t * (8f + 26f * r4) * (if (i % 2 == 0) 1f else -1f)
            val col = if (i % 2 == 0) th.accent else th.accent2
            val a = (0.10f + 0.10f * r4 + 0.12f * f.treble).coerceAtMost(0.34f)
            c.save()
            c.translate(x, y)
            c.rotate(rot)
            when (i % 4) {
                0 -> { stroke.color = withAlpha(col, a); c.drawCircle(0f, 0f, s, stroke) }
                1 -> { fill.color = withAlpha(col, a * 0.55f); c.drawCircle(0f, 0f, s * 0.8f, fill) }
                2 -> {
                    tri.reset()
                    tri.moveTo(0f, -s); tri.lineTo(s * 0.87f, s * 0.5f); tri.lineTo(-s * 0.87f, s * 0.5f); tri.close()
                    stroke.color = withAlpha(col, a)
                    c.drawPath(tri, stroke)
                }
                else -> {
                    stroke.color = withAlpha(col, a)
                    c.drawLine(-s, 0f, s, 0f, stroke); c.drawLine(0f, -s, 0f, s, stroke)
                }
            }
            c.restore()
        }
    }
}

/** Partita: a five-line staff above the lyric; every sung word drops a note onto it. */
internal class PartitaStyle : LyricStyle(
    "partita", "Partita", "A musical staff where every word becomes a note",
    listOf(StyleParam("notes", "Note size", 0.6f, 1.6f, 1f), StyleParam("lift", "Word lift", 0f, 2f, 1f))
) {
    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        val c = f.c
        val th = f.theme
        val lines = f.track.lines
        val line = lines[idx]
        val size = f.heroPx * 0.82f
        val lay = layoutOf(f, line, size, f.maxTextW, 3)
        val spacing = size * 0.30f * f.params[0]
        val staffTop = f.cy - lay.height / 2f - spacing * 6.2f
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(1.2f, size * 0.025f)
        stroke.color = withAlpha(th.text, 0.22f)
        val left = f.safeL + f.contentW * 0.05f
        val right = f.safeL + f.contentW * 0.95f
        for (i in 0 until 5) c.drawLine(left, staffTop + i * spacing, right, staffTop + i * spacing, stroke)
        stroke.color = withAlpha(th.text, 0.4f)
        c.drawLine(left, staffTop, left, staffTop + 4 * spacing, stroke)
        c.drawLine(right, staffTop, right, staffTop + 4 * spacing, stroke)
        val ox = f.cx - lay.width / 2f
        val oy = f.cy - lay.height / 2f + spacing * 0.8f
        val fill = f.pen.shape
        val words = line.words
        val staffBottom = staffTop + 4 * spacing
        for (i in words.indices) {
            val p = words[i].progress(f.posMs)
            val step = (hash01(line.index * 131 + i) * 8f).toInt()
            val ny = staffBottom - step * spacing * 0.5f
            val nx = left + (right - left) * ((i + 0.5f) / words.size)
            val drop = if (p > 0f) (1f - easeOutBack(min(1f, p * 2.5f))) * spacing * 3f else spacing * 3f
            val a = if (p > 0f) 1f else 0.28f
            val rx = spacing * 0.62f
            val ry = spacing * 0.46f
            f.pen.rect.set(nx - rx, ny - ry - drop, nx + rx, ny + ry - drop)
            c.save()
            c.rotate(-18f, nx, ny - drop)
            if (p > 0f) {
                fill.color = withAlpha(th.accent, a)
                c.drawOval(f.pen.rect, fill)
            } else {
                stroke.color = withAlpha(th.text, a)
                c.drawOval(f.pen.rect, stroke)
            }
            c.restore()
            stroke.color = withAlpha(if (p > 0f) th.accent else th.text, a)
            val stemDir = if (step >= 4) 1f else -1f
            val sx = nx + (if (stemDir < 0f) rx * 0.92f else -rx * 0.92f)
            c.drawLine(sx, ny - drop, sx, ny - drop + stemDir * spacing * 3.2f, stroke)
            if (p > 0f && p < 1f) {
                fill.color = withAlpha(th.accent, 0.25f * (1f - p))
                c.drawCircle(nx, ny - drop, spacing * (1f + p * 1.5f), fill)
            }
        }
        VisDraw.sweep(c, f.pen, lay, ox, oy, f.posMs, th.textDim, th.text, th.accent, th.accent, size * 0.2f, size * 0.08f * f.params[1], 1f)
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, oy + lay.height + size * 0.7f, size * 0.42f, f.maxTextW, th.textSoft, 1f)
    }
}

/** Still: the calmest style – a centred line, a quiet sweep and nothing else. Great for battery. */
internal class StillStyle : LyricStyle(
    "still", "Still", "Minimal, calm and very light on battery",
    listOf(StyleParam("weight", "Brightness", 0.4f, 1f, 0.9f)),
    preferredFps = 30
) {
    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        val lines = f.track.lines
        val line = lines[idx]
        val since = f.posMs - line.startMs
        if (idx > 0) {
            val a = 1f - smoothstep(since / 420f)
            if (a > 0.02f) draw(f, lines[idx - 1], a * 0.7f)
        }
        draw(f, line, smoothstep(since / 420f + 0.1f))
    }

    private fun draw(f: VisFrame, line: VisLine, alpha: Float) {
        val th = f.theme
        val size = f.heroPx * 0.92f
        val lay = layoutOf(f, line, size, f.maxTextW, 4)
        val sec = line.translation.ifEmpty { line.romanization }
        val total = lay.height + (if (sec.isEmpty()) 0f else size * 0.75f)
        val ox = f.cx - lay.width / 2f
        val oy = f.cy - total / 2f
        val a = alpha * f.params[0]
        VisDraw.sweep(f.c, f.pen, lay, ox, oy, f.posMs, th.textDim, th.text, th.text, 0, 0f, 0f, a)
        VisDraw.secondary(f.c, f.pen, sec, f.cx, oy + lay.height + size * 0.6f, size * 0.4f, f.maxTextW, th.textSoft, a)
        val p = line.progress(f.posMs)
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(1.5f, size * 0.03f)
        stroke.color = withAlpha(th.accent, 0.5f * a)
        val y = oy + total + size * 0.35f
        val half = lay.width * 0.5f
        f.c.drawLine(f.cx - half, y, f.cx - half + lay.width * p, y, stroke)
    }
}

/** Tilt: lines stacked in a gently rotated 3D plane that sways with the beat. */
internal class TiltStyle : LyricStyle(
    "tilt", "Tilt", "A tilted 3D stack of lines that sways with the music",
    listOf(StyleParam("angle", "Angle", 0f, 2f, 1f), StyleParam("sway", "Beat sway", 0f, 2f, 1f))
) {
    private val stack = LineStack(2, 5)
    private val camera = Camera()
    private val mat = Matrix()

    override fun reset() { super.reset(); stack.fol.snap(0f) }

    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        val c = f.c
        val th = f.theme
        val size = f.heroPx * 0.78f
        stack.build(f, cache, size, f.maxTextW * 0.92f, 2, idx, 8f, size * 0.42f, 1.22f, 0.74f)
        camera.save()
        camera.setLocation(0f, 0f, -18f)
        camera.rotateY((-16f * f.params[0] + 3f * f.params[1] * sin(f.t * 0.7f) + 2.2f * f.params[1] * f.beat))
        camera.rotateX(6f * f.params[0])
        camera.rotateZ(-4f * f.params[0] + 1.2f * f.params[1] * f.kick)
        camera.getMatrix(mat)
        camera.restore()
        mat.preTranslate(-f.cx, -f.cy)
        mat.postTranslate(f.cx, f.cy)
        c.save()
        c.concat(mat)
        for (i in 0 until stack.count) {
            val lay = stack.lay[i] ?: continue
            val d = abs(stack.dist[i])
            val a = (1f - 0.8f * smoothstep(d / 3.4f)).coerceIn(0.08f, 1f)
            val s = stack.scale[i]
            val oy = f.cy + stack.y[i] - lay.height * s / 2f
            c.save()
            c.translate(f.cx - lay.width * s / 2f, oy)
            c.scale(s, s)
            if (d < 0.6f) {
                VisDraw.sweep(c, f.pen, lay, 0f, 0f, f.posMs, th.textDim, th.text, th.accent, th.accent, size * 0.25f, size * 0.08f, a)
            } else {
                VisDraw.flat(c, f.pen, lay, 0f, 0f, if (stack.dist[i] < 0f) th.textSoft else th.text, a * 0.55f)
            }
            c.restore()
        }
        c.restore()
    }
}

/** Cappella: lyrics arrive as chat bubbles, one side per singer, with a typing indicator. */
internal class CappellaStyle : LyricStyle(
    "cappella", "Cappella", "Chat bubbles – duets answer from opposite sides",
    listOf(StyleParam("size", "Bubble text", 0.7f, 1.3f, 1f))
) {
    private val shift = Follower()
    private var lastActive = -99

    override fun reset() { super.reset(); shift.snap(0f); lastActive = -99 }

    override fun draw(f: VisFrame) {
        val idx = focus(f)
        if (idx < 0) return
        val c = f.c
        val th = f.theme
        val lines = f.track.lines
        val size = f.heroPx * 0.56f * f.params[0]
        val bubbleMaxW = f.contentW * (if (f.landscape) 0.55f else 0.78f)
        val pad = size * 0.55f
        val gap = size * 0.5f
        if (idx != lastActive) {
            if (abs(idx - lastActive) > 3) shift.snap(0f) else shift.value = shift.value + size * 2.2f
            lastActive = idx
        }
        val off = shift.step(0f, f.dt, 9f)
        var bottom = f.safeT + f.contentH * 0.80f + off
        val lo = max(0, idx - 4)
        // draw from the newest bubble upwards
        var typingNext = false
        val next = lines.getOrNull(idx + 1)
        if (next != null && next.startMs - f.posMs in 0L..2600L && lines[idx].endMs <= f.posMs + 200L) typingNext = true
        if (typingNext) {
            drawTyping(f, bottom, size, (next?.singer ?: 0) == 1 || (idx + 1) % 2 == 1 && sameSinger(lines))
            bottom -= size * 1.9f + gap
        }
        var k = idx
        while (k >= lo) {
            val line = lines[k]
            val lay = layoutOf(f, line, size, bubbleMaxW - pad * 2f, 4)
            val bw = lay.width + pad * 2f
            val bh = lay.height + pad * 1.1f
            val right = rightSide(line, lines)
            val bx = if (right) f.safeL + f.contentW - bw - f.contentW * 0.05f else f.safeL + f.contentW * 0.05f
            val top = bottom - bh
            val age = (idx - k).toFloat()
            val a = (1f - 0.22f * age).coerceIn(0.15f, 1f)
            val enter = if (k == idx) easeOutBack((f.posMs - line.startMs) / 300f + 0.2f) else 1f
            c.save()
            c.scale(0.9f + 0.1f * min(1f, enter), 0.9f + 0.1f * min(1f, enter), if (right) bx + bw else bx, bottom)
            val fill = f.pen.shape
            fill.color = withAlpha(if (right) th.accent else th.text, if (right) 0.20f * a else 0.10f * a)
            f.pen.rect.set(bx, top, bx + bw, bottom)
            c.drawRoundRect(f.pen.rect, size * 0.7f, size * 0.7f, fill)
            val stroke = f.pen.stroke
            stroke.strokeWidth = max(1.2f, size * 0.04f)
            stroke.color = withAlpha(if (right) th.accent else th.text, 0.35f * a)
            c.drawRoundRect(f.pen.rect, size * 0.7f, size * 0.7f, stroke)
            VisDraw.sweep(
                c, f.pen, lay, bx + pad, top + pad * 0.55f, f.posMs, th.textDim,
                th.text, th.accent, th.accent, size * 0.2f, 0f, a
            )
            c.restore()
            bottom = top - gap
            if (bottom < f.safeT) break
            k--
        }
    }

    private fun sameSinger(lines: List<VisLine>): Boolean = lines.none { it.singer == 1 }

    private fun rightSide(line: VisLine, lines: List<VisLine>): Boolean =
        if (sameSinger(lines)) line.index % 2 == 1 else line.singer == 1

    private fun drawTyping(f: VisFrame, bottom: Float, size: Float, right: Boolean) {
        val c = f.c
        val th = f.theme
        val bw = size * 3.2f
        val bh = size * 1.7f
        val bx = if (right) f.safeL + f.contentW - bw - f.contentW * 0.05f else f.safeL + f.contentW * 0.05f
        val fill = f.pen.shape
        fill.color = withAlpha(th.text, 0.1f)
        f.pen.rect.set(bx, bottom - bh, bx + bw, bottom)
        c.drawRoundRect(f.pen.rect, bh / 2f, bh / 2f, fill)
        for (i in 0 until 3) {
            val bounce = max(0f, sin(f.t * 6f - i * 0.8f))
            fill.color = withAlpha(th.text, 0.45f + 0.4f * bounce)
            c.drawCircle(bx + bw * (0.25f + 0.25f * i), bottom - bh / 2f - bounce * size * 0.2f, size * 0.17f, fill)
        }
    }
}

/** Claddagh: the line follows an arc above a ring and a heart that beats with the music. */
internal class CladdaghStyle : LyricStyle(
    "claddagh", "Claddagh", "Lyrics on an arc above a beating heart and ring",
    listOf(StyleParam("curve", "Curve", 0.3f, 1.6f, 1f), StyleParam("ring", "Ring glow", 0f, 2f, 1f))
) {
    private val heart = Path()
    private val blobs = SoftBlobs()

    override fun draw(f: VisFrame) {
        val c = f.c
        val th = f.theme
        val idx = focus(f)
        val ringR = min(f.contentW, f.contentH) * 0.34f
        val ringCx = f.cx
        val ringCy = f.cy + f.contentH * (if (f.landscape) 0.08f else 0.2f)
        // ring
        blobs.draw(c, ringCx, ringCy, ringR * (1.5f + 0.1f * f.beat), withAlpha(th.accent, 0.16f * f.params[1]), add = true)
        val stroke = f.pen.stroke
        stroke.strokeWidth = max(2f, ringR * 0.03f)
        stroke.color = withAlpha(th.accent, 0.55f)
        c.drawCircle(ringCx, ringCy, ringR, stroke)
        stroke.strokeWidth = max(1.5f, ringR * 0.012f)
        stroke.color = withAlpha(th.text, 0.22f)
        c.drawCircle(ringCx, ringCy, ringR * 1.08f, stroke)
        c.save()
        c.rotate(f.t * 6f, ringCx, ringCy)
        for (i in 0 until 24) {
            val a = i * (2f * PI.toFloat() / 24f)
            val r0 = ringR * 1.13f
            val r1 = ringR * (1.17f + 0.04f * f.treble * ((i % 3) + 1))
            c.drawLine(ringCx + cos(a) * r0, ringCy + sin(a) * r0, ringCx + cos(a) * r1, ringCy + sin(a) * r1, stroke)
        }
        c.restore()
        // heart
        val hs = ringR * 0.32f * (1f + 0.16f * f.beat + 0.05f * sin(f.t * 2.4f))
        heart.reset()
        heart.moveTo(ringCx, ringCy + hs * 0.9f)
        heart.cubicTo(ringCx - hs * 1.6f, ringCy - hs * 0.1f, ringCx - hs * 0.7f, ringCy - hs * 1.3f, ringCx, ringCy - hs * 0.35f)
        heart.cubicTo(ringCx + hs * 0.7f, ringCy - hs * 1.3f, ringCx + hs * 1.6f, ringCy - hs * 0.1f, ringCx, ringCy + hs * 0.9f)
        heart.close()
        val fill = f.pen.shape
        fill.color = withAlpha(th.accent2, 0.9f)
        c.drawPath(heart, fill)
        if (idx < 0) return
        // text on the arc
        val line = f.track.lines[idx]
        val lay = VisLayoutEngine.layoutFit(line, f.pen, f.heroPx * 0.88f, f.maxTextW * 1.1f, 0, 1, 0.5f)
        val arcR = ringR * 1.55f / f.params[0].coerceAtLeast(0.3f)
        val half = lay.width / 2f
        val sizePx = lay.sizePx
        val p = f.pen.fill
        p.textSize = sizePx
        val centerY = ringCy - ringR * 1.15f + arcR
        val words = line.words
        for (i in words.indices) {
            val w = words[i]
            val prog = w.progress(f.posMs)
            val wc = lay.wordX[i] + lay.wordWidth[i] / 2f - half
            val ang = wc / arcR
            val px = ringCx + sin(ang) * arcR
            val py = centerY - cos(ang) * arcR
            c.save()
            c.translate(px, py)
            c.rotate(ang * 180f / PI.toFloat())
            val lift = -sizePx * 0.12f * smoothstep(prog)
            p.color = withAlpha(if (prog >= 1f) th.text else th.textDim, 1f)
            if (prog > 0f && prog < 1f) {
                p.color = withAlpha(lerpColor(th.textDim, th.accent, prog), 1f)
                p.setShadowLayer(sizePx * 0.3f, 0f, 0f, withAlpha(th.accent, 0.9f))
            } else if (prog >= 1f) {
                p.color = th.text
            }
            c.drawText(w.text.trimEnd(), -lay.wordWidth[i] / 2f, lift, p)
            p.clearShadowLayer()
            c.restore()
        }
        val sec = line.translation.ifEmpty { line.romanization }
        VisDraw.secondary(c, f.pen, sec, f.cx, f.safeT + f.contentH * 0.1f, sizePx * 0.5f, f.maxTextW, th.textSoft, 1f)
    }
}
