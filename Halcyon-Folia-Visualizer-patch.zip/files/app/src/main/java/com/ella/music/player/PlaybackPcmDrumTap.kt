package com.ella.music.player

import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.ArrayDeque
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/** One timestamped hit from the PCM stream handed to the audio output. Times are track-relative. */
internal data class PlaybackDrumHit(
    val sequence: Long,
    val timeUs: Long,
    val kind: Int, // Folia's DrumHitKind: 0 kick, 1 snare, 2 hat.
    val strength: Float
)

internal data class PlaybackPcmSnapshot(
    val sampleRate: Int,
    val samplesSeen: Long,
    val warm: Boolean,
    val bass: Float,
    val mid: Float,
    val vocal: Float,
    val treble: Float,
    val outputQueueMs: Float,
    val outputBufferMs: Float,
    val hits: List<PlaybackDrumHit>
)

/**
 * Small shared hand-off between the audio render thread and the visualizer. The PCM tap is dormant
 * unless the lyric visualizer is open; no microphone/RECORD_AUDIO capture is involved.
 */
internal object PlaybackPcmDrumCapture {
    @Volatile var enabled: Boolean = false

    private class TrackState {
        val lock = Any()
        val hits = ArrayDeque<PlaybackDrumHit>()
        var sequence = 0L
        @Volatile var sampleRate = 0
        @Volatile var samplesSeen = 0L
        @Volatile var bass = 0f
        @Volatile var mid = 0f
        @Volatile var vocal = 0f
        @Volatile var treble = 0f
        @Volatile var outputQueueMs = -1f
        @Volatile var outputBufferMs = -1f
    }

    private val tracks = java.util.concurrent.ConcurrentHashMap<String, TrackState>()
    private val orderLock = Any()
    private val trackOrder = LinkedHashMap<String, Unit>(16, 0.75f, true)
    private val maxTrackStates = 8 // current + crossfade plus a small recent-song cushion

    private fun trackFor(key: String): TrackState {
        val track = tracks.computeIfAbsent(key) { TrackState() }
        synchronized(orderLock) {
            trackOrder[key] = Unit
            while (trackOrder.size > maxTrackStates) {
                val oldest = trackOrder.entries.iterator()
                if (!oldest.hasNext()) break
                val staleKey = oldest.next().key
                trackOrder.remove(staleKey)
                if (staleKey != key) tracks.remove(staleKey)
            }
        }
        return track
    }

    /** Starts a fresh visualizer visit without replaying hits retained from a previous visit. */
    fun beginSession(key: String) {
        if (key.isBlank()) return
        val track = trackFor(key)
        synchronized(track.lock) {
            track.hits.clear()
            track.sequence = 0L
            track.sampleRate = 0
            track.samplesSeen = 0L
            track.bass = 0f
            track.mid = 0f
            track.vocal = 0f
            track.treble = 0f
            track.outputQueueMs = -1f
            track.outputBufferMs = -1f
        }
    }

    fun addSamples(key: String, frames: Int, sampleRate: Int) {
        if (key.isBlank() || frames <= 0 || sampleRate <= 0) return
        val track = trackFor(key)
        synchronized(track.lock) {
            track.sampleRate = sampleRate
            track.samplesSeen += frames.toLong()
        }
    }

    fun publishBands(key: String, bass: Float, mid: Float, vocal: Float, treble: Float) {
        if (key.isBlank()) return
        val track = trackFor(key)
        synchronized(track.lock) {
            track.bass = bass.coerceIn(0f, 1f)
            track.mid = mid.coerceIn(0f, 1f)
            track.vocal = vocal.coerceIn(0f, 1f)
            track.treble = treble.coerceIn(0f, 1f)
        }
    }

    fun publishOutputTiming(key: String, queuedUs: Long, bufferUs: Long) {
        if (key.isBlank() || queuedUs < 0L) return
        val track = trackFor(key)
        synchronized(track.lock) {
            val queueMs = queuedUs / 1000f
            track.outputQueueMs = if (track.outputQueueMs < 0f) queueMs else track.outputQueueMs * 0.75f + queueMs * 0.25f
            if (bufferUs > 0L) track.outputBufferMs = bufferUs / 1000f
        }
    }

    fun addHit(key: String, timeUs: Long, kind: Int, strength: Float) {
        if (key.isBlank() || timeUs < 0L || kind !in 0..2) return
        val track = trackFor(key)
        synchronized(track.lock) {
            track.sequence += 1L
            track.hits.addLast(PlaybackDrumHit(track.sequence, timeUs, kind, strength.coerceIn(0f, 1f)))
            // A four-minute song normally produces far fewer than this at Folia's 90 ms hit gap.
            while (track.hits.size > 4096) track.hits.removeFirst()
        }
    }

    fun snapshot(key: String, afterSequence: Long = Long.MAX_VALUE): PlaybackPcmSnapshot {
        val track = tracks[key] ?: return PlaybackPcmSnapshot(0, 0L, false, 0f, 0f, 0f, 0f, -1f, -1f, emptyList())
        return synchronized(track.lock) {
            val sampleRate = track.sampleRate
            val samplesSeen = track.samplesSeen
            PlaybackPcmSnapshot(
                sampleRate = sampleRate,
                samplesSeen = samplesSeen,
                warm = sampleRate > 0 && samplesSeen >= sampleRate / 4L,
                bass = track.bass,
                mid = track.mid,
                vocal = track.vocal,
                treble = track.treble,
                outputQueueMs = track.outputQueueMs,
                outputBufferMs = track.outputBufferMs,
                hits = if (afterSequence == Long.MAX_VALUE) emptyList() else track.hits.filter { it.sequence > afterSequence }
            )
        }
    }
}

/**
 * Taps already-decoded PCM at the Media3 output boundary. handleBuffer's presentationTimeUs is
 * retained through partial writes, so every sample block is stamped against the same clock that
 * drives AudioTrack/Oboe playback. It never changes buffer contents or positions.
 */
@androidx.media3.common.util.UnstableApi
internal class PlaybackPcmDrumTap {
    @Volatile private var songKey: String = ""
    private val detector = RealtimeDrumDetector { key, timeUs, kind, strength ->
        PlaybackPcmDrumCapture.addHit(key, timeUs, kind, strength)
    }

    fun bind(player: ExoPlayer) {
        val updateKey: (androidx.media3.common.MediaItem?) -> Unit = { item ->
            val path = item?.toSongFromMediaItemExtras()?.path.orEmpty()
            val mediaKey = path.ifBlank { item?.mediaId.orEmpty() }
            if (songKey != mediaKey) {
                songKey = mediaKey
                detector.reset()
            }
        }
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: androidx.media3.common.MediaItem?, reason: Int) {
                updateKey(mediaItem)
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                detector.resetSignal()
            }
        })
        updateKey(player.currentMediaItem)
    }

    fun accept(pcm: ByteBuffer, format: Format, presentationTimeUs: Long) {
        val key = songKey
        if (!PlaybackPcmDrumCapture.enabled || key.isBlank()) return
        val sampleRate = format.sampleRate
        val channels = format.channelCount
        val encoding = format.pcmEncoding
        if (sampleRate <= 0 || channels <= 0 || channels > 8 || presentationTimeUs < 0L) return
        detector.process(key, pcm, sampleRate, channels, encoding, presentationTimeUs)
    }

    fun reportOutputTiming(endPtsUs: Long, outputPositionUs: Long, bufferSizeUs: Long) {
        val key = songKey
        if (key.isBlank() || outputPositionUs < 0L || endPtsUs < outputPositionUs) return
        PlaybackPcmDrumCapture.publishOutputTiming(key, endPtsUs - outputPositionUs, bufferSizeUs)
    }

    fun resetSignal() = detector.resetSignal()
}

/**
 * Three lightweight stateful band-pass filters + causal 20 ms spectral-flux frames. The completed
 * frame is timestamped at its centre; no future-frame peak wait is added to the live path.
 */
internal class RealtimeDrumDetector(
    private val onHit: (key: String, timeUs: Long, kind: Int, strength: Float) -> Unit
) {
    private companion object {
        const val FPS = 50
        const val FRAME_US = 20_000L
        const val BASE_FROM = 6
        const val BASE_TO = 2
        const val MIN_HIT_GAP_US = 90_000L
        const val HIT_ONSET_FLOOR = 0.15f
        const val HIT_TOP = 0.99f
        const val HISTORY_SIZE = 512
        const val QUANTILE_WINDOW = 128 // 2.56 seconds at 50 frames per second.
    }

    private class Biquad(sampleRate: Int, lowHz: Float, highHz: Float) {
        private val enabled: Boolean
        private val b0: Float
        private val b1: Float
        private val b2: Float
        private val a1: Float
        private val a2: Float
        private var z1 = 0f
        private var z2 = 0f

        init {
            val high = min(highHz, sampleRate * 0.45f)
            val low = lowHz.coerceAtLeast(10f)
            enabled = high > low + 1f
            if (!enabled) {
                b0 = 0f; b1 = 0f; b2 = 0f; a1 = 0f; a2 = 0f
            } else {
                val centre = sqrt(low * high)
                val q = (centre / (high - low).coerceAtLeast(1f)).coerceAtLeast(0.12f)
                val w = (2.0 * PI * centre / sampleRate).toFloat()
                val c = kotlin.math.cos(w)
                val alpha = sin(w) / (2f * q)
                val inv = 1f / (1f + alpha)
                b0 = alpha * inv
                b1 = 0f
                b2 = -alpha * inv
                a1 = -2f * c * inv
                a2 = (1f - alpha) * inv
            }
        }

        fun step(input: Float): Float {
            if (!enabled) return 0f
            val output = b0 * input + z1
            z1 = b1 * input - a1 * output + z2
            z2 = b2 * input - a2 * output
            return output
        }

        fun clear() { z1 = 0f; z2 = 0f }
    }

    private class BandState {
        val levels = FloatArray(HISTORY_SIZE)
        val rms = FloatArray(HISTORY_SIZE)
        val riseWindow = FloatArray(QUANTILE_WINDOW)
        val riseScratch = FloatArray(QUANTILE_WINDOW)
        var riseCursor = 0
        var riseCount = 0
        var framesSinceQuantile = 0
        var top = 1f
        var peakRms = 0.02f
    }

    private var rate = 0
    private var channelCount = 0
    private var frameSamples = 0
    private var frameCount = 0
    private var trackStartUs = 0L
    private var frameIndex = 0L
    private var lastInputEndUs = Long.MIN_VALUE
    private var samplesInCurrentBuffer = 0L
    private var filters: Array<Array<Biquad>> = emptyArray()
    private val bands = Array(3) { BandState() }
    private val sumSquares = FloatArray(3)
    private val candidateBandEnergy = FloatArray(3)
    private val frameBandShares = Array(3) { FloatArray(HISTORY_SIZE) }
    private var lastHitUs = Long.MIN_VALUE / 2
    private var lastHitStrength = 0f
    private var lastBandsAtUs = 0L

    fun reset() {
        resetSignal()
        rate = 0
        channelCount = 0
        filters = emptyArray()
    }

    fun resetSignal() {
        frameCount = 0
        trackStartUs = 0L
        frameIndex = 0L
        lastInputEndUs = Long.MIN_VALUE
        samplesInCurrentBuffer = 0L
        sumSquares.fill(0f)
        frameBandShares.forEach { it.fill(0f) }
        lastHitUs = Long.MIN_VALUE / 2
        lastHitStrength = 0f
        lastBandsAtUs = 0L
        for (band in bands) {
            band.levels.fill(0f)
            band.rms.fill(0f)
            band.riseWindow.fill(0f)
            band.riseScratch.fill(0f)
            band.riseCursor = 0
            band.riseCount = 0
            band.framesSinceQuantile = 0
            band.top = 1f
            band.peakRms = 0.02f
        }
        filters.forEach { row -> row.forEach { it.clear() } }
    }

    fun process(
        key: String,
        input: ByteBuffer,
        sampleRate: Int,
        channels: Int,
        encoding: Int,
        presentationTimeUs: Long
    ) {
        val bytesPerSample = when (encoding) {
            C.ENCODING_PCM_8BIT -> 1
            C.ENCODING_PCM_16BIT -> 2
            C.ENCODING_PCM_24BIT -> 3
            C.ENCODING_PCM_32BIT, C.ENCODING_PCM_FLOAT -> 4
            else -> return
        }
        if (rate != sampleRate || channelCount != channels) configure(sampleRate, channels)
        val bytesPerFrame = bytesPerSample * channels
        if (input.remaining() < bytesPerFrame) return
        if (lastInputEndUs != Long.MIN_VALUE && abs(presentationTimeUs - lastInputEndUs) > 55_000L) resetSignal()
        samplesInCurrentBuffer = 0L
        val pcm = input.duplicate().order(ByteOrder.LITTLE_ENDIAN)
        while (pcm.remaining() >= bytesPerFrame) {
            if (frameCount == 0 && frameIndex == 0L) {
                trackStartUs = presentationTimeUs + samplesInCurrentBuffer * 1_000_000L / sampleRate
            }
            for (channel in 0 until channels) {
                val sample = readSample(pcm, encoding)
                for (band in 0..2) {
                    val filtered = filters[band][channel].step(sample)
                    sumSquares[band] += filtered * filtered / channels
                }
            }
            frameCount++
            samplesInCurrentBuffer++
            if (frameCount >= frameSamples) finishFrame(key)
        }
        PlaybackPcmDrumCapture.addSamples(key, samplesInCurrentBuffer.toInt(), sampleRate)
        lastInputEndUs = presentationTimeUs + samplesInCurrentBuffer * 1_000_000L / sampleRate
    }

    private fun configure(sampleRate: Int, channels: Int) {
        rate = sampleRate
        channelCount = channels
        frameSamples = (sampleRate / FPS).coerceAtLeast(1)
        filters = Array(3) { band -> Array(channels) {
            when (band) {
                0 -> Biquad(sampleRate, 30f, 150f) // kick / bass.
                1 -> Biquad(sampleRate, 150f, 4000f) // snare and body.
                else -> Biquad(sampleRate, 6000f, 12000f) // hats.
            }
        } }
        resetSignal()
    }

    private fun readSample(buffer: ByteBuffer, encoding: Int): Float = when (encoding) {
        C.ENCODING_PCM_FLOAT -> buffer.float.coerceIn(-1f, 1f)
        C.ENCODING_PCM_16BIT -> buffer.short / 32768f
        C.ENCODING_PCM_8BIT -> ((buffer.get().toInt() and 0xff) - 128) / 128f
        C.ENCODING_PCM_24BIT -> {
            val b0 = buffer.get().toInt() and 0xff
            val b1 = buffer.get().toInt() and 0xff
            val b2 = buffer.get().toInt() and 0xff
            var value = (b2 shl 16) or (b1 shl 8) or b0
            if ((value and 0x800000) != 0) value = value or -0x1000000
            value / 8388608f
        }
        else -> buffer.int / 2147483648f
    }

    /** Causal 50 fps onset detector with Folia's q99 threshold, bands and 90 ms merge window. */
    private fun finishFrame(key: String) {
        val slot = (frameIndex % HISTORY_SIZE).toInt()
        var bestShare = 0f
        for (kind in 0..2) {
            val band = bands[kind]
            val rms = sqrt(sumSquares[kind] / frameSamples.toFloat()).coerceAtLeast(0f)
            val level = kotlin.math.ln(1f + 1000f * rms)
            band.rms[slot] = rms
            band.levels[slot] = level
            band.peakRms = max(rms, band.peakRms * 0.994f)
            sumSquares[kind] = 0f

            // Causal onset: compare this completed 20 ms frame only with the preceding 100 ms.
            // No future-frame max or local-peak confirmation is required, keeping detection delay
            // below one frame rather than waiting ~100 ms for a symmetrical peak window.
            var base = 0f
            var baseCount = 0
            for (at in max(0L, frameIndex - BASE_FROM)..(frameIndex - BASE_TO)) {
                base += band.levels[(at % HISTORY_SIZE).toInt()]
                baseCount++
            }
            val rise = max(0f, level - if (baseCount > 0) base / baseCount else 0f)
            band.riseWindow[band.riseCursor] = rise
            band.riseCursor = (band.riseCursor + 1) % QUANTILE_WINDOW
            band.riseCount = min(band.riseCount + 1, QUANTILE_WINDOW)
            band.framesSinceQuantile++
            if (band.framesSinceQuantile >= 5) {
                band.framesSinceQuantile = 0
                var positiveCount = 0
                for (i in 0 until band.riseCount) {
                    val value = band.riseWindow[i]
                    if (value > 0f) band.riseScratch[positiveCount++] = value
                }
                if (positiveCount > 0) {
                    band.riseScratch.sort(0, positiveCount)
                    val qIndex = (HIT_TOP * positiveCount).toInt().coerceIn(0, positiveCount - 1)
                    band.top = band.riseScratch[qIndex].coerceAtLeast(0.0001f)
                } else {
                    band.top = 1f
                }
            }
            val share = (rise / band.top.coerceAtLeast(0.0001f)).coerceIn(0f, 1f)
            frameBandShares[kind][slot] = share
            if (share > bestShare) {
                bestShare = share
            }
        }
        // In the live full mix, the strongest *absolute* band energy classifies the transient;
        // per-band q99 alone can make a faint band win because it has less dynamic range.
        candidateBandEnergy[0] = bands[0].rms[slot]
        candidateBandEnergy[1] = bands[1].rms[slot]
        candidateBandEnergy[2] = bands[2].rms[slot]
        var kind = 0
        if (candidateBandEnergy[1] > candidateBandEnergy[kind]) kind = 1
        if (candidateBandEnergy[2] > candidateBandEnergy[kind]) kind = 2
        val kindStrength = frameBandShares[kind][slot]
        val floor = when (kind) { 0 -> 0.0035f; 1 -> 0.0018f; else -> 0.0010f }
        val peakRms = candidateBandEnergy[kind]
        val strength = kindStrength.coerceIn(0f, 1f)
        val timeUs = trackStartUs + frameIndex * FRAME_US + FRAME_US / 2L
        if (bestShare >= HIT_ONSET_FLOOR && kindStrength >= HIT_ONSET_FLOOR && peakRms >= floor && timeUs - lastHitUs >= MIN_HIT_GAP_US) {
            onHit(key, timeUs, kind, strength)
            lastHitUs = timeUs
            lastHitStrength = strength
        } else if (bestShare >= HIT_ONSET_FLOOR && kindStrength >= HIT_ONSET_FLOOR && peakRms >= floor && timeUs - lastHitUs < MIN_HIT_GAP_US && strength > lastHitStrength) {
            onHit(key, timeUs, kind, strength)
            lastHitUs = timeUs
            lastHitStrength = strength
        }

        val frameTimeUs = timeUs
        if (frameTimeUs - lastBandsAtUs >= 20_000L) {
            val lowPeak = bands[0].peakRms.coerceAtLeast(0.02f)
            val midPeak = bands[1].peakRms.coerceAtLeast(0.02f)
            val highPeak = bands[2].peakRms.coerceAtLeast(0.02f)
            PlaybackPcmDrumCapture.publishBands(
                key,
                (bands[0].rms[slot] / lowPeak).coerceIn(0f, 1f),
                (bands[1].rms[slot] / midPeak).coerceIn(0f, 1f),
                (bands[1].rms[slot] / midPeak * 0.85f).coerceIn(0f, 1f),
                (bands[2].rms[slot] / highPeak).coerceIn(0f, 1f)
            )
            lastBandsAtUs = frameTimeUs
        }
        frameIndex++
        frameCount = 0
    }
}
