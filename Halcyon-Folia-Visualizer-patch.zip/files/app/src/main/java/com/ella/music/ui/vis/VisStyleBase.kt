package com.ella.music.ui.vis

import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.Shader
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min

internal class StyleParam(val key: String, val label: String, val min: Float, val max: Float, val def: Float)

/** Everything a style may read for one frame. A single instance is reused for every frame. */
internal class VisFrame {
    lateinit var c: Canvas
    lateinit var pen: VisPen
    var w = 0f
    var h = 0f
    var safeL = 0f
    var safeT = 0f
    var safeR = 0f
    var safeB = 0f
    var posMs = 0L
    var t = 0f
    var dt = 0.016f
    var playing = true
    var track: VisTrack = VisTrack.Empty
    var theme: VisTheme = VisThemes.presets[0]
    var drive: AudioDrive = AudioDrive()
    var quality = 1f
    var landscape = false
    var textScale = 1f
    var align = 1
    var react = 1f
    var beatK = 1f
    var active = -1
    var fontId = 0
    val params = FloatArray(4)

    val contentW: Float get() = w - safeL - safeR
    val contentH: Float get() = h - safeT - safeB
    val cx: Float get() = safeL + contentW * 0.5f
    val cy: Float get() = safeT + contentH * 0.5f

    /** Base text size for hero lines. */
    val heroPx: Float
        get() {
            val base = if (landscape) contentH * 0.125f else min(contentW * 0.105f, contentH * 0.075f)
            return (base * textScale).coerceAtLeast(20f)
        }

    val maxTextW: Float get() = contentW * (if (landscape) 0.82f else 0.9f)

    val beat: Float get() = drive.beat * react * beatK
    val kick: Float get() = drive.kick * react * beatK
    val bass: Float get() = drive.bass * react
    val treble: Float get() = drive.treble * react
    val energy: Float get() = drive.energy * react

    fun line(i: Int): VisLine? = track.lines.getOrNull(i)

    /** Milliseconds since line [i] started (negative before). */
    fun sinceStart(i: Int): Long = posMs - (track.lines.getOrNull(i)?.startMs ?: posMs)
}

internal abstract class LyricStyle(
    val id: String,
    val title: String,
    val blurb: String,
    val params: List<StyleParam> = emptyList(),
    /** 0 = follow the global frame-rate cap; otherwise the style needs no more than this. */
    val preferredFps: Int = 0
) {
    val paramKeys: Array<String> = Array(params.size) { "$id.${params[it].key}" }
    protected val cache = LayoutCache()
    protected val cacheB = LayoutCache()

    open fun reset() { cache.clear(); cacheB.clear() }
    abstract fun draw(f: VisFrame)

    protected fun layoutOf(f: VisFrame, line: VisLine, size: Float, maxW: Float, maxRows: Int = 3): LineLayout =
        cache.get(line, f.pen, size, maxW, f.align, maxRows, f.fontId)

    /** Second layout cache for a different text size (neighbour lines, previews). */
    protected fun layoutB(f: VisFrame, line: VisLine, size: Float, maxW: Float, maxRows: Int = 2): LineLayout =
        cacheB.get(line, f.pen, size, maxW, f.align, maxRows, f.fontId)

    /** Index of the line to feature: the last started line, or the first line shortly before it begins. */
    protected fun focus(f: VisFrame): Int {
        val lines = f.track.lines
        if (lines.isEmpty()) return -1
        if (f.active >= 0) return f.active
        return if (f.posMs >= lines[0].startMs - 2500L) 0 else -1
    }

    protected fun palette(f: VisFrame, k: Int): Int = when (k % 3) {
        0 -> f.theme.accent
        1 -> f.theme.accent2
        else -> f.theme.text
    }
}

/** Soft radial blobs with a per-colour shader cache (no allocation while drawing). */
internal class SoftBlobs {
    private val shaders = arrayOfNulls<RadialGradient>(10)
    private val colors = IntArray(10)
    private var next = 0
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val m = Matrix()

    private fun shaderFor(color: Int): RadialGradient {
        for (i in shaders.indices) {
            val s = shaders[i]
            if (s != null && colors[i] == color) return s
        }
        val s = RadialGradient(
            0f, 0f, 1f, intArrayOf(color, withAlpha(color, 0f)), floatArrayOf(0f, 1f), Shader.TileMode.CLAMP
        )
        shaders[next] = s
        colors[next] = color
        next = (next + 1) % shaders.size
        return s
    }

    /** [color] carries the peak alpha of the shader (keep it stable); [alpha] scales it per draw. */
    fun draw(
        c: Canvas, x: Float, y: Float, r: Float, color: Int, alpha: Float = 1f,
        sx: Float = 1f, sy: Float = 1f, add: Boolean = false
    ) {
        if (r <= 0.5f || (color ushr 24) < 2 || alpha <= 0.01f) return
        val s = shaderFor(color)
        m.reset()
        m.postScale(r * sx, r * sy)
        m.postTranslate(x, y)
        s.setLocalMatrix(m)
        paint.shader = s
        paint.alpha = (255f * alpha.coerceIn(0f, 1f)).toInt()
        paint.xfermode = if (add) ADD else null
        c.drawCircle(x, y, r * max(sx, sy), paint)
        paint.xfermode = null
        paint.shader = null
        paint.alpha = 255
    }

    companion object {
        private val ADD = android.graphics.PorterDuffXfermode(android.graphics.PorterDuff.Mode.ADD)
    }
}

/** Critically damped follower: keeps scrolling smooth regardless of frame rate. */
internal class Follower(var value: Float = 0f) {
    fun step(target: Float, dt: Float, rate: Float = 9f): Float {
        value += (target - value) * (1f - exp(-rate * dt))
        return value
    }

    fun snap(v: Float) { value = v }
}

/** Fixed-size particle pool. Arrays are parallel; dead slots have life <= 0. */
internal class ParticlePool(val capacity: Int) {
    val x = FloatArray(capacity)
    val y = FloatArray(capacity)
    val px = FloatArray(capacity)
    val py = FloatArray(capacity)
    val vx = FloatArray(capacity)
    val vy = FloatArray(capacity)
    val life = FloatArray(capacity)
    val maxLife = FloatArray(capacity)
    val size = FloatArray(capacity)
    val color = IntArray(capacity)
    private var cursor = 0

    fun clear() { for (i in 0 until capacity) life[i] = 0f }

    /** Returns the slot index that was filled (reuses the oldest slot when full). */
    fun spawn(sx: Float, sy: Float, svx: Float, svy: Float, l: Float, s: Float, col: Int): Int {
        var idx = -1
        for (k in 0 until capacity) {
            val j = (cursor + k) % capacity
            if (life[j] <= 0f) { idx = j; break }
        }
        if (idx < 0) idx = cursor
        cursor = (idx + 1) % capacity
        x[idx] = sx; y[idx] = sy; px[idx] = sx; py[idx] = sy
        vx[idx] = svx; vy[idx] = svy
        life[idx] = l; maxLife[idx] = l; size[idx] = s; color[idx] = col
        return idx
    }

    fun alive(): Int {
        var n = 0
        for (i in 0 until capacity) if (life[i] > 0f) n++
        return n
    }
}

/** Vertical list of lines that scrolls smoothly to keep the active line in focus. */
internal class LineStack(private val before: Int, private val after: Int) {
    private val n = before + after + 1
    val fol = Follower()
    val idx = IntArray(n)
    val y = FloatArray(n)
    val scale = FloatArray(n)
    val dist = FloatArray(n)
    val lay = arrayOfNulls<LineLayout>(n)
    private val h = FloatArray(n)
    var count = 0
        private set
    private var lastActive = -99

    /**
     * Fills idx/y/scale/dist/lay. y is the centre of each line relative to the focus point.
     * Scale falls from [scaleNear] (at the focus) to [scaleFar] over about 2.5 lines.
     */
    fun build(
        f: VisFrame, cache: LayoutCache, size: Float, maxW: Float, maxRows: Int,
        active: Int, rate: Float, gap: Float, scaleNear: Float, scaleFar: Float
    ) {
        if (kotlin.math.abs(active - lastActive) > 6) fol.snap(active.toFloat())
        lastActive = active
        val fa = fol.step(active.toFloat(), f.dt, rate)
        val lines = f.track.lines
        val lo = max(0, active - before)
        val hi = min(lines.size - 1, active + after)
        count = 0
        for (k in lo..hi) {
            val d = k - fa
            val s = scaleFar + (scaleNear - scaleFar) * (1f - smoothstep(kotlin.math.abs(d) / 2.5f))
            val l = cache.get(lines[k], f.pen, size, maxW, f.align, maxRows, f.fontId)
            idx[count] = k; dist[count] = d; scale[count] = s; lay[count] = l; h[count] = l.height * s
            count++
        }
        if (count == 0) return
        var cursor = 0f
        for (i in 0 until count) {
            cursor += if (i == 0) h[0] * 0.5f else h[i - 1] * 0.5f + gap + h[i] * 0.5f
            y[i] = cursor
        }
        // Shift so that the (fractional) focus line sits at zero.
        var focusY = y[0]
        for (i in 0 until count) {
            if (dist[i] >= 0f) {
                focusY = if (i == 0) y[0] else lerpF(y[i - 1], y[i], 1f - dist[i] / max(0.0001f, dist[i] - dist[i - 1]))
                break
            }
            focusY = y[i]
        }
        for (i in 0 until count) y[i] -= focusY
    }
}
