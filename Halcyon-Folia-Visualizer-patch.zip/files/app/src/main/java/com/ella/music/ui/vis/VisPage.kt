package com.ella.music.ui.vis

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.ella.music.data.model.LyricLine
import com.ella.music.data.model.Song
import com.ella.music.ui.player.PlayerPalette
import java.io.File
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext

private enum class VisSheetKind { NONE, STYLE, THEME, TUNE }

/** Watches frame times and lowers the effect quality when the device cannot keep up. */
internal class QualityGovernor {
    var quality = 1f
    private var acc = 0f
    private var frames = 0
    private var goodSeconds = 0f

    fun sample(dt: Float, targetDt: Float) {
        acc += dt
        frames++
        if (acc < 1f) return
        val avg = acc / frames
        if (avg > targetDt * 1.45f) {
            quality = max(0.4f, quality - 0.15f)
            goodSeconds = 0f
        } else if (avg < targetDt * 1.15f) {
            goodSeconds += acc
            if (goodSeconds > 5f) {
                quality = min(1f, quality + 0.1f)
                goodSeconds = 0f
            }
        }
        acc = 0f
        frames = 0
    }
}

/**
 * Mounted once inside the player. Shows a small button on the lyrics page and, when pressed,
 * the full-screen lyric visualizer on top of the player.
 */
@Composable
internal fun VisOverlayHost(
    lyrics: List<LyricLine>,
    song: Song?,
    durationMs: Long,
    isPlaying: Boolean,
    positionProvider: () -> Long,
    lyricOffsetMs: Long,
    palette: PlayerPalette,
    paletteBitmap: Bitmap?,
    embeddedCover: Bitmap?,
    audioSessionId: Int,
    appFontPath: String,
    isLandscape: Boolean,
    lyricsVisible: Boolean,
    onSeek: (Long) -> Unit,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    playerBackground: @Composable (Modifier) -> Unit
) {
    val context = LocalContext.current
    remember(context) { VisPrefs.init(context); true }
    Box(Modifier.fillMaxSize()) {
        if (lyricsVisible && VisPrefs.showButton && !VisController.open && lyrics.isNotEmpty()) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 8.dp)
                    .offset(y = (-84).dp)
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Color(0x66000000))
                    .tap { VisController.show() },
                contentAlignment = Alignment.Center
            ) {
                VisIcon(VisIconKind.VIS, Color(0xEBFFFFFF), 22.dp)
            }
        }
        AnimatedVisibility(
            visible = VisController.open,
            enter = fadeIn(tween(220)),
            exit = fadeOut(tween(160))
        ) {
            VisPage(
                lyrics, song, durationMs, isPlaying, positionProvider, lyricOffsetMs, palette, paletteBitmap,
                embeddedCover, audioSessionId, appFontPath, isLandscape, onSeek, onPlayPause, onPrevious, onNext,
                playerBackground
            )
        }
    }
}

@Composable
private fun VisPage(
    lyrics: List<LyricLine>,
    song: Song?,
    durationMs: Long,
    isPlaying: Boolean,
    positionProvider: () -> Long,
    lyricOffsetMs: Long,
    palette: PlayerPalette,
    paletteBitmap: Bitmap?,
    embeddedCover: Bitmap?,
    audioSessionId: Int,
    appFontPath: String,
    isLandscape: Boolean,
    onSeek: (Long) -> Unit,
    onPlayPause: () -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    playerBackground: @Composable (Modifier) -> Unit
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val layoutDirection = LocalLayoutDirection.current
    var sheet by remember { mutableStateOf(VisSheetKind.NONE) }
    var lastSheet by remember { mutableStateOf(VisSheetKind.STYLE) }
    var hudVisible by remember { mutableStateOf(true) }
    var hudNonce by remember { mutableIntStateOf(0) }
    var toast by remember { mutableStateOf("") }
    var dragFrac by remember { mutableFloatStateOf(-1f) }
    SideEffect { if (sheet != VisSheetKind.NONE) lastSheet = sheet }

    val foliaController = remember { FoliaController() }

    BackHandler {
        if (foliaController.settingsOpen) {
            foliaController.call("HalcyonHost.openSettings(false)")
            foliaController.settingsOpen = false
        } else if (sheet != VisSheetKind.NONE) {
            sheet = VisSheetKind.NONE
        } else {
            VisController.hide()
        }
    }

    val view = LocalView.current
    DisposableEffect(VisPrefs.keepScreenOn) {
        val previous = view.keepScreenOn
        if (VisPrefs.keepScreenOn) view.keepScreenOn = true
        onDispose { view.keepScreenOn = previous }
    }

    // ---- model
    val track = remember(lyrics, durationMs, VisPrefs.showTranslation, VisPrefs.showRomanization) {
        buildVisTrack(lyrics, durationMs, VisPrefs.showTranslation, VisPrefs.showRomanization)
    }
    val styles = remember { VisStyles.createAll() }
    val previewStyles = remember { VisStyles.createAll() }
    val style = styles.firstOrNull { it.id == VisPrefs.styleId } ?: styles[0]
    LaunchedEffect(style.id) { style.reset() }

    val coverTheme = remember(palette) {
        VisThemes.fromCover(
            palette.top.toArgb(), palette.middle.toArgb(), palette.bottom.toArgb(),
            palette.accent.toArgb(), palette.onBackground.toArgb(), palette.isLight
        )
    }
    val baseTheme = VisThemes.byId(VisPrefs.themeId, VisPrefs.customThemes) ?: coverTheme
    val theme = remember(baseTheme, VisPrefs.fontOverride) {
        if (VisPrefs.fontOverride.isEmpty()) baseTheme else baseTheme.withFont(VisFont.fromName(VisPrefs.fontOverride))
    }
    val typeface = remember(theme.font, appFontPath) { VisTypefaces.get(theme.font, appFontPath) }
    val pen = remember { VisPen() }
    if (pen.typeface !== typeface) pen.setFont(typeface)
    val fontId = theme.font.ordinal * 31 + appFontPath.hashCode()

    val frame = remember { VisFrame() }
    val drive = remember { AudioDrive() }
    val bg = remember { VisBackground() }
    val governor = remember { QualityGovernor() }
    val foliaAvailable = remember { FoliaAssets.available(context) }
    var foliaFailed by remember { mutableStateOf(false) }
    val useFolia = VisPrefs.engine == "folia" && foliaAvailable && !foliaFailed
    val latestUseFolia by rememberUpdatedState(useFolia)
    val latestHudShown by rememberUpdatedState(hudVisible || sheet != VisSheetKind.NONE)
    val foliaDpr = if (VisPrefs.foliaDpr > 0f) VisPrefs.foliaDpr else when (VisPrefs.quality) { 1 -> 2f; 3 -> 1f; else -> 1.5f }
    val rtlSong = track.rtlRatio > 0.5f
    val foliaModeEffective =
        if (rtlSong && VisPrefs.foliaRtlAuto && VisPrefs.foliaMode !in RTL_READY_MODES) VisPrefs.foliaRtlMode else VisPrefs.foliaMode
    LaunchedEffect(rtlSong, foliaModeEffective, useFolia, song?.path) {
        if (useFolia && rtlSong && foliaModeEffective != VisPrefs.foliaMode) {
            val label = foliaController.modes.firstOrNull { it.first == foliaModeEffective }?.second ?: foliaModeEffective
            toast = "Right-to-left lyrics: using $label"
        }
    }
    val powerCap by rememberPowerFrameCap()
    var idleLong by remember { mutableStateOf(false) }
    LaunchedEffect(isPlaying) {
        idleLong = false
        if (!isPlaying) {
            delay(10_000L)
            idleLong = true
        }
    }
    val foliaFpsBase = if (VisPrefs.fpsCap > 0) VisPrefs.fpsCap else if (VisPrefs.quality == 3) 30 else 60
    val foliaFpsLimited = if (powerCap > 0) min(foliaFpsBase, powerCap) else foliaFpsBase
    val foliaFps = if (!isPlaying) min(foliaFpsLimited, if (idleLong) 10 else 20) else foliaFpsLimited
    LaunchedEffect(useFolia) {
        if (useFolia) {
            delay(18000L)
            if (!foliaController.firstFrame) foliaFailed = true
        }
    }
    val tick = remember { mutableLongStateOf(0L) }
    val secondsShown = remember { mutableIntStateOf(0) }
    LaunchedEffect(paletteBitmap, embeddedCover) { bg.setCover(paletteBitmap ?: embeddedCover) }
    LaunchedEffect(song?.path) { drive.reset(); styles.forEach { it.reset() } }

    // ---- beat analysis (offline, cached per song)
    var beatMap by remember { mutableStateOf<BeatMap?>(null) }
    LaunchedEffect(song?.path, VisPrefs.beatFx) {
        beatMap = null
        VisController.beatStatus = ""
        val s = song ?: return@LaunchedEffect
        if (!VisPrefs.beatFx) return@LaunchedEffect
        val dir = File(context.cacheDir, "vis_beats")
        val key = BeatAnalyzer.cacheKey(s.path, s.fileSize, s.dateModified)
        val cached = withContext(Dispatchers.IO) { BeatAnalyzer.loadCached(dir, key) }
        if (cached != null) {
            beatMap = cached
            VisController.beatStatus = describeBeats(cached)
            return@LaunchedEffect
        }
        VisController.beatStatus = "Analysing beats…"
        val result = withContext(Dispatchers.Default) { BeatAnalyzer.analyze(context, s.path) { isActive } }
        if (result != null) {
            beatMap = result
            VisController.beatStatus = describeBeats(result)
            withContext(Dispatchers.IO) { BeatAnalyzer.saveCached(dir, key, result) }
        } else {
            VisController.beatStatus = "Beat analysis is not available for this source – using the live spectrum."
        }
    }

    // ---- live spectrum
    var hasPermission by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        hasPermission = granted
    }
    val playingNow by rememberUpdatedState(isPlaying)
    LaunchedEffect(audioSessionId, hasPermission, VisPrefs.audioReactive) {
        if (VisPrefs.audioReactive && hasPermission && audioSessionId > 0) {
            VisBands.run(drive, audioSessionId) { playingNow }
        }
    }

    // ---- frame loop
    val latestStyle by rememberUpdatedState(style)
    val latestTrack by rememberUpdatedState(track)
    val latestMap by rememberUpdatedState(beatMap)
    val latestProvider by rememberUpdatedState(positionProvider)
    val latestOffset by rememberUpdatedState(lyricOffsetMs)
    LaunchedEffect(Unit) {
        var last = 0L
        var timeSec = 0f
        var lastShownSec = -1
        while (true) {
            withFrameNanos { now ->
                var cap = if (VisPrefs.fpsCap > 0) VisPrefs.fpsCap else 60
                if (VisPrefs.quality == 3) cap = min(cap, 30)
                val preferred = latestStyle.preferredFps
                if (preferred > 0) cap = min(cap, preferred)
                if (!playingNow) cap = min(cap, 24)
                if (latestUseFolia) cap = min(cap, if (latestHudShown) 10 else 2)
                val minInterval = 1_000_000_000L / cap
                if (last != 0L && now - last < minInterval - 1_500_000L) return@withFrameNanos
                val dt = if (last == 0L) 0.016f else ((now - last) / 1_000_000_000f).coerceIn(0.001f, 0.1f)
                last = now
                timeSec += dt
                val pos = (latestProvider() - latestOffset).coerceAtLeast(0L)
                frame.posMs = pos
                frame.t = timeSec
                frame.dt = dt
                frame.playing = playingNow
                frame.active = latestTrack.indexAt(pos)
                if (!latestUseFolia) drive.step(pos, dt, timeSec, playingNow, latestMap, VisPrefs.audioReactive, VisPrefs.beatFx, VisPrefs.beatOffsetMs)
                if (VisPrefs.quality == 0 && playingNow) governor.sample(dt, 1f / cap)
                val sec = (pos / 1000L).toInt()
                if (sec != lastShownSec) { lastShownSec = sec; secondsShown.intValue = sec }
                tick.longValue = now
            }
        }
    }

    // ---- HUD auto-hide
    LaunchedEffect(hudVisible, hudNonce, sheet) {
        if (hudVisible && VisPrefs.autoHideHud && sheet == VisSheetKind.NONE) {
            delay(4500L)
            hudVisible = false
        }
    }
    LaunchedEffect(toast) {
        if (toast.isNotEmpty()) {
            delay(1300L)
            toast = ""
        }
    }

    fun cycleStyle(direction: Int) {
        if (latestUseFolia) {
            val modes = foliaController.modes
            val fi = modes.indexOfFirst { it.first == VisPrefs.foliaMode }
            val picked = modes[((if (fi < 0) 0 else fi) + direction + modes.size) % modes.size]
            VisPrefs.foliaMode = picked.first
            VisPrefs.save()
            toast = picked.second
            return
        }
        val i = styles.indexOfFirst { it.id == VisPrefs.styleId }
        val next = styles[((if (i < 0) 0 else i) + direction + styles.size) % styles.size]
        VisPrefs.styleId = next.id
        VisPrefs.save()
        toast = next.title
    }

    val latestPlayPause by rememberUpdatedState(onPlayPause)
    val latestSeek by rememberUpdatedState(onSeek)

    // ---- insets
    val insets = WindowInsets.safeDrawing
    val padL = insets.getLeft(density, layoutDirection).toFloat()
    val padT = insets.getTop(density).toFloat()
    val padR = insets.getRight(density, layoutDirection).toFloat()
    val padB = insets.getBottom(density).toFloat()
    val reserveTop = with(density) { (if (isLandscape) 44.dp else 60.dp).toPx() }
    val reserveBottom = with(density) { (if (isLandscape) 80.dp else 104.dp).toPx() }

    val accentColor = Color(theme.accent)
    val hudAlpha by animateFloatAsState(
        targetValue = if (hudVisible || sheet != VisSheetKind.NONE) 1f else 0f,
        animationSpec = tween(260)
    )

    Box(
        Modifier
            .fillMaxSize()
            .background(Color(theme.bgBottom))
            .pointerInput(foliaController.settingsOpen) {
                if (foliaController.settingsOpen) return@pointerInput
                detectTapGestures(
                    onTap = { hudVisible = !hudVisible; hudNonce++ },
                    onDoubleTap = { latestPlayPause() }
                )
            }
            .pointerInput(foliaController.settingsOpen) {
                // Folia's settings screen scrolls inside the WebView: leave every touch to it.
                if (foliaController.settingsOpen) return@pointerInput
                var dx = 0f
                var dy = 0f
                detectDragGestures(
                    onDragStart = { dx = 0f; dy = 0f },
                    onDrag = { change, amount -> change.consume(); dx += amount.x; dy += amount.y },
                    onDragEnd = {
                        val threshold = 80.dp.toPx()
                        if (abs(dx) > abs(dy) && abs(dx) > threshold) {
                            cycleStyle(if (dx < 0f) 1 else -1)
                        } else if (abs(dy) > abs(dx) && dy > threshold * 1.6f) {
                            VisController.hide()
                        }
                        dx = 0f; dy = 0f
                    },
                    onDragCancel = { dx = 0f; dy = 0f }
                )
            }
    ) {
        if (useFolia) {
            FoliaStage(foliaController, foliaDpr, foliaFps, Modifier.fillMaxSize())
            FoliaSync(
                controller = foliaController,
                track = track,
                theme = theme,
                mode = foliaModeEffective,
                background = VisPrefs.foliaBackground,
                songKey = song?.path.orEmpty(),
                songTitle = song?.title.orEmpty(),
                songArtist = song?.artist.orEmpty(),
                cover = paletteBitmap ?: embeddedCover,
                beatMap = beatMap,
                drive = drive,
                playing = isPlaying,
                durationMs = durationMs,
                positionProvider = positionProvider,
                lyricOffsetMs = lyricOffsetMs,
                fps = foliaFps
            )
            // Transparent touch shield: the WebView never sees touches, so taps/swipes reach the page gestures.
            // It is lifted while Folia's own settings screen is open, which needs the touches.
            if (!foliaController.settingsOpen) {
                Box(
                    Modifier.fillMaxSize().pointerInput(Unit) {
                        awaitPointerEventScope { while (true) awaitPointerEvent() }
                    }
                )
            }
            if (foliaController.error.isNotEmpty() && !foliaController.settingsOpen) {
                BasicText(
                    "Folia: " + foliaController.error,
                    maxLines = 3,
                    style = TextStyle(color = Color(0xFFFFB4A8), fontSize = 11.sp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 118.dp, start = 14.dp, end = 14.dp)
                        .clip(CircleShape)
                        .background(Color(0x99000000))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                )
            }
            if (!foliaController.firstFrame) {
                Box(Modifier.fillMaxSize().background(Color(theme.bgBottom)), contentAlignment = Alignment.Center) {
                    BasicText(
                        "Starting Folia…",
                        style = TextStyle(color = Color(0x99FFFFFF), fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    )
                }
            }
        } else {
            if (VisPrefs.backgroundId == VisBackgroundIds.HALCYON) playerBackground(Modifier.fillMaxSize())

            Canvas(Modifier.fillMaxSize()) {
                tick.longValue
                drawIntoCanvas { cv ->
                    val c = cv.nativeCanvas
                    val w = size.width
                    val h = size.height
                    frame.c = c
                    frame.pen = pen
                    frame.w = w
                    frame.h = h
                    frame.safeL = padL
                    frame.safeR = padR
                    frame.safeT = padT + reserveTop
                    frame.safeB = padB + reserveBottom
                    frame.track = track
                    frame.theme = theme
                    frame.drive = drive
                    frame.landscape = w > h
                    frame.textScale = VisPrefs.textScale
                    frame.align = VisPrefs.align
                    frame.react = if (VisPrefs.audioReactive || VisPrefs.beatFx) VisPrefs.reactStrength else 0f
                    frame.beatK = if (VisPrefs.beatFx) VisPrefs.beatStrength else 0f
                    frame.fontId = fontId
                    frame.quality = when (VisPrefs.quality) {
                        1 -> 1f
                        2 -> 0.7f
                        3 -> 0.45f
                        else -> governor.quality
                    }
                    val ps = style.params
                    for (i in ps.indices) {
                        if (i < frame.params.size) frame.params[i] = VisPrefs.tunings[style.paramKeys[i]] ?: ps[i].def
                    }
                    bg.draw(c, w, h, VisPrefs.backgroundId, theme, frame.t, drive, frame.quality, VisPrefs.bgDim, frame.react)
                    style.draw(frame)
                    drawInterlude(frame, theme)
                }
            }

        }

        if (track.isEmpty) {
            BasicText(
                "No lyrics for this song",
                style = TextStyle(color = Color(0xAAFFFFFF), fontSize = 18.sp, fontWeight = FontWeight.Bold),
                modifier = Modifier.align(Alignment.Center)
            )
        }

        if (toast.isNotEmpty()) {
            BasicText(
                toast,
                style = TextStyle(color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold),
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 96.dp)
                    .clip(CircleShape)
                    .background(Color(0x88000000))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        if (hudAlpha > 0.02f && !foliaController.settingsOpen) {
            Row(
                Modifier
                    .align(Alignment.TopCenter)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Top))
                    .padding(horizontal = 10.dp, vertical = 8.dp)
                    .graphicsLayer { alpha = hudAlpha },
                verticalAlignment = Alignment.CenterVertically
            ) {
                HudButton(VisIconKind.CLOSE) { VisController.hide() }
                Column(Modifier.weight(1f).padding(horizontal = 10.dp)) {
                    BasicText(
                        song?.title.orEmpty(),
                        maxLines = 1,
                        style = TextStyle(color = Color(theme.text), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    )
                    BasicText(
                        song?.artist.orEmpty(),
                        maxLines = 1,
                        style = TextStyle(color = Color(theme.text).copy(alpha = 0.65f), fontSize = 12.sp)
                    )
                }
                HudButton(VisIconKind.STYLE) { sheet = VisSheetKind.STYLE }
                HudButton(VisIconKind.THEME) { sheet = VisSheetKind.THEME }
                HudButton(VisIconKind.TUNE) { sheet = VisSheetKind.TUNE }
            }

            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.safeDrawing.only(WindowInsetsSides.Horizontal + WindowInsetsSides.Bottom))
                    .padding(horizontal = if (isLandscape) 80.dp else 18.dp, vertical = 8.dp)
                    .graphicsLayer { alpha = hudAlpha }
            ) {
                Canvas(
                    Modifier
                        .fillMaxWidth()
                        .height(26.dp)
                        .pointerInput(durationMs) {
                            detectTapGestures { off ->
                                latestSeek((durationMs * (off.x / size.width).coerceIn(0f, 1f)).toLong())
                            }
                        }
                        .pointerInput(durationMs) {
                            detectHorizontalDragGestures(
                                onDragStart = { dragFrac = (it.x / size.width).coerceIn(0f, 1f) },
                                onDragEnd = {
                                    if (dragFrac >= 0f) latestSeek((durationMs * dragFrac).toLong())
                                    dragFrac = -1f
                                },
                                onDragCancel = { dragFrac = -1f },
                                onHorizontalDrag = { change, _ ->
                                    change.consume()
                                    dragFrac = (change.position.x / size.width).coerceIn(0f, 1f)
                                }
                            )
                        }
                ) {
                    tick.longValue
                    val cy = size.height / 2f
                    val live = (frame.posMs.toFloat() / max(1L, durationMs).toFloat()).coerceIn(0f, 1f)
                    val frac = if (dragFrac >= 0f) dragFrac else live
                    drawLine(Color(0x33FFFFFF), Offset(0f, cy), Offset(size.width, cy), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                    drawLine(accentColor, Offset(0f, cy), Offset(size.width * frac, cy), strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round)
                    drawCircle(Color.White, radius = 6.dp.toPx(), center = Offset(size.width * frac, cy))
                }
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    BasicText(formatClock(secondsShown.intValue.toLong()), style = TextStyle(color = Color(0xBBFFFFFF), fontSize = 12.sp))
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                        HudButton(VisIconKind.PREV, onClick = onPrevious)
                        Box(Modifier.padding(horizontal = 10.dp)) {
                            Box(
                                Modifier.size(54.dp).clip(CircleShape).background(Color(0xE6FFFFFF)).tap(onPlayPause),
                                contentAlignment = Alignment.Center
                            ) {
                                VisIcon(if (isPlaying) VisIconKind.PAUSE else VisIconKind.PLAY, Color(0xFF14161C), 26.dp)
                            }
                        }
                        HudButton(VisIconKind.NEXT, onClick = onNext)
                    }
                    BasicText(formatClock(durationMs / 1000L), style = TextStyle(color = Color(0xBBFFFFFF), fontSize = 12.sp))
                }
            }
        }

        val env = VisSheetEnv(
            theme = theme,
            coverTheme = coverTheme,
            style = style,
            previewStyles = previewStyles,
            songHint = listOfNotNull(song?.title, song?.artist).joinToString(" – "),
            hasAudioPermission = hasPermission,
            requestAudioPermission = { permissionLauncher.launch(Manifest.permission.RECORD_AUDIO) },
            landscape = isLandscape,
            typeface = typeface,
            engine = if (useFolia) "folia" else "native",
            foliaAvailable = foliaAvailable,
            foliaModes = foliaController.modes,
            foliaBackgrounds = foliaController.backgrounds,
            foliaRtlSong = rtlSong,
            foliaEffectiveMode = foliaModeEffective,
            foliaError = foliaController.error,
            foliaDiag = foliaController.diag.toList(),
            foliaStatus = if (foliaFailed) "Folia did not start (" + foliaController.error.ifEmpty { "timed out" } + ") – using the native engine." else ""
        )
        VisSheetPanel(
            visible = sheet != VisSheetKind.NONE,
            landscape = isLandscape,
            onDismiss = { sheet = VisSheetKind.NONE }
        ) {
            when (lastSheet) {
                VisSheetKind.STYLE -> StyleSheetContent(
                    env,
                    onPick = { picked ->
                        VisPrefs.styleId = picked.id
                        VisPrefs.save()
                    },
                    onFoliaSettings = {
                        if (foliaController.ready) {
                            sheet = VisSheetKind.NONE
                            foliaController.settingsOpen = true
                            foliaController.call("HalcyonHost.openSettings(true)")
                        }
                    }
                )
                VisSheetKind.THEME -> ThemeSheetContent(env)
                VisSheetKind.TUNE -> TuneSheetContent(env)
                VisSheetKind.NONE -> Unit
            }
        }
    }
}

@Composable
private fun HudButton(kind: VisIconKind, onClick: () -> Unit) {
    Box(
        Modifier
            .padding(horizontal = 2.dp)
            .size(44.dp)
            .clip(CircleShape)
            .background(Color(0x40000000))
            .tap(onClick),
        contentAlignment = Alignment.Center
    ) {
        VisIcon(kind, Color.White, 22.dp)
    }
}

private fun describeBeats(map: BeatMap): String =
    if (map.confident) "${map.bpm.toInt()} BPM – beat grid ready"
    else "No steady beat found – using the drum hits only"

private fun formatClock(totalSeconds: Long): String {
    val s = totalSeconds.coerceAtLeast(0L)
    return "%d:%02d".format(s / 60L, s % 60L)
}

/** Three breathing dots during long instrumental gaps. */
private fun drawInterlude(f: VisFrame, theme: VisTheme) {
    val lines = f.track.lines
    if (lines.isEmpty() || !f.playing) return
    val active = f.active
    val gapStart = if (active >= 0) lines[active].endMs + 400L else 0L
    val next = lines.getOrNull(active + 1) ?: return
    val span = next.startMs - gapStart
    if (span < 3200L || f.posMs < gapStart || f.posMs > next.startMs) return
    val p = (f.posMs - gapStart).toFloat() / span.toFloat()
    val fade = min(1f, min(p * 8f, (1f - p) * 8f))
    val r = min(f.w, f.h) * 0.016f
    val y = f.safeT + f.contentH * 0.5f
    val paint = f.pen.shape
    for (i in 0 until 3) {
        val fill = ((p * 3f) - i).coerceIn(0f, 1f)
        val breathe = 1f + 0.18f * sin(f.t * 2.4f - i * 0.7f)
        paint.color = withAlpha(theme.text, (0.22f + 0.7f * fill) * fade)
        f.c.drawCircle(f.cx + (i - 1) * r * 3.4f, y, r * breathe, paint)
    }
}
