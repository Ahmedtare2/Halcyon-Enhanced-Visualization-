# TASK E — dry-run and verification report

## Inputs and merge basis

- `AI-HANDOFF-Halcyon-Folia.md` was read in full. TASK E and PART 3 require a
  complete patch against the unmodified Halcyon + trimmed Folia source ZIPs,
  an updated workflow when needed, ZIP safety, idempotence, licence checks,
  TypeScript/Kotlin static checks and a 10-step phone checklist.
- Halcyon source: `Halcyon-main.zip` (selected by project markers, not name).
- Folia source: `folia-web-min.zip` (selected by Vite/package/visualizer markers).
- Patch: the latest cumulative A–D `Halcyon-Folia-Visualizer-patch.zip`.
- `folia-web-min.zip` did not need changes; the Halcyon host config is supplied
  by the patch's `folia-host/` overlay.

## Passed checks

| Check | Result |
|---|---|
| Source import using deliberately renamed ZIPs in `source/` | Passed |
| A–D patch application to clean original Halcyon + Folia | Passed |
| Apply `apply.py` a second time | Identical source-tree SHA-256 |
| Halcyon `tools/check_licenses.py` | Passed |
| Patch helper Python compilation | Passed |
| YAML parse (`yaml.BaseLoader`) | Passed |
| Shell syntax (`bash -n`) | 15/15 workflow `run` blocks passed |
| Embedded workflow import helper vs tested helper | Byte-for-byte match |
| ZIP CRC and path-safety validation | Passed for supplied source archives |
| Path-traversal ZIP fixture (`../../escape.txt`) | Rejected before extraction |
| Duplicate Halcyon ZIP fixture | Failed with a clear ambiguity error |
| Symlink ZIP input fixture | Rejected before import |
| ZIP traversal fixture (`../../escape.txt`) | Rejected before extraction |
| Manual `use_patches: false` path | Passed; no patch files applied |
| Missing Folia source | Halcyon patch applied; native fallback selected |
| TypeScript/TSX syntax parser | 2,614 files, zero syntax diagnostics |
| Patched Kotlin delimiter check | 24 files, zero errors |
| Android/AndroidX imports vs original Halcyon | 191 unique imports, zero new/unmatched |
| Explicit Halcyon-owned imports | 30 checked, zero unresolved source symbols |
| Patch ZIP integrity / no nested ZIPs | Passed |

The combined patched tree hash before and after the second application was:

`09c962a6d3d70bf844d6b13731b9cb3ac97723b9a68890da110db5471d1f0c14`

### Node TypeScript check note

The exact handoff command, `node --experimental-strip-types --check`, was
attempted against 1,928 `.ts` files using the installed Node 22.16.0 runtime.
It returned 45 parser failures for TypeScript declarations/type annotations
(including `interface`, `type`, generics and `.d.ts`). The same full source set,
including `.tsx`, passed the installed TypeScript 5.8 parser: 2,614 files and
zero syntax diagnostics. The 45 Node errors are therefore recorded as a Node
check limitation, not silently reported as successful.

## Workflow hardening

- Content-based, filename-agnostic detection remains supported for ZIPs in the
  repository root, `source/` or `patches/`.
- Exactly one Halcyon archive is required; multiple candidates now fail with
  their filenames rather than selecting the first sorted archive.
- At most one Folia archive is accepted; missing Folia retains the native app
  fallback.
- With patching enabled, exactly one merged patch archive is required to avoid
  stale A/B/C/D patch overlays being applied in an unpredictable order.
- Before extraction, ZIP entries are checked for traversal/absolute paths,
  duplicate paths, symlinks/special files, encryption, excessive count/size,
  suspicious compression ratios and CRC errors.
- `use_patches: false` is now respected; the old `|| 'true'` expression could
  turn a false manual input back into true.
- Build actions are full-SHA pinned except cache restore/save, which use the
  exact `v6.1.0` release tag. Checkout credentials are not persisted; job
  permissions are read-only; the Gradle wrapper is validated.
- The licence/provenance check now fails the run instead of being allowed to
  continue. Folia bundle failure still falls back to native styles. Patched
  Kotlin failure still attempts the plain Halcyon fallback APK and then marks
  the run failed with diagnostics.

## Not run / remaining risks

- `npm ci --offline` failed because the local npm cache does not contain the
  locked `zustand-5.0.15.tgz`; the environment has Node 22.16, while Folia's
  package declares Node >=24. The GitHub workflow installs Node 24 and performs
  a normal online `npm ci` before Vite.
- Full Vite production build not run locally.
- Android Release/Debug Gradle build not run: this environment has no Android
  SDK, `sdkmanager`, `adb` or Gradle installation. Android NDK/CMake/platform
  installation and the APK compile must be done by GitHub Actions.
- `actionlint` is not installed. YAML parsing and all embedded shell syntax
  blocks passed, but GitHub's server-side workflow evaluation is not available
  in this environment.
- No phone tests: Xiaomi GPU/battery/thermal behaviour, Arabic glyph visual
  clipping, end-to-end audible beat latency and Bluetooth route delay remain
  physical-device checks.

The output ZIPs remain below the repository's 25 MB per-file limit. See
`TEST-ON-PHONE.md` and `UPLOAD-STEPS.txt` for the next steps.
