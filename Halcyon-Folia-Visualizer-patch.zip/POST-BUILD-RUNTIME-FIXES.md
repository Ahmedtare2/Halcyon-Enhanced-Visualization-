# Post-build visualizer fixes — 22 November 2026

This update follows the first successful patched APK installation and the phone
runtime report. It is a replacement for the previous cumulative A–D/E patch,
not an additional patch to stack on top of it.

## 1. Rainy-glass / Nebbia runtime failure

The screenshot showed:

`Folia: promise: ReferenceError: isIconChar is not defined`

`nebbiaLayout.ts` used `isIconChar()` while filtering icon glyphs in its RTL
layout, but did not import the function. The Folia patch now imports the named
export from `./nebbiaChars`. This directly fixes the reported unresolved
runtime identifier. It does not change Nebbia's palette, rain/glass layers,
lighting, typography or animation values.

## 2. Arabic word-level drawing in Sonnet and Tempera

Both styles previously generated and animated a separate text node per
Arabic grapheme. That caused unnecessary Pixi objects and repeated per-letter
animation on cursive words.

- Sonnet now creates one shaped Pixi text node per Arabic word. The word starts
  at the first lyric onset for that word and uses the existing word-entry
  motion. Arabic cursive remains on a horizontal joined-text path.
- Tempera now measures and draws one complete shaped Arabic word node, with the
  unit's start/end spanning the source word's grapheme timings.
- The non-Arabic paths are unchanged. In particular, Latin remains on its
  original per-grapheme animation path and keeps its prior visual treatment.

## 3. Beat reaction update

The sink-side PCM tap still analyses read-only decoded PCM and does not alter
or delay audible audio. The detector now evaluates kick, snare and hat bands
independently, with energy-ratio gates to reduce overlapping-filter
misclassification. Each instrument has its own merge/debounce window, so a
kick, snare and hat in the same analysis frame can all be retained.

The visual reaction is intentionally differentiated:

- Kick/bass drives the stronger pulse and can become a downbeat when it matches
  the selected analysed downbeat timing.
- Snare/body adds a lighter beat accent.
- Hi-hat events remain available to styles that use detailed drum hits, but do
  not drive the shared beat clock; this avoids continuous subdivision flicker.
- The live PCM stream only replaces the future shared beat-clock events when
  the user's beat source is set to live drums. An analysed beat-grid selection
  remains authoritative.

The beat clock's already-fired prefix and envelope are not reset for each
incoming PCM update.

## Verification completed

- Applied the complete cumulative patch to fresh, unmodified Halcyon and Folia
  source trees.
- Applied it again; the full-tree hash was unchanged:
  `8526edcb7cd3953239e302ff28cc31359d63b3c419514b5028f9508581e7f24c`.
- TypeScript parser check: 2,498 `.ts`/`.tsx` files, zero syntax diagnostics and
  zero unresolved relative imports.
- Sonnet/Tempera runtime harness: Arabic `سَلَام` produced one whole-word node
  in each style; English `hello` remained five per-grapheme nodes in each.
- Nebbia `isIconChar` import checked against the actual named export.
- Kotlin Media3 sink tap compiled against local Media3/API stubs.
- Synthetic PCM detector: isolated kick, snare and hat were classified; a
  simultaneous kick+snare+hat frame retained all three; low-level noise was
  rejected by the test fixture.
- Halcyon application-header and pinned Miuix provenance check passed.

## Not yet verified on hardware

These are source and synthetic checks, not a physical-device acceptance test.
A full Vite production build and Android Release build of this exact replacement
were not run here. The user-reported prior APK build succeeded, but this new
replacement must be built again through GitHub Actions. Real-song beat timing,
Bluetooth downstream latency, phone GPU load, heat, battery drain and visual
parity still require testing on the device.
