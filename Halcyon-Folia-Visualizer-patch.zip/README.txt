Halcyon x Folia lyric visualizer patch
======================================
Adds a full-screen lyric visualizer page to Halcyon (button on the right edge of the lyrics page).

Two engines:
  Folia (GPU)   Folia's own visualizers (17 styles + backgrounds) running unchanged in a
                hardware-accelerated WebView, fed by Halcyon (lyrics, clock, theme, audio bands,
                beat grid). Render scale and frame rate are capped for the Xiaomi 11T / battery.
  Native        the built-in Canvas styles (lightest on battery).

Contents
  apply.py       anchored edits to PlayerScreen.kt, MusicRepositoryUtils.kt, proguard-rules.pro
  files/         new Kotlin sources: ui/vis/* and data/parser/KrcDecoder.kt
  folia-host/    small web host (halcyon-host.html + src/halcyon/*) added to the Folia source at build time

Use with build.yml: upload this zip, the Halcyon source zip and folia-web-min.zip to the repository
root and run the workflow. Folia is AGPL-3.0: the APK that embeds it is for personal use unless you
also publish the corresponding source.
