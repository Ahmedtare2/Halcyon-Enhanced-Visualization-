Halcyon + Folia visualizer patch — complete Tasks A, B, C and D

This is the single, complete, phone-upload-friendly patch for the unmodified
Halcyon-main.zip and folia-web-min.zip source archives. It is not a delta over
an older task patch.

Included work:
- Task A: native, low-resolution, vsync-paced OpenGL ES Latent background for
  Battery quality, with the original web mesh retained as fallback.
- Task B: timestamped, read-only Media3 output-sink PCM beat detection for both
  playback/crossfade players, integrated with Folia's live drum-hit clock.
- Task C: Arabic shaping, RTL line layout and highlight sweep across all 17
  styles, preserving the original Latin path.
- Task D: v0.7.21 Android mobile GPU-budget principles applied to v0.7.25-only
  Hanabi, Machi and Nebbia and the relevant high-cost mobile backgrounds.

Task E supplies a separate hardened build.yml. Upload it to the exact GitHub
path .github/workflows/build.yml. Keep folia-web-min.zip unchanged. Do not unzip
this patch on Android or upload separate Task A/B/C/D patch ZIPs.

The patch is anchored and idempotent. The source-level validation, exact
verification results and remaining limits are in TASK-E-VERIFICATION.md.
Follow TEST-ON-PHONE.md after a successful Release APK build.
