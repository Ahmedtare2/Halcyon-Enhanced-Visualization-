Halcyon x Folia lyric visualizer — complete current patch
========================================================

This is the complete patch for the unmodified Halcyon-main.zip and
folia-web-min.zip sources. It retains Tasks A and B and adds Task C; it is not
a delta that must be applied over an older patch.

TASK A — native low-power Latent mesh
-------------------------------------
Adds a Halcyon-owned OpenGL ES 2.0 mesh behind Folia's transparent WebView.
The low-resolution 180 x 400 surface uses Choreographer/vsync pacing and
RENDERMODE_WHEN_DIRTY, receives the cover/theme palette, tuning and audio
energy, and stops when the visualizer is hidden or paused. Only Battery quality
+ Latent enables it; Auto, Balanced and High retain Folia's original mesh.
The Dithering layer, all 17 lyric styles, other backgrounds and web fallback
remain. Battery quality also applies the existing temporary DPR/FPS/render-scale
limits. The native mesh is an approximation of Paper's mesh shader, so visual
parity still needs checking on the phone.

TASK B — real-time PCM beat reactions
-------------------------------------
Adds read-only PCM taps at Media3's final AudioSink boundary for the primary and
secondary crossfade players. The tap uses the output presentation timestamp and
does not modify audio samples or replace the configured audio output. Causal
20 ms analysis detects kick/bass, snare/body and hats, then sends incremental
hits to Folia without resetting its beat clock or fired-event prefix. The
native source claims the track before warm-up, preventing redundant htdemucs GPU
separation. It adds hit-flash and output-route timing diagnostics; Bluetooth
codec delay downstream of Android's sink remains a manual calibration.

TASK C — Arabic RTL and connected letters in all 17 styles
----------------------------------------------------------
Audited and patched the renderer layout/reveal paths instead of reversing the
lyric data. RTL word order and per-row positions are mirrored from the right;
word timings remain in source order, and active sweeps travel right-to-left.
DOM text uses direction-aware bidi layout, Canvas uses right alignment and
right-origin clipping, and glyph-based styles receive Arabic presentation
forms while retaining one grapheme/timing unit per source grapheme. Combining
marks, punctuation, digits, Lam-Alef sequences, embedded Latin runs, word
segments, alternate text and backing-vocal text are preserved.

The four styles that already had Folia-native RTL handling remain on that path:
Classic, Partita, Monet and Diorama. Fume, Pendolo and Still use RTL-aware
whole-run text layout/reveal. Cadenza, Cappella, Claddagh, Hanabi, Lumiere,
Machi, Nebbia, Sonnet, Tempera and Tilt receive per-style glyph/word RTL layout
or shaping. For Arabic only, Hanabi and Lumiere switch vertical glyph-column
variants to horizontal joined text flow; Latin keeps its original vertical
variants. Latin text is not shaped or reordered by the Arabic helper.

The patch is anchored and idempotent. apply.py fails loudly if a required source
anchor is missing and does not replace whole Folia files. The Folia changes are
applied to the Folia sibling directory expected by the supplied build workflow.

VERIFICATION LIMITS
-------------------
See TASK-C-ENGINE-REPORT.md, TASK-B-ENGINE-REPORT.md and TEST-ON-PHONE.md.
Arabic runtime tests, changed-file TypeScript/TSX syntax transpilation,
apply.py compilation, clean-source application and repeated-application hash
checks passed. No full Folia npm typecheck/Vite build, Android Release build,
headless visual screenshots, or on-device font/clipping/RTL sweep verification
was possible in this environment. Real Xiaomi 11T testing is still required.

BUILD
-----
Keep .github/workflows/build.yml unchanged. Keep the repository's existing
Halcyon-main.zip and folia-web-min.zip. Replace the old patch ZIP with this
complete Halcyon-Folia-Visualizer-patch.zip. Upload it directly from the phone;
do not unzip it on Android and do not keep duplicate old patch ZIPs.
