Halcyon Folia-style Lyric Visualizer patch
==========================================
Adds a full-screen lyric visualizer page to Halcyon. Open it with the small button on the
right edge of the lyrics page.

Contents
  apply.py   anchored edits to PlayerScreen.kt and MusicRepositoryUtils.kt (safe to re-run)
  files/     new Kotlin sources: ui/vis/* (visualizer) and data/parser/KrcDecoder.kt

Use with the import-and-build workflow (build.yml): upload this zip and the Halcyon source zip
to the repository root and run the workflow. No unzipping needed.
