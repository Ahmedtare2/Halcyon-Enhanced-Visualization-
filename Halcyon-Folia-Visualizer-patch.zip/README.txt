HALCYON × FOLIA — COMPLETE PHONE PATCH

This is the single replacement patch for the original Halcyon source ZIP and
folia-web-min.zip. It contains Tasks A, B, C, D, Task E packaging/build fixes,
and the 22 November post-build runtime fixes. It is not a delta over another
patch. Do not stack earlier A/B/C/D ZIPs with it.

LATEST FIXES
- Nebbia rainy-glass runtime: imports the missing isIconChar named export that
  caused `ReferenceError: isIconChar is not defined`.
- Sonnet and Tempera Arabic: one shaped word node is drawn at word onset;
  English/Latin retains the previous per-grapheme animation path.
- Beat response: independent kick/snare/hat detection and debounce; kicks drive
  strong pulses/downbeats, snares lighter accents, hats remain per-style hits;
  selected analysed beat-grid timing is respected.

UPLOAD
Upload only Halcyon-Folia-Visualizer-patch.zip to the repository root. Keep the
Halcyon and folia-web-min source ZIPs. Keep the already-working
.github/workflows/build.yml unchanged. Follow UPLOAD-STEPS.txt.

The patch is source-anchored and idempotent. See the task reports and
POST-BUILD-RUNTIME-FIXES.md for implementation, tests and limits. A new GitHub
Release build and physical phone tests are still required for these latest
changes.
