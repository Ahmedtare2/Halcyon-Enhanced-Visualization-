# Task C — Arabic RTL, shaping and sweep report

## Approach

The previous integration applied broad text transformations (`logical-reversed`
and `shaped-visual`) before handing lyrics to renderers that still measured and
revealed them in left-to-right order. That mismatch could reverse the data while
the reveal mask, wrapped rows, or glyph positions continued moving left-to-right.

The new patch keeps lyric and word arrays in logical source order. Each style
handles writing direction in its own layout/reveal code:

- RTL row and word-block positions are anchored from the right edge.
- Timed words and graphemes remain in ascending source/timeline order.
- Per-word internal glyph placement is mirrored only for Arabic words. Embedded
  Latin runs remain internally left-to-right.
- Whole-run DOM and Canvas renderers use native text shaping and direction-aware
  alignment/masks rather than manually reversing strings.
- Glyph-at-a-time renderers receive contextual Arabic presentation forms while
  retaining combining marks and grapheme boundaries. Lam and Alef remain two
  timed graphemes (rather than being collapsed into one ligature), so their
  connected forms do not destroy word/letter timing.

The helper preserves source punctuation, spaces, digits, Latin sequences,
translation, romanization, word timestamps, word segments, alternate text and
background-vocal data. Arabic-only shaping is selected per mode; native RTL
styles continue to let the browser/renderer shape original Unicode text.

## Per-style implementation

| Folia style | Renderer path | Arabic handling in this patch |
|---|---|---|
| Classic | Native RTL-aware text layout | Existing `resolveLyricTextDirection`/DOM direction path retained. |
| Partita | Native RTL-aware word/chunk placement | Existing right-origin placement and RTL chunk direction retained. |
| Monet | Native RTL-aware rail/word sequence | Existing direction-aware rail layout retained. |
| Diorama | 3D scene line/glyph placement | Existing right-origin prefix positions and camera follow retained. |
| Fume | Canvas 2D whole-line/segment rendering | Mirrors segment boxes per row, aligns Canvas text to the right and clips the active reveal from the right; LTR branch remains unchanged. |
| Pendolo | DOM text with CSS mask sweep | Applies `dir`/bidi for RTL and reverses the mask gradient's reveal edge; timed grapheme offsets stay in source order. |
| Still | DOM lyric and translation lines | Adds first-strong `dir="auto"` to lyric and translation blocks; no string transformation. |
| Cadenza | Wrapped word/glyph placement and glow overlay | Mirrors wrapped word-fragment positions within each row; RTL overlay uses right alignment and Arabic-safe line height, then restores original LTR styles. |
| Cappella | Timed grapheme reveal and speech bubble | Uses grapheme clusters for reveal (rather than code points) and lets text/bubble use first-strong direction; no Latin metric changes. |
| Claddagh | Per-grapheme ring/orbit placement | Reverses orbit angle for RTL lines while retaining ascending timing order; Arabic forms are shaped before glyph placement. |
| Hanabi | Sprite/glyph word layout | Mirrors word blocks and Arabic internal glyph positions while preserving time order; Arabic vertical/vertical-split options fall back to joined horizontal flow. Latin vertical variants are unchanged. |
| Lumiere | Wrapped word/glyph layout in an animated window | Mirrors word blocks and glyph positions on each row; RTL geometry uses horizontal flow even when the selected typography is vertical, preserving Arabic joining. Latin orientation is unchanged. |
| Machi | Board/glyph layout and shader reveal | Retains the existing right-origin board placement and mirrored `uRtl` sweep; receives shaped logical Arabic graphemes. |
| Nebbia | Per-word glyph layout in scene space | Mirrors each word block about the scene centre and mirrors only Arabic glyph positions inside each word; word/timing order remains unchanged. |
| Sonnet | Wrapped text-box segments and per-glyph reveal | Mirrors segment centres within each line and advances RTL glyph placement from the right edge. |
| Tempera | Row/word/glyph layout | Places logical words from the right, mirrors Arabic glyph positions only, and keeps Latin internals LTR. |
| Tilt | DOM normal/italic motion text | Uses first-strong direction and plaintext bidi on normal and italic text wrappers; no data reversal. |

All 17 modes are covered. Classic, Partita, Monet and Diorama were already
RTL-aware and were kept as references rather than reworked unnecessarily.

## Verification performed

- `node --experimental-strip-types /mnt/data/taskC/test-arabic.mjs` — PASS.
  Eight Arabic/Egyptian and mixed-script fixtures covered dialect sentences,
  Lam-Alef sequences, ta marbuta, hamza forms, punctuation, digits, embedded
  Latin, diacritics and long mixed lines. Tests asserted equal grapheme counts,
  preserved non-Arabic content, preserved timing values, unchanged English-only
  text, unchanged translation/romanization, and unchanged native-mode line data.
- `node /mnt/data/taskC/check_ts.cjs` — PASS: 30 changed TypeScript/TSX files
  transpiled with zero syntax diagnostics. This is a syntax check, not a full
  project typecheck.
- `python3 -m py_compile .../apply.py` — PASS.
- Clean source test — Task A+B+C applied to unmodified Halcyon and Folia source
  trees. Reapplying the patch produced the same complete source-tree hash:
  `6b21815b387660ce332d58514eda0c75cc9bb5199df47c850b19ec293cb8dbaf`.
- `tools/check_licenses.py` and build workflow parsing had passed in the existing
  Task A+B patch checks; Task C adds no Kotlin files, licence headers or Gradle
  dependencies.

## Visual test status and residual risks

A responsive RTL/Latin fixture was prepared for 393×873 and 873×393 viewports
at DPR 1.5. Headless Chromium repeatedly stalled in this environment, so no
reliable screenshots were produced. The Folia npm dependencies are not present
and network installation is unavailable here, so the full Vite build/typecheck
was not run. No Android SDK/adb or Xiaomi device is attached, so actual font
metrics, transitions, clipping and line-wrap behavior are not verified on the
phone.

Two deliberate Arabic-only layout adaptations are worth noting: Hanabi and
Lumiere cannot preserve connected cursive letterforms in their vertical
per-character columns, so those two Arabic layouts use horizontal joined text
flow while retaining the style's colours, animation and visual treatment. Their
Latin vertical layouts stay as before.

Arabic shaping covers the core Arabic alphabet (U+0621–U+064A) and retains
combining marks. The Lam-Alef sequence is kept as two connected shaped graphemes
so word/letter timing is not collapsed. Persian/Urdu extended letters and rare
presentation forms are outside this Task C test set. Android font fallback and
very dense stacked diacritics still need on-device visual inspection.

## Phone acceptance checks

Use `TEST-ON-PHONE.md`: swipe all 17 styles in portrait and landscape, test
Arabic words and wrapped multi-row lines, confirm the highlight moves right to
left, and verify embedded English/digits remain left-to-right. Test both Hanabi
and Lumiere in their vertical settings, plus diacritics and translation/backing
vocals. Send a Folia diagnostics screenshot and the GitHub build-log ZIP if a
style clips or reveals in the wrong direction.
