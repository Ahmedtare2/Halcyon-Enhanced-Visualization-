# Phone test checklist — complete Tasks A–D

A successful GitHub Release build is required before these physical-device
checks. Source and synthetic tests do not replace real listening, visual or
battery testing.

1. **Install and open.** Install the Release APK. Open a local song, go to the
   lyrics page and tap the Folia visualizer button. Confirm the page opens; then
   open Tune and the Folia settings.

2. **Swipe through all styles.** Visit Classic, Partita, Monet, Diorama, Fume,
   Pendolo, Still, Cadenza, Cappella, Claddagh, Hanabi, Lumiere, Machi, Nebbia,
   Sonnet, Tempera and Tilt. Check that styles load, respond to touch and keep
   their normal look and motion.

3. **Open style settings.** Change the quality/tuning controls on Hanabi, Machi
   and Nebbia. Check the detail, glow, shadows, reflections, fog and rain. Look
   for black frames, clipping, stutter or lost controls.

4. **Switch backgrounds.** Try Latent, Nomand, Sora, Monet, Fluid and URL
   backgrounds. In Battery quality + Latent, confirm the native background is
   visible. In Auto/Balanced/High, Latent should use its original web path.
   Check blur and softness on Monet, Nomand and Sora.

5. **Play an Arabic song.** Use a real Egyptian/Arabic track with long lines and
   word-timed lyrics. Confirm the first word starts at the right, line/row order
   reads RTL, and the active word sweep moves right-to-left without jumping.

6. **Check Arabic shaping and mixed text.** Test `إزيك يا صاحبي؟ أنا تمام،
   الحمد لله.` and `مش هتصدق إن ده Apple Music 2026؟`, plus `لا لآ لأ لإ` and
   `بِسْمِ اللّٰهِ الرَّحْمَٰنِ الرَّحِيمِ`. Check joined letters, marks, digits,
   punctuation, word wrapping and no top/bottom/edge clipping. The Latin run
   should remain LTR. Also inspect translations and backing vocals.

7. **Check Latin is unchanged.** Play an English song and compare its font,
   alignment, wrapping, colors, effects, vertical modes and sweep. Latin should
   retain its previous look and direction.

8. **Check beat reactions.** Enable the hit flash and play a song with clear
   kick, snare and hi-hat hits. Check timing against the audible hits. Seek,
   pause/resume, skip and test gapless crossfade. Repeat with bass-heavy Arabic
   pop; note whether the output is speaker, wired/USB or Bluetooth.

9. **Check battery and suspension.** Test Android Battery Saver and Folia's
   Battery quality for 5–10 minutes with Hanabi, Machi, Nebbia and Latent. Note
   heat, frame pacing and battery drain under the same brightness/song/quality.
   Hide the visualizer and background the app; heavy rendering should suspend.

10. **Check landscape and report.** Rotate to landscape and repeat the Arabic
    lyric and style checks. If anything fails, send phone model/Android version,
    style/background/quality/orientation, track and exact symptom, screenshots,
    and Tune → Folia diagnostics. For a build failure, send the GitHub
    Halcyon-build-logs artifact ZIP.


## Build-fix retest

After uploading the corrected cumulative patch ZIP, run the patched Release build
again with `use_patches=true`. Confirm the `:app:compileReleaseKotlin` task passes
before installing. Then open the player, open the visualizer, pause and resume
playback repeatedly, and confirm the frame loop follows play/pause without
needing to close/reopen the visualizer.
