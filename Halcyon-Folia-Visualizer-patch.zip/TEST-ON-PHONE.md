# Phone test checklist — replacement runtime/visualizer patch

A new patched Release APK from GitHub Actions is required. The checks below
must be performed on the phone; source/synthetic tests are not substitutes.

1. **Install and open.** Install the newly built patched Release APK. Open a
   local song, go to lyrics, open the Folia visualizer, and confirm Tune opens.

2. **Nebbia / rainy glass.** Select Nebbia, then try both Arabic and Latin
   lyrics. Confirm the rainy-glass/night background and lyric overlay render.
   The toast `ReferenceError: isIconChar is not defined` must not appear. Check
   for black frames, missing glyphs or a stuck loading state.

3. **Sonnet Arabic.** Use an Arabic TTML track with word-level timings. Confirm
   each Arabic word appears as one complete joined word at its word onset,
   rather than revealing one letter at a time. Confirm words still advance in
   the correct RTL order and diacritics remain attached.

4. **Tempera Arabic.** Repeat the same test. Check that a whole word appears
   together, without separate letter flashes, clipping or extra pauses.

5. **Latin regression.** In Sonnet and Tempera, play an English song. Confirm
   Latin keeps its previous per-grapheme/letter animation, font, layout, motion,
   colors and timing. Other styles should retain their existing appearance.

6. **Mixed script.** Test `مش هتصدق إن ده Apple Music 2026؟` and
   `إزيك يا صاحبي؟ أنا تمام، الحمد لله.`. Verify Arabic joins and reads RTL,
   embedded English/numbers remain LTR, and punctuation stays attached.

7. **Kick/snare/hat reaction.** Enable beat effects and the hit flash. Play a
   track with clear kick, snare and hi-hat. Kick should create the strongest
   low-frequency pulse; snare should add a lighter accent; hats should animate
   only styles that use detailed drum-hit events and should not make the whole
   screen flicker continuously. Compare the flash to audible transients.

8. **Beat-source selection.** Test live-drums source and analysed beat-grid
   source separately. The former should follow detected kick/snare; the latter
   should keep its analysed timing. Pause/resume, seek, skip and gapless
   crossfade; ensure effects do not reset or replay old hits.

9. **Output route.** Repeat on the phone speaker and wired/USB output. Test
   Bluetooth separately and note the device/codec; Android cannot expose every
   downstream Bluetooth buffer, so Bluetooth timing may differ.

10. **Other styles and backgrounds.** Visit all 17 styles and all six
    backgrounds. In particular check Hanabi, Machi, Nebbia and Task A's
    Battery/Latent background. Check portrait and landscape.

11. **Heat/battery.** Play continuously for 10 minutes under a consistent
    brightness and quality setting. Note heat, stutter, missed words, battery
    drain and whether the visualizer suspends when hidden.

If anything fails, send: phone model/Android version, style/background,
orientation/quality, song name or a short non-copyrighted test clip, screenshot
or screen recording, and Tune → Folia diagnostics. For a build failure, send
the GitHub Halcyon-build-logs artifact ZIP.
