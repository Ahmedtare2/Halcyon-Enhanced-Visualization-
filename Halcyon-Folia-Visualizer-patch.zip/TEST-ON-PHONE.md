# On-phone verification checklist (Tasks A + B + C)

A GitHub Release APK build and physical-device checks are still required. The
source/synthetic tests are not a substitute for visual and listening checks.

1. **Install and open.** Install the Release APK from GitHub Actions. Open a
   local song, open the Apple Music-style lyrics page, tap the Folia button, and
   open Tune.

2. **Swipe all 17 styles.** In portrait and landscape, visit Classic, Partita,
   Monet, Diorama, Fume, Pendolo, Still, Cadenza, Cappella, Claddagh, Hanabi,
   Lumiere, Machi, Nebbia, Sonnet, Tempera and Tilt.

3. **Check Arabic reading order and sweep.** Use Egyptian lyrics such as
   `إزيك يا صاحبي؟ أنا تمام، الحمد لله.` and a long line that wraps to multiple
   rows. The first word should start at the right, rows should read right-to-left,
   and the active highlight should move from right to left without reversing
   word timing.

4. **Check shaping and clipping.** Test `لا لآ لأ لإ` (Lam-Alef/hamza), ta
   marbuta, hamza forms, `، ؟ !`, digits, and a fully or partially vocalized line
   such as `بِسْمِ اللّٰهِ الرَّحْمَٰنِ الرَّحِيمِ`. Confirm joining, visible marks,
   no cut-off at the edges/top/bottom, and correct wrapping.

5. **Check mixed language and secondary text.** Test a line like
   `مش هتصدق إن ده Apple Music 2026؟`, plus translation, romanization, alternate
   text and backing vocals. The Arabic run should be RTL; `Apple Music 2026` and
   other Latin/digit runs should remain LTR and visually unchanged.

6. **Check special layouts.** In Hanabi and Lumiere, switch to vertical and
   vertical-split settings with Arabic and then English. Arabic should use joined
   horizontal flow; English should keep its original vertical look. Also inspect
   Cappella bubble wrapping and Cadenza diacritics.

7. **Check beat reactions.** Play a track with clear kick, snare and hi-hat hits.
   Enable the hit flash; verify it aligns with the audible hits, and repeat with
   an Arabic-pop/bass-heavy song, seek, pause/resume, skip and gapless crossfade.

8. **Check battery and background.** Select Battery quality + Latent; confirm the
   native mesh appears, then switch to Auto/Balanced/High and confirm the web mesh
   returns. Hide the page and background the app to check the renderer stops.

9. **Check Latin regression.** Compare English lyrics in all styles before/after
   where possible. Ensure alignment, font size, color, wrapping, movement and
   effects retain their former appearance. Pay special attention to vertical
   Hanabi/Lumiere Latin lines.

10. **Send results.** If anything fails, note phone/Android version, style,
    orientation, exact lyric line and settings. Send a screenshot and Tune →
    Folia diagnostics; if the APK fails to build, send the GitHub Actions log ZIP.
