# GitHub Release compile fix — `playingNow`

The uploaded GitHub Actions logs identify the patched build failure precisely:

- Task: `:app:compileReleaseKotlin`
- File: `VisPage.kt`
- Errors: unresolved `playingNow` at generated lines 421, 432, 434 and 435.

`VisPage.kt` already receives `isPlaying: Boolean` and declares
`val latestPlaying by rememberUpdatedState(isPlaying)`. Its frame loop is inside
`LaunchedEffect(Unit)`, so it must read `latestPlaying`; directly reading the
parameter would capture the initial play/pause value for the life of that effect.

## Fix

All four stale references are replaced with `latestPlaying`. The merged patch's
`apply.py` also has an idempotent guard that repairs exactly those four references
from the previous cumulative ZIP, then verifies that a live playback-state value
exists. No build workflow or visualization appearance change is required.

## Important CI result

The patched build failed only on the four `playingNow` references in the supplied
log. The workflow's plain, unpatched Halcyon fallback then completed successfully
(`BUILD SUCCESSFUL` in 6m 23s) and uploaded:

`Halcyon-PLAIN-fallback-release-arm64-v8a-7`

That fallback APK is the original Halcyon build without Tasks A–D. It is useful only
as a temporary install/test of the original app, not as the patched Folia build.

The corrected cumulative ZIP still requires a new GitHub Actions Release run to
verify the patched APK.


## Local re-application checks

- Patch ZIP CRC: passed.
- Python compilation of `apply.py`: passed.
- All 24 Kotlin patch files: no `playingNow` identifier remains.
- Clean-source patch import: passed.
- Second application: passed; identical patched source-tree hash
  `e8895976d67f55c05c978170be807b6c8831540faa3ca03f1c8e78ec68239920`.
- Halcyon licence/provenance checker: passed.
- No local Gradle or Kotlin compiler is installed, so no local Android compile
  is claimed. The corrected patch must be compiled on the next GitHub Actions run.
