# TASK A — Folia renderer and Android battery/GPU report

## 1. What the older Android build does

The supplied Folia Android reference (`Folia-Music-player--main-compressed.zip`, v0.7.21) puts a native `GLSurfaceView` behind a transparent WebView. `FoliaBackgroundSurfaceView` selects OpenGL ES 2, requests an RGBA8888 EGL surface, fixes the internal buffer at 180 × 400 pixels (72,000 pixels), and lets Android's surface compositor scale that result to the view. It uses `RENDERMODE_WHEN_DIRTY`, requests frames from `Choreographer` with a vsync divider, and stops callbacks / pauses the GL thread when the visualizer is hidden or the host activity is paused. Palette and bass/mid/high energy arrive over the Capacitor bridge. On the web side, the mesh is removed when the native background is available, while the rest of the player stays transparent over it.

This is the architecture adopted here. The new Halcyon `VisNativeBackdrop.kt` and shader are independently written; no legacy AGPL source was copied into Halcyon. No CPU Canvas background renderer or new Gradle dependency was added.

## 2. Folia's 17 lyric visualizers

Cost classes are source-based estimates, not measurements. Actual load varies with resolution/DPR, lyric length, tuning, particle count, device driver and how many filters are active.

| Style | Main renderer | Main GPU / battery costs | Relative cost |
|---|---|---|---|
| **Cadenza** | React DOM + Framer Motion | Multiple animated text/glyph elements, per-word transforms and glow/shadow styling; layout and paint can dominate with long lyrics. | Medium |
| **Cappella** | DOM + Framer Motion | Animated message/bubble rows, avatars or emoji imagery, transitions and composited layers. | Medium |
| **Claddagh** | DOM/CSS + Framer Motion | Ring/ornament layers, glows, shadows and filter-backed highlights. | Medium–high |
| **Classic** | DOM/CSS + Framer Motion | Layered word spans, animated active-word treatment, text shadows and glow. | Medium |
| **Diorama** | three.js through React Three Fiber | 3D scene/camera, geometry and particles; lyric text rasterized to Canvas textures and uploaded to the GPU. | High |
| **Fume** | Canvas 2D | Full-scene canvas drawing, smoke/particles, text rasterization and filter/shadow effects; large canvases also cost fill rate. | High |
| **Hanabi** | PixiJS / WebGL | Particle/sprite rendering, texture uploads and shader-driven animation. | Medium–high |
| **Lumière** | PixiJS / WebGL | Layered lights, particles and sprites plus bloom/blur/filter passes. | High |
| **Machi** | three.js / WebGL | 3D city/environment scene, textures and CanvasTexture lyric surfaces, plus moving traffic/weather/environment effects. | High |
| **Monet** | DOM/Framer Motion + Canvas2D worker pipeline | Worker-generated/processed image background, image layers, blur/drift compositing and animated text chrome. | Medium–high |
| **Nebbia** | Custom WebGL2 shader canvas | Full-screen water/glass/condensation/aquarium/weather/particle effects; shader work scales with render resolution. | High |
| **Partita** | DOM/CSS + Framer Motion | Word-span composition, animated transitions, glow/shadow and active-line treatments. | Medium |
| **Pendolo** | Canvas 2D + DOM/Framer Motion | Clock/gear drawing and sweep effects on Canvas, combined with animated lyric layers. | Medium–high |
| **Sonnet** | PixiJS / WebGL | Text/texture/sprite scene, particles and filter/post-processing passes. | High |
| **Still** | DOM/CSS | Simple text composition with little continuous animation and few effects. | Low |
| **Tempera** | PixiJS / WebGL | Layered image/texture scene, `BlurFilter` and custom difference/filter effects. | High |
| **Tilt** | DOM/CSS + Framer Motion | Pre-layout line composition and CSS transforms; fewer heavy post-processing operations than the 3D/Pixi styles. | Low–medium |

## 3. Folia's six backgrounds

| Background | Renderer | Main GPU / battery costs | Native replacement decision |
|---|---|---|---|
| **Common** | CSS colour fills, gradients and geometric decorations | Mostly compositing and CSS effects; generally light. | Keep in WebView; it is not the expensive pure mesh being targeted. |
| **Latent** | Paper `MeshGradient` + Paper 4×4 `Dithering` WebGL layers | Two large animated shader layers; the mesh and dithering are separate full-screen GPU surfaces. | Replace **only the mesh** with Halcyon's native low-resolution surface, and only in Battery quality when the display mode includes mesh. Keep dithering and overlays in WebView. |
| **Monet** | Worker/Canvas2D image processing + image/blur layers and compositor animation | Image processing, large image layers, blur and motion; source image size affects memory and fill. | Keep in WebView. |
| **Nomand** | Paper image shaders (fluted glass, halftone, image dithering, lens distortion, paper texture) | Full-screen image-backed WebGL shader and overscan; shader complexity and image texture bandwidth. | Keep in WebView. |
| **Sora** | TWGL/WebGL starfield | Full-screen shader/point rendering with about 150 GL points; lighter than multi-pass image effects, but still a live WebGL canvas. | Keep in WebView. |
| **URL** | Embedded page/content | Cost is content-dependent and unpredictable; arbitrary page layout/animation can be expensive. | Keep in WebView. The Android host continues to block external hosts/network access. |

## 4. Existing quality controls identified

The implementation reuses existing controls rather than introducing a second quality system:

- `lyricRenderQuality`: global lyric render scale (supported scale steps include 0.5, 0.75, 1, 1.5 and 2) and antialias mode (`auto`, `on`, `off`). Individual style tuning overrides remain in place.
- `glowBlurQuantize`: bounds/quantizes dynamic glow blur radii instead of allowing many arbitrary blur values.
- `disableVisualizerVignette`: removes the visualizer vignette. `disableVisualizerGeometricBackground` and `backgroundOpacity` control the geometric backdrop and its opacity.
- Style/background-specific tuning objects are registered through Folia's tuning registry. Particle counts, scene complexity, blur, speed and other options are exposed by each style/background where supported.
- `smartBeat`: global and per-effect beat toggles/strengths; the app's frame governor can disable beat effects if the page repeatedly misses its frame budget.
- Halcyon's existing Folia DPR/FPS and device governor: Battery DPR 1 and 30 FPS by default; power saver, low battery and thermal caps further reduce FPS. While paused, Folia is capped at 20 FPS, then 10 FPS after 10 seconds. The host requests a matching display refresh rate and pauses/destroys the WebView with the lifecycle/page. Audio bands are forwarded at about 15 Hz, rather than on every animation frame.

## 5. Halcyon implementation

### Native layer and bridge

- New `VisNativeBackdrop.kt`: original GLES2 mesh renderer in a 180 × 400 RGBA surface behind the transparent Folia WebView. The fragment shader is GPU-side; there is no per-pixel CPU rendering.
- The Android bridge accepts the current six blended Latent mesh colours, Latent mesh speed/audio speed/distortion/swirl/enhanced-beat-response values, and live bass/mid/high energy plus playback state.
- `Choreographer` drives render requests at the existing Folia FPS cap, using a vsync divider derived from the display refresh rate. `RENDERMODE_WHEN_DIRTY` avoids an uncapped GL loop. When playback stops, the final mesh frame remains visible and the continuous native frame callbacks stop; a palette transition is allowed to finish. When hidden, unfocused, paused by the activity or closed, callbacks and the GL thread stop.
- The WebView and page root are transparent. If native setup or shader linking fails, `nativeBackdropAvailable` remains false and Folia keeps its original Paper mesh.

### Activation and appearance trade-off

The new renderer activates only if all conditions are true: the existing **Battery** quality preset is selected, the background is **Latent**, and Latent's display mode is `mesh` or `both`. In `dithering` mode it is not requested. Auto, High and Balanced keep the original Paper `MeshGradient`; the 17 foreground visualizers and the other five backgrounds are not modified by the native mesh patch.

Battery mode also temporarily lowers the existing Folia `lyricRenderQuality.scale` to at most 0.75 (it never raises a smaller user value). Antialias, explicit per-style overrides, vignette, glow quantization and beat-effect settings are left alone. The override is applied directly to the in-memory Zustand store, not through its local-storage save handler, and restored when Battery mode ends. This may make raster/canvas text or effects slightly softer; Auto/High/Balanced retain the original scale. The new mesh uses the same palette and key controls, but its shader is an approximation of Paper's mesh, not a proven pixel-identical port. This visual difference is confined to the Battery preset.

### Expected resource effect (estimate only)

The native render buffer is 180 × 400 = 72,000 pixels. Folia's Latent mesh layer has a 1,280 × 720 maximum pixel budget (921,600 pixels); at that cap the native shader shades about 12.8 times fewer pixels for the mesh layer before compositor upscaling. Battery mode also halves the normal 60 FPS ceiling to 30 FPS and caps WebView DPR at 1. The Latent Dithering layer remains active in WebView, so this is a reduction in one of the two Latent shader layers, not removal of all background GPU work. Actual GPU power savings are not measured in the sandbox.

## 6. How to measure on the phone

Use the same track, style, background, brightness and screen refresh mode for each run. Compare Auto/Balanced against Battery for at least five minutes after the phone has cooled:

1. Record FPS/frame-time and jank with Android Studio **not required**: the GitHub build is installed normally; use a device performance overlay or `adb shell dumpsys gfxinfo <package> framestats` if ADB is available.
2. For deeper tracing, record a Perfetto system trace with `sched`, `freq`, `idle`, `gfx`, `view`, `surfaceflinger` and GPU counters if the device exposes them. Compare GPU busy time, missed frames, CPU wakeups and surface frame rate.
3. Record battery percentage and temperature at the start/end of equal-duration runs. Battery percentage is coarse; repeat runs and keep brightness/network/background activity constant.
4. Inspect app diagnostics for native shader/link errors and compare a screenshot of Latent in Auto/Balanced vs Battery.

No performance figures are claimed here: this sandbox has no access to the user's phone, Perfetto trace, GPU counters or battery telemetry.

## 7. Verification in this session

- Read the handoff file through PART 1, TASK A and PART 3. All six named input classes were found in the supplied handoff archive. The old Android reference archive has the suffix `-compressed` in its actual filename.
- Extracted and inspected the old Android `FoliaBackgroundSurfaceView`, Capacitor bridge, Android overrides and page/backdrop mount code.
- Applied the complete patch to clean Halcyon and `folia-web-min` sources, then ran `apply.py` a second time. SHA-256 manifests of all 1,895 Halcyon files and 2,924 Folia files were identical before vs after the second application.
- `tools/check_licenses.py`: passed (`Application headers and pinned Miuix adaptation provenance passed`).
- `python -m py_compile apply.py`: passed.
- YAML parser: supplied `build.yml` parsed successfully; this task does not change it.
- TypeScript transpile syntax check: passed for 9 relevant `.ts`/`.tsx` files (0 syntax diagnostics).
- A local Kotlin compiler parse attempt found no `expecting` / syntax diagnostics, but type resolution failed because this environment has no Android SDK or `android.jar`. This is not an Android compile.
- Release APK compilation, device runtime, visual comparison, GPU use, battery drain and thermal behavior remain **unverified** until the GitHub Actions build and phone test.
