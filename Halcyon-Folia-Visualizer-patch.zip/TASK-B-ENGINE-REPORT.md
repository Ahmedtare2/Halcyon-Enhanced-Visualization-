# TASK B — real-time beat reaction engine report

## What changed

Halcyon now analyses the PCM that ExoPlayer has decoded and is about to hand to
its selected Media3 output sink. The new `PlaybackPcmTeeAudioSink` is a transparent
`ForwardingAudioSink` wrapper. It reads a read-only duplicate of the incoming PCM
buffer and its `presentationTimeUs`, then delegates the untouched original buffer
to the existing sink. It preserves the normal AudioTrack/AAudio/OpenSL ES path,
EQ, output processors, decoder selection, Oboe backend and crossfade gain chain.
The analysis happens before the delegate call because the custom Oboe sink may
block while writing to the device; waiting until after that write would delay the
visual event hand-off.

The primary and secondary crossfade ExoPlayers each have their own tap and state.
The detector therefore follows the outgoing and incoming songs independently
through gapless crossfade promotion; the visualizer consumes only the key matching
the currently displayed song. The PCM hand-off keeps at most eight recent track states
(current song, crossfade partner and a small recent-track cushion), bounding hit and
level history rather than retaining a state object for every song played in a session.

## Detection and timing

The live detector is causal and processes completed 20 ms frames at 50 fps. It
uses three biquad bands: 30–150 Hz for kick/bass, 150–4000 Hz for snare/body and
6–12 kHz for hats. Each band has a short rolling baseline, a q99 rise reference,
and an RMS floor. The strongest band classifies each event; a 90 ms strongest-hit
merge matches Folia's existing hit-spacing behaviour. No future-frame maximum or
symmetric local-peak confirmation is required, so the detector does not add the
old roughly 100 ms confirmation wait.

Each event is stamped at the centre of its completed 20 ms frame. The test fixtures
therefore show a consistent +10 ms centre-of-frame offset from an impulse exactly
on a frame boundary. The WebView scheduling lead is set to one display frame plus
3 ms instead of subtracting the previous fixed 40 ms. The player-position clock
and the sink presentation timestamps stay in the same track timebase. A route
calibration offset remains available to tune residual output/display timing.

The output-queue diagnostic estimates the sink's queued lead from accepted PCM
and the sink's current position, and separately reports the configured output
buffer size when available. It is not a measurement of Bluetooth codec/DSP delay
that occurs after the Android sink.

## Full timing-chain audit (old path versus live PCM path)

### Previous cached/offline path

- Halcyon's predictive `BeatAnalyzer` decodes a local file with `MediaExtractor` +
  `MediaCodec` on a background dispatcher. Its cache key is
  `path|size|modified|v3`; JSON version 3 stores track-relative milliseconds. A
  cache hit avoids decoding again, but the cached timestamps do not carry a live
  output-device presentation timestamp.
- `FluxExtractor` uses a 2048-sample Hann FFT every 512 samples. Its hop is
  11.61 ms at 44.1 kHz or 23.22 ms at 22.05 kHz. The stored frame coordinate adds
  `0.75 * 2048 / sampleRate`: 34.83 ms at 44.1 kHz or 69.66 ms at 22.05 kHz.
  This is the analyser's peak-location convention relative to the window start,
  not a measured speaker delay. The offline peak picker also needs two later hop
  frames to confirm its +/-2-frame local maximum (about 23.22 / 46.44 ms). These
  are analysis-coordinate/look-ahead terms, not extra audio output latency.
- Folia's previous live drum-stem picker is also intentionally non-causal: it
  uses `PEAK_AFTER=2`, `PEAK_HALF=3`, 50 fps and a 90 ms minimum gap. Its live
  head leaves a 10-frame tail (200 ms) unpicked and refreshes about once a
  second after a 10-second minimum head. This works for an asynchronously
  separated stem, but is too delayed for the new live player-PCM source.
- The previous `foliaBeatsJson` shift was
  `userTimingOffset - lyricOffset - 40 ms`. The constant did not follow the
  frame rate: at 60 fps one frame is 16.67 ms (40 ms over-advances by about
  23.33 ms); at 30 fps one frame is 33.33 ms (about 6.67 ms over-advance);
  at 15 fps one frame is 66.67 ms (about 26.67 ms under-compensation).

### Playback clock and Folia render step

- The Android host samples Media3's player position every 120 ms. It sends an
  epoch-millisecond anchor when drift exceeds 180 ms, playback state changes,
  or two seconds have elapsed. `HalcyonHost.setClock` stores the anchor and
  extrapolates between anchors; the 120 ms poll interval is not itself a fixed
  120 ms visual delay. The player position and sink PCM timestamps are both
  track-relative.
- Folia's `tickBeatFx` is stepped from its existing visualizer animation-frame
  loop. With an HTML media element it subtracts WebAudio `outputLatency +
  baseLatency`; the Android bridge instead supplies the Media3-anchored host
  clock. Event crossing is therefore quantized to the next visualizer frame
  (about 16.7 ms at 60 fps, 33.3 ms at 30 fps, or 66.7 ms at 15 fps). Its
  `dt` is capped at 100 ms for envelope decay; that cap does not intentionally
  wait 100 ms before firing an event.
- The new shift is one configured display frame plus 3 ms of hand-off allowance,
  clamped to 8 ms minimum: approximately 19 ms at 60 fps, 36 ms at 30 fps and
  69 ms at 15 fps. It remains subject to the actual active frame rate and the
  user's per-output calibration.

### New live path and remaining unknowns

- Each decoded PCM block carries Media3 `presentationTimeUs`. The tap analyses a
  read-only duplicate before the sink delegate, so Oboe/AudioTrack write blocking
  cannot postpone detection and the original output buffer is untouched.
  Completed 20 ms frames are timestamped at their centre, so the synthetic
  fixture has a known +10 ms timestamp quantisation for impulses exactly on a
  frame boundary. The event is published to the UI poll loop (10 ms while
  playing), then Folia schedules it against its existing anchored clock.
- The PCM path uses the same track timebase as the output sink; it does not infer
  drum time from a low-rate Android `Visualizer` callback or from a separately
  decoded copy of the file. It avoids Folia's future-peak waiting and GPU stem
  separation on the native-fed track.
- The sink diagnostic estimates queued PCM lead from the submitted PTS and
  Media3 sink playback position and shows the configured buffer duration. It
  cannot see Bluetooth codec/radio/DSP buffering after Android's sink. The
  Tune flash plus the per-route `Timing` offset (Bluetooth, USB, wired, speaker)
  is therefore an end-to-end visual calibration aid, not an automatic Bluetooth
  latency measurement. No physical route latency has been measured in this
  environment.

### Expected processing cost

At 48 kHz stereo, three band-pass filters process about 288,000
channel-band sample steps per second (17.28 million per minute), followed by
50 lightweight 20 ms frame summaries per second and three q99 updates at 10 Hz.
The tap is enabled only while the visualizer is open and the relevant reaction
or audio-reactive feature is active; it adds no decoder, microphone capture or
GPU stem-separation job. This is an operation-count estimate, not a measured
CPU percentage or battery result; those require a release build on the target
phone.

## Avoiding duplicate GPU analysis

Folia's previous drum-hit loader could still start or rejoin htdemucs even after
an external hit list had been supplied. Task B adds an external-source key set and
makes `loadTrackDrumHits()` return without starting/rejoining the GPU stem task for
those keys. The Android bridge claims a stream key at reset time with an empty
hit list, before its 250 ms PCM warm-up, then updates it incrementally. If a stem
job was already active, its wanted-track signal is cleared so it stops at its next
segment. The native hit list then becomes the sole source for that track. Live
kick events replace only the future, not-yet-fired Folia beat events; the playback
clock, fired prefix and envelopes are not reset.

## Tests performed

All Kotlin tests below compiled and executed against the actual patched detector
and sink-wrapper source, with lightweight stub definitions for Android/Media3
interfaces. They are source-level harness tests, not a full Android build.

| Fixture | Expected | Detected | Timing result |
|---|---:|---:|---:|
| 48 kHz stereo synthetic sequence: 6 kicks, 6 snares, 6 hats | 18 | 18 | Median absolute error 10 ms; max 10 ms |
| 48 kHz stereo transient/click sequence | 12 | 12 | Median absolute error 10 ms; max 10 ms |
| 8 seconds low-level random noise (amplitude 0.00035) | 0 | 0 | No false hits |
| 8 seconds silence | 0 | 0 | No false hits |

The sink harness deliberately made its fake sink consume one PCM buffer in two
partial writes. It passed 384,000 stereo sample frames to the tap exactly once,
observed 18 hits, and confirmed that the original buffer's position/ownership
remained with the delegate. The wrapper did not re-analyse the same PCM buffer on
the second partial-write call.

Folia source was applied to a clean source copy twice. The second run left the
checked source hashes unchanged. The patched `hostApi.ts`, `drumHits.ts` and
`beatFxLive.ts` passed Node's TypeScript syntax check. Halcyon's application
header/licence provenance check passed. `apply.py` passed Python compilation.

## What is not verified

- No full Android/Gradle Release build: the environment has no Android SDK or `adb`.
- No physical phone test of audio latency, visual latency, crossfade timing, output
  route switching, heat or battery use.
- No real Arabic-pop or bass-heavy song was supplied. The available source archive
  has only a short demo tone, which is not sufficient to assess real-song kick/snare
  classification, doubled drums, bass guitar or percussion-heavy mixes.
- The 10 ms result is synthetic frame-quantization accuracy, not a claim of 10 ms
  end-to-end hardware latency. Bluetooth output can add downstream codec delay.

The patch is designed to avoid a fixed software beat delay and avoid redundant GPU
stem analysis. Listening tests on the target phone remain necessary before claiming
zero audible lag for a particular speaker/headphone route.
