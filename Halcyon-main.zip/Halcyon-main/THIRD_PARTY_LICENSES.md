# Third-Party Licenses

Halcyon main project is licensed under Apache-2.0. Third-party components keep their own licenses.

This document lists the main third-party projects, libraries, native components, APIs, and implementation references used by Halcyon.

| Project                     | Purpose                                                                                                                          | License    | Link                                               | Notes                                                                                                                              |
| :-------------------------- | :------------------------------------------------------------------------------------------------------------------------------- | :--------- | :------------------------------------------------- | :--------------------------------------------------------------------------------------------------------------------------------- |
| CatClawMusic.Plugins.Netease | NetEase protocol client, EAPI encryption, account/library/playlist/lyrics and playback integration | MIT | https://github.com/kankejiang/CatClawMusic.Plugins.Netease | Copyright (c) 2026 kankejiang. Kotlin adaptation of NeteaseEapi.cs and NetEaseOpenApiClient.cs at dbb4db84904cd339fbebaf5a43f6b87e5818d17d. Full notice bundled at app/src/main/assets/licenses/CatClawMusic-Netease-MIT.txt. No MAUI/.ccp runtime is bundled. |
| CatClawMusic | Host/plugin interface and browser-session login integration reference | MIT | https://github.com/kankejiang/CatClawMusic | Copyright (c) 2024–2026 kankejiang. Reference revision 9dc3e08d9699a69dd20a806d7c3edc8ab6b10da5. Full notice bundled at app/src/main/assets/licenses/CatClawMusic-MIT.txt. |
| Miuix                       | MIUI / HyperOS-style Compose UI components                                                                                       | Apache-2.0 | https://github.com/compose-miuix-ui/miuix          | UI / icons / blur / preference artifacts aligned at 0.9.4. |
| AndroidX / Jetpack Compose  | Android framework libraries, Compose UI/runtime, lifecycle, navigation, DataStore, DocumentFile, and related AndroidX components | Apache-2.0 | https://developer.android.com/jetpack/androidx     | Includes AndroidX libraries used by the app UI and platform integration                                                            |
| AndroidX Media3             | Playback, media session, ExoPlayer, and FFmpeg decoder integration                                                               | Apache-2.0 | https://github.com/androidx/media                  | `androidx.media3:*` aligned at 1.11.1; local FFmpeg Java/JNI adaptation keeps its APE and format-filter extensions. |
| Kotlin / Kotlinx Coroutines | Kotlin language runtime and coroutine support                                                                                    | Apache-2.0 | https://github.com/JetBrains/kotlin                | Kotlin 2.4.20 and kotlinx-coroutines Android 1.11.0; used by Android app code and asynchronous tasks. |
| Miuix Icons                 | MIUI / HyperOS-style icon set used through Miuix                                                                                 | Apache-2.0 | https://github.com/compose-miuix-ui/miuix          | Gradle artifact: `top.yukonga.miuix.kmp:miuix-icons-android`                                                                       |
| Coil                        | Compose image loading                                                                                                            | Apache-2.0 | https://github.com/coil-kt/coil                    | `io.coil-kt.coil3:coil-compose` and `coil-network-okhttp` 3.6.3. |
| OkHttp                      | HTTP client used for network access, WebDAV, and online resources                                                                | Apache-2.0 | https://github.com/lysine-dev/okhttp                   | Version 5.5.0; upstream moved to Lysine / Commonhaus while retaining Maven coordinate `com.squareup.okhttp3:okhttp`. |
| Lyricon                     | Lyric Provider API and status-bar lyric integration                                                                              | Apache-2.0 | https://github.com/proify/lyricon                  | Gradle artifact: `io.github.proify.lyricon:provider`                                                                               |
| LyricGetter-API             | API for passing raw lyric text to the Lyric Getter ecosystem                                                                     | LGPL-2.1   | https://github.com/xiaowine/Lyric-Getter-Api       | Gradle artifact: `com.github.HChenX:Lyric-Getter-Api`                                                                              |
| SuperLyricApi               | API for publishing lyric data to the SuperLyric ecosystem                                                                        | LGPL-2.1   | https://github.com/HChenX/SuperLyricApi            | `com.github.HChenX:SuperLyricApi:3.6`; real playback position / duration and forced line updates are adapted locally. |
| lyrico-audiotag / Lyrico    | Primary local audio tag reading / writing path and external tag-editor adaptation reference                                      | Apache-2.0 | https://github.com/Replica0110/Lyrico              | Local module; JNI fixes selectively synchronized with v1.6.0, commit `ad9c83f5e78561edf60cfae762556583f359a395`. Halcyon's FD resets and additional formats are retained. |
| TagLib                      | Underlying native tag read/write capability used by lyrico-audiotag                                                              | LGPL-2.1-or-later / MPL-1.1 | https://taglib.org/                                | Vendored 2.3.2, commit `deadc2990767dfbda0701e0ab35fdeea653db08f`; bundled through `liblyrico_taglib.so`. License texts remain in the local vendor directory. |
| utfcpp | UTF-8 conversion used by the native TagLib library | BSL-1.0 | https://github.com/nemtrif/utfcpp | Vendored 4.1.1, commit `819011bb01628fe1aa2f1da9f2c842a48fd5680b`; license retained at `lyrico-audiotag/src/main/cpp/taglib/3rdparty/utfcpp/LICENSE`. |
| FFmpeg                      | Software decoding for ALAC and other audio formats                                                                               | LGPL-2.1-or-later | https://ffmpeg.org                                 | Local decoder build is pinned to source 9.0.2; GPL, nonfree and version3 are disabled. Header, static archive and JNI versions must be updated together. Separate from FFmpegKit's converter build. |
| FFmpegKit                    | Local audio format conversion and extraction of independent streams from multi-audio-track media                                | LGPL-3.0   | https://github.com/arthenica/ffmpeg-kit            | Retired original artifact `com.arthenica:ffmpeg-kit-full:6.0-2.LTS` retained. Official FFmpegKitNext is source-only and requires an independent wrapper / native migration; it is not bundled. |
| quickjs-wrapper Android     | JavaScript runtime wrapper used for LX Music API sources                                                                         | Apache-2.0 | https://github.com/HarlonWang/quickjs-wrapper      | `wang.harlon.quickjs:wrapper-android:3.2.3`; LX and MusicFree compatibility runtimes use its public Java API. |
| LX Music Mobile             | LX Music API compatibility reference                                                                                             | Apache-2.0 | https://github.com/lyswhut/lx-music-mobile         | Protocol / preload and metadata-search reference synchronized with v1.9.1, commit `fb8480728d875fa5e0da25eebd3a26bb71723aae`; Halcyon's qs / binary-Base64 extensions remain. |
| ColorOS Live Lyrics Bridge | OPlus bridge payload interoperability reference | Apache-2.0 | https://github.com/Andrea-lyz/ColorOS-Live-Lyrics-Bridge | Payload adaptation targets v4.4.0, commit `44d5d347623e93a008bf188ae96c060ee4791e98`; independent raw and translation lanes, millisecond timing and word markers. Module / application binaries are not bundled. |
| MusicFree | Plugin protocol interoperability reference | AGPL-3.0 (upstream application) | https://github.com/maotoumao/MusicFree | Reference v0.6.2, commit `b3cb5e5829dc600af86731c582429f5eb99cad27`. Halcyon supplies its own protocol adapter; MusicFree application code / binaries and user plugins are not bundled. Imported plugins retain their own licenses. |
| Oboe | Native Android audio output / device routing | Apache-2.0 | https://github.com/google/oboe | `com.google.oboe:oboe:1.11.0` prefab; linked into Halcyon's native audio sink. |
| Ktor | Embedded HTTP server and JSON content negotiation | Apache-2.0 | https://github.com/ktorio/ktor | CIO / content negotiation / serialization artifacts aligned at 3.6.0. |
| kotlinx-serialization | Kotlin JSON serialization | Apache-2.0 | https://github.com/Kotlin/kotlinx.serialization | `kotlinx-serialization-json:1.11.0`. |
| MCP Kotlin SDK | Model Context Protocol server API | MIT / Apache-2.0 (upstream transition) | https://github.com/modelcontextprotocol/kotlin-sdk | `io.modelcontextprotocol:kotlin-sdk-server:0.15.0`; the published POM says MIT, while the release LICENSE preserves MIT contributions and applies Apache-2.0 to relicensed / new contributions. See the release's full LICENSE. |
| Shizuku API | Optional privileged Android user-service bridge | MIT | https://github.com/RikkaApps/Shizuku-API | API and provider artifacts 13.1.5; this entry covers the client API, not the separate Shizuku application. |
| AndroidHiddenApiBypass | Android hidden API access helper | Apache-2.0 | https://github.com/LSPosed/AndroidHiddenApiBypass | `org.lsposed.hiddenapibypass:hiddenapibypass:6.1`. |
| HONOR media-audio SDK | Optional device-specific high-sample-rate playback | Proprietary vendor SDK (not open source) | https://developer.honor.com/repo/com/hihonor/mcs/media-audio/maven-metadata.xml | `com.hihonor.mcs:media-audio:1.2.0.301`. The vendor POM does not declare an open-source license; this SDK is listed separately from open-source components. |
| LySy                        | Lyric synchronization interaction and timing-algorithm reference                                                                  | MIT        | https://github.com/pxeemo/LySy                     | Native Kotlin / Compose lyric-timing editor reference; LySy Web source code and dependencies are not bundled                       |
| Beautiful Lyrics            | Dynamic lyric background, fullscreen lyric, and lyric visual experience reference                                                 | Not stated | https://github.com/surfbryce/beautiful-lyrics      | No standalone license    |
| 163KeyDecrypter             | NetEase Music 163 key decoding reference                                                                                         | MIT        | https://github.com/lycode404/163KeyDecrypter       | Used as decoding reference                                                                                                         |
| Reorderable                 | Drag-to-reorder list component for Compose                                                                                        | Apache-2.0 | https://github.com/Calvin-LL/Reorderable           | Gradle artifact: `sh.calvin.reorderable:reorderable`                                                                              |
| Inter                       | Bundled Western lyric typeface                                                                                                    | OFL-1.1    | https://github.com/rsms/inter                       | Bundled static Bold font from the official Inter 4.1 release                                                                      |
| RawS Music                  | Software DSP core and player waveform / mirrored-spectrum visual references                                                       | Apache-2.0 | https://github.com/QFDY-GZC/RawS-Music             | Halcyon's `com.ella.music.dsp` includes Kotlin ports/adaptations of RawS BiQuad / EQ / surround / panoramic audio / loudness / dynamic-EQ / Moog ladder / limiter algorithms for Media3 PCM. The player waveform and mirrored-spectrum presentations are adapted for Halcyon's Compose UI. Mini-player surface and artwork morph geometry references RawS ComposePlayerContainer and PlayerArtworkHandoffMotion (Copyright 2024–2026 RawSMusic Contributors). The USB-exclusive native output core, BRIR renderer, and FFT convolver are not included. |


LGPL-2.1 components are listed separately here so the Apache-2.0 license of the Halcyon main project is not confused with the licenses of bundled or linked third-party components.

The [2026-10-07 dependency audit](docs/dependency-audit-2026-10-07.md) records all direct dependency versions, unchanged stable versions, protocol adaptations, native source provenance and the retained FFmpegKit exception. Development tools and test-only dependencies listed there are not application runtime components.

For FFmpeg, FFmpegKit, TagLib, LyricGetter-API, SuperLyricApi, and other LGPL/MPL components, redistribution must follow the corresponding upstream license terms. If the native build configuration or bundled binaries change, this document should be updated before release.

Home daily-shuffle icon: Google Material Symbols Outlined (Apache-2.0), using the user-selected 24dp, weight 400, unfilled shuffle vector from fonts.gstatic.com.

RawS timeline port: ImmersiveWaveformProgress, ImmersiveClimaxAnalysis, PlayerTimelineGesturePolicy and RawWaveformCache, Copyright 2024–2026 RawSMusic Contributors, Apache-2.0. Halcyon supplies an independent MediaCodec PCM scanner.

RawS library pinch adaptation: LibraryPinchState uses VirtualListZoomGesturePolicy's 30-percent/500-dp-per-second release decision, endpoint velocity forwarding, and 500-ms accelerate/decelerate settling. LibraryItemMorph adapts VirtualList's retained source/target holder geometry to Halcyon's Compose cover/title/subtitle layers, preserving the focal song and existing library actions. Copyright 2024–2026 RawSMusic Contributors, Apache-2.0.

RawS cover-overlay visualizer: RawSArtworkSpectrum adapts ComposeAudioVisualizer's AlbumArtworkSpectrumOverlay (AudioVisualizerLayer.Foreground) and DisplaySpectrumMotion, plus the band mapping and rise/fall smoothing of stereo_spectrum_analyzer.cpp (MonoSpectrumAnalyzer::transform / updateSmoothedBands), to Android Visualizer FFT data, Copyright 2024–2026 RawSMusic Contributors, Apache-2.0.

ConePlayer reference: supplied v1.3.0-dev(3f88eb12f), renderer le.u, frame provider cf.c and spectrum processor se.a; the four visualizer motion models were reconstructed for Compose. No ConePlayer binaries are bundled.

Speed menu icon: Google Material Symbols Outlined, Apache-2.0, user-selected 24dp speed vector.

Comment like icon (`ic_comment_like.xml`): Google Material Icons thumb-up outline, Apache-2.0.

Lyrics motion references: user-supplied Apple Music Android decompilation (player.C.j0/q0, FullWidthAlphaGradientFlexboxLayout and lyrics dimensions) and Flamingo 1.0.0-2608212119 (t7.A0/B0/C1). The spring equations, mask geometry and motion parameters are adapted to Halcyon Compose layouts; no reference APK binaries are bundled.

## BetterLyrics visualization reference

[BetterLyrics](https://github.com/jayfunc/BetterLyrics), jayfunc and contributors, GPL-3.0,
was consulted for its centered frequency layout, smooth curve and bottom gradient behavior
(`SpectrumAnalyzer.cs` and `SpectrumRenderer.cs`, `dev` branch, 2026-09-28).
Halcyon's `CenteredSpectrum.kt` is an independent Android implementation using mixed FFT
from Android Visualizer; BetterLyrics source/binaries and its stereo WASAPI capture are not bundled.

### MusicFree plugin compatibility

Halcyon restores its own historical QuickJS compatibility layer for the [MusicFree plugin protocol](https://musicfree.catcat.work/plugin/protocol.html). Plugin names and search functions are read from plugin exports. MusicFree application binaries and plugins are not bundled; user-imported plugins retain their respective licenses. This adapter supports a subset of Node/React Native dependencies and does not imply compatibility with every plugin.

## HyperOS Super Island API

HyperNotification / Focus API, xzakota and contributors, Apache-2.0.
Halcyon directly uses `com.xzakota.hyper.notification:focus-api:1.4` for HyperOS Focus notification payloads.
Upstream: https://github.com/xzakota/HyperNotification
License: https://github.com/xzakota/HyperNotification/blob/main/LICENSE
This identifies the library's license; it does not establish the provenance of application-side integration code.

## SMBJ

SMB2 / SMB3 network share access uses [SMBJ](https://github.com/hierynomus/smbj), licensed under Apache-2.0.

## Opencc4j

Artist-name Simplified / Traditional Chinese conversion uses [Opencc4j](https://github.com/houbb/opencc4j), licensed under Apache-2.0.


### Apache Commons Net 3.13.0

FTP / explicit FTPS client. Apache License 2.0: https://commons.apache.org/proper/commons-net/

### JSch (mwiede) 2.28.7

SFTP client. BSD-style license: https://github.com/mwiede/jsch/blob/master/LICENSE.txt

### Bouncy Castle 1.86

Cryptographic primitives shared by SMB and SFTP, including the modern SSH key exchanges. MIT-style license: https://www.bouncycastle.org/licence.html

## 2026-10-11 navigation provenance and redistribution materials

The liquid navigation implementation was reimported from the Apache-2.0 Miuix v0.9.4 examples, commit `39c40f99844227b853f0049a0933b1f3ae6c00ba`, credited to compose-miuix-ui and Kyant0/AndroidLiquidGlass. The former GPL gesture inspector and KernelSU/InstallerX-derived animation and navigation sources are no longer compiled. See [migration and distribution evidence](docs/license-compliance-2026-10-11.md) and [source hashes](docs/licenses/miuix-example-provenance.json). Remaining font and vendor-SDK authorization gaps are recorded explicitly.
