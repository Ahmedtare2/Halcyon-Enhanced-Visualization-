package com.ella.music

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.FileProvider
import com.ella.music.data.model.Song
import com.ella.music.ui.player.DynamicCoverSource
import org.json.JSONObject
import java.io.File

/** Intent bridge for the audible MV opened from the song-detail page. */
internal object MusicVideoLauncher {
    private const val EXTRA_GENERIC_VIDEO = "generic_video"
    private const val EXTRA_SONG = "music_video_song"
    private const val EXTRA_VIDEO_URI = "music_video_uri"
    private const val EXTRA_VIDEO_KEY = "music_video_key"
    private const val EXTRA_VIDEO_ASPECT_RATIO = "music_video_aspect_ratio"

    fun open(context: Context, song: Song?, source: DynamicCoverSource) {
        val resolvedSong = song ?: return
        com.ella.music.player.PlaybackService.pausePlayback()
        context.startActivity(
            Intent(context, MusicVideoActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra(EXTRA_SONG, resolvedSong.toMusicVideoJson().toString())
                .putExtra(EXTRA_VIDEO_URI, source.uri.toString())
                .putExtra(EXTRA_VIDEO_KEY, source.failureKey)
                .putExtra(EXTRA_VIDEO_ASPECT_RATIO, source.aspectRatio ?: 0f)
        )
    }

    fun openVideo(context: Context, uri: Uri, title: String, mimeType: String? = null) {
        val song = Song(id = -uri.toString().hashCode().toLong(), title = title, artist = "", album = "",
            albumId = 0, duration = 0, path = uri.toString(), fileName = title, mimeType = mimeType.orEmpty())
        com.ella.music.player.PlaybackService.pausePlayback()
        context.startActivity(Intent(context, MusicVideoActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .putExtra(EXTRA_SONG, song.toMusicVideoJson().toString())
            .putExtra(EXTRA_VIDEO_URI, uri.toString())
            .putExtra(EXTRA_VIDEO_KEY, "video:$uri")
            .putExtra(EXTRA_GENERIC_VIDEO, true)
            .putExtra("video_tools_mime", mimeType)
            .apply { clipData = ClipData.newUri(context.contentResolver, title, uri) })
    }

    fun openNetease(context: Context, song: Song?, mvId: String) {
        if ((mvId.toLongOrNull() ?: 0L) <= 0L) return
        if (com.ella.music.data.netease.NeteaseLinks.current(context).openMusicVideoExternally) {
            com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.MusicVideo, mvId)
            return
        }
        open(context, song, DynamicCoverSource(
            uri = Uri.parse("halcyon-netease-mv://mv/$mvId"),
            failureKey = "netease-mv:$mvId",
            role = com.ella.music.ui.player.PlayerVideoRole.MusicVideo
        ))
    }

    fun isMusicVideo(intent: Intent): Boolean = !intent.getBooleanExtra(EXTRA_GENERIC_VIDEO, false)

    fun songFrom(intent: Intent): Song? = intent.getStringExtra(EXTRA_SONG)
        ?.let(::JSONObject)
        ?.toMusicVideoSong()

    fun sourceUriFrom(intent: Intent): Uri? = intent.getStringExtra(EXTRA_VIDEO_URI)
        ?.takeIf { it.isNotBlank() }
        ?.let(Uri::parse)

    fun sourceAspectRatioFrom(intent: Intent): Float? =
        intent.getFloatExtra(EXTRA_VIDEO_ASPECT_RATIO, 0f).takeIf { it > 0f }

    fun share(context: Context, source: Uri, label: String) {
        if (source.scheme == "halcyon-netease-mv") {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, com.ella.music.data.neteaseMvUrl(source.lastPathSegment.orEmpty()))
            }
            context.startActivity(Intent.createChooser(intent, context.getString(R.string.common_share)))
            return
        }
        val shareUri = source.asShareUri(context)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "video/*"
            putExtra(Intent.EXTRA_STREAM, shareUri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = ClipData.newUri(context.contentResolver, label, shareUri)
        }
        context.startActivity(Intent.createChooser(intent, context.getString(com.ella.music.R.string.common_share)))
    }

    fun share(context: Context, sources: List<Uri>, label: String) {
        val shareUris = ArrayList(sources.distinct().map { it.asShareUri(context) })
        if (shareUris.isEmpty()) return
        if (shareUris.size == 1) {
            share(context, shareUris.first(), label)
            return
        }
        val clips = ClipData.newUri(context.contentResolver, label, shareUris.first()).apply {
            shareUris.drop(1).forEach { addItem(ClipData.Item(it)) }
        }
        val intent = Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = "video/*"
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, shareUris)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            clipData = clips
        }
        context.startActivity(Intent.createChooser(intent, context.getString(com.ella.music.R.string.common_share)))
    }

    private fun Uri.asShareUri(context: Context): Uri {
        if (!scheme.equals("file", ignoreCase = true)) return this
        val file = File(path.orEmpty())
        return if (file.exists()) {
            FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        } else {
            this
        }
    }

    private fun Song.toMusicVideoJson(): JSONObject = JSONObject()
        .put("id", id)
        .put("title", title)
        .put("artist", artist)
        .put("album", album)
        .put("albumId", albumId)
        .put("duration", duration)
        .put("path", path)
        .put("fileName", fileName)
        .put("fileSize", fileSize)
        .put("mimeType", mimeType)
        .put("dateAdded", dateAdded)
        .put("dateModified", dateModified)
        .put("coverUrl", coverUrl)
        .put("onlineSource", onlineSource).put("onlineId", onlineId).put("onlineMvId", onlineMvId)

    private fun JSONObject.toMusicVideoSong(): Song = Song(
        id = optLong("id"),
        title = optString("title"),
        artist = optString("artist"),
        album = optString("album"),
        albumId = optLong("albumId"),
        duration = optLong("duration"),
        path = optString("path"),
        fileName = optString("fileName"),
        fileSize = optLong("fileSize"),
        mimeType = optString("mimeType"),
        dateAdded = optLong("dateAdded"),
        dateModified = optLong("dateModified"),
        coverUrl = optString("coverUrl"),
        onlineSource = optString("onlineSource"), onlineId = optString("onlineId"), onlineMvId = optString("onlineMvId")
    )
}
