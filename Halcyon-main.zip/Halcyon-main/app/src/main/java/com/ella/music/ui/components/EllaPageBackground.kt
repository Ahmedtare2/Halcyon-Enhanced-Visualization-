package com.ella.music.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import com.ella.music.data.SettingsManager
import com.ella.music.ui.navigation.Screen
import top.yukonga.miuix.kmp.basic.CardDefaults
import top.yukonga.miuix.kmp.theme.MiuixTheme

import com.ella.music.isSettingsGraphRoute

internal val LocalSharedAppBackgroundVisible = compositionLocalOf { false }

internal fun supportsNowPlayingFlowBackground(route: String?): Boolean {
    if (route == null) return false
    if (route.startsWith(Screen.LibrarySearch.baseRoute) || route == Screen.LibrarySearch.route) {
        return true
    }
    val path = route.substringBefore('?')
    val categoryBase = Screen.MetadataCategory.baseRoute
    val isCategoryRoot = path.startsWith("$categoryBase/") && '/' !in path.removePrefix("$categoryBase/")
    return setOf(
        Screen.Home.route,
        Screen.Library.route,
        Screen.Album.baseRoute,
        Screen.Artist.baseRoute,
        Screen.Folder.baseRoute,
        Screen.FolderPlaylists.route,
        Screen.Playlists.baseRoute,
        Screen.MetadataCategory.route.substringBefore('/'),
        Screen.NeteaseSearch.route,
        Screen.MusicFreeOnline.route,
        Screen.LxOnline.route
    ).any { path == it.substringBefore('?') } || isCategoryRoot || route.isSettingsGraphRoute()
}

@Composable
fun isAppWallpaperVisible(): Boolean {
    if (LocalSharedAppBackgroundVisible.current) return true
    val context = LocalContext.current
    val settingsManager = androidx.compose.runtime.remember(context) { SettingsManager.getInstance(context) }
    val appWallpaperEnabled by settingsManager.appWallpaperEnabled.collectAsState(initial = false)
    val appWallpaperUri by settingsManager.appWallpaperUri.collectAsState(initial = "")
    return appWallpaperEnabled && appWallpaperUri.isNotBlank()
}

@Composable
fun ellaPageCanvasColor(): Color {
    val isDark = MiuixTheme.colorScheme.background.luminance() < 0.5f
    return if (isDark) Color(0xFF101014) else Color(0xFFF4F4F7)
}

@Composable
fun ellaPageBackground(): Color =
    if (isAppWallpaperVisible()) Color.Transparent else ellaPageCanvasColor()

@Composable
fun wallpaperAwareCardColor(defaultAlpha: Float = 0.42f): Color {
    if (!isAppWallpaperVisible()) return MiuixTheme.colorScheme.surface
    val backgroundIsLight = MiuixTheme.colorScheme.background.luminance() >= 0.5f
    val base = if (backgroundIsLight) Color.White else Color(0xFF252528)
    return base.copy(alpha = defaultAlpha)
}

@Composable
fun wallpaperAwareCardColors(defaultAlpha: Float = 0.42f) =
    CardDefaults.defaultColors(color = wallpaperAwareCardColor(defaultAlpha))
