package com.ella.music.ui.album

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ella.music.R
import com.ella.music.MusicVideoLauncher
import com.ella.music.data.audioQualitySummary
import com.ella.music.data.LibraryNormalizer
import com.ella.music.data.model.Album
import com.ella.music.data.model.AudioInfo
import com.ella.music.data.model.Song
import com.ella.music.data.model.albumIdentityId
import com.ella.music.data.model.formatPlaybackDuration
import com.ella.music.ui.components.AudioQualityListBadge
import com.ella.music.ui.components.DefaultAlbumCover
import com.ella.music.ui.player.DynamicCoverSource
import com.ella.music.ui.player.DynamicCoverVideo
import com.ella.music.ui.components.ExplicitSongTitle
import com.ella.music.ui.components.PlayNextQuickButton
import com.ella.music.ui.components.MusicVideoListAction
import com.ella.music.ui.components.rememberSongListVideoActions
import com.ella.music.ui.components.RatingStarIcon
import com.ella.music.ui.components.SafeCoverImage
import com.ella.music.ui.components.SelectionCheck
import com.ella.music.ui.components.startDraggingLocalSongs
import com.ella.music.ui.artist.rememberArtistCoverModel
import com.ella.music.viewmodel.MainViewModel
import com.ella.music.viewmodel.PlayerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.basic.ArrowRight
import top.yukonga.miuix.kmp.icon.extended.Play
import top.yukonga.miuix.kmp.icon.extended.More
import top.yukonga.miuix.kmp.theme.MiuixTheme

@Composable
internal fun AlbumCopyrightFooter(
    copyright: String,
    publisher: String,
    releaseDate: String?,
    year: AlbumMetadataDisplayItem?,
    genres: List<AlbumMetadataDisplayItem>,
    artists: List<AlbumMetadataDisplayItem>,
    composers: List<AlbumMetadataDisplayItem>,
    arrangers: List<AlbumMetadataDisplayItem>,
    lyricists: List<AlbumMetadataDisplayItem>,
    mainViewModel: MainViewModel,
    artistCoverFolderUri: String,
    onGenreClick: (String) -> Unit,
    onArtistClick: (String) -> Unit,
    onComposerClick: (String) -> Unit,
    onArrangerClick: (String) -> Unit,
    onLyricistClick: (String) -> Unit,
    onYearClick: (String) -> Unit,
    showReleaseDateSection: Boolean = true
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 22.dp),
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        copyright.lines().filter { it.isNotBlank() }.takeIf { it.isNotEmpty() }?.let { values ->
            AlbumTextInfoSection(
                title = stringResource(R.string.album_copyright),
                values = values
            )
        }
        publisher.lines().filter { it.isNotBlank() }.takeIf { it.isNotEmpty() }?.let { values ->
            AlbumTextInfoSection(
                title = stringResource(R.string.album_publisher),
                values = values
            )
        }
        // Keep the full release date and the tappable year-category entry available together.
        if (showReleaseDateSection) {
            val releaseDateText = releaseDate?.takeIf { it.isNotBlank() }
            if (releaseDateText != null) {
                AlbumTextInfoSection(
                    title = stringResource(R.string.album_release_date),
                    values = listOf(releaseDateText)
                )
            }
        }
        year?.let { item ->
            AlbumMetadataSection(
                title = stringResource(R.string.category_year),
                items = listOf(item),
                circularCover = false,
                mainViewModel = mainViewModel,
                artistCoverFolderUri = artistCoverFolderUri,
                onItemClick = { onYearClick(item.name) }
            )
        }
        AlbumMetadataSection(
            title = stringResource(R.string.category_genre),
            items = genres,
            circularCover = false,
            mainViewModel = mainViewModel,
            artistCoverFolderUri = artistCoverFolderUri,
            onItemClick = onGenreClick
        )
        AlbumMetadataSection(
            title = stringResource(R.string.player_detail_artist),
            items = artists,
            circularCover = true,
            mainViewModel = mainViewModel,
            artistCoverFolderUri = artistCoverFolderUri,
            onItemClick = onArtistClick
        )
        AlbumMetadataSection(
            title = stringResource(R.string.player_detail_composer),
            items = composers,
            circularCover = true,
            mainViewModel = mainViewModel,
            artistCoverFolderUri = artistCoverFolderUri,
            onItemClick = onComposerClick
        )
        AlbumMetadataSection(
            title = stringResource(R.string.player_detail_arranger),
            items = arrangers,
            circularCover = true,
            mainViewModel = mainViewModel,
            artistCoverFolderUri = artistCoverFolderUri,
            onItemClick = onArrangerClick
        )
        AlbumMetadataSection(
            title = stringResource(R.string.player_detail_lyricist),
            items = lyricists,
            circularCover = true,
            mainViewModel = mainViewModel,
            artistCoverFolderUri = artistCoverFolderUri,
            onItemClick = onLyricistClick
        )
    }
}

internal data class AlbumMetadataDisplayItem(
    val name: String,
    val songCount: Int,
    val duration: Long,
    val albumCount: Int,
    val coverModel: Any?,
    val artistCoverName: String? = null,
    val artistCoverSong: Song? = null
)

@Composable
private fun AlbumTextInfoSection(
    title: String,
    values: List<String>
) {
    if (values.isEmpty()) return
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MiuixTheme.colorScheme.primary
        )
        values.forEach { value ->
            Text(
                text = value,
                fontSize = 15.sp,
                lineHeight = 21.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
            )
        }
    }
}

@Composable
private fun AlbumMetadataSection(
    title: String,
    items: List<AlbumMetadataDisplayItem>,
    circularCover: Boolean,
    mainViewModel: MainViewModel,
    artistCoverFolderUri: String,
    onItemClick: (String) -> Unit
) {
    if (items.isEmpty()) return
    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(
            text = title,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = MiuixTheme.colorScheme.primary
        )
        items.forEach { item ->
            AlbumMetadataRow(
                item = item,
                circularCover = circularCover,
                mainViewModel = mainViewModel,
                artistCoverFolderUri = artistCoverFolderUri,
                onClick = { onItemClick(item.name) }
            )
        }
    }
}

@Composable
private fun AlbumMetadataRow(
    item: AlbumMetadataDisplayItem,
    circularCover: Boolean,
    mainViewModel: MainViewModel,
    artistCoverFolderUri: String,
    onClick: () -> Unit,
) {
    val coverModel = item.artistCoverName?.let { artistName ->
        rememberArtistCoverModel(
            artistName = artistName,
            representativeSong = item.artistCoverSong,
            folderLocation = artistCoverFolderUri,
            mainViewModel = mainViewModel
        )
    } ?: item.coverModel
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        SafeCoverImage(
            model = coverModel,
            contentDescription = item.name,
            modifier = Modifier
                .size(52.dp)
                .clip(if (circularCover) CircleShape else RoundedCornerShape(12.dp)),
            sizePx = 256
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = item.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = MiuixTheme.colorScheme.onSurface,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = stringResource(
                    R.string.player_detail_person_summary,
                    item.songCount,
                    item.duration.formatPlaybackDuration(),
                    item.albumCount
                ),
                fontSize = 13.sp,
                color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
internal fun DiscHeader(group: AlbumDiscGroup) {
    Text(
        text = stringResource(
            R.string.album_disc_header,
            group.discNumber,
            group.songs.size,
            group.songs.sumOf { it.duration }.formatPlaybackDuration()
        ),
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold,
        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
        modifier = Modifier.padding(start = 26.dp, end = 26.dp, top = 22.dp, bottom = 8.dp)
    )
}

@Composable
internal fun AlbumSongRow(
    song: Song,
    index: Int,
    sortedAlbumSongs: List<Song>,
    currentSongId: Long?,
    isFavorite: Boolean,
    showTrackNumber: Boolean,
    mainViewModel: MainViewModel,
    ratingRevision: Int,
    playerViewModel: PlayerViewModel,
    openPlayerOnPlay: Boolean,
    onNavigateToPlayer: () -> Unit,
    selectionMode: Boolean,
    selected: Boolean,
    onLongClick: () -> Unit,
    onSelectionClick: () -> Unit,
    onMore: () -> Unit,
    showPlayNextInLists: Boolean,
    titleOverride: String? = null,
    dragSelectedSongs: List<Song> = emptyList(),
    isRandomSort: Boolean = false
) {
    AlbumTrackRow(
        song = song,
        isCurrent = currentSongId == song.id,
        loadAudioInfo = mainViewModel::getAudioInfo,
        isFavorite = isFavorite,
        loadSongRating = mainViewModel::getSongRating,
        loadSongTagInfo = mainViewModel::getSongTagInfo,
        ratingRevision = ratingRevision,
        leadingLabel = if (showTrackNumber) song.displayTrackNumber() else null,
        selectionMode = selectionMode,
        selected = selected,
        onLongClick = onLongClick,
        dragSelectedSongs = dragSelectedSongs,
        onClick = {
            if (selectionMode) {
                onSelectionClick()
                return@AlbumTrackRow
            }
            val safeIndex = index.coerceAtLeast(0)
            val resumeKey = sortedAlbumSongs.firstOrNull()?.let {
                com.ella.music.data.CategoryResumeKeys.album(it.albumIdentityId())
            }
            if (isRandomSort) {
                playerViewModel.setShuffledPlaylist(
                    sortedAlbumSongs,
                    safeIndex,
                    resumeCategoryKey = resumeKey,
                    preserveOrder = true
                )
            } else {
                playerViewModel.setPlaylist(
                    sortedAlbumSongs,
                    safeIndex,
                    resumeCategoryKey = resumeKey
                )
            }
            if (openPlayerOnPlay) onNavigateToPlayer()
        },
        showPlayNextInLists = showPlayNextInLists,
        onPlayNext = { playerViewModel.playNext(song) },
        onMore = onMore,
        titleOverride = titleOverride
    )
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun AlbumTrackRow(
    song: Song,
    isCurrent: Boolean,
    loadAudioInfo: (Song) -> AudioInfo,
    isFavorite: Boolean,
    loadSongRating: (Song) -> Int,
    loadSongTagInfo: (Song) -> com.ella.music.data.model.SongTagInfo,
    ratingRevision: Int,
    leadingLabel: String?,
    selectionMode: Boolean,
    selected: Boolean,
    onLongClick: () -> Unit,
    onClick: () -> Unit,
    showPlayNextInLists: Boolean,
    onPlayNext: () -> Unit,
    onMore: () -> Unit,
    titleOverride: String? = null,
    dragSelectedSongs: List<Song> = emptyList()
) {
    val audioInfo by produceState<AudioInfo?>(initialValue = null, song.id, song.dateModified, loadAudioInfo) {
        value = withContext(Dispatchers.IO) { loadAudioInfo(song) }
    }
    val rating by produceState(initialValue = 0, song.id, song.dateModified, ratingRevision, loadSongRating) {
        value = withContext(Dispatchers.IO) { loadSongRating(song) }
    }
    val qualityTag = audioInfo?.let { audioQualitySummary(it).listTag }
    val context = LocalContext.current
    val sourceView = LocalView.current
    val videoActions = rememberSongListVideoActions(song, loadSongTagInfo, enabled = !selectionMode)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(if (selected) MiuixTheme.colorScheme.primary.copy(alpha = 0.10f) else Color.Transparent)
            .combinedClickable(
                onClick = onClick,
                onLongClick = {
                    val dragStarted = if (selectionMode && selected && dragSelectedSongs.isNotEmpty()) {
                        startDraggingLocalSongs(sourceView, context, dragSelectedSongs)
                    } else {
                        false
                    }
                    if (!dragStarted) onLongClick()
                }
            )
            .padding(start = 26.dp, end = 16.dp, top = 15.dp, bottom = 15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (selectionMode) {
            SelectionCheck(
                selected = selected,
                checkColor = Color.White
            )
            Spacer(modifier = Modifier.width(12.dp))
        }
        Text(
            text = leadingLabel.orEmpty(),
            fontSize = 16.sp,
            color = if (isCurrent) MiuixTheme.colorScheme.primary else MiuixTheme.colorScheme.onSurface,
            modifier = Modifier.width(46.dp)
        )
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                ExplicitSongTitle(
                    title = titleOverride ?: song.title,
                    fontSize = 15.sp,
                    fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                    color = if (isCurrent) MiuixTheme.colorScheme.primary else MiuixTheme.colorScheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false)
                )
                if (isFavorite) {
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "♥", fontSize = 12.sp, color = Color(0xFFFF4D6D))
                }
                if (rating > 0) {
                    Spacer(modifier = Modifier.width(6.dp))
                    RatingStarIcon(
                        filled = true,
                        tint = Color(0xFFFFB703),
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(text = rating.toString(), fontSize = 11.sp, color = Color(0xFFFFB703))
                }
            }
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (!qualityTag.isNullOrBlank()) {
                    AudioQualityListBadge(qualityTag)
                    Spacer(modifier = Modifier.width(6.dp))
                }
                Text(
                    text = song.artist.ifBlank { stringResource(R.string.player_unknown_artist) },
                    fontSize = 12.sp,
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Spacer(modifier = Modifier.width(8.dp))
        if (!selectionMode) {
            videoActions.localSource?.let { source ->
                MusicVideoListAction(
                    label = stringResource(R.string.library_search_filter_mv),
                    contentDescription = stringResource(R.string.local_mv),
                    color = MiuixTheme.colorScheme.primary,
                    onClick = { MusicVideoLauncher.open(context, song, source) }
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
            videoActions.onlineUrl?.takeUnless { videoActions.localSource != null }?.let { url ->
                MusicVideoListAction(
                    label = stringResource(R.string.online_mv),
                    contentDescription = stringResource(R.string.online_mv),
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    onClick = { MusicVideoLauncher.openNetease(context, song, Uri.parse(url).getQueryParameter("id").orEmpty()) }
                )
                Spacer(modifier = Modifier.width(6.dp))
            }
        }
        Text(
            text = song.duration.formatPlaybackDuration(),
            fontSize = 13.sp,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
            modifier = Modifier.padding(end = 4.dp)
        )
        if (!selectionMode && showPlayNextInLists) {
            Spacer(modifier = Modifier.width(8.dp))
            PlayNextQuickButton(onClick = onPlayNext)
        }
        if (!selectionMode) {
            Spacer(modifier = Modifier.width(6.dp))
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .clickable(onClick = onMore),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = MiuixIcons.Regular.More,
                    contentDescription = stringResource(R.string.player_quick_more),
                    tint = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
internal fun AlbumHeader(
    album: Album?,
    albumCoverModel: Any?,
    hasNeteaseAlbum: Boolean,
    onNeteaseAlbumClick: () -> Unit,
    onNeteaseCommentsClick: () -> Unit = {},
    onAlbumArtistClick: () -> Unit,
    onIntroductionClick: () -> Unit,
    onCoverClick: () -> Unit,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onAddToPlaylist: () -> Unit,
    yearText: String? = null,
    releaseDate: String? = null,
    onReleaseYearClick: () -> Unit = {},
    immersivePlayButtonColor: Color? = null,
    immersiveDynamicCover: Boolean = false,
    dynamicCoverSource: DynamicCoverSource? = null
) {
    // Immersive only when caller says so AND (resolved video source OR confirmed sidecar hint).
    // Never treat name-index match alone as immersive — that painted full-bleed static art.
    if (immersiveDynamicCover) {
        ImmersiveAlbumHeader(
            album = album,
            albumCoverModel = albumCoverModel,
            hasNeteaseAlbum = hasNeteaseAlbum,
            onNeteaseAlbumClick = onNeteaseAlbumClick,
            onNeteaseCommentsClick = onNeteaseCommentsClick,
            onAlbumArtistClick = onAlbumArtistClick,
            onIntroductionClick = onIntroductionClick,
            onCoverClick = onCoverClick,
            onPlayAll = onPlayAll,
            onShuffle = onShuffle,
            onAddToPlaylist = onAddToPlaylist,
            dynamicCoverSource = dynamicCoverSource,
            playButtonColor = immersivePlayButtonColor
        )
    } else {
        CompactAlbumHeader(
            album = album,
            albumCoverModel = albumCoverModel,
            hasNeteaseAlbum = hasNeteaseAlbum,
            onNeteaseAlbumClick = onNeteaseAlbumClick,
            onNeteaseCommentsClick = onNeteaseCommentsClick,
            onAlbumArtistClick = onAlbumArtistClick,
            onIntroductionClick = onIntroductionClick,
            onCoverClick = onCoverClick,
            onPlayAll = onPlayAll,
            onShuffle = onShuffle,
            onAddToPlaylist = onAddToPlaylist,
            yearText = yearText,
            releaseDate = releaseDate,
            onReleaseYearClick = onReleaseYearClick
        )
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun CompactAlbumHeader(
    album: Album?,
    albumCoverModel: Any?,
    hasNeteaseAlbum: Boolean,
    onNeteaseAlbumClick: () -> Unit,
    onNeteaseCommentsClick: () -> Unit = {},
    onAlbumArtistClick: () -> Unit,
    onIntroductionClick: () -> Unit,
    onCoverClick: () -> Unit,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onAddToPlaylist: () -> Unit,
    yearText: String? = null,
    releaseDate: String? = null,
    onReleaseYearClick: () -> Unit = {}
) {
    // Compact (non-dynamic): cover | album title → album artist → release date → 介绍.
    // An album artist is a distinct tag — do not substitute the track artist when missing (#570).
    val albumArtist = album?.albumArtist?.takeIf(LibraryNormalizer::isUsableArtistText)
    val albumTitle = album?.name
        ?.takeUnless(LibraryNormalizer::isGeneratedUnknownAlbumPlaceholder)
        ?: stringResource(R.string.player_unknown_album)
    val headerReleaseDate = releaseDate?.takeIf { it.isNotBlank() }
        ?: yearText?.takeIf { it.isNotBlank() }
        ?: album?.year?.takeIf { it.isNotBlank() }?.let { Regex("""\d{4}""").find(it)?.value ?: it }
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.statusBars)
            .padding(start = 26.dp, end = 26.dp, top = 82.dp, bottom = 22.dp),
        verticalArrangement = Arrangement.spacedBy(22.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.Top
        ) {
            Box(
                modifier = Modifier
                    .size(124.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(MiuixTheme.colorScheme.surfaceContainer)
                    .clickable(onClick = onCoverClick),
                contentAlignment = Alignment.Center
            ) {
                if (albumCoverModel != null) {
                    SafeCoverImage(
                        model = albumCoverModel,
                        contentDescription = null,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop,
                        sizePx = 512,
                        loadOriginal = true
                    )
                } else {
                    DefaultAlbumCover(modifier = Modifier.fillMaxSize())
                }
            }
            Spacer(modifier = Modifier.width(22.dp))
            Column(
                modifier = Modifier
                    .weight(1f)
                    .heightIn(min = 124.dp)
                    .padding(top = 2.dp)
            ) {
                Text(
                    text = albumTitle,
                    fontSize = 20.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.Bold,
                    color = MiuixTheme.colorScheme.onSurface,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                if (!albumArtist.isNullOrBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = albumArtist,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.clickable(onClick = onAlbumArtistClick)
                    )
                }
                // Preserve the complete release date beside the cover; tapping it opens the year category.
                if (headerReleaseDate != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = headerReleaseDate,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Normal,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = if (yearText?.isNotBlank() == true) {
                            Modifier.clickable(onClick = onReleaseYearClick)
                        } else Modifier
                    )
                }
                Spacer(modifier = Modifier.weight(1f))
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .clickable(onClick = onIntroductionClick)
                        .padding(horizontal = 6.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stringResource(R.string.album_introduction_entry),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                    )
                    Icon(
                        imageVector = MiuixIcons.Basic.ArrowRight,
                        contentDescription = null,
                        tint = MiuixTheme.colorScheme.onSurfaceVariantSummary,
                        modifier = Modifier.size(13.dp)
                    )
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(999.dp))
                .background(MiuixTheme.colorScheme.surfaceContainer),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f).fillMaxHeight().clickable(onClick = onPlayAll).padding(horizontal = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(MiuixIcons.Regular.Play, null, modifier = Modifier.size(20.dp))
                Text(stringResource(R.string.album_play_all), fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            }
            if (hasNeteaseAlbum) {
                Box(Modifier.width(1.dp).height(14.dp).background(MiuixTheme.colorScheme.onSurface.copy(alpha = 0.12f)))
                Text(stringResource(R.string.netease_album_comment_button), fontSize = 13.sp,
                    modifier = Modifier.clickable(onClick = onNeteaseCommentsClick).padding(horizontal = 12.dp, vertical = 10.dp))
                Box(Modifier.width(1.dp).height(14.dp).background(MiuixTheme.colorScheme.onSurface.copy(alpha = 0.12f)))
                Text(stringResource(R.string.player_netease_album_page), fontSize = 13.sp,
                    color = MiuixTheme.colorScheme.primary,
                    modifier = Modifier.clickable(onClick = onNeteaseAlbumClick).padding(horizontal = 12.dp, vertical = 10.dp))
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ImmersiveAlbumHeader(
    album: Album?,
    albumCoverModel: Any?,
    hasNeteaseAlbum: Boolean,
    onNeteaseAlbumClick: () -> Unit,
    onNeteaseCommentsClick: () -> Unit = {},
    onAlbumArtistClick: () -> Unit,
    onIntroductionClick: () -> Unit,
    onCoverClick: () -> Unit,
    onPlayAll: () -> Unit,
    onShuffle: () -> Unit,
    onAddToPlaylist: () -> Unit,
    dynamicCoverSource: DynamicCoverSource?,
    playButtonColor: Color?
) {
    // Match ArtistHeader: full-bleed cover (static or matched dynamic video) with a soft
    // gradient melt into the page — only used when the album has a dynamic/matched cover.
    val albumArtist = album?.albumArtist?.takeIf(LibraryNormalizer::isUsableArtistText)
    val albumTitle = album?.name
        ?.takeUnless(LibraryNormalizer::isGeneratedUnknownAlbumPlaceholder)
        ?: stringResource(R.string.player_unknown_album)
    val headerTextColor = Color.White
    val headerSubTextColor = Color.White.copy(alpha = 0.78f)
    val coverFadeStart = if (dynamicCoverSource?.aspectRatio?.let { it in 0.01f..0.95f } == true) {
        0.62f
    } else {
        0.70f
    }
    var videoFailed by remember(dynamicCoverSource?.failureKey) { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(468.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    compositingStrategy = CompositingStrategy.Offscreen
                }
                .drawWithContent {
                    drawContent()
                    drawRect(
                        brush = Brush.verticalGradient(
                            colorStops = arrayOf(
                                0.00f to Color.White,
                                coverFadeStart to Color.White,
                                0.88f to Color.White.copy(alpha = 0.55f),
                                1.00f to Color.Transparent
                            )
                        ),
                        blendMode = BlendMode.DstIn
                    )
                }
                .combinedClickable(
                    onClick = onCoverClick,
                    onLongClick = onCoverClick
                )
        ) {
            if (dynamicCoverSource != null && !videoFailed) {
                DynamicCoverVideo(
                    source = dynamicCoverSource,
                    isPlaying = true,
                    onPlaybackError = { videoFailed = true },
                    modifier = Modifier.fillMaxSize(),
                    cornerRadiusDp = 0f,
                    resizeMode = androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                )
            } else if (albumCoverModel != null) {
                SafeCoverImage(
                    model = albumCoverModel,
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop,
                    sizePx = 3000,
                    loadOriginal = true
                )
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(MiuixTheme.colorScheme.surfaceContainer),
                    contentAlignment = Alignment.Center
                ) {
                    DefaultAlbumCover(modifier = Modifier.size(160.dp))
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colorStops = arrayOf(
                            0.00f to Color.Black.copy(alpha = 0.12f),
                            0.42f to Color.Black.copy(alpha = 0.28f),
                            0.62f to Color.Black.copy(alpha = 0.46f),
                            0.78f to Color.Black.copy(alpha = 0.22f),
                            0.90f to Color.Transparent,
                            1.00f to Color.Transparent
                        )
                    )
                )
        )

        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 42.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = albumTitle,
                fontSize = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                color = headerTextColor,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                textAlign = TextAlign.Center
            )

            if (!albumArtist.isNullOrBlank()) {
                Text(
                    text = albumArtist,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = headerSubTextColor,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.clickable(onClick = onAlbumArtistClick)
                )
            }

            AlbumAmCircularActions(
                onShuffle = onShuffle,
                onPlayAll = onPlayAll,
                onAddToPlaylist = onAddToPlaylist,
                frosted = true,
                playButtonColor = playButtonColor,
                modifier = Modifier.padding(top = 12.dp)
            )
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(999.dp))
                    .clickable(onClick = onIntroductionClick)
                    .padding(horizontal = 2.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = stringResource(R.string.album_introduction_entry),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = headerSubTextColor
                )
                Icon(
                    imageVector = MiuixIcons.Basic.ArrowRight,
                    contentDescription = null,
                    tint = headerSubTextColor,
                    modifier = Modifier.size(16.dp)
                )
            }
            if (hasNeteaseAlbum) {
                Text(stringResource(R.string.netease_album_comment_button), color = Color.White,
                    modifier = Modifier.clickable(onClick = onNeteaseCommentsClick).padding(10.dp))
                Text(
                    text = stringResource(R.string.player_netease_album_page),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .background(Color.White.copy(alpha = 0.18f))
                        .clickable(onClick = onNeteaseAlbumClick)
                        .padding(horizontal = 12.dp, vertical = 9.dp)
                )
            }
        }
    }
}

@Composable
private fun AlbumAmCircularActions(
    onShuffle: () -> Unit,
    onPlayAll: () -> Unit,
    onAddToPlaylist: () -> Unit,
    frosted: Boolean,
    playButtonColor: Color? = null,
    modifier: Modifier = Modifier
) {
    val circleBg = if (frosted) {
        Color.White.copy(alpha = 0.22f)
    } else {
        MiuixTheme.colorScheme.surfaceContainerHigh
    }
    val contentTint = if (frosted) {
        Color.White
    } else {
        MiuixTheme.colorScheme.onSurface
    }
    val playBg = playButtonColor ?: if (frosted) {
        Color.White.copy(alpha = 0.92f)
    } else {
        MiuixTheme.colorScheme.primary
    }
    val playTint = if (frosted && playButtonColor != null) {
        Color.White
    } else if (frosted) {
        Color.Black.copy(alpha = 0.82f)
    } else {
        MiuixTheme.colorScheme.onPrimary
    }
    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        AlbumAmCircleButton(
            drawableRes = R.drawable.ic_shuffle,
            contentDescription = stringResource(R.string.shuffle),
            size = 48.dp,
            iconSize = 22.dp,
            background = circleBg,
            tint = contentTint,
            onClick = onShuffle
        )
        Spacer(modifier = Modifier.width(28.dp))
        AlbumAmCircleButton(
            drawableRes = R.drawable.ic_player_play,
            contentDescription = stringResource(R.string.album_play_all),
            size = 64.dp,
            iconSize = 28.dp,
            background = playBg,
            tint = playTint,
            onClick = onPlayAll
        )
        Spacer(modifier = Modifier.width(28.dp))
        AlbumAmCircleButton(
            drawableRes = R.drawable.ic_playlist_add,
            contentDescription = stringResource(R.string.player_add_to_playlist),
            size = 48.dp,
            iconSize = 22.dp,
            background = circleBg,
            tint = contentTint,
            onClick = onAddToPlaylist
        )
    }
}

@Composable
private fun AlbumAmCircleButton(
    drawableRes: Int,
    contentDescription: String,
    size: androidx.compose.ui.unit.Dp,
    iconSize: androidx.compose.ui.unit.Dp,
    background: Color,
    tint: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(size)
            .clip(CircleShape)
            .background(background)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            painter = painterResource(id = drawableRes),
            contentDescription = contentDescription,
            tint = tint,
            modifier = Modifier.size(iconSize)
        )
    }
}

internal fun openUrl(context: Context, url: String) {
    if (url.isBlank()) return
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}
