package com.ella.music.data.repository

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import androidx.documentfile.provider.DocumentFile
import com.ella.music.data.exception.WritePermissionRequiredException
import com.ella.music.data.AppLogStore
import com.ella.music.data.AppLogType
import com.ella.music.data.AppNetworkLoggingInterceptor
import com.ella.music.data.LibraryAlbumAggregator
import com.ella.music.data.LibraryNormalizer
import com.ella.music.data.SettingsManager
import com.ella.music.data.isContentAudioSource
import com.ella.music.data.isHttpAudioSource
import com.ella.music.data.isMediaStoreContentAudioSource
import com.ella.music.data.model.Album
import com.ella.music.data.model.AudioInfo
import com.ella.music.data.model.LyricLine
import com.ella.music.data.model.Song
import com.ella.music.data.model.SongTagInfo
import com.ella.music.data.model.albumIdentityId
import com.ella.music.data.metadata.AudioCoverInfo
import com.ella.music.data.metadata.AudioTagInfo
import com.ella.music.data.libraryCustomTags
import com.ella.music.data.metadata.AudioTagRepository
import com.ella.music.data.metadata.LyricoAudioTagReaderWriter
import com.ella.music.data.metadata.WavMetadataReader
import com.ella.music.data.scanner.MediaStoreAudioItem
import com.ella.music.data.scanner.MusicScanner
import com.ella.music.data.scanner.TwoStageScanCoordinator
import com.ella.music.data.scanner.TwoStageScanEvent
import com.ella.music.data.webdav.WebDavClient
import com.ella.music.data.webdav.WebDavConfig
import com.ella.music.data.smb.toLibrarySong
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import com.ella.music.data.remote.EmbyService
import com.ella.music.data.remote.NavidromeService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.supervisorScope
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.currentCoroutineContext
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

enum class CoverUsage {
    ListThumbnail,
    AlbumGrid,
    /** Artist headers must not trust the shared .thumbnails cache, which can contain stale files. */
    ArtistImage,
    Player,
    Notification,
    ShareCard
}

data class MusicScanSummary(
    val total: Int,
    val added: Int = 0,
    val updated: Int = 0,
    val deleted: Int = 0,
    val failed: Int = 0,
    val fullRescan: Boolean = false
)

class MusicRepository(private val context: Context) {
    companion object {
        private const val WEBDAV_EAGER_METADATA_LIMIT = 300

        @Volatile
        private var instance: MusicRepository? = null

        fun getInstance(context: Context): MusicRepository =
            instance ?: synchronized(this) {
                instance ?: MusicRepository(context.applicationContext).also { instance = it }
            }

        /** Releases repository caches without creating the repository just to trim memory. */
        fun clearMemoryCachesIfInitialized() {
            instance?.clearCache()
        }
    }

    data class LyricFormatAvailability(
        val hasTtml: Boolean = false,
        val hasPlain: Boolean = false
    ) {
        val hasBoth: Boolean get() = hasTtml && hasPlain
    }

    private val scanner = MusicScanner(context)
    private val audioTagRepository = AudioTagRepository(
        primary = LyricoAudioTagReaderWriter(context)
    )
    private val settingsManager = SettingsManager.getInstance(context)
    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .addInterceptor(AppNetworkLoggingInterceptor("MusicRepoNetwork"))
        .build()

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    private val librarySnapshotLock = Any()
    private val librarySnapshotGeneration = AtomicLong(0L)

    /** Cached #655 toggle; refreshed at the start of each library load. */
    @Volatile private var folderNameAsAlbumWhenMissingEnabled: Boolean = false
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()
    private val _webDavMetadataRevision = MutableStateFlow(0L)
    val webDavMetadataRevision: StateFlow<Long> = _webDavMetadataRevision.asStateFlow()

    private val _albums = MutableStateFlow<List<Album>>(emptyList())
    val albums: StateFlow<List<Album>> = _albums.asStateFlow()
    private val albumAggregationGeneration = AtomicLong(0L)

    private val scanProgressState = LibraryScanProgressState()
    val isScanning: StateFlow<Boolean> = scanProgressState.isScanning
    val scanProgress: StateFlow<Int> = scanProgressState.scanProgress

    private val _scanSummaryEvents = MutableSharedFlow<MusicScanSummary>(extraBufferCapacity = 1)
    val scanSummaryEvents: SharedFlow<MusicScanSummary> = _scanSummaryEvents.asSharedFlow()

    fun startScanning() {
        scanProgressState.start()
    }

    fun emitScanSummary(summary: MusicScanSummary) {
        _scanSummaryEvents.tryEmit(summary)
    }

    fun finishScanning() {
        scanProgressState.finish()
    }

    fun clearInMemoryLibrary() {
        synchronized(librarySnapshotLock) {
            librarySnapshotGeneration.incrementAndGet()
            _songs.value = emptyList()
            _albums.value = emptyList()
        }
    }

    private fun beginLibrarySnapshotLoad(): Long = synchronized(librarySnapshotLock) {
        librarySnapshotGeneration.incrementAndGet()
    }

    private fun isCurrentLibrarySnapshotLoad(generation: Long): Boolean =
        librarySnapshotGeneration.get() == generation

    private fun publishLibrarySnapshot(generation: Long, songs: List<Song>): Boolean {
        val albums = songs.toAlbums()
        return synchronized(librarySnapshotLock) {
            if (librarySnapshotGeneration.get() != generation) {
                false
            } else {
                _songs.value = songs
                _albums.value = albums
                true
            }
        }
    }

    private val remoteAudioCacheDir = File(context.cacheDir, "webdav_audio")
    private val remoteMetadataHeaderCacheDir = File(context.cacheDir, "webdav_metadata_headers")
    private val webDavMetadataLocks = ConcurrentHashMap<String, Mutex>()
    private val webDavMetadataWindowAttempts = ConcurrentHashMap.newKeySet<String>()
    private val lyricsManager = MusicLyricsManager(context, settingsManager, audioTagRepository, httpClient, remoteAudioCacheDir, remoteMetadataHeaderCacheDir)
    private val coverArtManager = MusicCoverArtManager(context, audioTagRepository, settingsManager, httpClient, remoteAudioCacheDir, remoteMetadataHeaderCacheDir)
    private val snapshotManager: MusicSnapshotManager = MusicSnapshotManager(
        File(context.filesDir, "library_search_snapshot.json"),
        File(context.filesDir, "library_rating_snapshot.json")
    ) { song -> searchCoordinator.buildSongSearchSnapshotText(song, includeCachedTagInfo = true) }
    private val searchCoordinator: MusicLibrarySearchCoordinator =
        MusicLibrarySearchCoordinator(snapshotManager) { song -> getCachedSongTagInfo(song) }

    private val tagInfoCache = ConcurrentHashMap<String, SongTagInfo>()
    private val audioInfoProvider = MusicAudioInfoProvider(
        scanner,
        audioTagRepository,
        metadataPathResolver = { song -> song.effectiveLocalPathForMetadata() },
        qualityCacheFile = File(context.filesDir, "audio_quality_cache.json"),
        onlineStreamInfo = { song ->
            if (song.onlineSource == SettingsManager.LIBRARY_SOURCE_NETEASE && song.onlineId.isNotBlank())
                com.ella.music.data.netease.NeteaseLibraryStore.getInstance(context).audioInfoFor(song.onlineId)
            else null
        }
    )
    private val tagWriter = MusicTagWriter(
        context,
        audioTagRepository,
        metadataPathResolver = { song -> song.effectiveLocalPathForMetadata() },
        clearMetadataCache = { song -> clearMetadataCache(song) }
    )
    private val libraryCacheStore = MusicLibraryCacheStore(context, settingsManager)

    suspend fun scanMusic(
        minDurationMs: Long = 0,
        includeFolders: List<String> = emptyList(),
        excludeFolders: List<String> = emptyList(),
        fullRescan: Boolean = false,
        deepRescan: Boolean = fullRescan,
        deepMetadataEnabled: Boolean = true,
        filesystemFallbackFolders: List<String> = includeFolders,
        filterVideoFiles: Boolean = true,
        refreshMediaStore: Boolean = false
    ): MusicScanSummary = withContext(Dispatchers.IO) {
        currentCoroutineContext().ensureActive()
        val generation = beginLibrarySnapshotLoad()
        refreshFolderAlbumSetting()

        val mode = if (includeFolders.isEmpty()) "media_library" else "custom_folders"
        val previousSongs = libraryCacheStore.readLocalScanBaselineSongs().ifEmpty { _songs.value }
        AppLogStore.info(
            context,
            "MusicScanner",
            "Start scan mode=$mode minDuration=${minDurationMs}ms include=${includeFolders.size} fallbackFolders=${filesystemFallbackFolders.size} exclude=${excludeFolders.size} fullRescan=$fullRescan deepRescan=$deepRescan deepMetadataEnabled=$deepMetadataEnabled",
            AppLogType.LIBRARY
        )
        // A complete scan must always rebuild tags, even when the normal-scan full-tag option is
        // off. Otherwise a long press only re-enumerates MediaStore and can retain stale metadata.
        val effectiveDeepRescan = fullRescan || (deepRescan && deepMetadataEnabled)
        if (effectiveDeepRescan) {
            clearScanMetadataCaches()
            if (fullRescan) snapshotManager.clearLibraryCache()
        }

        var finalSummary: MusicScanSummary? = null

        TwoStageScanCoordinator.scan(
            context = context,
            scanner = scanner,
            minDurationMs = minDurationMs,
            includeFolders = includeFolders,
            excludeFolders = excludeFolders,
            filesystemFallbackFolders = filesystemFallbackFolders,
            filterVideoFiles = filterVideoFiles,
            refreshMediaStore = refreshMediaStore,
            deepMetadataEnabled = effectiveDeepRescan,
            forceClearCache = fullRescan,
            previousSongs = previousSongs,
            folderNameAsAlbumWhenMissing = folderNameAsAlbumWhenMissingEnabled,
            enrichSong = { song -> song.withRepositoryTags() }
        ).collect { event ->
            when (event) {
                is TwoStageScanEvent.Started -> {
                    scanProgressState.start()
                }
                is TwoStageScanEvent.QuickProgress -> {
                    scanProgressState.update(event.scanned)
                }
                is TwoStageScanEvent.QuickCompleted -> {
                    if (!isCurrentLibrarySnapshotLoad(generation)) return@collect
                    val songs = event.songs
                    val preservePreviousLibrary = !fullRescan && songs.isEmpty() && previousSongs.isNotEmpty()
                    val resolvedQuickSongs = if (preservePreviousLibrary) previousSongs else songs
                    val albums = resolvedQuickSongs.toAlbums()
                    if (!publishLibrarySnapshot(generation, resolvedQuickSongs)) return@collect
                    scanProgressState.update(resolvedQuickSongs.size)
                    libraryCacheStore.saveLibraryCacheTo(
                        libraryCacheStore.libraryCacheFile,
                        resolvedQuickSongs,
                        albums
                    )
                    AppLogStore.info(
                        context,
                        "MusicScanner",
                        "Stage 1 (Quick) completed: found=${resolvedQuickSongs.size} in ${event.timeMs}ms",
                        AppLogType.LIBRARY
                    )
                }
                is TwoStageScanEvent.EnrichBatchCompleted -> {
                    if (!isCurrentLibrarySnapshotLoad(generation)) return@collect
                    val currentSongs = _songs.value
                    val batchMap = event.enrichedBatch.associateBy { it.path }
                    val updatedSongs = currentSongs.map { song -> batchMap[song.path] ?: song }
                    if (!publishLibrarySnapshot(generation, updatedSongs)) return@collect
                    scanProgressState.update(event.processed)
                }
                is TwoStageScanEvent.EnrichProgress -> {
                    scanProgressState.update(event.processed)
                }
                is TwoStageScanEvent.FullyCompleted -> {
                    if (!isCurrentLibrarySnapshotLoad(generation)) return@collect
                    val preservePreviousLibrary = !fullRescan && event.allSongs.isEmpty() && previousSongs.isNotEmpty()
                    val resolvedSongs = if (preservePreviousLibrary) previousSongs else event.allSongs
                    if (preservePreviousLibrary) {
                        AppLogStore.warn(
                            context,
                            "MusicScanner",
                            "Ignoring unexpected empty incremental scan and preserving ${previousSongs.size} cached songs",
                            type = AppLogType.LIBRARY
                        )
                    }
                    val albums = resolvedSongs.toAlbums()
                    if (!publishLibrarySnapshot(generation, resolvedSongs)) return@collect
                    val clearedRatingSnapshots = snapshotManager.clearMissingFileSnapshots(resolvedSongs.map { it.path }.toSet())
                    libraryCacheStore.saveLibraryCacheTo(
                        libraryCacheStore.libraryCacheFile,
                        resolvedSongs,
                        albums
                    )
                    libraryCacheStore.saveLocalScanBaseline(resolvedSongs, albums)

                    val summary = if (preservePreviousLibrary) {
                        MusicScanSummary(total = resolvedSongs.size)
                    } else {
                        buildFullScanSummary(previousSongs, resolvedSongs, fullRescan = fullRescan)
                            .copy(total = resolvedSongs.size)
                    }
                    finalSummary = summary
                    AppLogStore.info(
                        context,
                        "MusicScanner",
                        "Scan finished mode=$mode songs=${resolvedSongs.size} albums=${albums.size} added=${summary.added} removed=${summary.deleted} updated=${summary.updated} ratingSnapshotsCleared=$clearedRatingSnapshots preservedPrevious=$preservePreviousLibrary totalTime=${event.totalTimeMs}ms cacheHits=${event.cacheHits} enriched=${event.enrichedCount}",
                        AppLogType.LIBRARY
                    )
                }
                is TwoStageScanEvent.Error -> {
                    AppLogStore.warn(
                        context,
                        "MusicScanner",
                        "TwoStageScan error: ${event.message}",
                        type = AppLogType.LIBRARY
                    )
                }
            }
        }
        finalSummary ?: MusicScanSummary(total = _songs.value.size)
    }

    /**
     * Scan USB folders via SAF and merge the results into the current library.
     */
    suspend fun scanUsbFolders(
        usbUris: List<android.net.Uri>,
        minDurationMs: Long = 0,
        deepMetadata: Boolean = false
    ): MusicScanSummary {
        currentCoroutineContext().ensureActive()
        if (usbUris.isEmpty()) return MusicScanSummary(total = _songs.value.size)
        if (settingsManager.librarySource.first() != SettingsManager.LIBRARY_SOURCE_LOCAL) {
            return MusicScanSummary(total = _songs.value.size)
        }
        val generation = librarySnapshotGeneration.get()
        val existingSongs = _songs.value
        val existingPaths = existingSongs.map { it.path }.toSet()
        val usbSongs = mutableListOf<Song>()
        for (uri in usbUris) {
            val accessible = scanner.isUsbUriAccessible(uri)
            if (!accessible) {
                AppLogStore.info(
                    context,
                    "MusicScanner",
                    "USB URI not accessible, skipping: $uri",
                    AppLogType.LIBRARY
                )
                continue
            }
            val found = scanner.scanUsbFolder(
                treeUri = uri,
                minDurationMs = minDurationMs,
                deepMetadata = deepMetadata
            ) { count -> scanProgressState.update(count) }
            usbSongs.addAll(found.filter { it.path !in existingPaths })
        }
        if (usbSongs.isNotEmpty()) {
        currentCoroutineContext().ensureActive()
        val merged = existingSongs + usbSongs
            if (!publishLibrarySnapshot(generation, merged)) {
                return MusicScanSummary(total = _songs.value.size)
            }
            libraryCacheStore.saveLibraryCacheTo(
                libraryCacheStore.libraryCacheFile,
                merged,
                merged.toAlbums()
            )
            AppLogStore.info(
                context,
                "MusicScanner",
                "USB scan finished: ${usbSongs.size} new songs from ${usbUris.size} folders, total=${merged.size}",
                AppLogType.LIBRARY
            )
            return MusicScanSummary(total = merged.size, added = usbSongs.size)
        }
        return MusicScanSummary(total = _songs.value.size)
    }

    /**
     * Refreshes (re-scans) the songs within the given [folders] and **merges** the results into
     * the current library, rather than replacing the entire library. This is used by the
     * "文件夹歌单" (folder playlist) refresh action: only songs under the playlist's folders are
     * re-scanned for metadata/cover updates, and any newly-discovered songs in those folders are
     * added. Songs elsewhere in the library are left untouched.
     *
     * @return a summary of the refresh (added/updated counts).
     */
    suspend fun refreshFolders(
        folders: List<String>,
        minDurationMs: Long = 0,
        deepMetadata: Boolean = true,
        filterVideoFiles: Boolean = true
    ): MusicScanSummary = withContext(Dispatchers.IO) {
        val normalizedFolders = folders.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (normalizedFolders.isEmpty()) return@withContext MusicScanSummary(total = _songs.value.size)

        val previousSummarySongs = libraryCacheStore.readLocalScanBaselineSongs()
        val existingSongs = _songs.value
        val existingByPath = existingSongs.associateBy { it.path }
        val existingPaths = existingByPath.keys

        // Scan only the specified folders via two-stage concurrent coordinator
        var scannedSongs: List<Song> = emptyList()
        TwoStageScanCoordinator.scan(
            context = context,
            scanner = scanner,
            minDurationMs = minDurationMs,
            includeFolders = normalizedFolders,
            excludeFolders = emptyList(),
            filesystemFallbackFolders = normalizedFolders,
            filterVideoFiles = filterVideoFiles,
            deepMetadataEnabled = deepMetadata,
            forceClearCache = false,
            previousSongs = existingSongs,
            folderNameAsAlbumWhenMissing = folderNameAsAlbumWhenMissingEnabled,
            enrichSong = { song -> song.withRepositoryTags() }
        ).collect { event ->
            when (event) {
                is TwoStageScanEvent.QuickProgress -> scanProgressState.update(event.scanned)
                is TwoStageScanEvent.EnrichProgress -> scanProgressState.update(event.processed)
                is TwoStageScanEvent.FullyCompleted -> scannedSongs = event.allSongs
                else -> Unit
            }
        }

        val scannedByPath = scannedSongs.associateBy { it.path }

        // Build the merged library: keep all existing songs, but replace/update those whose path
        // falls within the scanned folders, and add any brand-new songs found.
        val merged = existingSongs.mapTo(ArrayList(existingSongs.size)) { existing ->
            val scanned = scannedByPath[existing.path]
            if (scanned != null) {
                scanned
            } else {
                existing
            }
        }
        // Add songs that are in the scanned folders but not already in the library.
        val newPathSongs = scannedSongs.filter { it.path !in existingPaths }
        if (newPathSongs.isNotEmpty()) {
            merged.addAll(newPathSongs)
        }

        val clearedRatingSnapshots = snapshotManager.clearMissingFileSnapshots(merged.map { it.path }.toSet())
        val normalizedFolderFilters = normalizedFolders.mapNotNull { it.normalizedLocalFolderPath() }
        val previousFolderSongs = previousSummarySongs.filter { song ->
            song.path.isAllowedByLocalFolderFilters(normalizedFolderFilters, excludeFolders = emptyList())
        }
        val currentFolderSongs = merged.filter { song ->
            song.path.isAllowedByLocalFolderFilters(normalizedFolderFilters, excludeFolders = emptyList())
        }
        val summary = buildLibraryDeltaSummary(previousFolderSongs, currentFolderSongs).copy(total = merged.size)
        val albums = merged.toAlbums()
        _songs.value = merged
        _albums.value = albums
        libraryCacheStore.saveLibraryCache(merged, albums)
        libraryCacheStore.saveLocalScanBaseline(merged, albums)
        AppLogStore.info(
            context,
            "MusicScanner",
            "Folder refresh finished: folders=${normalizedFolders.size} scanned=${scannedSongs.size} added=${summary.added} updated=${summary.updated} total=${merged.size}",
            AppLogType.LIBRARY
        )
        summary
    }

    private fun buildFullScanSummary(
        previousSongs: List<Song>,
        scannedSongs: List<Song>,
        fullRescan: Boolean
    ): MusicScanSummary = buildLibraryDeltaSummary(
        previousSongs = previousSongs,
        currentSongs = scannedSongs,
        fullRescan = fullRescan
    )

    private fun buildLibraryDeltaSummary(
        previousSongs: List<Song>,
        currentSongs: List<Song>,
        fullRescan: Boolean = false
    ): MusicScanSummary {
        val previousByKey = previousSongs.associateBy { it.scanSummaryKey() }
        val currentByKey = currentSongs.associateBy { it.scanSummaryKey() }
        val added = currentByKey.keys.count { it !in previousByKey }
        val deleted = previousByKey.keys.count { it !in currentByKey }
        val updated = currentByKey.count { (key, song) ->
            val previous = previousByKey[key]
            previous != null && previous.toScanSummaryInfo() != song.toScanSummaryInfo()
        }
        return MusicScanSummary(
            total = currentSongs.size,
            added = added,
            updated = updated,
            deleted = deleted,
            failed = 0,
            fullRescan = fullRescan
        )
    }

    suspend fun refreshSongAfterExternalEdit(song: Song): Song? = withContext(Dispatchers.IO) {
        if (song.path.isHttpAudioSource()) return@withContext null

        clearMetadataCache(song)
        scanEditedFile(song)
        delay(350)

        val updated = (querySystemSong(song) ?: song.withCurrentFileSnapshot())
            .withRepositoryTags()
            .withCurrentFileSnapshot()
        clearMetadataCache(updated)

        val currentSongs = _songs.value
        if (currentSongs.isNotEmpty()) {
            val nextSongs = currentSongs.map { existing ->
                if (existing.id == song.id || existing.path == song.path) updated else existing
            }
            _songs.value = nextSongs
            _albums.value = nextSongs.toAlbums()
            libraryCacheStore.saveLibraryCache(nextSongs, _albums.value)
        }
        updated
    }

    suspend fun loadCachedLibrary() = withContext(Dispatchers.IO) {
        val generation = beginLibrarySnapshotLoad()
        suspend fun applyCachedSongs(songs: List<Song>): Boolean {
            currentCoroutineContext().ensureActive()
            if (!isCurrentLibrarySnapshotLoad(generation)) return false
            val albums = songs.toAlbums()
            val published = synchronized(librarySnapshotLock) {
                if (librarySnapshotGeneration.get() != generation) {
                    false
                } else {
                    _songs.value = songs
                    _albums.value = albums
                    true
                }
            }
            if (!published) return false
            if (!hasLibraryCache(libraryCacheStore.localScanBaselineFile)) {
                libraryCacheStore.saveLocalScanBaseline(songs, albums)
            }
            return true
        }

        val primarySongs = if (hasLibraryCache(libraryCacheStore.libraryCacheFile)) {
            runCatching { readLibraryCacheSongs(libraryCacheStore.libraryCacheFile) }
                .onFailure { Log.w("MusicRepo", "Failed to load music library cache", it) }
                .getOrNull()
        } else {
            null
        }
        if (!primarySongs.isNullOrEmpty()) {
            applyCachedSongs(primarySongs)
            return@withContext
        }

        // If a service-process crash lands between the primary and baseline writes, the primary
        // cache can be a valid-but-empty snapshot while the baseline still has the last complete
        // library. Prefer that non-empty recovery snapshot, then heal the primary cache.
        val baselineSongs = if (hasLibraryCache(libraryCacheStore.localScanBaselineFile)) {
            runCatching { readLibraryCacheSongs(libraryCacheStore.localScanBaselineFile) }
                .onFailure { Log.w("MusicRepo", "Failed to restore local scan baseline", it) }
                .getOrNull()
        } else {
            null
        }
        if (!baselineSongs.isNullOrEmpty()) {
            currentCoroutineContext().ensureActive()
            val albums = baselineSongs.toAlbums()
            if (isCurrentLibrarySnapshotLoad(generation)) {
                val published = synchronized(librarySnapshotLock) {
                    if (librarySnapshotGeneration.get() != generation) {
                        false
                    } else {
                        _songs.value = baselineSongs
                        _albums.value = albums
                        true
                    }
                }
                if (published) {
                    libraryCacheStore.saveLibraryCacheTo(libraryCacheStore.libraryCacheFile, baselineSongs, albums)
                }
            }
        } else if (primarySongs != null) {
            applyCachedSongs(primarySongs)
        } else if (baselineSongs != null) {
            if (applyCachedSongs(baselineSongs)) {
                libraryCacheStore.saveLibraryCacheTo(
                    libraryCacheStore.libraryCacheFile,
                    baselineSongs,
                    baselineSongs.toAlbums()
                )
            }
        } else {
            publishLibrarySnapshot(generation, emptyList())
        }
    }

    /**
     * Load the whole library from a remote source (Navidrome / Emby / WebDAV) into [_songs] /
     * [_albums] so all the local library views (artist / album / genre / year …) work against
     * streamed songs.
     *
     * With [forceRefresh] = false a cached snapshot is loaded instantly (and only fetched over the
     * network when there is no cache); the library refresh button passes true to re-fetch. The
     * remote library is cached per-source so switching back is instant and works offline.
     */
    suspend fun loadRemoteLibrary(source: String, forceRefresh: Boolean): MusicScanSummary = withContext(Dispatchers.IO) {
        val generation = beginLibrarySnapshotLoad()
        refreshFolderAlbumSetting()
        if (!isCurrentLibrarySnapshotLoad(generation)) {
            return@withContext MusicScanSummary(total = _songs.value.size)
        }

        val cacheFile = libraryCacheStore.remoteLibraryCacheFile(source)
        val previousSongs = _songs.value.takeIf { it.isNotEmpty() }
            ?: runCatching { readLibraryCacheSongs(cacheFile) }.getOrDefault(emptyList())

        fun applyCache(): Boolean {
            if (!hasLibraryCache(cacheFile)) return false
            val cached = runCatching { readLibraryCacheSongs(cacheFile) }.getOrDefault(emptyList())
            if (cached.isEmpty()) return false
            return publishLibrarySnapshot(generation, cached)
        }

        if (source != SettingsManager.LIBRARY_SOURCE_NETEASE && !forceRefresh && applyCache()) {
            return@withContext MusicScanSummary(total = _songs.value.size)
        }
        if (!isCurrentLibrarySnapshotLoad(generation)) {
            return@withContext MusicScanSummary(total = _songs.value.size)
        }

        val remoteSongs = runCatching {
            when (source) {
                SettingsManager.LIBRARY_SOURCE_NETEASE -> {
                    com.ella.music.data.netease.NeteaseLibraryStore.getInstance(context).refresh(forceRefresh)
                }
                SettingsManager.LIBRARY_SOURCE_NAVIDROME -> {
                    val config = settingsManager.navidromeConfig.first()
                    if (!config.isConfigured) return@runCatching null
                    NavidromeService(context).listSongs(config) { page ->
                        // Publish partial pages so a multi-hour sync shows songs instead of a blank library.
                        val partial = page.map { it.song }
                        publishLibrarySnapshot(generation, partial)
                    }.map { it.song }
                }
                SettingsManager.LIBRARY_SOURCE_OPENSUBSONIC -> {
                    val config = settingsManager.openSubsonicConfig.first()
                    if (!config.isConfigured) return@runCatching null
                    NavidromeService(context).listSongs(config) { page ->
                        val partial = page.map { it.song }
                        publishLibrarySnapshot(generation, partial)
                    }.map { it.song }
                }
                SettingsManager.LIBRARY_SOURCE_EMBY -> {
                    val config = settingsManager.embyConfig.first()
                    if (!config.isConfigured) return@runCatching null
                    EmbyService(context).listSongs(config).map { it.song }
                }
                SettingsManager.LIBRARY_SOURCE_WEBDAV -> {
                    val config = loadWebDavConfig(settingsManager) ?: return@runCatching null
                    listWebDavLibrarySongs(config, forceRefresh = forceRefresh) { publishLibrarySnapshot(generation, it) }
                }
                SettingsManager.LIBRARY_SOURCE_FTP, SettingsManager.LIBRARY_SOURCE_SFTP -> {
                    if (settingsManager.transferLibraryConfig(source).first().url.isBlank()) return@runCatching null
                    val account = com.ella.music.data.ftp.transferAccount(context, source)
                    com.ella.music.data.ftp.transferSession(account).use { session ->
                        com.ella.music.data.remote.scanRemoteFileLibrary(account.root.url(), list = { url ->
                            session.list(com.ella.music.data.ftp.TransferLocation.parse(url)).map { entry ->
                                com.ella.music.data.remote.RemoteFileLibraryEntry(entry.location.url(), entry.directory,
                                    entry.takeIf { !it.directory && WebDavClient.isAudioFile(it.name) }?.toSong())
                            }
                        }, onSongs = { publishLibrarySnapshot(generation, it) })
                    }
                }
                SettingsManager.LIBRARY_SOURCE_SMB -> {
                    if (settingsManager.smbUrl.first().isBlank()) return@runCatching null
                    val account = com.ella.music.data.smb.smbAccount(context)
                    com.ella.music.data.smb.SmbSession(account).use { session ->
                        com.ella.music.data.remote.scanRemoteFileLibrary(account.root.url(), list = { url ->
                            session.list(com.ella.music.data.smb.SmbLocation.parse(url)).map { entry ->
                                com.ella.music.data.remote.RemoteFileLibraryEntry(entry.location.url(), entry.directory,
                                    entry.takeIf { !it.directory && WebDavClient.isAudioFile(it.name) }?.toLibrarySong())
                            }
                        }, onSongs = { publishLibrarySnapshot(generation, it) })
                    }
                }
                else -> return@withContext MusicScanSummary(total = _songs.value.size)
            }
        }.getOrElse { error ->
            if (error is CancellationException) throw error
            Log.w("MusicRepo", "Failed to load remote library ($source)", error)
            // Never wipe a usable in-memory / on-disk library after a failed huge sync —
            // that left users on a blank library (and a subsequent cold start could hang
            // retrying the same multi-GB Navidrome pull).
            if (!applyCache() && previousSongs.isEmpty()) {
                Log.w("MusicRepo", "No remote cache/previous songs to keep after failure ($source)")
            } else if (_songs.value.isEmpty() && previousSongs.isNotEmpty()) {
                publishLibrarySnapshot(generation, previousSongs)
            }
            return@withContext MusicScanSummary(total = _songs.value.size)
        } ?: run {
            // Not configured yet — fall back to any cache; keep whatever is already loaded.
            if (!applyCache() && previousSongs.isEmpty()) {
                Log.w("MusicRepo", "Remote source not configured and no cache ($source)")
            } else if (_songs.value.isEmpty() && previousSongs.isNotEmpty()) {
                publishLibrarySnapshot(generation, previousSongs)
            }
            return@withContext MusicScanSummary(total = _songs.value.size)
        }

        currentCoroutineContext().ensureActive()
        if (!publishLibrarySnapshot(generation, remoteSongs)) {
            return@withContext MusicScanSummary(total = _songs.value.size)
        }
        libraryCacheStore.saveLibraryCacheTo(cacheFile, remoteSongs, remoteSongs.toAlbums())
        buildLibraryDeltaSummary(previousSongs, remoteSongs)
    }

    private suspend fun listWebDavLibrarySongs(config: WebDavConfig, forceRefresh: Boolean, onSongs: (List<Song>) -> Unit): List<Song> {
        if (forceRefresh) WebDavClient.clearListCache()
        val songs = com.ella.music.data.remote.scanRemoteFileLibrary(WebDavClient.normalizeFileUrl(config.url.trim()),
            list = { url -> WebDavClient.list(config, url, forceRefresh = forceRefresh).map { item ->
                com.ella.music.data.remote.RemoteFileLibraryEntry(WebDavClient.normalizeFileUrl(item.url), item.isDirectory,
                    item.takeIf { !it.isDirectory && WebDavClient.isAudioFile(it.name) }?.toWebDavLibrarySong())
            } }, onSongs = onSongs)
        return if (songs.size <= WEBDAV_EAGER_METADATA_LIMIT) {
            songs.map { it.withRepositoryTags(allowFullDownload = false) }
        } else {
            songs.map { song ->
                if (song.hasUsableWebDavMetadataCache(remoteAudioCacheDir, remoteMetadataHeaderCacheDir)) {
                    song.withRepositoryTags(allowFullDownload = false)
                } else {
                    song.withFinalLibraryFallbacks()
                }
            }
        }
    }

    private fun com.ella.music.data.webdav.WebDavItem.toWebDavLibrarySong(): Song {
        val playbackUrl = WebDavClient.normalizeFileUrl(url)
        val fileName = name.ifBlank { playbackUrl.substringBefore('?').substringBefore('#').substringAfterLast('/') }
        val title = fileName.substringBeforeLast('.', fileName).ifBlank { fileName }
        val parentAlbum = runCatching {
            java.net.URI(playbackUrl).path
                .trimEnd('/')
                .substringBeforeLast('/', "")
                .substringAfterLast('/')
                .ifBlank { "WebDAV" }
        }.getOrDefault("WebDAV")
        return Song(
            id = stableRemoteSongId("webdav:$playbackUrl"),
            title = title,
            artist = "",
            album = parentAlbum,
            albumId = 0L,
            duration = 0L,
            path = playbackUrl,
            fileName = fileName,
            fileSize = size,
            mimeType = mimeType.substringBefore(';').trim().lowercase(),
            dateAdded = System.currentTimeMillis(),
            dateModified = 0L
        )
    }

    private fun stableRemoteSongId(key: String): Long {
        val value = key.hashCode().toLong()
        return if (value == Long.MIN_VALUE) 1L else kotlin.math.abs(value).takeIf { it != 0L } ?: 1L
    }

    private suspend fun neteaseLyricsSong(song: Song): Song =
        if (song.onlineSource == SettingsManager.LIBRARY_SOURCE_NETEASE)
            com.ella.music.data.netease.NeteaseLibraryStore.getInstance(context).lyrics(song)
        else song

    suspend fun getLyrics(
        song: Song,
        sourceMode: Int = SettingsManager.LYRIC_SOURCE_AUTO
    ): List<LyricLine> = lyricsManager.getLyrics(neteaseLyricsSong(song), sourceMode)

    suspend fun reloadLyrics(song: Song, sourceMode: Int): List<LyricLine> = lyricsManager.reloadLyrics(neteaseLyricsSong(song), sourceMode)

    suspend fun getLyricFormatAvailability(song: Song): LyricFormatAvailability = lyricsManager.getLyricFormatAvailability(song)

    suspend fun reloadLyricsByFormat(song: Song, preferTtml: Boolean): List<LyricLine> = lyricsManager.reloadLyricsByFormat(song, preferTtml)

    fun getReplayGain(song: Song, mode: Int = SettingsManager.REPLAY_GAIN_AUTO): Float? =
        audioInfoProvider.getReplayGain(song, mode)

    fun getCachedReplayGain(song: Song, mode: Int = SettingsManager.REPLAY_GAIN_AUTO): Float? =
        audioInfoProvider.getCachedReplayGain(song, mode)

    fun getAudioInfo(song: Song): AudioInfo = audioInfoProvider.getAudioInfo(song)
    fun getAudioQualityInfo(song: Song): AudioInfo = audioInfoProvider.getAudioQualityInfo(song)
    val audioQualityRevision: Long get() = audioInfoProvider.qualityRevision

    /** Cached tag info only; never touches the file (safe on the main thread). */
    fun peekSongTagInfo(song: Song): SongTagInfo? = tagInfoCache[song.metadataCacheKey()]

    fun getSongTagInfo(song: Song): SongTagInfo {
        if (song.onlineSource == "netease" && song.onlineId.isNotBlank()) {
            return SongTagInfo(neteaseKey = org.json.JSONObject()
                .put("musicId", song.onlineId).put("musicName", song.title)
                .put("mvId", song.onlineMvId).put("albumId", kotlin.math.abs(song.albumId))
                .put("albumName", song.album).toString())
        }
        val cacheKey = song.metadataCacheKey()
        tagInfoCache[cacheKey]?.let { return it }
        val info = runCatching {
            audioTagRepository.readTagsBlocking(song.effectiveLocalPathForMetadata())?.toSongTagInfo() ?: SongTagInfo()
        }.getOrElse {
            Log.w("MusicRepo", "Failed to read tag info for ${song.path}", it)
            SongTagInfo()
        }
        // A WebDAV song may be inspected before its metadata window arrives. Do not pin an empty
        // tag result under the stable song key; the later background hydration must be observable.
        if (!song.isFileLibraryRemoteSong() || song.effectiveLocalPathForMetadata() != song.path || info != SongTagInfo()) {
            tagInfoCache[cacheKey] = info
        }
        return info
    }

    fun getCachedSongTagInfo(song: Song): SongTagInfo? =
        tagInfoCache[song.metadataCacheKey()]

    private fun resolveSongRatingFromTags(song: Song): Int =
        runCatching { getSongTagInfo(song).rating.coerceIn(0, 5) }
            .getOrElse {
                Log.w("MusicRepo", "Failed to resolve rating for ${song.path}", it)
                0
            }

    suspend fun songMatchesSearchSnapshot(
        song: Song,
        query: String,
        includeFullTags: Boolean = true
    ): Boolean = searchCoordinator.songMatchesSearchSnapshot(song, query, includeFullTags)

    suspend fun filterSongsBySearchSnapshot(
        songs: List<Song>,
        query: String,
        includeFullTags: Boolean = true
    ): List<Song> = searchCoordinator.filterSongsBySearchSnapshot(songs, query, includeFullTags)

    suspend fun getSongSearchText(song: Song): String =
        snapshotManager.getSongSearchText(song)

    suspend fun preloadLibrarySearchSnapshot(
        songs: List<Song>,
        refreshExisting: Boolean = false
    ) = snapshotManager.preloadSearchSnapshot(songs, refreshExisting)

    suspend fun preloadSongTagInfos(songs: List<Song>) = withContext(Dispatchers.IO) {
        songs.forEach(::getSongTagInfo)
    }

    suspend fun clearLibrarySnapshotCache() = withContext(Dispatchers.IO) {
        snapshotManager.clearLibraryCache()
    }

    fun getSongRating(song: Song): Int {
        snapshotManager.getFreshSongRating(song)?.let { return it }
        val resolved = resolveSongRatingFromTags(song)
        snapshotManager.updateRatingSnapshot(song, resolved, trustedLocalWrite = false)
        return resolved
    }

    suspend fun preloadSongRatings(songs: List<Song>) = withContext(Dispatchers.IO) {
        snapshotManager.preloadSongRatings(songs, ::resolveSongRatingFromTags)
        snapshotManager.saveAll()
    }

    suspend fun writeSongRating(song: Song, rating: Int): Result<Song?> = withContext(Dispatchers.IO) {
        val safeRating = rating.coerceIn(0, 5)
        val result = try {
            tagWriter.writeSongTags(
                song,
                AudioTagInfo(rating = safeRating)
            )
        } catch (e: SecurityException) {
            val sender = tagWriter.createWritePermissionIntentSender(song)
                ?: return@withContext Result.failure(e)
            return@withContext Result.failure(WritePermissionRequiredException(sender))
        }
        tagWriter.writePermissionRequestIfNeeded(result, song)?.let { return@withContext it }
        result.map {
            val immediate = updateSongAfterLocalTagWrite(song)
            snapshotManager.updateRatingSnapshot(immediate, safeRating)
            val refreshed = refreshSongAfterExternalEdit(immediate) ?: immediate
            snapshotManager.updateRatingSnapshot(refreshed, safeRating)
            snapshotManager.saveAll()
            refreshed
        }
    }

    suspend fun writeCategoryTagForBatch(song: Song, key: String, value: String): Result<Song> = withContext(Dispatchers.IO) {
        val result = try {
            tagWriter.writeSongTags(song, AudioTagInfo(customTags = mapOf(key to listOf(value))))
        } catch (error: SecurityException) { Result.failure(error) }
        tagWriter.writePermissionRequestIfNeeded(result, song)?.exceptionOrNull()?.let {
            return@withContext Result.failure(it)
        }
        result.map {
            clearMetadataCache(song)
            scanEditedFile(song)
            song.withCurrentFileSnapshot().withRepositoryTags().withCurrentFileSnapshot()
        }
    }

    suspend fun publishCategoryTagEdits(edited: List<Song>) = withContext(Dispatchers.IO) {
        if (edited.isEmpty()) return@withContext
        val updates = edited.associateBy { it.path }
        val next = synchronized(librarySnapshotLock) {
            _songs.value.map { updates[it.path] ?: it }.also {
                _songs.value = it
                _albums.value = it.toAlbums()
            }
        }
        libraryCacheStore.saveLibraryCache(next, next.toAlbums())
    }

    /** One-time backfill for libraries saved before arbitrary tags were cached. */
    suspend fun hydrateCustomCategoryTags() = withContext(Dispatchers.IO) {
        val candidates = _songs.value.filter { !it.customTagsLoaded &&
            (it.path.startsWith("/") || it.path.startsWith("content://") || it.path.startsWith("file://")) }
        val updates = candidates.map { song ->
            currentCoroutineContext().ensureActive()
            song.withRepositoryTags().copy(customTagsLoaded = true)
        }
        if (updates.isNotEmpty()) publishCategoryTagEdits(updates)
    }

    suspend fun writeSongCustomTag(song: Song, key: String, value: String): Result<Song?> = withContext(Dispatchers.IO) {
        val tagKey = key.trim()
        if (tagKey.isBlank()) {
            return@withContext Result.failure(IllegalArgumentException("Tag name is blank"))
        }
        val result = try {
            tagWriter.writeSongTags(
                song,
                AudioTagInfo(customTags = mapOf(tagKey to listOf(value)))
            )
        } catch (e: SecurityException) {
            val sender = tagWriter.createWritePermissionIntentSender(song)
                ?: return@withContext Result.failure(e)
            return@withContext Result.failure(WritePermissionRequiredException(sender))
        }
        tagWriter.writePermissionRequestIfNeeded(result, song)?.let { return@withContext it }
        result.map {
            val immediate = updateSongAfterLocalTagWrite(song)
            refreshSongAfterExternalEdit(immediate) ?: immediate
        }
    }

    suspend fun writeSongMetadata(song: Song, tags: AudioTagInfo): Result<Song?> = withContext(Dispatchers.IO) {
        val result = try {
            tagWriter.writeSongTags(song, tags)
        } catch (e: SecurityException) {
            val sender = tagWriter.createWritePermissionIntentSender(song)
                ?: return@withContext Result.failure(e)
            return@withContext Result.failure(WritePermissionRequiredException(sender))
        }
        tagWriter.writePermissionRequestIfNeeded(result, song)?.let { return@withContext it }
        result.map {
            val immediate = updateSongAfterLocalTagWrite(song)
            val refreshed = refreshSongAfterExternalEdit(immediate) ?: immediate
            tags.rating?.let { rating ->
                snapshotManager.updateRatingSnapshot(refreshed, rating.coerceIn(0, 5))
                snapshotManager.saveAll()
            }
            refreshed
        }
    }

    suspend fun writeSongEmbeddedCover(song: Song, cover: AudioCoverInfo?): Result<Song?> = withContext(Dispatchers.IO) {
        val result = try {
            tagWriter.writeSongCover(song, cover)
        } catch (e: SecurityException) {
            val sender = tagWriter.createWritePermissionIntentSender(song)
                ?: return@withContext Result.failure(e)
            return@withContext Result.failure(WritePermissionRequiredException(sender))
        }
        tagWriter.writePermissionRequestIfNeeded(result, song)?.let { return@withContext it }
        result.map {
            val immediate = updateSongAfterLocalTagWrite(song)
            refreshSongAfterExternalEdit(immediate) ?: immediate
        }
    }

    suspend fun updateSongModifiedTime(song: Song, modifiedAtMs: Long): Boolean = withContext(Dispatchers.IO) {
        val file = File(song.path)
        if (!file.isFile) return@withContext false
        val applied = applyFileLastModified(file, modifiedAtMs) ||
            updateMediaStoreDateModified(song, modifiedAtMs)
        if (!applied) return@withContext false
        val fileMs = file.lastModified()
        val resolvedMs = if (fileLastModifiedMatches(fileMs, modifiedAtMs)) fileMs else modifiedAtMs
        val updated = song.copy(dateModified = resolvedMs)
        val currentSongs = _songs.value
        if (currentSongs.isNotEmpty()) {
            val nextSongs = currentSongs.map { existing ->
                if (existing.id == song.id || existing.path == song.path) updated else existing
            }
            _songs.value = nextSongs
            _albums.value = nextSongs.toAlbums()
            libraryCacheStore.saveLibraryCache(nextSongs, _albums.value)
        }
        true
    }

    private fun applyFileLastModified(file: File, modifiedAtMs: Long): Boolean {
        runCatching { invokeOsUtimes(file.absolutePath, modifiedAtMs) }
        if (fileLastModifiedMatches(file.lastModified(), modifiedAtMs)) return true
        runCatching { file.setLastModified(modifiedAtMs) }
        return fileLastModifiedMatches(file.lastModified(), modifiedAtMs)
    }

    private fun invokeOsUtimes(path: String, modifiedAtMs: Long) {
        val timevalClass = Class.forName("android.system.StructTimeval")
        val timeval = timevalClass
            .getMethod("fromMillis", Long::class.javaPrimitiveType)
            .invoke(null, modifiedAtMs)
        val times = java.lang.reflect.Array.newInstance(timevalClass, 2)
        java.lang.reflect.Array.set(times, 0, timeval)
        java.lang.reflect.Array.set(times, 1, timeval)
        Class.forName("android.system.Os")
            .getMethod("utimes", String::class.java, times.javaClass)
            .invoke(null, path, times)
    }

    private fun updateMediaStoreDateModified(song: Song, modifiedAtMs: Long): Boolean {
        val values = android.content.ContentValues().apply {
            put(android.provider.MediaStore.MediaColumns.DATE_MODIFIED, modifiedAtMs / 1000L)
        }
        val byId = runCatching {
            val uri = android.content.ContentUris.withAppendedId(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                song.id
            )
            context.contentResolver.update(uri, values, null, null)
        }.getOrDefault(0)
        if (byId > 0) return true
        return runCatching {
            context.contentResolver.update(
                android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                values,
                "${android.provider.MediaStore.MediaColumns.DATA}=?",
                arrayOf(song.path)
            )
        }.getOrDefault(0) > 0
    }

    private fun fileLastModifiedMatches(actualMs: Long, expectedMs: Long): Boolean =
        kotlin.math.abs(actualMs - expectedMs) < 2_000L

    private suspend fun updateSongAfterLocalTagWrite(song: Song): Song = withContext(Dispatchers.IO) {
        clearMetadataCache(song)
        val updated = song.withCurrentFileSnapshot()
            .withRepositoryTags()
            .withCurrentFileSnapshot()
        val currentSongs = _songs.value
        if (currentSongs.isNotEmpty()) {
            val nextSongs = currentSongs.map { existing ->
                if (existing.id == song.id || existing.path == song.path) updated else existing
            }
            _songs.value = nextSongs
            _albums.value = nextSongs.toAlbums()
            libraryCacheStore.saveLibraryCache(nextSongs, _albums.value)
        }
        updated
    }

    private fun Song.withCurrentFileSnapshot(): Song {
        if (path.isHttpAudioSource()) return this
        val file = File(path)
        if (!file.exists()) return copy(dateModified = System.currentTimeMillis())
        return copy(
            fileSize = file.length().takeIf { it > 0L } ?: fileSize,
            dateModified = file.lastModified().takeIf { it > 0L } ?: System.currentTimeMillis()
        )
    }

    fun getFullAudioTagInfo(song: Song): AudioTagInfo? {
        return runCatching {
            audioTagRepository.readTagsBlocking(song.effectiveLocalPathForMetadata())
        }.getOrNull()
    }

    fun getCoverArt(song: Song): ByteArray? = coverArtManager.getCoverArt(song)

    fun getOriginalCoverModel(song: Song): Any? = coverArtManager.getOriginalCoverModel(song)

    fun getArtistCoverModel(song: Song): Any? = coverArtManager.getArtistCoverModel(song)

    fun getCoverArtBitmap(
        song: Song,
        maxSize: Int = 512,
        usage: CoverUsage = CoverUsage.ListThumbnail
    ): Bitmap? = coverArtManager.getCoverArtBitmap(song, maxSize, usage)

    fun getAlbumArtUri(albumId: Long): Uri? = coverArtManager.getAlbumArtUri(albumId)

    fun getSongsForAlbum(albumId: Long): List<Song> {
        return _songs.value
            .filter { it.albumIdentityId() == albumId }
            .sortedWith(
                compareBy<Song> { it.discNumber <= 0 && it.trackNumber <= 0 }
                    .thenBy { if (it.discNumber > 0) it.discNumber else Int.MAX_VALUE }
                    .thenBy { if (it.trackNumber > 0) it.trackNumber else Int.MAX_VALUE }
                    .thenBy { it.title.lowercase() }
                    .thenBy { it.id }
            )
    }

    suspend fun deleteSongs(songs: Collection<Song>): Int = withContext(Dispatchers.IO) {
        var deleted = 0
        val deletedSongs = mutableListOf<Song>()
        val mediaStoreUrisNeedingPermission = mutableListOf<Uri>()

        songs.forEach { song ->
            if (tryDeleteSongDirect(song)) {
                deleted++
                deletedSongs += song
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                song.mediaStoreDeleteUriOrNull()?.let { mediaStoreUrisNeedingPermission += it }
            }
        }

        if (deletedSongs.isNotEmpty()) {
            removeDeletedSongsFromState(deletedSongs)
        }

        if (mediaStoreUrisNeedingPermission.isNotEmpty()) {
            val request = MediaStore.createDeleteRequest(context.contentResolver, mediaStoreUrisNeedingPermission.distinct())
            throw WritePermissionRequiredException(request.intentSender)
        }

        deleted
    }

    private fun tryDeleteSongDirect(song: Song): Boolean {
        if (song.onlineSource.isNotBlank()) return false
        val path = song.path.trim()
        if (path.isContentAudioSource()) {
            val uri = Uri.parse(path)
            val documentDeleted = runCatching {
                DocumentFile.fromSingleUri(context, uri)?.delete() == true
            }.getOrDefault(false)
            if (documentDeleted) return true
            return runCatching { context.contentResolver.delete(uri, null, null) > 0 }.getOrDefault(false)
        }

        val fileDeleted = runCatching {
            val file = File(path)
            file.exists() && file.delete()
        }.getOrDefault(false)
        if (fileDeleted) return true

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R && song.id > 0L) {
            return runCatching {
                val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
                context.contentResolver.delete(uri, null, null) > 0
            }.getOrDefault(false)
        }

        return false
    }

    private fun Song.mediaStoreDeleteUriOrNull(): Uri? {
        if (onlineSource.isNotBlank() || id <= 0L) return null
        if (path.isContentAudioSource() && !path.isMediaStoreContentAudioSource()) {
            return null
        }
        return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    }

    private suspend fun removeDeletedSongsFromState(deletedSongs: Collection<Song>) {
        val deletedKeys = deletedSongs.map { it.deleteIdentityKey() }.toSet()
        val deletedIds = deletedSongs.map { it.id }.filter { it > 0L }.toSet()
        _songs.value = _songs.value.filterNot { song ->
            (song.id > 0L && song.id in deletedIds) || song.deleteIdentityKey() in deletedKeys
        }
        _albums.value = _songs.value.toAlbums()
        libraryCacheStore.saveLibraryCache(_songs.value, _albums.value)
    }

    private fun Song.deleteIdentityKey(): String = "$id|$path"

    suspend fun removeSongsFromLibrary(songs: Collection<Song>): Unit = withContext(Dispatchers.IO) {
        if (songs.isEmpty()) return@withContext
        removeDeletedSongsFromState(songs)
    }

    /** Rebuilds album identities after a grouping rule changes without scanning media again. */
    suspend fun rebuildAlbumAggregation() {
        val aggregationGeneration = albumAggregationGeneration.incrementAndGet()
        val currentSongs = _songs.value
        val rebuiltAlbums = withContext(Dispatchers.Default) {
            currentSongs.toAlbums()
        }
        // Settings flows emit immediately at startup. If their aggregation began while the
        // in-memory list was still empty, do not let that stale result overwrite the cache that
        // finished restoring in the meantime. The generation check also prevents an older
        // grouping-rule calculation from winning a later settings update for the same song list.
        if (albumAggregationGeneration.get() == aggregationGeneration && _songs.value === currentSongs) {
            _albums.value = rebuiltAlbums
        }
    }

    fun clearCache() {
        lyricsManager.clearCache()
        coverArtManager.clearCache()
        snapshotManager.clearCache()
        audioTagRepository.clearCache()
        audioInfoProvider.clearCache()
        tagInfoCache.clear()
        webDavMetadataWindowAttempts.clear()
    }

    private fun clearScanMetadataCaches() {
        lyricsManager.clearCache()
        coverArtManager.clearCache()
        audioTagRepository.clearCache()
        audioInfoProvider.clearCache()
        tagInfoCache.clear()
    }

    /** Drops only cached lyrics/format availability, e.g. after an external sidecar was written. */
    fun clearLyricsCache(song: Song) {
        lyricsManager.clearMetadataCache(song)
    }

    fun clearMetadataCache(song: Song) {
        lyricsManager.clearMetadataCache(song)
        coverArtManager.clearMetadataCache(song)
        snapshotManager.clearMetadataCache(song)
        val metadataPrefix = "${song.metadataCachePrefix()}:"
        audioInfoProvider.clearMetadataCache(metadataPrefix)
        com.ella.music.ui.analytics.invalidateLibraryAnalysisCache(context)
        tagInfoCache.removeKeysMatching { it.startsWith(metadataPrefix) || it.startsWith("${song.id}:") }
        audioTagRepository.clear(song.effectiveLocalPathForMetadataBlocking(settingsManager, httpClient, remoteAudioCacheDir, remoteMetadataHeaderCacheDir))
        if (song.isWebDavRemoteSong()) {
            val headerCache = song.webDavHeaderCacheFile(remoteMetadataHeaderCacheDir)
            headerCache.delete()
            WebDavClient.clearFlacMetadataCacheMarker(headerCache)
            song.webDavFullCacheFile(remoteAudioCacheDir).delete()
        }
    }

    fun clearRemoteMetadataCache() {
        clearCache()
        webDavMetadataWindowAttempts.clear()
        runCatching {
            if (remoteAudioCacheDir.exists()) {
                remoteAudioCacheDir.deleteRecursively()
            }
            if (remoteMetadataHeaderCacheDir.exists()) {
                remoteMetadataHeaderCacheDir.deleteRecursively()
            }
            RemoteAudioCache.clearAll()
        }.onFailure {
            Log.w("MusicRepo", "Failed to clear online metadata cache", it)
        }
    }

    fun clearRemoteAudioCache() {
        runCatching {
            if (remoteAudioCacheDir.exists()) {
                remoteAudioCacheDir.deleteRecursively()
                remoteAudioCacheDir.mkdirs()
            }
            RemoteAudioCache.clearAll()
            com.ella.music.data.netease.NeteaseStreamCache.clear(context)
            com.ella.music.data.netease.NeteaseLibraryStore.getInstance(context).clearServedQuality()
        }.onFailure {
            Log.w("MusicRepo", "Failed to clear remote audio cache", it)
        }
    }

    suspend fun localSearchSnapshot(): Pair<List<Song>, List<Album>> = withContext(Dispatchers.IO) {
        val localSongs = libraryCacheStore.readCachedSongs().filter { it.onlineSource.isBlank() }
        localSongs to localSongs.toAlbums()
    }

    suspend fun resolveSongForPlayback(song: Song): Song = withContext(Dispatchers.IO) {
        // Media3 resolves this stable URI at each open, including queue advance and seek.
        if (song.onlineSource == SettingsManager.LIBRARY_SOURCE_NETEASE) return@withContext song
        try {
            val fileSource = when {
                song.path.startsWith("smb://", true) -> SettingsManager.LIBRARY_SOURCE_SMB
                song.path.startsWith("sftp://", true) -> SettingsManager.LIBRARY_SOURCE_SFTP
                song.path.startsWith("ftp://", true) || song.path.startsWith("ftps://", true) -> SettingsManager.LIBRARY_SOURCE_FTP
                song.isWebDavRemoteSong() -> SettingsManager.LIBRARY_SOURCE_WEBDAV
                else -> null
            }
            val hadMetadata = fileSource == null || song.effectiveLocalPathForMetadata() != song.path
            if (RemoteAudioCache.localFileIfCached(song) == null) when (fileSource) {
                SettingsManager.LIBRARY_SOURCE_SMB -> com.ella.music.data.smb.SmbMetadataCache.metadataFile(context, song, allowNetwork = true)
                SettingsManager.LIBRARY_SOURCE_FTP, SettingsManager.LIBRARY_SOURCE_SFTP ->
                    com.ella.music.data.ftp.TransferMetadataCache.metadataFile(context, song, allowNetwork = true)
                SettingsManager.LIBRARY_SOURCE_WEBDAV -> {
                    try { song.ensureWebDavMetadataCached(allowFullDownload = false) }
                    finally { com.ella.music.data.remote.RemoteMetadataCachePolicy.trim(remoteMetadataHeaderCacheDir,
                        song.webDavHeaderCacheFile(remoteMetadataHeaderCacheDir).takeIf { it.isFile }) }
                }
            }
            val resolved = song.withRepositoryTags()
            if (fileSource != null) {
                val snapshot = _songs.value
                val index = snapshot.indexOfFirst { it.path == song.path }
                if (index >= 0 && snapshot[index] != resolved && _songs.value === snapshot) {
                    val enriched = snapshot.toMutableList().apply { set(index, resolved) }
                    _songs.value = enriched
                    val albums = enriched.toAlbums()
                    _albums.value = albums
                    libraryCacheStore.saveLibraryCacheTo(libraryCacheStore.remoteLibraryCacheFile(fileSource), enriched, albums)
                }
            }
            if (!hadMetadata && song.effectiveLocalPathForMetadata() != song.path) _webDavMetadataRevision.value += 1L
            resolved
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (error: Throwable) {
            Log.w("MusicRepo", "Failed to resolve playback song for ${song.path}", error)
            song
        }
    }

    fun trimRemoteMetadataCaches() {
        for (name in listOf("smb_metadata", "ftp_metadata", "webdav_metadata_headers")) {
            com.ella.music.data.remote.RemoteMetadataCachePolicy.trim(File(context.cacheDir, name))
        }
    }

    private fun Song.effectiveLocalPathForMetadata(allowFullDownload: Boolean = false): String {
        RemoteAudioCache.localFileIfCached(this)?.let { return it.absolutePath }
        if (path.startsWith("ftp://", true) || path.startsWith("ftps://", true) || path.startsWith("sftp://", true))
            return com.ella.music.data.ftp.TransferMetadataCache.metadataFile(context, this)?.absolutePath ?: path
        if (path.startsWith("smb://", true)) return com.ella.music.data.smb.SmbMetadataCache.metadataFile(context, this)?.absolutePath ?: path
        if (path.isContentAudioSource()) return path
        if (!isWebDavRemoteSong()) return path
        val fullCache = webDavFullCacheFile(remoteAudioCacheDir)
        if (fullCache.exists() && fullCache.length() > 0L) return fullCache.absolutePath
        val headerCache = webDavHeaderCacheFile(remoteMetadataHeaderCacheDir)
        if (headerCache.exists() && headerCache.length() > 0L) {
            val usable = when {
                isLikelyFlacAudio() -> WebDavClient.isFlacMetadataCacheUsable(headerCache, fileSize)
                supportsSparseWebDavMetadataWindow() -> fileSize <= 0L || headerCache.length() >= fileSize
                else -> false
            }
            if (usable) return headerCache.absolutePath
        }
        return path
    }

    private suspend fun Song.ensureWebDavMetadataCached(allowFullDownload: Boolean) {
        if (!isWebDavRemoteSong()) return
        val lock = webDavMetadataLocks.getOrPut(path) { Mutex() }
        lock.withLock {
            val fullCache = webDavFullCacheFile(remoteAudioCacheDir)
            val fullCacheIsUsable = fullCache.exists() && fullCache.length() > 0L &&
                (fileSize <= 0L || fullCache.length() == fileSize)
            if (fullCacheIsUsable) return@withLock

            val headerCache = webDavHeaderCacheFile(remoteMetadataHeaderCacheDir)
            val flacAudio = isLikelyFlacAudio()
            val sparseWindowSupported = supportsSparseWebDavMetadataWindow()
            if (!flacAudio && fileSize > com.ella.music.data.remote.RemoteMetadataCachePolicy.MAX_WINDOW_BYTES) return@withLock
            if (!flacAudio && !sparseWindowSupported && headerCache.exists()) {
                // Never pass an old partial/sparse cache for DSF/APE/DTS/etc. to native TagLib.
                // These formats need a complete file for reliable parsing.
                headerCache.delete()
                WebDavClient.clearFlacMetadataCacheMarker(headerCache)
                if (!allowFullDownload) return@withLock
            }
            val headerCacheIsUsable = headerCache.exists() && headerCache.length() > 0L &&
                if (flacAudio) {
                    WebDavClient.isFlacMetadataCacheUsable(headerCache, fileSize)
                } else if (sparseWindowSupported) {
                    fileSize <= 0L || headerCache.length() >= fileSize
                } else {
                    false
                }
            if (headerCacheIsUsable) return@withLock

            val config = loadWebDavConfig(settingsManager) ?: return@withLock
            val attemptKey = "$path:$fileSize"
            if (fileSize > 0L && (flacAudio || sparseWindowSupported) && webDavMetadataWindowAttempts.add(attemptKey)) {
                val window = try {
                    if (flacAudio) {
                        WebDavClient.downloadFlacMetadataPrefixToFileCancellable(
                            url = path,
                            config = config,
                            target = headerCache,
                            remoteSize = fileSize
                        )
                    } else {
                        WebDavClient.downloadMetadataWindowToFileCancellable(
                            url = path,
                            config = config,
                            target = headerCache,
                            remoteSize = fileSize
                        )
                    }
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: Throwable) {
                    Log.w("MusicRepo", "Failed to cache WebDAV metadata window for ${path.webDavSafeLogUrl()}", error)
                    null
                }
                if (window != null) return@withLock
            }

            if (!flacAudio && !sparseWindowSupported) {
                if (!allowFullDownload) return@withLock
                WebDavClient.downloadToFile(path, config, fullCache)
                return@withLock
            }

            // A partial head cache is still useful for non-FLAC tags when the server has no Range
            // support. FLAC must keep the contiguous-prefix marker, otherwise an old sparse or
            // truncated cache would be handed to the tag reader as if it were complete.
            if (!flacAudio && headerCache.exists() && headerCache.length() > 0L) return@withLock
            val header = WebDavClient.downloadHeaderToFileCancellable(path, config, headerCache)
            if (!flacAudio) {
                if (header != null || !allowFullDownload) return@withLock
                WebDavClient.downloadToFile(path, config, fullCache)
            } else {
                if (header != null && WebDavClient.isFlacMetadataCacheUsable(header, fileSize)) return@withLock
                if (!allowFullDownload) return@withLock
                WebDavClient.downloadToFile(path, config, fullCache)
            }
        }
    }

    private fun List<Song>.toAlbums(): List<Album> {
        return LibraryAlbumAggregator.toAlbums(this)
    }

    private fun Song.withRepositoryTags(allowFullDownload: Boolean = false): Song {
        val metadataPath = effectiveLocalPathForMetadata(allowFullDownload)
        val tagInfo = runCatching {
            audioTagRepository.readTagsBlocking(metadataPath)
        }.getOrElse { error ->
            Log.w("MusicRepo", "Failed to refresh library tags for $path", error)
            null
        }
        val wavMetadata = runCatching { WavMetadataReader.read(metadataPath) }
            .getOrNull()

        val mergedArtist = tagInfo?.artist.takeIf { it.isUsableArtistText() }
            ?: wavMetadata?.artist.takeIf { it.isUsableArtistText() }
            ?: artist.takeIf { it.isUsableArtistText() }
            ?: "Unknown Artist"
        val tagAlbum = tagInfo?.album.takeIf { it.isUsableAlbumText() }
            ?: wavMetadata?.album.takeIf { it.isUsableAlbumText() }
        val mergedAlbum = tagAlbum
            ?: album.takeIf { it.isUsableAlbumText() }
            ?: "" // withFinalLibraryFallbacks may substitute the parent folder (#655)
        val mergedAlbumArtist = tagInfo?.albumArtist.takeIf { it.isUsableArtistText() }
            ?: wavMetadata?.albumArtist.takeIf { it.isUsableArtistText() }
            ?: albumArtist.takeIf { it.isUsableArtistText() }
            ?: ""

        return copy(
            title = tagInfo?.title.takeIf { it.isUsableTagText() }
                ?: wavMetadata?.title.takeIf { it.isUsableTagText() }
                ?: title.takeIf { it.isUsableTagText() }
                ?: fileName.substringBeforeLast('.').ifBlank { path.substringAfterLast('/') },
            artist = mergedArtist,
            album = mergedAlbum,
            albumArtist = mergedAlbumArtist,
            genre = tagInfo?.genre.takeIf { it.isUsableTagText() } ?: wavMetadata?.genre.takeIf { it.isUsableTagText() } ?: genre,
            year = tagInfo?.year.takeIf { it.isUsableTagText() } ?: wavMetadata?.year.takeIf { it.isUsableTagText() } ?: year,
            composer = tagInfo?.composer.takeIf { it.isUsableTagText() } ?: wavMetadata?.composer.takeIf { it.isUsableTagText() } ?: composer,
            arranger = tagInfo?.arranger.takeIf { it.isUsableTagText() } ?: wavMetadata?.arranger.takeIf { it.isUsableTagText() } ?: arranger,
            lyricist = tagInfo?.lyricist.takeIf { it.isUsableTagText() } ?: wavMetadata?.lyricist.takeIf { it.isUsableTagText() } ?: lyricist,
            trackNumber = tagInfo?.trackNumber ?: wavMetadata?.trackNumber ?: trackNumber,
            discNumber = tagInfo?.discNumber ?: wavMetadata?.discNumber ?: discNumber,
            customTags = tagInfo?.customTags?.libraryCustomTags() ?: customTags,
            customTagsLoaded = tagInfo != null || customTagsLoaded
        ).withFinalLibraryFallbacks(albumFromTag = tagAlbum != null)
    }

    private suspend fun refreshFolderAlbumSetting() {
        folderNameAsAlbumWhenMissingEnabled =
            runCatching { settingsManager.folderNameAsAlbumWhenMissing.first() }.getOrDefault(false)
    }

    /** Re-apply album fallbacks after [folderNameAsAlbumWhenMissing] changes (#658). */
    suspend fun rematerializeFolderAlbumFallbacks() {
        refreshFolderAlbumSetting()
        val current = _songs.value
        val rematerialized = withContext(Dispatchers.IO) {
            current.map { song ->
                // A folder-lookalike album may be a real tag (Artist/Album/01.flac, #675). Re-read
                // the tags instead of discarding it; only inferred folder albums become Unknown.
                if (!folderNameAsAlbumWhenMissingEnabled &&
                    song.album.isUsableAlbumText() &&
                    song.album.looksLikeLastFolderName(song.path) &&
                    song.canReadTagsWithoutNetwork()
                ) {
                    runCatching { song.withRepositoryTags(allowFullDownload = false) }
                        .getOrElse { song.withFinalLibraryFallbacks() }
                } else {
                    song.withFinalLibraryFallbacks()
                }
            }
        }
        synchronized(librarySnapshotLock) {
            // Tag reads ran off-thread; do not clobber a snapshot published meanwhile by a scan.
            if (_songs.value === current && rematerialized != current) {
                _songs.value = rematerialized
            }
        }
    }

    private fun Song.canReadTagsWithoutNetwork(): Boolean =
        !path.isHttpAudioSource() ||
            (isWebDavRemoteSong() && hasUsableWebDavMetadataCache(remoteAudioCacheDir, remoteMetadataHeaderCacheDir))

    /**
     * @param albumFromTag true when [Song.album] was just read from the file's own tags; such an
     * album is kept even when it equals the parent folder name (#675).
     */
    private fun Song.withFinalLibraryFallbacks(albumFromTag: Boolean = false): Song {
        val fallbackArtist = artist.takeIf { it.isUsableArtistText() } ?: "Unknown Artist"
        // MediaStore often fills album with the parent folder name when tags are missing. With the
        // setting OFF those count as missing so songs land in Unknown Album (#658), unless the
        // value came from the file's tags (#675).
        val fallbackAlbum = LibraryNormalizer.resolveLibraryAlbum(
            album = album,
            path = path,
            folderNameAsAlbumWhenMissing = folderNameAsAlbumWhenMissingEnabled,
            albumFromTag = albumFromTag
        )
        return copy(
            title = title.takeIf { it.isUsableTagText() } ?: fileName.substringBeforeLast('.').ifBlank { path.substringAfterLast('/') },
            artist = fallbackArtist,
            album = fallbackAlbum,
            albumArtist = albumArtist.takeIf { it.isUsableArtistText() }.orEmpty()
        )
    }

    private fun Song.needsMetadataPlaceholderRefresh(): Boolean =
        LibraryNormalizer.isGeneratedUnknownArtistPlaceholder(artist) ||
            LibraryNormalizer.isGeneratedUnknownAlbumPlaceholder(album) ||
            (album.isUsableAlbumText() && album.looksLikeLastFolderName(path))

    private suspend fun scanEditedFile(song: Song) = suspendCoroutine<Unit> { continuation ->
        val path = song.path.takeIf { it.isNotBlank() }
        if (path == null || path.isContentAudioSource()) {
            continuation.resume(Unit)
            return@suspendCoroutine
        }
        val mimeTypes = song.mimeType.takeIf { it.isNotBlank() }?.let { arrayOf(it) }
        MediaScannerConnection.scanFile(
            context,
            arrayOf(path),
            mimeTypes,
        ) { _, _ ->
            continuation.resume(Unit)
        }
    }

    private fun querySystemSong(song: Song): Song? {
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.DATE_MODIFIED,
            MediaStore.Audio.Media.TRACK
        )
        val uri = if (song.id > 0L) {
            ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
        } else {
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        val selection = if (song.id > 0L) null else "${MediaStore.Audio.Media.DATA} = ?"
        val selectionArgs = if (song.id > 0L) null else arrayOf(song.path)

        return context.contentResolver.query(uri, projection, selection, selectionArgs, null)?.use { cursor ->
            if (!cursor.moveToFirst()) return@use null
            val tagInfo = runCatching {
                audioTagRepository.readTagsBlocking(song.effectiveLocalPathForMetadata())?.toSongTagInfo()
            }.getOrNull() ?: SongTagInfo()
            val wavInfo = runCatching { WavMetadataReader.read(song.effectiveLocalPathForMetadata()) }
                .getOrNull()
            val path = cursor.getString(6).orEmpty().ifBlank { song.path }
            val file = File(path)
            val fileSize = file.length().takeIf { file.exists() && it > 0L }
                ?: cursor.getLong(8)
            val dateModified = file.lastModified().takeIf { file.exists() && it > 0L }
                ?: (cursor.getLong(11) * 1000L).takeIf { it > 0L }
                ?: song.dateModified
            Song(
                id = cursor.getLong(0),
                title = tagInfo.title.usableTagText().ifBlank {
                    wavInfo?.title.usableTagText().ifBlank {
                        cursor.getString(1)?.usableTagText().orEmpty().ifBlank { song.title }
                    }
                },
                artist = tagInfo.artist.usableArtistText().ifBlank {
                    wavInfo?.artist.usableArtistText().ifBlank {
                        cursor.getString(2)?.usableArtistText().orEmpty().ifBlank { song.artist }
                    }
                },
                album = tagInfo.album.usableAlbumText().ifBlank {
                    wavInfo?.album.usableAlbumText().ifBlank {
                        cursor.getString(3)?.usableAlbumText().orEmpty().ifBlank { song.album }
                    }
                },
                albumId = cursor.getLong(4),
                duration = cursor.getLong(5).takeIf { it > 0L } ?: song.duration,
                path = path,
                fileName = cursor.getString(7).orEmpty().ifBlank { song.fileName },
                fileSize = fileSize,
                mimeType = cursor.getString(9).orEmpty().ifBlank { song.mimeType },
                dateAdded = cursor.getLong(10) * 1000L,
                dateModified = dateModified,
                trackNumber = tagInfo.track.takeIf { it.isNotBlank() }?.toIntOrNull()
                    ?: wavInfo?.trackNumber
                    ?: cursor.getInt(12).let { if (it > 1000) it % 1000 else it },
                discNumber = wavInfo?.discNumber
                    ?: cursor.getInt(12).let { if (it >= 1000) it / 1000 else song.discNumber },
                albumArtist = tagInfo.albumArtist.usableArtistText().ifBlank {
                    wavInfo?.albumArtist.usableArtistText().ifBlank { song.albumArtist }
                },
                genre = tagInfo.genre.ifBlank { wavInfo?.genre.orEmpty().ifBlank { song.genre } },
                year = tagInfo.year.ifBlank { wavInfo?.year.orEmpty().ifBlank { song.year } },
                composer = tagInfo.composer.ifBlank { wavInfo?.composer.orEmpty().ifBlank { song.composer } },
                arranger = tagInfo.arranger.ifBlank { wavInfo?.arranger.orEmpty().ifBlank { song.arranger } },
                lyricist = tagInfo.lyricist.ifBlank { wavInfo?.lyricist.orEmpty().ifBlank { song.lyricist } },
                customTags = tagInfo.customTags.libraryCustomTags(),
                customTagsLoaded = true,
                coverUrl = song.coverUrl,
                onlineSource = song.onlineSource,
                onlineId = song.onlineId,
                onlineMvId = song.onlineMvId,
                onlineLyrics = song.onlineLyrics,
                onlineLyricTranslation = song.onlineLyricTranslation,
                onlineLyricPronunciation = song.onlineLyricPronunciation
            ).withFinalLibraryFallbacks(
                albumFromTag = tagInfo.album.isUsableAlbumText() || wavInfo?.album.isUsableAlbumText()
            )
        }
    }

    private fun Song.librarySyncKey(): String =
        com.ella.music.data.scanner.MediaStoreLibraryIndexer.mediaStoreLibrarySyncKey(id, path)

    private fun MediaStoreAudioItem.librarySyncKey(): String =
        com.ella.music.data.scanner.MediaStoreLibraryIndexer.mediaStoreLibrarySyncKey(id, path)

    private fun Song.scanSummaryKey(): String = path.ifBlank { librarySyncKey() }

    private fun Song.toScanSummaryInfo(): ScanSummaryInfo =
        ScanSummaryInfo(
            key = scanSummaryKey(),
            fileSize = fileSize,
            dateModified = dateModified,
            title = title,
            artist = artist,
            album = album,
            duration = duration,
            year = year,
            trackNumber = trackNumber,
            discNumber = discNumber
        )

    private data class ScanSummaryInfo(
        val key: String,
        val fileSize: Long,
        val dateModified: Long,
        val title: String,
        val artist: String,
        val album: String,
        val duration: Long,
        val year: String,
        val trackNumber: Int,
        val discNumber: Int
    )
}
