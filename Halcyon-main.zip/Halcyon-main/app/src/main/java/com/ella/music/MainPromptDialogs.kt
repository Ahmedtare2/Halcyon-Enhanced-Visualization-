package com.ella.music

import androidx.compose.runtime.Composable
import androidx.compose.ui.res.stringResource
import com.ella.music.ui.components.EllaMiuixDialog
import com.ella.music.ui.components.EllaMiuixDialogActions

@Composable
internal fun LocalPlaylistScanPromptDialog(
    show: Boolean,
    onDismiss: () -> Unit,
    onScan: () -> Unit
) {
    EllaMiuixDialog(
        show = show,
        title = stringResource(R.string.local_playlist_scan_title),
        summary = stringResource(R.string.local_playlist_scan_message),
        onDismissRequest = onDismiss
    ) {
        EllaMiuixDialogActions(
            cancelText = stringResource(R.string.local_playlist_scan_skip),
            confirmText = stringResource(R.string.local_playlist_scan_confirm),
            onCancel = onDismiss,
            onConfirm = onScan
        )
    }
}

@Composable
internal fun AllFilesAccessPromptDialog(
    show: Boolean,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    EllaMiuixDialog(
        show = show,
        title = stringResource(R.string.all_files_access_prompt_title),
        summary = stringResource(R.string.all_files_access_prompt_message),
        onDismissRequest = onDismiss
    ) {
        EllaMiuixDialogActions(
            cancelText = stringResource(R.string.common_cancel),
            confirmText = stringResource(R.string.all_files_access_prompt_confirm),
            onCancel = onDismiss,
            onConfirm = onConfirm
        )
    }
}

@Composable
internal fun WebDavCloudRestorePromptDialog(
    show: Boolean,
    restoring: Boolean,
    onDismiss: () -> Unit,
    onRestore: () -> Unit
) {
    EllaMiuixDialog(
        show = show,
        title = stringResource(R.string.settings_backup_webdav_newer_title),
        summary = stringResource(R.string.settings_backup_webdav_newer_message),
        onDismissRequest = { if (!restoring) onDismiss() }
    ) {
        EllaMiuixDialogActions(
            cancelText = stringResource(R.string.common_cancel),
            confirmText = stringResource(R.string.settings_backup_webdav_restore_now),
            confirmDangerous = true,
            onCancel = { if (!restoring) onDismiss() },
            onConfirm = { if (!restoring) onRestore() }
        )
    }
}

@Composable
internal fun ShuffleAllShortcutConfirmationDialog(
    show: Boolean,
    onDismiss: () -> Unit,
    onConfirm: () -> Unit
) {
    EllaMiuixDialog(
        show = show,
        title = stringResource(R.string.shortcut_shuffle_all_confirm_title),
        summary = stringResource(R.string.shortcut_shuffle_all_confirm_message),
        onDismissRequest = onDismiss
    ) {
        EllaMiuixDialogActions(
            cancelText = stringResource(R.string.common_cancel),
            confirmText = stringResource(R.string.shortcut_shuffle_all_confirm),
            onCancel = onDismiss,
            onConfirm = onConfirm
        )
    }
}
