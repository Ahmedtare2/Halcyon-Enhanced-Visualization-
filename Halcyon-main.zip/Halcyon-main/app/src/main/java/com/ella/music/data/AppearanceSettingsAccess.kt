package com.ella.music.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.Preferences
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_DE
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_EN
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_FR
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_JA
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_KO
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_RU
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_SYSTEM
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_TR
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_AR
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_ZH_CN
import com.ella.music.data.SettingsManager.Companion.APP_LANGUAGE_ZH_TW
import com.ella.music.data.SettingsManager.Companion.DEFAULT_APP_SHORTCUT_ORDER
import com.ella.music.data.SettingsManager.Companion.DEFAULT_BOTTOM_DOCK_ITEMS
import com.ella.music.data.SettingsManager.Companion.DEFAULT_HOME_LIBRARY_TILE_ORDER
import com.ella.music.data.SettingsManager.Companion.DEFAULT_HOME_ONLINE_TILE_ORDER
import com.ella.music.data.SettingsManager.Companion.DEFAULT_HOME_SECTION_ORDER
import com.ella.music.data.SettingsManager.Companion.HOME_RECENT_SECTION_MODE_ADDED
import com.ella.music.data.SettingsManager.Companion.HOME_RECENT_SECTION_MODE_PLAYED
import com.ella.music.data.SettingsManager.Companion.DEFAULT_SHORTCUT_FOLDER_LABEL
import com.ella.music.data.SettingsManager.Companion.DEFAULT_SHORTCUT_LIBRARY_LABEL
import com.ella.music.data.SettingsManager.Companion.DEFAULT_SHORTCUT_PLAYLISTS_LABEL
import com.ella.music.data.SettingsManager.Companion.DEFAULT_STARTUP_POSTER_DURATION_MS
import com.ella.music.data.SettingsManager.Companion.normalizeAppShortcutOrder
import com.ella.music.data.SettingsManager.Companion.normalizeBottomDockItems
import com.ella.music.data.SettingsManager.Companion.normalizeBottomDockStartupItem
import com.ella.music.data.SettingsManager.Companion.visibleBottomDockItems
import com.ella.music.data.SettingsManager.Companion.STARTUP_POSTER_DURATION_MAX_MS
import com.ella.music.data.SettingsManager.Companion.STARTUP_POSTER_DURATION_MIN_MS
import com.ella.music.data.SettingsManager.Companion.KEY_APP_ICON_STYLE
import com.ella.music.data.SettingsManager.Companion.KEY_WIDGET_SAFE_LAYOUT
import com.ella.music.data.SettingsManager.Companion.KEY_APP_FONT_SCALE_PERCENT
import com.ella.music.data.SettingsManager.Companion.KEY_APP_DISPLAY_SCALE_PERCENT
import com.ella.music.data.SettingsManager.Companion.KEY_APP_LANGUAGE
import com.ella.music.data.SettingsManager.Companion.KEY_APP_SHORTCUT_ORDER
import com.ella.music.data.SettingsManager.Companion.KEY_BG_EFFECT_VERSION
import com.ella.music.data.SettingsManager.Companion.KEY_TOP_BAR_BLUR_STYLE
import com.ella.music.data.SettingsManager.Companion.TOP_BAR_BLUR_OFF
import com.ella.music.data.SettingsManager.Companion.KEY_APP_WALLPAPER_CONTENT_OVERLAY
import com.ella.music.data.SettingsManager.Companion.KEY_APP_WALLPAPER_DIM
import com.ella.music.data.SettingsManager.Companion.KEY_APP_WALLPAPER_ENABLED
import com.ella.music.data.SettingsManager.Companion.KEY_APP_WALLPAPER_OPACITY
import com.ella.music.data.SettingsManager.Companion.KEY_APP_WALLPAPER_URI
import com.ella.music.data.SettingsManager.Companion.KEY_APP_NOW_PLAYING_FLOW_BACKGROUND
import com.ella.music.data.SettingsManager.Companion.KEY_ARTIST_COVER_CAROUSEL
import com.ella.music.data.SettingsManager.Companion.KEY_ARTIST_COVER_FOLDER_URI
import com.ella.music.data.SettingsManager.Companion.KEY_ARTIST_COVER_DOWNLOAD_FOLDER_URI
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_STYLE
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_GLASS_EFFECT
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_CORNER_RADIUS
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_LIQUID_BLUR_RADIUS
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_LIQUID_REFRACTION_HEIGHT
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_LIQUID_REFRACTION_AMOUNT
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_DOCK_ITEMS
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_DOCK_STARTUP_ITEM
import com.ella.music.data.SettingsManager.Companion.KEY_BOTTOM_DOCK_MERGE_SEARCH
import com.ella.music.data.SettingsManager.Companion.KEY_CUSTOM_ACCENT_COLOR
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_TOP_BAR_ACTION_ORDER
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_HIDDEN_TOP_BAR_ACTIONS
import com.ella.music.data.SettingsManager.Companion.DEFAULT_HOME_TOP_BAR_ACTION_ORDER
import com.ella.music.data.SettingsManager.Companion.KEY_HI_RES_LOGO_ENABLED
import com.ella.music.data.SettingsManager.Companion.KEY_HI_RES_LOGO_URI
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_AI_MIX_VISIBLE
import com.ella.music.data.SettingsManager.Companion.KEY_CONTINUE_PLAYBACK_ROW_VISIBLE
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_FEATURE_WALLPAPER_URI
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_HIDDEN_LIBRARY_TILES
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_HIDDEN_ONLINE_TILES
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_HIDDEN_SECTIONS
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_LIBRARY_TILE_ORDER
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_ONLINE_TILE_ORDER
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_SECTION_ORDER
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_RECENT_SECTION_MODE
import com.ella.music.data.SettingsManager.Companion.KEY_HOME_TILE_PIN_BUTTONS_VISIBLE
import com.ella.music.data.SettingsManager.Companion.KEY_MONET_COLOR_MODE
import com.ella.music.data.SettingsManager.Companion.KEY_SHORTCUT_FOLDER_LABEL
import com.ella.music.data.SettingsManager.Companion.KEY_SHORTCUT_LIBRARY_LABEL
import com.ella.music.data.SettingsManager.Companion.KEY_SETTINGS_SEARCH_HISTORY
import com.ella.music.data.SettingsManager.Companion.KEY_SHORTCUT_PLAYLISTS_LABEL
import com.ella.music.data.SettingsManager.Companion.KEY_STARTUP_POSTER_DURATION_MS
import com.ella.music.data.SettingsManager.Companion.KEY_STARTUP_POSTER_ENABLED
import com.ella.music.data.SettingsManager.Companion.KEY_STARTUP_POSTER_URI
import com.ella.music.data.SettingsManager.Companion.KEY_THEME_MODE
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * App-wide appearance and home customisation: theme, language, icon style, bottom dock,
 * startup poster, wallpaper, home cards/tiles/sections, Hi-Res logo, launcher shortcuts and artist covers.
 *
 * Extracted verbatim from [SettingsManager], which implements this interface via class
 * delegation so every call site keeps using settingsManager.<member> unchanged. All flow
 * properties MUST stay eagerly-initialised stored properties (never computed get() =):
 * Compose collectAsState keys on the flow instance, and a fresh instance per access would
 * restart collection on every recomposition.
 */
interface AppearanceSettingsAccess {
    val themeMode: Flow<Int>
    val monetColorMode: Flow<Int>
    val appLanguage: Flow<String>
    val appFontScalePercent: Flow<Int>
    val appDisplayScalePercent: Flow<Int>
    val appIconStyle: Flow<String>
    val recentsIconFollowsSystemTheme: Flow<Boolean>
    val widgetSafeLayout: Flow<Boolean>
    val bottomBarStyle: Flow<BottomBarStyle>
    val bottomBarGlassEffect: Flow<BottomBarGlassEffect>
    val bottomBarCornerRadius: Flow<Int>
    val bottomBarLiquidBlurRadius: Flow<Int>
    val bottomBarLiquidRefractionHeight: Flow<Int>
    val bottomBarLiquidRefractionAmount: Flow<Int>
    val bottomBarLiquidChromaticAberration: Flow<Int>
    val bottomDockItems: Flow<List<String>>
    val bottomDockStartupItem: Flow<String>
    val homeSearchTarget: Flow<String>
    suspend fun setHomeSearchTarget(target: String)
    val bottomDockMergeSearch: Flow<Boolean>
    val artistCoverFolderUri: Flow<String>
    val artistCoverDownloadFolderUri: Flow<String>
    suspend fun setArtistCoverDownloadFolderUri(uri: String)
    val artistCoverCarousel: Flow<Boolean>
    val startupPosterEnabled: Flow<Boolean>
    val startupPosterUri: Flow<String>
    val startupPosterDurationMs: Flow<Int>
    val bgEffectVersion: Flow<Int>
    val defaultBgEffectVersion: Int get() = HyperOsDetector.defaultBgEffectVersion()
    val topBarBlurStyle: Flow<Int>
    val progressiveTopBarBlur: Flow<Boolean>
    suspend fun setProgressiveTopBarBlur(enabled: Boolean)
    suspend fun setTopBarBlurStyle(style: Int)
    val appWallpaperEnabled: Flow<Boolean>
    val appWallpaperUri: Flow<String>
    val appWallpaperOpacity: Flow<Int>
    val appWallpaperDim: Flow<Int>
    val appWallpaperContentOverlay: Flow<Int>
    val appNowPlayingFlowBackground: Flow<Boolean>
    val hiResLogoEnabled: Flow<Boolean>
    val hiResLogoUri: Flow<String>
    val shortcutLibraryLabel: Flow<String>
    val shortcutPlaylistsLabel: Flow<String>
    val shortcutFolderLabel: Flow<String>
    val appShortcutOrder: Flow<List<String>>
    val settingsSearchHistory: Flow<List<String>>
    val homeFeatureStyle: Flow<Int>
    suspend fun setHomeFeatureStyle(style: Int)
    val homeFeatureWallpaperUri: Flow<String>
    val homeAiMixVisible: Flow<Boolean>
    val continuePlaybackRowVisible: Flow<Boolean>
    val categoryContinuePlaybackRowVisible: Flow<Boolean>
    val homeRecentSectionMode: Flow<Int>
    val homeSectionOrder: Flow<String>
    val homeHiddenSections: Flow<String>
    val homeShortcutItems: Flow<String>
    val homeFeatureItems: Flow<String>
    val posterWallInfiniteScroll: Flow<Boolean>
    suspend fun setPosterWallInfiniteScroll(enabled: Boolean)
    val posterWallLyricStyle: Flow<Int>
    suspend fun setPosterWallLyricStyle(style: Int)
    suspend fun setHomeShortcutItems(value: String)
    suspend fun setHomeFeatureItems(value: String)
    val homeLibraryTileOrder: Flow<String>
    val homeHiddenLibraryTiles: Flow<String>
    val homeOnlineTileOrder: Flow<String>
    val homeHiddenOnlineTiles: Flow<String>
    val homeTilePinButtonsVisible: Flow<Boolean>
    val customAccentColor: Flow<String>
    suspend fun setCustomAccentColor(color: String)
    val homeTopBarActionOrder: Flow<String>
    val homeHiddenTopBarActions: Flow<String>
    suspend fun setHomeTopBarActionOrder(order: String)
    suspend fun setHomeHiddenTopBarActions(actions: String)
    suspend fun setThemeMode(mode: Int)
    suspend fun setMonetColorMode(mode: Int)
    suspend fun setAppLanguage(languageTag: String)
    suspend fun setAppFontScalePercent(percent: Int)
    suspend fun setAppDisplayScalePercent(percent: Int)
    suspend fun setAppIconStyle(style: String)
    suspend fun setRecentsIconFollowsSystemTheme(enabled: Boolean)
    suspend fun setWidgetSafeLayout(enabled: Boolean)
    suspend fun setBottomBarStyle(style: BottomBarStyle)
    suspend fun setBottomBarGlassEffect(effect: BottomBarGlassEffect)
    suspend fun setBottomBarCornerRadius(radiusDp: Int)
    suspend fun setBottomBarLiquidBlurRadius(radiusDp: Int)
    suspend fun setBottomBarLiquidRefractionHeight(heightDp: Int)
    suspend fun setBottomBarLiquidRefractionAmount(amountDp: Int)
    suspend fun setBottomBarLiquidChromaticAberration(percent: Int)
    suspend fun setBottomDockItems(items: List<String>)
    suspend fun setBottomDockStartupItem(itemId: String)
    suspend fun setBottomDockMergeSearch(enabled: Boolean)
    suspend fun setArtistCoverCarousel(carousel: Boolean)
    suspend fun setArtistCoverFolderUri(uri: String)
    suspend fun setStartupPosterEnabled(enabled: Boolean)
    suspend fun setStartupPosterUri(uri: String)
    suspend fun setStartupPosterDurationMs(durationMs: Int)
    suspend fun setBgEffectVersion(version: Int)
    suspend fun setAppWallpaperEnabled(enabled: Boolean)
    suspend fun setAppWallpaperUri(uri: String)
    suspend fun setAppWallpaperOpacity(opacity: Int)
    suspend fun setAppWallpaperDim(dim: Int)
    suspend fun setAppWallpaperContentOverlay(strength: Int)
    suspend fun setAppNowPlayingFlowBackground(enabled: Boolean)
    suspend fun setHiResLogoEnabled(enabled: Boolean)
    suspend fun setHiResLogoUri(uri: String)
    suspend fun setShortcutLibraryLabel(label: String)
    suspend fun setShortcutPlaylistsLabel(label: String)
    suspend fun setShortcutFolderLabel(label: String)
    suspend fun setAppShortcutOrder(shortcutIds: List<String>)
    suspend fun recordSettingsSearchQuery(query: String)
    suspend fun clearSettingsSearchHistory()
    suspend fun setHomeFeatureWallpaperUri(uri: String)
    suspend fun setHomeAiMixVisible(visible: Boolean)
    suspend fun setContinuePlaybackRowVisible(visible: Boolean)
    suspend fun setCategoryContinuePlaybackRowVisible(visible: Boolean)
    suspend fun setHomeRecentSectionMode(mode: Int)
    suspend fun setHomeSectionOrder(order: String)
    suspend fun setHomeHiddenSections(hidden: String)
    suspend fun setHomeLibraryTileOrder(order: String)
    suspend fun setHomeHiddenLibraryTiles(hidden: String)
    suspend fun setHomeOnlineTileOrder(order: String)
    suspend fun setHomeHiddenOnlineTiles(hidden: String)
    suspend fun setHomeTilePinButtonsVisible(visible: Boolean)
}

internal class AppearanceSettingsAccessImpl(private val context: Context) : AppearanceSettingsAccess {

    override val themeMode: Flow<Int> = context.dataStore.data.map { it[KEY_THEME_MODE] ?: 0 }
    override val monetColorMode: Flow<Int> = context.dataStore.data.map { it[KEY_MONET_COLOR_MODE] ?: 0 }

    override val appLanguage: Flow<String> =
        context.dataStore.data.map { it[KEY_APP_LANGUAGE] ?: APP_LANGUAGE_SYSTEM }
    override val appFontScalePercent: Flow<Int> =
        context.dataStore.data.map {
            (it[KEY_APP_FONT_SCALE_PERCENT]
                ?: SettingsManager.DEFAULT_APP_FONT_SCALE_PERCENT).coerceIn(
                SettingsManager.APP_FONT_SCALE_MIN_PERCENT,
                SettingsManager.APP_FONT_SCALE_MAX_PERCENT
            )
        }
    override val appDisplayScalePercent: Flow<Int> =
        context.dataStore.data.map {
            (it[KEY_APP_DISPLAY_SCALE_PERCENT]
                ?: SettingsManager.DEFAULT_APP_DISPLAY_SCALE_PERCENT).coerceIn(
                SettingsManager.APP_DISPLAY_SCALE_MIN_PERCENT,
                SettingsManager.APP_DISPLAY_SCALE_MAX_PERCENT
            )
        }
    override val appIconStyle: Flow<String> =
        context.dataStore.data.map { AppIconManager.normalize(it[KEY_APP_ICON_STYLE]) }
    override val recentsIconFollowsSystemTheme: Flow<Boolean> = context.dataStore.data.map {
        it[SettingsManager.KEY_RECENTS_ICON_FOLLOWS_SYSTEM_THEME]
            ?: SettingsManager.DEFAULT_RECENTS_ICON_FOLLOWS_SYSTEM_THEME
    }
    override val widgetSafeLayout: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_WIDGET_SAFE_LAYOUT] ?: false }
    override val bottomBarStyle: Flow<BottomBarStyle> = context.dataStore.data.map { preferences ->
        preferences[KEY_BOTTOM_BAR_STYLE]
            ?.let { stored -> runCatching { BottomBarStyle.valueOf(stored) }.getOrNull() }
            ?: runCatching {
                when (
                    BottomBarGlassEffect.valueOf(
                        preferences[KEY_BOTTOM_BAR_GLASS_EFFECT] ?: BottomBarGlassEffect.Blur.name
                    )
                ) {
                    BottomBarGlassEffect.Blur -> BottomBarStyle.Floating
                    BottomBarGlassEffect.LiquidGlass -> BottomBarStyle.LiquidGlass
                }
            }.getOrDefault(BottomBarStyle.Floating)
    }
    override val bottomBarGlassEffect: Flow<BottomBarGlassEffect> = context.dataStore.data.map { preferences ->
        runCatching {
            BottomBarGlassEffect.valueOf(
                preferences[KEY_BOTTOM_BAR_GLASS_EFFECT] ?: BottomBarGlassEffect.Blur.name
            )
        }.getOrDefault(BottomBarGlassEffect.Blur)
    }
    override val bottomBarCornerRadius: Flow<Int> = context.dataStore.data.map { preferences ->
        (preferences[KEY_BOTTOM_BAR_CORNER_RADIUS]
            ?: SettingsManager.DEFAULT_BOTTOM_BAR_CORNER_RADIUS_DP)
            .coerceIn(
                SettingsManager.BOTTOM_BAR_CORNER_RADIUS_MIN_DP,
                SettingsManager.BOTTOM_BAR_CORNER_RADIUS_MAX_DP,
            )
    }
    override val bottomBarLiquidBlurRadius: Flow<Int> = context.dataStore.data.map { preferences ->
        (preferences[KEY_BOTTOM_BAR_LIQUID_BLUR_RADIUS]
            ?: SettingsManager.DEFAULT_BOTTOM_BAR_LIQUID_BLUR_RADIUS_DP)
            .coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_BLUR_RADIUS_MIN_DP,
                SettingsManager.BOTTOM_BAR_LIQUID_BLUR_RADIUS_MAX_DP,
            )
    }
    override val bottomBarLiquidRefractionHeight: Flow<Int> = context.dataStore.data.map { preferences ->
        (preferences[KEY_BOTTOM_BAR_LIQUID_REFRACTION_HEIGHT]
            ?: SettingsManager.DEFAULT_BOTTOM_BAR_LIQUID_REFRACTION_HEIGHT_DP)
            .coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MIN_DP,
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MAX_DP,
            )
    }
    override val bottomBarLiquidRefractionAmount: Flow<Int> = context.dataStore.data.map { preferences ->
        (preferences[KEY_BOTTOM_BAR_LIQUID_REFRACTION_AMOUNT]
            ?: SettingsManager.DEFAULT_BOTTOM_BAR_LIQUID_REFRACTION_AMOUNT_DP)
            .coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MIN_DP,
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MAX_DP,
            )
    }
    override val bottomBarLiquidChromaticAberration: Flow<Int> = context.dataStore.data.map { preferences ->
        (preferences[KEY_BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION]
            ?: SettingsManager.DEFAULT_BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION_PERCENT)
            .coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION_MIN_PERCENT,
                SettingsManager.BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION_MAX_PERCENT,
            )
    }
    override val posterWallInfiniteScroll: Flow<Boolean> = context.dataStore.data.map {
        it[SettingsManager.KEY_POSTER_WALL_INFINITE_SCROLL] ?: false
    }
    override suspend fun setPosterWallInfiniteScroll(enabled: Boolean) {
        context.dataStore.edit { it[SettingsManager.KEY_POSTER_WALL_INFINITE_SCROLL] = enabled }
    }
    override val posterWallLyricStyle: Flow<Int> = context.dataStore.data.map {
        (it[SettingsManager.KEY_POSTER_WALL_LYRIC_STYLE] ?: 0).coerceIn(0, 4)
    }
    override suspend fun setPosterWallLyricStyle(style: Int) {
        context.dataStore.edit { it[SettingsManager.KEY_POSTER_WALL_LYRIC_STYLE] = style.coerceIn(0, 4) }
    }

    override val homeSearchTarget: Flow<String> = context.dataStore.data.map {
        normalizeHomeSearchTarget(it[SettingsManager.KEY_HOME_SEARCH_TARGET].orEmpty())
    }
    override suspend fun setHomeSearchTarget(target: String) {
        context.dataStore.edit { it[SettingsManager.KEY_HOME_SEARCH_TARGET] = normalizeHomeSearchTarget(target) }
    }
    override val bottomDockMergeSearch: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_BOTTOM_DOCK_MERGE_SEARCH] ?: true }
    override val bottomDockItems: Flow<List<String>> =
        context.dataStore.data.map {
            normalizeBottomDockItems(it[KEY_BOTTOM_DOCK_ITEMS] ?: DEFAULT_BOTTOM_DOCK_ITEMS)
                .split(',')
                .filter(String::isNotBlank)
        }
    override val bottomDockStartupItem: Flow<String> =
        context.dataStore.data.map { preferences ->
            val mergeSearch = preferences[KEY_BOTTOM_DOCK_MERGE_SEARCH] ?: true
            val configuredItems = visibleBottomDockItems(
                normalizeBottomDockItems(
                    preferences[KEY_BOTTOM_DOCK_ITEMS] ?: DEFAULT_BOTTOM_DOCK_ITEMS
                ).split(',').filter(String::isNotBlank),
                mergeSearch
            )
            normalizeBottomDockStartupItem(
                value = preferences[KEY_BOTTOM_DOCK_STARTUP_ITEM],
                configuredItems = configuredItems
            )
        }

    override val settingsSearchHistory: Flow<List<String>> =
        context.dataStore.data.map {
            SettingsSearchHistory.decode(it[KEY_SETTINGS_SEARCH_HISTORY])
        }

    override val artistCoverFolderUri: Flow<String> =
        context.dataStore.data.map { it[KEY_ARTIST_COVER_FOLDER_URI].orEmpty() }
    override val artistCoverDownloadFolderUri: Flow<String> =
        context.dataStore.data.map { it[KEY_ARTIST_COVER_DOWNLOAD_FOLDER_URI].orEmpty() }
    // 当某位艺术家有多张封面图时：true=多图轮播，false=随机取一张。
    override val artistCoverCarousel: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_ARTIST_COVER_CAROUSEL] ?: true }

    override val startupPosterEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_STARTUP_POSTER_ENABLED] ?: false }
    override val startupPosterUri: Flow<String> =
        context.dataStore.data.map { it[KEY_STARTUP_POSTER_URI] ?: "" }
    override val startupPosterDurationMs: Flow<Int> =
        context.dataStore.data.map {
            (it[KEY_STARTUP_POSTER_DURATION_MS] ?: DEFAULT_STARTUP_POSTER_DURATION_MS)
                .coerceIn(STARTUP_POSTER_DURATION_MIN_MS, STARTUP_POSTER_DURATION_MAX_MS)
        }
    override val bgEffectVersion: Flow<Int> =
        context.dataStore.data.map { it[KEY_BG_EFFECT_VERSION] ?: defaultBgEffectVersion }
    override val topBarBlurStyle: Flow<Int> =
        context.dataStore.data.map { it[KEY_TOP_BAR_BLUR_STYLE] ?: TOP_BAR_BLUR_OFF }
    override val progressiveTopBarBlur: Flow<Boolean> = context.dataStore.data.map {
        it[androidx.datastore.preferences.core.booleanPreferencesKey("progressive_top_bar_blur")] ?: true
    }
    override suspend fun setProgressiveTopBarBlur(enabled: Boolean) {
        context.dataStore.edit { it[androidx.datastore.preferences.core.booleanPreferencesKey("progressive_top_bar_blur")] = enabled }
    }
    override val appWallpaperEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_APP_WALLPAPER_ENABLED] ?: false }
    override val appWallpaperUri: Flow<String> =
        context.dataStore.data.map { it[KEY_APP_WALLPAPER_URI] ?: "" }
    override val appWallpaperOpacity: Flow<Int> =
        context.dataStore.data.map { it[KEY_APP_WALLPAPER_OPACITY]?.coerceIn(20, 100) ?: 100 }
    override val appWallpaperDim: Flow<Int> =
        context.dataStore.data.map { it[KEY_APP_WALLPAPER_DIM]?.coerceIn(0, 80) ?: 30 }
    override val appWallpaperContentOverlay: Flow<Int> =
        context.dataStore.data.map { it[KEY_APP_WALLPAPER_CONTENT_OVERLAY]?.coerceIn(0, 80) ?: 24 }
    override val appNowPlayingFlowBackground: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_APP_NOW_PLAYING_FLOW_BACKGROUND] ?: true }

    override val homeFeatureStyle: Flow<Int> = context.dataStore.data.map {
        it[SettingsManager.KEY_HOME_FEATURE_STYLE]?.coerceIn(0, 2) ?: 0
    }
    override suspend fun setHomeFeatureStyle(style: Int) {
        context.dataStore.edit { it[SettingsManager.KEY_HOME_FEATURE_STYLE] = style.coerceIn(0, 2) }
    }
    override val hiResLogoEnabled: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_HI_RES_LOGO_ENABLED] ?: false }
    override val hiResLogoUri: Flow<String> =
        context.dataStore.data.map { it[KEY_HI_RES_LOGO_URI] ?: "" }

    override val shortcutLibraryLabel: Flow<String> =
        context.dataStore.data.map { it[KEY_SHORTCUT_LIBRARY_LABEL] ?: DEFAULT_SHORTCUT_LIBRARY_LABEL }
    override val shortcutPlaylistsLabel: Flow<String> =
        context.dataStore.data.map { it[KEY_SHORTCUT_PLAYLISTS_LABEL] ?: DEFAULT_SHORTCUT_PLAYLISTS_LABEL }
    override val shortcutFolderLabel: Flow<String> =
        context.dataStore.data.map { it[KEY_SHORTCUT_FOLDER_LABEL] ?: DEFAULT_SHORTCUT_FOLDER_LABEL }
    override val appShortcutOrder: Flow<List<String>> =
        context.dataStore.data.map { preferences ->
            preferences[KEY_APP_SHORTCUT_ORDER]
                ?.let(::normalizeAppShortcutOrder)
                ?: DEFAULT_APP_SHORTCUT_ORDER
        }

    override val homeFeatureWallpaperUri: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_FEATURE_WALLPAPER_URI] ?: "" }
    override val homeAiMixVisible: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_HOME_AI_MIX_VISIBLE] ?: true }
    override val continuePlaybackRowVisible: Flow<Boolean> =
        context.dataStore.data.map { resolveContinuePlaybackVisibility(it, library = true) }
    override val categoryContinuePlaybackRowVisible: Flow<Boolean> =
        context.dataStore.data.map { resolveContinuePlaybackVisibility(it, library = false) }
    override val homeRecentSectionMode: Flow<Int> =
        context.dataStore.data.map {
            (it[KEY_HOME_RECENT_SECTION_MODE] ?: HOME_RECENT_SECTION_MODE_ADDED)
                .coerceIn(HOME_RECENT_SECTION_MODE_PLAYED, HOME_RECENT_SECTION_MODE_ADDED)
        }
    override val homeSectionOrder: Flow<String> =
        context.dataStore.data.map {
            it[KEY_HOME_SECTION_ORDER]?.takeUnless { saved -> saved == "library,recent,online" && it[SettingsManager.KEY_HOME_SECTION_ORDER_UPDATED] != true }
                ?: DEFAULT_HOME_SECTION_ORDER
        }
    override val homeHiddenSections: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_HIDDEN_SECTIONS] ?: "" }
    override val homeShortcutItems: Flow<String> = context.dataStore.data.map {
        it[SettingsManager.KEY_HOME_SHORTCUT_ITEMS] ?: migratedHomeItems(
            it[KEY_HOME_LIBRARY_TILE_ORDER] ?: DEFAULT_HOME_LIBRARY_TILE_ORDER,
            it[KEY_HOME_HIDDEN_LIBRARY_TILES].orEmpty(), true,
            defaultHomeShortcutCount(context.resources.configuration.smallestScreenWidthDp))
    }
    override val homeFeatureItems: Flow<String> = context.dataStore.data.map { preferences ->
        val order = preferences[KEY_HOME_LIBRARY_TILE_ORDER] ?: DEFAULT_HOME_LIBRARY_TILE_ORDER
        val hidden = preferences[KEY_HOME_HIDDEN_LIBRARY_TILES].orEmpty()
        val shortcuts = preferences[SettingsManager.KEY_HOME_SHORTCUT_ITEMS] ?: migratedHomeItems(order, hidden, true,
            defaultHomeShortcutCount(context.resources.configuration.smallestScreenWidthDp))
        val features = preferences[SettingsManager.KEY_HOME_FEATURE_ITEMS] ?: migratedHomeItems(order, hidden, false)
        resolvePosterWallHomeFeatureItems(features, shortcuts,
            preferences[SettingsManager.KEY_HOME_POSTER_WALL_CONFIGURED] == true, hidden)
            .split(',').filter { it.isNotBlank() && it !in shortcuts.split(',') }.distinct().joinToString(",")
    }
    override suspend fun setHomeShortcutItems(value: String) {
        context.dataStore.edit {
            it[SettingsManager.KEY_HOME_SHORTCUT_ITEMS] = value
            if ("poster_wall" in value.split(',')) it[SettingsManager.KEY_HOME_POSTER_WALL_CONFIGURED] = true
        }
    }
    override suspend fun setHomeFeatureItems(value: String) {
        context.dataStore.edit {
            it[SettingsManager.KEY_HOME_FEATURE_ITEMS] = value
            it[SettingsManager.KEY_HOME_POSTER_WALL_CONFIGURED] = true
        }
    }
    override val homeLibraryTileOrder: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_LIBRARY_TILE_ORDER] ?: DEFAULT_HOME_LIBRARY_TILE_ORDER }
    override val homeHiddenLibraryTiles: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_HIDDEN_LIBRARY_TILES] ?: "" }
    override val homeOnlineTileOrder: Flow<String> =
        context.dataStore.data.map { (it[KEY_HOME_ONLINE_TILE_ORDER] ?: DEFAULT_HOME_ONLINE_TILE_ORDER).split(',').plus("musicfree").distinct().joinToString(",") }
    override val homeHiddenOnlineTiles: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_HIDDEN_ONLINE_TILES] ?: "" }
    override val homeTilePinButtonsVisible: Flow<Boolean> =
        context.dataStore.data.map { it[KEY_HOME_TILE_PIN_BUTTONS_VISIBLE] ?: false }
    override val customAccentColor: Flow<String> =
        context.dataStore.data.map { it[KEY_CUSTOM_ACCENT_COLOR] ?: "" }
    override val homeTopBarActionOrder: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_TOP_BAR_ACTION_ORDER] ?: DEFAULT_HOME_TOP_BAR_ACTION_ORDER }
    override val homeHiddenTopBarActions: Flow<String> =
        context.dataStore.data.map { it[KEY_HOME_HIDDEN_TOP_BAR_ACTIONS] ?: "" }

    override suspend fun setCustomAccentColor(color: String) {
        context.dataStore.edit { it[KEY_CUSTOM_ACCENT_COLOR] = color }
    }

    override suspend fun setHomeTopBarActionOrder(order: String) {
        context.dataStore.edit { it[KEY_HOME_TOP_BAR_ACTION_ORDER] = order }
    }

    override suspend fun setHomeHiddenTopBarActions(actions: String) {
        context.dataStore.edit { it[KEY_HOME_HIDDEN_TOP_BAR_ACTIONS] = actions }
    }

    override suspend fun setThemeMode(mode: Int) {
        context.dataStore.edit { it[KEY_THEME_MODE] = mode }
    }

    override suspend fun setMonetColorMode(mode: Int) {
        context.dataStore.edit { it[KEY_MONET_COLOR_MODE] = mode }
    }

    override suspend fun setAppLanguage(languageTag: String) {
        val normalized = when (languageTag) {
            APP_LANGUAGE_ZH_CN -> APP_LANGUAGE_ZH_CN
            APP_LANGUAGE_ZH_TW -> APP_LANGUAGE_ZH_TW
            APP_LANGUAGE_EN -> APP_LANGUAGE_EN
            APP_LANGUAGE_JA -> APP_LANGUAGE_JA
            APP_LANGUAGE_KO -> APP_LANGUAGE_KO
            APP_LANGUAGE_DE -> APP_LANGUAGE_DE
            APP_LANGUAGE_FR -> APP_LANGUAGE_FR
            APP_LANGUAGE_RU -> APP_LANGUAGE_RU
            APP_LANGUAGE_TR -> APP_LANGUAGE_TR
            APP_LANGUAGE_AR -> APP_LANGUAGE_AR
            else -> APP_LANGUAGE_SYSTEM
        }
        context.dataStore.edit { it[KEY_APP_LANGUAGE] = normalized }
    }

    override suspend fun setAppFontScalePercent(percent: Int) {
        context.dataStore.edit {
            it[KEY_APP_FONT_SCALE_PERCENT] = percent.coerceIn(
                SettingsManager.APP_FONT_SCALE_MIN_PERCENT,
                SettingsManager.APP_FONT_SCALE_MAX_PERCENT
            )
        }
    }

    override suspend fun setAppDisplayScalePercent(percent: Int) {
        context.dataStore.edit {
            it[KEY_APP_DISPLAY_SCALE_PERCENT] = percent.coerceIn(
                SettingsManager.APP_DISPLAY_SCALE_MIN_PERCENT,
                SettingsManager.APP_DISPLAY_SCALE_MAX_PERCENT
            )
        }
    }

    override suspend fun setAppIconStyle(style: String) {
        context.dataStore.edit { it[KEY_APP_ICON_STYLE] = AppIconManager.normalize(style) }
    }

    override suspend fun setRecentsIconFollowsSystemTheme(enabled: Boolean) {
        context.dataStore.edit { it[SettingsManager.KEY_RECENTS_ICON_FOLLOWS_SYSTEM_THEME] = enabled }
    }

    override suspend fun setWidgetSafeLayout(enabled: Boolean) {
        context.dataStore.edit { it[KEY_WIDGET_SAFE_LAYOUT] = enabled }
    }

    override suspend fun setBottomBarStyle(style: BottomBarStyle) {
        context.dataStore.edit { preferences ->
            preferences[KEY_BOTTOM_BAR_STYLE] = style.name
            when (style) {
                BottomBarStyle.Floating -> preferences[KEY_BOTTOM_BAR_GLASS_EFFECT] = BottomBarGlassEffect.Blur.name
                BottomBarStyle.LiquidGlass -> preferences[KEY_BOTTOM_BAR_GLASS_EFFECT] = BottomBarGlassEffect.LiquidGlass.name
                BottomBarStyle.Normal -> Unit
            }
        }
    }

    override suspend fun setBottomBarGlassEffect(effect: BottomBarGlassEffect) {
        context.dataStore.edit {
            it[KEY_BOTTOM_BAR_GLASS_EFFECT] = effect.name
            it[KEY_BOTTOM_BAR_STYLE] = when (effect) {
                BottomBarGlassEffect.Blur -> BottomBarStyle.Floating.name
                BottomBarGlassEffect.LiquidGlass -> BottomBarStyle.LiquidGlass.name
            }
        }
    }

    override suspend fun setBottomBarCornerRadius(radiusDp: Int) {
        context.dataStore.edit {
            it[KEY_BOTTOM_BAR_CORNER_RADIUS] = radiusDp.coerceIn(
                SettingsManager.BOTTOM_BAR_CORNER_RADIUS_MIN_DP,
                SettingsManager.BOTTOM_BAR_CORNER_RADIUS_MAX_DP,
            )
        }
    }

    override suspend fun setBottomBarLiquidBlurRadius(radiusDp: Int) {
        context.dataStore.edit {
            it[KEY_BOTTOM_BAR_LIQUID_BLUR_RADIUS] = radiusDp.coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_BLUR_RADIUS_MIN_DP,
                SettingsManager.BOTTOM_BAR_LIQUID_BLUR_RADIUS_MAX_DP,
            )
        }
    }

    override suspend fun setBottomBarLiquidRefractionHeight(heightDp: Int) {
        context.dataStore.edit {
            it[KEY_BOTTOM_BAR_LIQUID_REFRACTION_HEIGHT] = heightDp.coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MIN_DP,
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MAX_DP,
            )
        }
    }

    override suspend fun setBottomBarLiquidRefractionAmount(amountDp: Int) {
        context.dataStore.edit {
            it[KEY_BOTTOM_BAR_LIQUID_REFRACTION_AMOUNT] = amountDp.coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MIN_DP,
                SettingsManager.BOTTOM_BAR_LIQUID_REFRACTION_MAX_DP,
            )
        }
    }

    override suspend fun setBottomBarLiquidChromaticAberration(percent: Int) {
        context.dataStore.edit {
            it[KEY_BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION] = percent.coerceIn(
                SettingsManager.BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION_MIN_PERCENT,
                SettingsManager.BOTTOM_BAR_LIQUID_CHROMATIC_ABERRATION_MAX_PERCENT,
            )
        }
    }

    override suspend fun setBottomDockMergeSearch(enabled: Boolean) {
        context.dataStore.edit { preferences ->
            preferences[KEY_BOTTOM_DOCK_MERGE_SEARCH] = enabled
            if (enabled) {
                val current = normalizeBottomDockItems(
                    preferences[KEY_BOTTOM_DOCK_ITEMS] ?: DEFAULT_BOTTOM_DOCK_ITEMS
                ).split(',').filter(String::isNotBlank)
                if (SettingsManager.BOTTOM_DOCK_ITEM_SEARCH !in current &&
                    current.size < SettingsManager.MAX_BOTTOM_DOCK_ITEMS_WITH_SEARCH
                ) {
                    preferences[KEY_BOTTOM_DOCK_ITEMS] =
                        (current + SettingsManager.BOTTOM_DOCK_ITEM_SEARCH).joinToString(",")
                }
            }
        }
    }

    override suspend fun setBottomDockItems(items: List<String>) {
        context.dataStore.edit { preferences ->
            val normalizedItems = normalizeBottomDockItems(items.joinToString(","))
            preferences[KEY_BOTTOM_DOCK_ITEMS] = normalizedItems
            preferences[KEY_BOTTOM_DOCK_STARTUP_ITEM] = normalizeBottomDockStartupItem(
                value = preferences[KEY_BOTTOM_DOCK_STARTUP_ITEM],
                configuredItems = normalizedItems.split(',').filter(String::isNotBlank)
            )
        }
    }

    override suspend fun setBottomDockStartupItem(itemId: String) {
        context.dataStore.edit { preferences ->
            val configuredItems = normalizeBottomDockItems(
                preferences[KEY_BOTTOM_DOCK_ITEMS] ?: DEFAULT_BOTTOM_DOCK_ITEMS
            ).split(',').filter(String::isNotBlank)
            preferences[KEY_BOTTOM_DOCK_STARTUP_ITEM] = normalizeBottomDockStartupItem(
                value = itemId,
                configuredItems = configuredItems
            )
        }
    }

    override suspend fun setArtistCoverCarousel(carousel: Boolean) {
        context.dataStore.edit { it[KEY_ARTIST_COVER_CAROUSEL] = carousel }
    }

    override suspend fun setArtistCoverFolderUri(uri: String) {
        context.dataStore.edit { prefs ->
            val safeUri = uri.trim()
            if (safeUri.isBlank()) {
                prefs.remove(KEY_ARTIST_COVER_FOLDER_URI)
            } else {
                prefs[KEY_ARTIST_COVER_FOLDER_URI] = safeUri
            }
        }
    }

    override suspend fun setArtistCoverDownloadFolderUri(uri: String) {
        context.dataStore.edit { prefs ->
            val safeUri = uri.trim()
            if (safeUri.isBlank()) {
                prefs.remove(KEY_ARTIST_COVER_DOWNLOAD_FOLDER_URI)
            } else {
                prefs[KEY_ARTIST_COVER_DOWNLOAD_FOLDER_URI] = safeUri
            }
        }
    }

    override suspend fun setStartupPosterEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_STARTUP_POSTER_ENABLED] = enabled }
    }

    override suspend fun setStartupPosterUri(uri: String) {
        context.dataStore.edit {
            val safeUri = uri.trim()
            if (safeUri.isBlank()) it.remove(KEY_STARTUP_POSTER_URI) else it[KEY_STARTUP_POSTER_URI] = safeUri
        }
    }

    override suspend fun setStartupPosterDurationMs(durationMs: Int) {
        context.dataStore.edit {
            it[KEY_STARTUP_POSTER_DURATION_MS] = durationMs.coerceIn(
                STARTUP_POSTER_DURATION_MIN_MS,
                STARTUP_POSTER_DURATION_MAX_MS
            )
        }
    }

    override suspend fun setBgEffectVersion(version: Int) {
        context.dataStore.edit { it[KEY_BG_EFFECT_VERSION] = version.coerceIn(0, 2) }
    }

    override suspend fun setTopBarBlurStyle(style: Int) {
        context.dataStore.edit { it[KEY_TOP_BAR_BLUR_STYLE] = style.coerceIn(0, 2) }
    }

    override suspend fun setAppWallpaperEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_APP_WALLPAPER_ENABLED] = enabled }
    }

    override suspend fun setAppWallpaperUri(uri: String) {
        context.dataStore.edit {
            val safeUri = uri.trim()
            if (safeUri.isBlank()) it.remove(KEY_APP_WALLPAPER_URI) else it[KEY_APP_WALLPAPER_URI] = safeUri
        }
    }

    override suspend fun setAppWallpaperOpacity(opacity: Int) {
        context.dataStore.edit { it[KEY_APP_WALLPAPER_OPACITY] = opacity.coerceIn(20, 100) }
    }

    override suspend fun setAppWallpaperDim(dim: Int) {
        context.dataStore.edit { it[KEY_APP_WALLPAPER_DIM] = dim.coerceIn(0, 80) }
    }

    override suspend fun setAppWallpaperContentOverlay(strength: Int) {
        context.dataStore.edit { it[KEY_APP_WALLPAPER_CONTENT_OVERLAY] = strength.coerceIn(0, 80) }
    }

    override suspend fun setAppNowPlayingFlowBackground(enabled: Boolean) {
        context.dataStore.edit { it[KEY_APP_NOW_PLAYING_FLOW_BACKGROUND] = enabled }
    }



    override suspend fun setHiResLogoEnabled(enabled: Boolean) {
        context.dataStore.edit { it[KEY_HI_RES_LOGO_ENABLED] = enabled }
    }

    override suspend fun setHiResLogoUri(uri: String) {
        context.dataStore.edit {
            val safeUri = uri.trim()
            if (safeUri.isBlank()) it.remove(KEY_HI_RES_LOGO_URI) else it[KEY_HI_RES_LOGO_URI] = safeUri
        }
    }

    override suspend fun setShortcutLibraryLabel(label: String) {
        setShortcutLabel(KEY_SHORTCUT_LIBRARY_LABEL, label, DEFAULT_SHORTCUT_LIBRARY_LABEL)
    }

    override suspend fun setShortcutPlaylistsLabel(label: String) {
        setShortcutLabel(KEY_SHORTCUT_PLAYLISTS_LABEL, label, DEFAULT_SHORTCUT_PLAYLISTS_LABEL)
    }

    override suspend fun setShortcutFolderLabel(label: String) {
        setShortcutLabel(KEY_SHORTCUT_FOLDER_LABEL, label, DEFAULT_SHORTCUT_FOLDER_LABEL)
    }

    override suspend fun recordSettingsSearchQuery(query: String) {
        context.dataStore.edit { prefs ->
            val next = SettingsSearchHistory.record(
                current = SettingsSearchHistory.decode(prefs[KEY_SETTINGS_SEARCH_HISTORY]),
                query = query
            )
            prefs[KEY_SETTINGS_SEARCH_HISTORY] = SettingsSearchHistory.encode(next)
        }
    }

    override suspend fun clearSettingsSearchHistory() {
        context.dataStore.edit { it.remove(KEY_SETTINGS_SEARCH_HISTORY) }
    }

    override suspend fun setAppShortcutOrder(shortcutIds: List<String>) {
        context.dataStore.edit {
            // Persist an explicit empty value too: users may deliberately choose no dynamic
            // shortcuts, while a missing preference means "keep the four legacy defaults".
            it[KEY_APP_SHORTCUT_ORDER] = normalizeAppShortcutOrder(shortcutIds.joinToString(","))
                .joinToString(",")
        }
    }

    private suspend fun setShortcutLabel(
        key: Preferences.Key<String>,
        label: String,
        defaultLabel: String
    ) {
        context.dataStore.edit {
            val safeLabel = label.trim().take(24)
            if (safeLabel.isBlank() || safeLabel == defaultLabel) it.remove(key) else it[key] = safeLabel
        }
    }



    override suspend fun setHomeFeatureWallpaperUri(uri: String) {
        context.dataStore.edit { preferences ->
            if (uri.isBlank()) preferences.remove(KEY_HOME_FEATURE_WALLPAPER_URI)
            else preferences[KEY_HOME_FEATURE_WALLPAPER_URI] = uri.trim()
        }
    }

    override suspend fun setHomeAiMixVisible(visible: Boolean) {
        context.dataStore.edit { it[KEY_HOME_AI_MIX_VISIBLE] = visible }
    }

    override suspend fun setContinuePlaybackRowVisible(visible: Boolean) {
        context.dataStore.edit { it[SettingsManager.KEY_LIBRARY_CONTINUE_PLAYBACK_ROW_VISIBLE] = visible }
    }

    override suspend fun setCategoryContinuePlaybackRowVisible(visible: Boolean) {
        context.dataStore.edit { it[SettingsManager.KEY_CATEGORY_CONTINUE_PLAYBACK_ROW_VISIBLE] = visible }
    }

    override suspend fun setHomeRecentSectionMode(mode: Int) {
        context.dataStore.edit {
            it[KEY_HOME_RECENT_SECTION_MODE] = mode.coerceIn(
                HOME_RECENT_SECTION_MODE_PLAYED,
                HOME_RECENT_SECTION_MODE_ADDED
            )
        }
    }

    override suspend fun setHomeSectionOrder(order: String) {
        context.dataStore.edit {
            it[KEY_HOME_SECTION_ORDER] = order.trim()
            it[SettingsManager.KEY_HOME_SECTION_ORDER_UPDATED] = true
        }
    }

    override suspend fun setHomeHiddenSections(hidden: String) {
        context.dataStore.edit { it[KEY_HOME_HIDDEN_SECTIONS] = hidden.trim() }
    }

    override suspend fun setHomeLibraryTileOrder(order: String) {
        context.dataStore.edit { it[KEY_HOME_LIBRARY_TILE_ORDER] = order.trim() }
    }

    override suspend fun setHomeHiddenLibraryTiles(hidden: String) {
        context.dataStore.edit { it[KEY_HOME_HIDDEN_LIBRARY_TILES] = hidden.trim() }
    }

    override suspend fun setHomeOnlineTileOrder(order: String) {
        context.dataStore.edit { it[KEY_HOME_ONLINE_TILE_ORDER] = order.trim() }
    }

    override suspend fun setHomeHiddenOnlineTiles(hidden: String) {
        context.dataStore.edit { it[KEY_HOME_HIDDEN_ONLINE_TILES] = hidden.trim() }
    }

    override suspend fun setHomeTilePinButtonsVisible(visible: Boolean) {
        context.dataStore.edit { it[KEY_HOME_TILE_PIN_BUTTONS_VISIBLE] = visible }
    }
}

internal fun defaultHomeShortcutCount(smallestScreenWidthDp: Int): Int = if (smallestScreenWidthDp >= 600) 8 else 4

internal fun migratedHomeItems(order: String, hidden: String, shortcuts: Boolean, shortcutCount: Int = 4): String {
    val defaults = SettingsManager.DEFAULT_HOME_LIBRARY_TILE_ORDER.split(',')
    val visible = (order.split(',') + defaults).distinct().filter { it in defaults && it !in hidden.split(',') }
    return (if (shortcuts) visible.take(shortcutCount) else visible.drop(shortcutCount)).joinToString(",")
}

internal fun normalizeHomeSearchTarget(value: String): String =
    value.takeIf { it in setOf("local", "lx", "musicfree") } ?: "local"

internal fun resolveHomeSearchTarget(librarySource: String, preference: String): String =
    if (librarySource == SettingsManager.LIBRARY_SOURCE_NETEASE) "netease" else normalizeHomeSearchTarget(preference)
