package com.ella.music.ui.home

import com.ella.music.ui.components.dragSelectList
import com.ella.music.ui.components.dragSelectGrid

import kotlinx.coroutines.ensureActive

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.shrinkVertically
import top.yukonga.miuix.kmp.icon.extended.GridView
import top.yukonga.miuix.kmp.icon.extended.ListView
import android.widget.Toast
import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.runtime.CompositionLocalProvider
import com.ella.music.ui.components.LibraryMorphScene
import com.ella.music.ui.components.LibraryMorphLane
import com.ella.music.ui.components.LocalLibraryMorphLane
import com.ella.music.ui.components.libraryMorphPart
import com.ella.music.ui.components.libraryMorphSurface
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.style.TextOverflow
import com.ella.music.R
import com.ella.music.data.SettingsManager
import com.ella.music.data.model.FAVORITES_PLAYLIST_ID
import com.ella.music.data.model.Song
import com.ella.music.data.repository.RemoteAudioCache
import com.ella.music.data.model.UserPlaylist
import com.ella.music.data.model.playlistIdentityKey
import com.ella.music.data.splitArtistNames
import com.ella.music.data.tagIdentityKey
import com.ella.music.ui.LibrarySortUiState
import com.ella.music.ui.components.ConfirmDangerDialog
import com.ella.music.ui.components.AddToPlaylistSheet
import com.ella.music.ui.components.EllaSearchBar
import com.ella.music.ui.components.LibrarySelectionState
import com.ella.music.ui.components.EllaMiuixBottomSheet
import com.ella.music.ui.components.EllaCenteredLoadingIndicator
import com.ella.music.ui.components.ArtistPickerContent
import com.ella.music.ui.components.DoubleTapScrollOverlay
import com.ella.music.ui.components.DirectionalSortField
import com.ella.music.ui.components.EllaSmallTopAppBar
import com.ella.music.ui.components.FastIndexBar
import com.ella.music.ui.components.LazyListScrollIndicator
import com.ella.music.ui.components.RestoreListScrollAfterSearch
import com.ella.music.ui.components.SideIndexListEndPadding
import com.ella.music.ui.components.ScrollIndicatorListEndPadding
import com.ella.music.ui.components.SongItem
import com.ella.music.ui.components.SafeCoverImage
import com.ella.music.ui.components.DefaultAlbumCover
import com.ella.music.ui.components.SelectionCheck
import com.ella.music.ui.components.ArtworkUsage
import com.ella.music.ui.components.rememberSongArtworkState
import com.ella.music.ui.components.SongMoreActionHost
import com.ella.music.ui.components.SongSelectionActionRow
import com.ella.music.ui.components.ShuffleAllSummaryButton

import com.ella.music.ui.components.SortDropdownMenu
import com.ella.music.ui.components.TagEditorOptionKind
import com.ella.music.ui.components.buildTagEditorOptions
import com.ella.music.ui.components.createPlaylistOrShowDuplicateToast
import com.ella.music.ui.components.ellaPageBackground
import com.ella.music.ui.components.isAppWallpaperVisible
import com.ella.music.ui.components.launchTagEditorOption
import com.ella.music.ui.components.rememberLibrarySelectionState
import com.ella.music.ui.components.rememberSongDeleteRequester
import com.ella.music.ui.components.directionalSortDropdownItems
import com.ella.music.ui.listmodel.SortDirection
import com.ella.music.ui.search.searchPlaybackSelection
import com.ella.music.viewmodel.MainViewModel
import com.ella.music.viewmodel.PlayerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.FloatingActionButton
import top.yukonga.miuix.kmp.basic.Icon
import top.yukonga.miuix.kmp.basic.IconButton
import top.yukonga.miuix.kmp.basic.PullToRefresh
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.rememberPullToRefreshState
import top.yukonga.miuix.kmp.icon.MiuixIcons
import top.yukonga.miuix.kmp.icon.basic.Search
import top.yukonga.miuix.kmp.icon.extended.Close
import top.yukonga.miuix.kmp.icon.extended.Delete
import top.yukonga.miuix.kmp.icon.extended.Download
import top.yukonga.miuix.kmp.icon.extended.SelectAll
import top.yukonga.miuix.kmp.icon.extended.More
import top.yukonga.miuix.kmp.theme.MiuixTheme
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withTimeoutOrNull

@Composable
fun LibraryScreen(
    mainViewModel: MainViewModel,
    playerViewModel: PlayerViewModel,
    onNavigateToPlayer: () -> Unit,
    onNavigateToAbout: () -> Unit,
    onNavigateToSearch: () -> Unit,
    onNavigateToAlbum: (Long) -> Unit = {},
    onNavigateToArtist: (String) -> Unit = {},
    onNavigateToAiChat: () -> Unit = {},
    onNavigateToAnalytics: () -> Unit = {},
    onNavigateToSettings: () -> Unit = {}
) {
    val songs by mainViewModel.songs.collectAsState()
    val playlists by mainViewModel.playlists.collectAsState()
    val currentSong by playerViewModel.currentSong.collectAsState()
    val playbackStats by mainViewModel.playbackStats.collectAsState()
    val favoriteSongKeys by playerViewModel.favoriteSongKeys.collectAsState()
    val locateCurrentSongRequest by playerViewModel.locateCurrentSongRequest.collectAsState()
    com.ella.music.ui.components.RememberPlaybackSourceScreen(
        com.ella.music.data.CategoryResumeKeys.HOME
    )
    val libraryCacheLoaded by mainViewModel.libraryCacheLoaded.collectAsState()
    val isScanning by mainViewModel.isScanning.collectAsState()
    val scanProgress by mainViewModel.scanProgress.collectAsState()
    var libraryRefreshing by remember { mutableStateOf(false) }
    val libraryPullToRefreshState = rememberPullToRefreshState()
    LaunchedEffect(libraryRefreshing, isScanning) {
        if (!libraryRefreshing) return@LaunchedEffect
        val started = withTimeoutOrNull(1_500) {
            snapshotFlow { isScanning }.first { it }
        }
        if (started == true) {
            snapshotFlow { isScanning }.first { !it }
        }
        libraryRefreshing = false
    }
    val ratingRevision by mainViewModel.ratingRevision.collectAsState()
    val context = LocalContext.current
    val settingsManager = remember(context) { SettingsManager.getInstance(context) }
    val openPlayerOnPlay by settingsManager.openPlayerOnPlay.collectAsState(initial = false)
    val showPlayNextInLists by settingsManager.showPlayNextInLists.collectAsState(initial = false)
    val excludeSearchResultsFromPlaylist by settingsManager.excludeSearchResultsFromPlaylist.collectAsState(initial = false)
    val searchClickPlaybackMode by settingsManager.searchClickPlaybackMode.collectAsState(
        initial = SettingsManager.DEFAULT_SEARCH_CLICK_PLAYBACK_MODE
    )
    val librarySongLayout by settingsManager.librarySongLayout.collectAsState(
        initial = SettingsManager.LIBRARY_LAYOUT_LIST
    )
    val librarySongGridColumnsPhone by settingsManager.librarySongGridColumnsPhone.collectAsState(initial = 2)
    val librarySongGridColumnsTablet by settingsManager.librarySongGridColumnsTablet.collectAsState(initial = 5)
    val librarySongRatingDisplayMode by settingsManager.songRatingDisplayMode.collectAsState(
        initial = SettingsManager.SONG_RATING_DISPLAY_STAR_NUMBER
    )
    val librarySongTitleMarqueeEnabled by settingsManager.librarySongTitleMarquee.collectAsState(initial = true)
    val libraryShowRatingFilter by settingsManager.libraryShowRatingFilter.collectAsState(initial = true)
    val libraryConfiguration = androidx.compose.ui.platform.LocalConfiguration.current
    val libraryIsTablet = libraryConfiguration.smallestScreenWidthDp >= 600
    val librarySongGridColumns = if (libraryIsTablet) {
        librarySongGridColumnsTablet
    } else {
        librarySongGridColumnsPhone
    }
    val librarySongGrid = librarySongLayout == SettingsManager.LIBRARY_LAYOUT_GRID
    val librarySongMultiRow = librarySongLayout == SettingsManager.LIBRARY_LAYOUT_MULTI_ROW
    val pageBackground = ellaPageBackground()
    val wallpaperVisible = isAppWallpaperVisible()
    val libraryPageBackground = pageBackground
    val searchBarColor = if (wallpaperVisible) {
        MiuixTheme.colorScheme.surfaceContainerHigh.copy(alpha = 0.74f)
    } else {
        MiuixTheme.colorScheme.surfaceContainerHigh
    }

    var searchQuery by remember { mutableStateOf("") }
    var searchExpanded by remember { mutableStateOf(false) }
    var ratingFilter by remember { mutableStateOf(HomeRatingFilterUiState.selection) }
    val sortIndex by settingsManager.librarySongSortIndex.collectAsState(initial = LibrarySortUiState.librarySongSortIndex)
    val sortMode = HomeSortMode.entries.getOrElse(sortIndex) { HomeSortMode.Title }
    LaunchedEffect(sortIndex) {
        LibrarySortUiState.librarySongSortIndex = sortIndex
    }
    val selection = rememberLibrarySelectionState<Long>()
    var actionSong by remember { mutableStateOf<Song?>(null) }
    var artistChoices by remember { mutableStateOf<List<String>>(emptyList()) }
    var playlistPickerSongs by remember { mutableStateOf<List<Song>?>(null) }
    var createPlaylistSongs by remember { mutableStateOf<List<Song>?>(null) }
    var tagEditorSong by remember { mutableStateOf<Song?>(null) }
    var songInfoSheetSong by remember { mutableStateOf<Song?>(null) }
    var aiInterpretationSong by remember { mutableStateOf<Song?>(null) }
    var listCoversEnabled by remember { mutableStateOf(false) }
    var pendingConfirmDeleteSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    val remoteCacheProgress by mainViewModel.remoteAudioCacheProgress.collectAsState()
    LaunchedEffect(remoteCacheProgress.active, remoteCacheProgress.completed, remoteCacheProgress.failed, remoteCacheProgress.cancelled) {
        val p = remoteCacheProgress
        if (p.active || p.total <= 0) return@LaunchedEffect
        if (p.cancelled) {
            Toast.makeText(context, R.string.library_cache_cancelled, Toast.LENGTH_SHORT).show()
        } else if (p.completed > 0 || p.failed > 0) {
            Toast.makeText(
                context,
                context.getString(R.string.library_cache_done, p.completed, p.failed),
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    var scrollToTopRequest by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    fun applyHomeSortMode(mode: HomeSortMode) {
        LibrarySortUiState.librarySongSortIndex = mode.ordinal
        scope.launch { settingsManager.setLibrarySongSortIndex(mode.ordinal) }
        scrollToTopRequest++
    }

    fun navigateToArtistOrChoose(artistText: String) {
        val artists = splitArtistNames(artistText)
            .distinctBy { it.tagIdentityKey() }
        when (artists.size) {
            0 -> Toast.makeText(context, context.getString(R.string.player_no_artist_jump), Toast.LENGTH_SHORT).show()
            1 -> onNavigateToArtist(artists.first())
            else -> artistChoices = artists
        }
    }
    val requestDeleteSongs = rememberSongDeleteRequester(mainViewModel)

    LaunchedEffect(Unit) {
        delay(260L)
        listCoversEnabled = true
    }

    var audioFiltersExpanded by remember { mutableStateOf(false) }
    var audioFilter by remember { mutableStateOf(LibraryAudioFilter()) }
    val filterLibrarySource by settingsManager.librarySource.collectAsState(initial = SettingsManager.LIBRARY_SOURCE_LOCAL)
    val latestFilterSongs = rememberUpdatedState(songs)
    val effectiveRatingFilter = if (libraryShowRatingFilter) ratingFilter else HomeRatingFilterSelection()
    val activeFavoriteSongKeys = if (effectiveRatingFilter.requiresFavoriteKeys()) favoriteSongKeys else emptySet()
    val activeRatingRevision = if (effectiveRatingFilter.hasRatingConstraint()) ratingRevision else 0
    val filterProgress by produceState(
        initialValue = LibraryAudioFilterProgress(songs, songs.size, songs.size, true),
        filterLibrarySource, searchQuery.trim(), effectiveRatingFilter, activeFavoriteSongKeys, activeRatingRevision, audioFilter
    ) {
        val filterSnapshot = audioFilter
        val ratingSnapshot = effectiveRatingFilter
        val query = searchQuery.trim()
        filterLibrarySnapshots(snapshotFlow { latestFilterSongs.value }) { songs -> kotlinx.coroutines.flow.flow {
            if (filterSnapshot.isEmpty && ratingSnapshot.isUnfiltered() && query.isBlank()) {
                emit(LibraryAudioFilterProgress(songs, songs.size, songs.size, true))
                return@flow
            }
            emit(LibraryAudioFilterProgress(emptyList(), 0, songs.size, false))
            val base = withContext(Dispatchers.IO) {
                if (ratingSnapshot.isUnfiltered()) songs else songs.filter { song ->
                    kotlinx.coroutines.currentCoroutineContext().ensureActive()
                    ratingSnapshot.matches(
                        rating = mainViewModel.getSongRating(song),
                        isFavorite = song.playlistIdentityKey() in activeFavoriteSongKeys
                    )
                }
            }
            val searched = if (query.isBlank()) base else mainViewModel.filterSongsBySearchSnapshot(base, query)
            filterLibraryAudio(searched, filterSnapshot, mainViewModel.audioQualityRevision, mainViewModel::getAudioQualityInfo).collect { emit(it) }
        }.flowOn(Dispatchers.IO) }.collect { value = it }
    }
    val filteredSongs = filterProgress.songs
    // Keep initialValue O(1) and avoid rendering the full unsorted list before the background
    // sort completes. Large libraries can otherwise allocate several 60k-entry helper
    // collections twice while switching into this screen.
    val sortedResult by produceState<HomeSortedSongs?>(
        initialValue = null,
        filteredSongs,
        sortMode,
        LibrarySortUiState.randomSortSeed
    ) {
        value = withContext(Dispatchers.Default) { filteredSongs.cachedSortedForHomeMode(sortMode) }
    }
    val sortedSongs = sortedResult?.songs.orEmpty()
    val sortKeysBySongId = sortedResult?.sortKeysBySongId.orEmpty()
    fun shuffleLibraryAndStart() {
        val queueSongs = if (sortMode == HomeSortMode.Random) {
            val seed = LibrarySortUiState.reshuffleRandomSort()
            scope.launch { settingsManager.setRandomSortSeed(seed) }
            LibrarySortUiState.randomizedSongs(filteredSongs, seed)
        } else {
            filteredSongs.shuffled()
        }
        if (queueSongs.isNotEmpty()) {
            playerViewModel.setShuffledPlaylist(
                queueSongs,
                0,
                resumeCategoryKey = com.ella.music.data.CategoryResumeKeys.HOME,
                preserveOrder = true
            )
        }
        if (openPlayerOnPlay) onNavigateToPlayer()
    }
    val visibleSongIds = remember(selection.selectionMode, sortedSongs) {
        if (selection.selectionMode) sortedSongs.mapTo(mutableSetOf()) { it.id } else emptySet()
    }
    val sortedSongIndexById = remember(selection.selectionMode, sortedSongs) {
        if (!selection.selectionMode) {
            emptyMap()
        } else {
            buildMap {
                sortedSongs.forEachIndexed { index, song -> put(song.id, index) }
            }
        }
    }
    val selectedVisibleCount = remember(selection.selectionMode, selection.selectedIds, visibleSongIds) {
        if (selection.selectionMode) selection.selectedIds.count { it in visibleSongIds } else 0
    }
    val rangeSelectionAvailable = remember(sortedSongIndexById, selection.selectedIds, selection.rangeAnchorId, selection.rangeTargetId) {
        selection.isRangeSelectionAvailable(sortedSongIndexById)
    }
    val selectedSongsForDrag = remember(selection.selectedIds, sortedSongs) {
        sortedSongs.filter { it.id in selection.selectedIds }
    }

    LaunchedEffect(selection.selectionMode, visibleSongIds) {
        if (!selection.selectionMode) return@LaunchedEffect
        selection.selectedIds = selection.selectedIds.filterTo(mutableSetOf()) { it in visibleSongIds }
        if (selection.rangeAnchorId !in visibleSongIds) selection.rangeAnchorId = null
        if (selection.rangeTargetId !in visibleSongIds) selection.rangeTargetId = null
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(libraryPageBackground)
            .windowInsetsPadding(WindowInsets.statusBars)
    ) {
        Box {
            EllaSmallTopAppBar(
                title = if (!selection.selectionMode && !libraryShowRatingFilter) {
                    stringResource(R.string.tab_library)
                } else {
                    ""
                },
                color = libraryPageBackground,
                titleStartPadding = if (!selection.selectionMode && libraryShowRatingFilter && songs.isNotEmpty()) 108.dp else 20.dp,
                // Selection mode adds a download action on the left of the row. The old 144dp
                // inset left that button under the double-tap overlay, so taps never arrived (#657).
                titleEndPadding = if (selection.selectionMode) 216.dp else 192.dp,
                navigationIcon = {
                    if (!selection.selectionMode && libraryShowRatingFilter && songs.isNotEmpty()) {
                        RatingFilterMenu(
                            selection = ratingFilter,
                            onSelectionChange = {
                                ratingFilter = it
                                HomeRatingFilterUiState.selection = it
                            }
                        )
                    }
                },
                actions = {
                    if (selection.selectionMode) {
                        IconButton(onClick = {
                            val selectedSongs = sortedSongs.filter { it.id in selection.selectedIds }
                            val cacheable = selectedSongs.filter(RemoteAudioCache::isCacheableRemoteSong)
                            if (cacheable.isEmpty()) {
                                Toast.makeText(context, R.string.library_cache_nothing, Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(
                                    context,
                                    context.getString(R.string.library_cache_started, cacheable.size),
                                    Toast.LENGTH_SHORT
                                ).show()
                                mainViewModel.cacheSongsToLocal(cacheable)
                            }
                        }) {
                            Icon(
                                imageVector = MiuixIcons.Regular.Download,
                                contentDescription = stringResource(R.string.library_cache_to_local),
                                tint = MiuixTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(onClick = {
                            val selectedSongs = sortedSongs.filter { it.id in selection.selectedIds }
                            if (selectedSongs.isEmpty()) {
                                Toast.makeText(context, context.getString(R.string.library_select_songs_first), Toast.LENGTH_SHORT).show()
                            } else {
                                playlistPickerSongs = selectedSongs
                            }
                        }) {
                            com.ella.music.ui.components.AddToPlaylistActionIcon(
                                contentDescription = stringResource(R.string.category_playlist),
                                tint = MiuixTheme.colorScheme.primary
                            )
                        }
                        IconButton(onClick = {
                            val selectedSongs = sortedSongs.filter { it.id in selection.selectedIds }
                            if (selectedSongs.isEmpty()) {
                                Toast.makeText(context, context.getString(R.string.library_select_songs_first), Toast.LENGTH_SHORT).show()
                            } else {
                                pendingConfirmDeleteSongs = selectedSongs
                            }
                        }) {
                            Icon(
                                imageVector = MiuixIcons.Regular.Delete,
                                contentDescription = stringResource(R.string.common_delete),
                                tint = Color(0xFFE5484D),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(onClick = {
                            selection.finishSelectionMode()
                        }) {
                            Icon(
                                imageVector = MiuixIcons.Regular.Close,
                                contentDescription = stringResource(R.string.common_exit_selection),
                                tint = MiuixTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    } else {
                        IconButton(onClick = {
                            audioFiltersExpanded = true
                        }) {
                            Icon(
                                painter = androidx.compose.ui.res.painterResource(R.drawable.ic_audio_filter),
                                contentDescription = stringResource(R.string.library_audio_filter),
                                tint = if (audioFiltersExpanded || !audioFilter.isEmpty) MiuixTheme.colorScheme.primary else MiuixTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(onClick = {
                            selection.selectionMode = true
                            selection.selectedIds = emptySet()
                        }) {
                            Icon(
                                imageVector = MiuixIcons.Regular.SelectAll,
                                contentDescription = stringResource(R.string.common_select_all),
                                tint = MiuixTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        IconButton(onClick = {
                            searchExpanded = !searchExpanded
                            if (!searchExpanded) searchQuery = ""
                        }) {
                            Icon(
                                imageVector = MiuixIcons.Basic.Search,
                                contentDescription = stringResource(R.string.common_search),
                                tint = MiuixTheme.colorScheme.onSurface,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        SortDropdownMenu(
                            items = directionalSortDropdownItems(
                                fields = HomeSortField.entries.filter { it != HomeSortField.Random }.map { field ->
                                    DirectionalSortField(
                                        field = field,
                                        text = stringResource(field.labelRes),
                                        defaultDirection = when (field) {
                                            HomeSortField.DateAdded,
                                            HomeSortField.DateModified,
                                            HomeSortField.Duration,
                                            HomeSortField.FileSize -> SortDirection.Descending
                                            else -> SortDirection.Ascending
                                        }
                                    )
                                },
                                selectedField = sortMode.sortField(),
                                selectedDirection = if (sortMode.isDescending()) {
                                    SortDirection.Descending
                                } else {
                                    SortDirection.Ascending
                                },
                                ascendingSummary = stringResource(R.string.common_sort_ascending),
                                descendingSummary = stringResource(R.string.common_sort_descending)
                            ) { field, direction ->
                                applyHomeSortMode(
                                    field.toMode(direction == SortDirection.Descending)
                                )
                            } + listOf(
                                com.ella.music.ui.components.randomSortDropdownItem(
                                    selected = sortMode == HomeSortMode.Random,
                                    onSelect = { applyHomeSortMode(HomeSortMode.Random) }
                                )
                            )
                        )
                    }
                }
            )
            DoubleTapScrollOverlay(
                onDoubleTap = { scrollToTopRequest++ },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                startPadding = if (!selection.selectionMode && songs.isNotEmpty()) 108.dp else 20.dp,
                endPadding = if (selection.selectionMode) 216.dp else 188.dp
            )
        }

        BackHandler(enabled = selection.selectionMode || searchExpanded || audioFiltersExpanded) {
            when {
                selection.selectionMode -> {
                    selection.finishSelectionMode()
                }
                audioFiltersExpanded -> { audioFiltersExpanded = false }
                searchExpanded -> {
                    searchExpanded = false
                    searchQuery = ""
                }
            }
        }

        com.ella.music.ui.components.EllaMiuixBottomSheet(
            show = audioFiltersExpanded,
            title = stringResource(R.string.library_audio_filter),
            onDismissRequest = { audioFiltersExpanded = false }
        ) {
            Column {
                LibraryAudioFilterPanel(audioFilter) { audioFilter = it }
                Text(
                    text = if (filterProgress.complete) stringResource(R.string.library_audio_filter_count, filteredSongs.size)
                        else stringResource(R.string.library_audio_filter_progress, filterProgress.checked, filterProgress.total, filteredSongs.size),
                    fontSize = 13.sp, modifier = Modifier.padding(12.dp),
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                )
                com.ella.music.ui.components.EllaMiuixSheetActions(
                    cancelText = stringResource(R.string.common_reset),
                    confirmText = stringResource(R.string.common_done),
                    onCancel = { audioFilter = LibraryAudioFilter() },
                    onConfirm = { audioFiltersExpanded = false }
                )
            }
        }
        if (!filterProgress.complete) Text(
            stringResource(R.string.library_audio_filter_progress, filterProgress.checked, filterProgress.total, filteredSongs.size),
            color = MiuixTheme.colorScheme.primary, fontSize = 13.sp,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
        )
        if (searchExpanded) {
            EllaSearchBar(
                query = searchQuery,
                onQueryChange = { searchQuery = it },
                onSearch = { searchExpanded = false },
                placeholder = stringResource(R.string.library_search_placeholder),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp),
                containerColor = searchBarColor
            )
        }

        AnimatedVisibility(
            visible = isScanning && scanProgress > 0,
            enter = expandVertically(),
            exit = shrinkVertically()
        ) {
            Text(
                    text = stringResource(R.string.library_scanning_count, scanProgress),
                fontSize = 13.sp,
                color = MiuixTheme.colorScheme.primary,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }

        if (songs.isEmpty() && !libraryCacheLoaded && !isScanning) {
            EllaCenteredLoadingIndicator()
        } else if (songs.isEmpty() && !isScanning) {
            PullToRefresh(
                isRefreshing = libraryRefreshing,
                onRefresh = { libraryRefreshing = true; mainViewModel.scanMusic() },
                pullToRefreshState = libraryPullToRefreshState,
                color = MiuixTheme.colorScheme.onSurface,
                refreshTexts = listOf(
                    stringResource(R.string.library_pull_to_refresh),
                    stringResource(R.string.library_release_to_refresh),
                    stringResource(R.string.library_refreshing),
                    stringResource(R.string.library_refresh_complete)
                ),
                modifier = Modifier.fillMaxSize()
            ) {
                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    item {
                        Box(modifier = Modifier.fillParentMaxSize(), contentAlignment = Alignment.Center) {
                            Text(
                                text = stringResource(R.string.library_empty_hint),
                                color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                            )
                        }
                    }
                }
            }
        } else if (filterProgress.complete && filteredSongs.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(stringResource(R.string.library_search_no_results), color = MiuixTheme.colorScheme.onSurfaceVariantSummary)
            }
        } else if (sortedResult == null) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = stringResource(R.string.library_organizing),
                    color = MiuixTheme.colorScheme.onSurfaceVariantSummary
                )
            }
        } else {
            // Two interchangeable list states: the settled list renders through one of them while
            // the other is pre-positioned as the pinch transition target, so a committed pinch
            // can swap their roles without any visible scroll jump.
            val listStateA = rememberSaveable(saver = androidx.compose.foundation.lazy.LazyListState.Saver) {
                androidx.compose.foundation.lazy.LazyListState()
            }
            val listStateB = rememberSaveable(saver = androidx.compose.foundation.lazy.LazyListState.Saver) {
                androidx.compose.foundation.lazy.LazyListState()
            }
            var settledListStateUsesA by rememberSaveable { mutableStateOf(true) }
            val listState = if (settledListStateUsesA) listStateA else listStateB
            val pinchTargetListState = if (settledListStateUsesA) listStateB else listStateA
            val libraryLandscape = libraryConfiguration.orientation ==
                android.content.res.Configuration.ORIENTATION_LANDSCAPE
            var pendingLayoutAnchor by remember { mutableStateOf<LibraryLayoutAnchor?>(null) }
            val libraryPinch = remember { LibraryPinchState(librarySongLayout) }
            var pinchTargetReady by remember { mutableStateOf(false) }
            val libraryMorph = remember(libraryPinch) {
                LibraryMorphScene(
                    requested = { libraryPinch.isTransitioning && pinchTargetReady },
                    source = { libraryPinch.sourceLayout },
                    target = { libraryPinch.targetLayout },
                    progress = { libraryPinch.transitionProgress },
                    settledLane = { settledListStateUsesA },
                )
            }
            val settledLayout = libraryPinch.currentLayout
            val morphPrepared = libraryMorph.hasPreparedPair()
            val needsArtworkFallback = libraryMorph.entries.any { (key, entry) ->
                key.laneId == settledListStateUsesA && key.part == "cover" &&
                    !entry.hasArtwork && libraryMorph.previousArtwork(key) != null
            }
            val libraryLanes = remember { LibraryPresentationLanes(librarySongLayout) }
            // Keep the inactive lane's previous contents alive as an artwork fallback.
            // Only rebind it when preparing the next transition.
            libraryLanes.bind(settledListStateUsesA, libraryPinch.isTransitioning,
                libraryPinch.sourceLayout, libraryPinch.targetLayout, settledLayout)
            androidx.compose.runtime.SideEffect {
                libraryMorph.prepared = morphPrepared
                if (!libraryPinch.isTransitioning && !needsArtworkFallback) libraryLanes.releaseInactive()
            }

            fun switchLibraryLayout(nextLayout: Int) {
                if (nextLayout == librarySongLayout || sortedSongs.isEmpty()) return
                pendingLayoutAnchor = LibraryLayoutAnchor(
                    songIndex = libraryLayoutAnchorSongIndex(
                        firstVisibleItemIndex = listState.firstVisibleItemIndex,
                        columns = libraryLayoutColumnCount(
                            multiRow = librarySongMultiRow,
                            grid = librarySongGrid,
                            landscape = libraryLandscape,
                            gridColumns = librarySongGridColumns
                        )
                    ).coerceIn(0, sortedSongs.lastIndex),
                    targetLayout = nextLayout
                )
                libraryPinch.onExternalLayout(nextLayout)
                scope.launch { settingsManager.setLibrarySongLayout(nextLayout) }
            }
            RestoreListScrollAfterSearch(
                searchExpanded = searchExpanded,
                query = searchQuery,
                listState = listState
            )
            var fastScrollJob by remember { mutableStateOf<Job?>(null) }
            var handledLocateRequest by remember { mutableStateOf(locateCurrentSongRequest) }
            val currentSongKey = remember(currentSong) { currentSong?.playlistIdentityKey() }
            val currentSongIndex = remember(sortedSongs, currentSongKey) {
                currentSongKey ?: return@remember -1
                sortedSongs.indexOfFirst { it.playlistIdentityKey() == currentSongKey }
            }
            val currentVisibleItemIndex = if ((librarySongGrid || librarySongMultiRow) && currentSongIndex >= 0) {
                currentSongIndex / libraryLayoutColumnCount(
                    multiRow = librarySongMultiRow,
                    grid = librarySongGrid,
                    landscape = libraryLandscape,
                    gridColumns = librarySongGridColumns
                )
            } else {
                currentSongIndex
            }
            val showLocateCurrentSongButton by remember(
                currentVisibleItemIndex,
                selection.selectionMode,
                librarySongGrid,
                librarySongMultiRow,
                librarySongGridColumns,
                libraryLandscape
            ) {
                derivedStateOf {
                    if (selection.selectionMode || currentVisibleItemIndex < 0) return@derivedStateOf false
                    val visibleItems = listState.layoutInfo.visibleItemsInfo
                    val firstVisible = visibleItems.firstOrNull()?.index
                        ?: return@derivedStateOf false
                    val lastVisible = visibleItems.lastOrNull()?.index ?: firstVisible
                    currentVisibleItemIndex !in (firstVisible - 2)..(lastVisible + 2)
                }
            }

            LaunchedEffect(locateCurrentSongRequest, currentSongIndex) {
                if (!com.ella.music.ui.components.shouldHonorLocateCurrentSongRequest(
                        locateCurrentSongRequest,
                        handledLocateRequest,
                        currentSongIndex
                    )
                ) {
                    return@LaunchedEffect
                }
                handledLocateRequest = locateCurrentSongRequest
                listState.animateScrollToItem(currentVisibleItemIndex)
            }

            LaunchedEffect(scrollToTopRequest) {
                if (scrollToTopRequest > 0) listState.animateScrollToItem(0)
            }

            LaunchedEffect(librarySongLayout, pendingLayoutAnchor, sortedSongs.size) {
                val anchor = pendingLayoutAnchor ?: return@LaunchedEffect
                if (anchor.targetLayout != librarySongLayout || sortedSongs.isEmpty()) {
                    return@LaunchedEffect
                }
                val columns = libraryLayoutColumnCount(
                    multiRow = librarySongMultiRow,
                    grid = librarySongGrid,
                    landscape = libraryLandscape,
                    gridColumns = librarySongGridColumns
                )
                val lastItemIndex = if (columns > 1) {
                    (sortedSongs.lastIndex / columns).coerceAtLeast(0)
                } else {
                    sortedSongs.lastIndex
                }
                listState.scrollToItem(
                    libraryLayoutItemIndexForSong(
                        songIndex = anchor.songIndex,
                        columns = columns
                    ).coerceIn(0, lastItemIndex)
                )
                pendingLayoutAnchor = null
            }

            LaunchedEffect(librarySongLayout) {
                libraryPinch.onExternalLayout(librarySongLayout)
            }

            // Preserve the song under the fingers, rather than always anchoring the top row.
            LaunchedEffect(libraryPinch.isTransitioning) {
                if (libraryPinch.isTransitioning && sortedSongs.isNotEmpty()) {
                    val sourceColumns = libraryLayoutColumnCount(
                        multiRow = libraryPinch.sourceLayout == SettingsManager.LIBRARY_LAYOUT_MULTI_ROW,
                        grid = libraryPinch.sourceLayout == SettingsManager.LIBRARY_LAYOUT_GRID,
                        landscape = libraryLandscape,
                        gridColumns = librarySongGridColumns
                    )
                    val targetColumns = libraryLayoutColumnCount(
                        multiRow = libraryPinch.targetLayout == SettingsManager.LIBRARY_LAYOUT_MULTI_ROW,
                        grid = libraryPinch.targetLayout == SettingsManager.LIBRARY_LAYOUT_GRID,
                        landscape = libraryLandscape,
                        gridColumns = librarySongGridColumns
                    )
                    val focal = libraryPinch.focalPoint
                    val sourceRow = listState.layoutInfo.visibleItemsInfo.minByOrNull {
                        kotlin.math.abs(it.offset + it.size / 2f - focal.y)
                    }
                    val sourceColumn = (focal.x / listState.layoutInfo.viewportSize.width.coerceAtLeast(1) * sourceColumns)
                        .toInt().coerceIn(0, sourceColumns - 1)
                    val songIndex = ((sourceRow?.index ?: listState.firstVisibleItemIndex) * sourceColumns + sourceColumn)
                        .coerceIn(0, sortedSongs.lastIndex)
                    val lastTargetItemIndex = if (targetColumns > 1) {
                        sortedSongs.lastIndex / targetColumns
                    } else {
                        sortedSongs.lastIndex
                    }
                    pinchTargetListState.scrollToItem(
                        libraryLayoutItemIndexForSong(songIndex, targetColumns)
                            .coerceIn(0, lastTargetItemIndex),
                        -(sourceRow?.offset ?: 0)
                    )
                    pinchTargetReady = true
                } else if (!libraryPinch.isTransitioning) {
                    pinchTargetReady = false
                }
            }

            // Compute the per-song index letter once and reuse it for both the bar labels and the
            // scroll targets. Building this inline on every recomposition was O(n) main-thread work
            // that scaled badly for large libraries (1k–10k+ songs).
            val showFastIndexBar = sortMode.sortField() in setOf(HomeSortField.Title, HomeSortField.FileName) && sortedSongs.size > 30
            // Use the layout that is actually rendering the settled list. During a pinch or an
            // external layout toggle the persisted preference can briefly lead/lag the list state;
            // deriving row targets from it would send a two-column list a one-column item index.
            val fastIndexUsesGrid = settledLayout == SettingsManager.LIBRARY_LAYOUT_GRID
            val fastIndexUsesMultiRow = settledLayout == SettingsManager.LIBRARY_LAYOUT_MULTI_ROW
            val fastIndexColumnCount = libraryLayoutColumnCount(
                multiRow = fastIndexUsesMultiRow,
                grid = fastIndexUsesGrid,
                landscape = libraryLandscape,
                gridColumns = librarySongGridColumns
            )
            // The target is a LazyColumn row in multi-row/grid layouts rather than a song index.
            // Include every layout dimension in the memoization keys; otherwise switching from
            // the detailed list to the two-column layout keeps the old per-song targets and the
            // side index appears to stop responding (or jumps to an unrelated row).
            val fastIndexData = remember(
                showFastIndexBar,
                sortedSongs,
                sortKeysBySongId,
                sortMode,
                settledLayout,
                libraryLandscape,
                librarySongGridColumns
            ) {
                if (!showFastIndexBar) {
                    FastIndexData.Empty
                } else {
                    val targets = LinkedHashMap<String, Int>()
                    sortedSongs.forEachIndexed { index, song ->
                        val indexKey = if (sortMode.sortField() == HomeSortField.FileName) {
                            song.fileName.ifBlank { song.path.substringAfterLast('/') }
                        } else {
                            sortKeysBySongId[song.id]
                        }
                        targets.putIfAbsent(
                            song.indexLetter(indexKey),
                            if (fastIndexUsesGrid || fastIndexUsesMultiRow) {
                                index / fastIndexColumnCount
                            } else {
                                index
                            }
                        )
                    }
                    FastIndexData(
                        letters = targets.keys.toList(),
                        targets = targets
                    )
                }
            }

            Box(modifier = Modifier.fillMaxSize()) {
                val showScrollIndicator = sortedSongs.size > 30 && !showFastIndexBar
                // Keep a small inset so the more button sits near, but not under, the side index bar.
                val listEndInset = when {
                    showFastIndexBar -> SideIndexListEndPadding
                    showScrollIndicator -> ScrollIndicatorListEndPadding
                    else -> 0.dp
                }
                Column(modifier = Modifier.fillMaxSize()) {
                    if (selection.selectionMode) {
                        SongSelectionActionRow(
                            selectedCount = selectedVisibleCount,
                            totalCount = sortedSongs.size,
                            rangeEnabled = rangeSelectionAvailable,
                            allSelected = sortedSongs.isNotEmpty() && selectedVisibleCount == sortedSongs.size,
                            onRangeSelect = { selection.applyRangeSelection(sortedSongs.map { it.id }, sortedSongIndexById) },
                            onSelectAll = { selection.toggleSelectAll(sortedSongs.map { it.id }) },
                            onInvertSelection = { selection.invertSelection(sortedSongs.map { it.id }) },
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
                        )
                    } else {
                        com.ella.music.ui.components.SortSummaryHeader(
                            text =
                                stringResource(
                                    R.string.library_song_count_sorted,
                                    sortedSongs.size,
                                    listOfNotNull(
                                        com.ella.music.ui.components.sortLabel(
                                            sortMode.sortField().labelRes,
                                            sortMode.isDescending()
                                        ),
                                        ratingFilter.summaryLabel(context),
                                ).joinToString(" · ")
                                ),
                            leadingContent = {
                                ShuffleAllSummaryButton(
                                    visible = !selection.selectionMode && sortedSongs.isNotEmpty(),
                                    onClick = ::shuffleLibraryAndStart
                                )
                            },
                            trailingContent = {
                                IconButton(
                                    onClick = {
                                        val nextLayout = when (librarySongLayout) {
                                            SettingsManager.LIBRARY_LAYOUT_LIST ->
                                                SettingsManager.LIBRARY_LAYOUT_MULTI_ROW
                                            SettingsManager.LIBRARY_LAYOUT_MULTI_ROW ->
                                                SettingsManager.LIBRARY_LAYOUT_DETAILS
                                            SettingsManager.LIBRARY_LAYOUT_DETAILS ->
                                                SettingsManager.LIBRARY_LAYOUT_GRID
                                            else -> SettingsManager.LIBRARY_LAYOUT_LIST
                                        }
                                        switchLibraryLayout(nextLayout)
                                    },
                                    modifier = Modifier.size(40.dp)
                                ) {
                                    Icon(
                                        imageVector = when (librarySongLayout) {
                                            SettingsManager.LIBRARY_LAYOUT_MULTI_ROW ->
                                                MiuixIcons.Regular.GridView
                                            else ->
                                                MiuixIcons.Regular.ListView
                                        },
                                        contentDescription = stringResource(
                                            when (librarySongLayout) {
                                                SettingsManager.LIBRARY_LAYOUT_GRID ->
                                                    R.string.library_layout_list
                                                SettingsManager.LIBRARY_LAYOUT_MULTI_ROW ->
                                                    R.string.library_layout_details
                                                SettingsManager.LIBRARY_LAYOUT_DETAILS ->
                                                    R.string.library_layout_grid
                                                else -> R.string.library_layout_multi_row
                                            }
                                        ),
                                        tint = MiuixTheme.colorScheme.onSurface,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }
                            }
                        )
                    }

                    com.ella.music.ui.components.ContinuePlaybackRow(
                        songs = sortedSongs,
                        categoryKey = com.ella.music.data.CategoryResumeKeys.HOME,
                        playbackStats = playbackStats,
                        currentSong = currentSong,
                        onContinue = { index ->
                            if (sortMode == HomeSortMode.Random) {
                                playerViewModel.setShuffledPlaylist(
                                    sortedSongs,
                                    index,
                                    resumeCategoryKey = com.ella.music.data.CategoryResumeKeys.HOME,
                                    preserveOrder = true
                                )
                            } else {
                                playerViewModel.setPlaylist(
                                    sortedSongs,
                                    index,
                                    resumeCategoryKey = com.ella.music.data.CategoryResumeKeys.HOME
                                )
                            }
                            if (openPlayerOnPlay) onNavigateToPlayer()
                        }
                    )

                    // Shared interaction handlers reused by every library layout below.
                    val onLibrarySongClick: (Int) -> Unit = { index ->
                        val playback = searchPlaybackSelection(
                            resultSongs = sortedSongs,
                            selectedIndex = index,
                            excludeResultsFromPlaylist =
                                searchQuery.isNotBlank() && excludeSearchResultsFromPlaylist,
                            playbackMode = if (searchQuery.isNotBlank()) {
                                searchClickPlaybackMode
                            } else {
                                SettingsManager.SEARCH_CLICK_REPLACE
                            },
                            currentQueue = playerViewModel.playlist.value,
                            currentSong = currentSong
                        )
                        if (sortMode == HomeSortMode.Random) {
                            playerViewModel.setShuffledPlaylist(
                                playback.songs,
                                playback.startIndex,
                                resumeCategoryKey = com.ella.music.data.CategoryResumeKeys.HOME,
                                preserveOrder = true
                            )
                        } else {
                            playerViewModel.setPlaylist(
                                playback.songs,
                                playback.startIndex,
                                resumeCategoryKey = com.ella.music.data.CategoryResumeKeys.HOME
                            )
                        }
                        if (openPlayerOnPlay) onNavigateToPlayer()
                    }
                    val onLibrarySongLongClick: (Song) -> Unit = { song ->
                        selection.selectionMode = true
                        if (song.id !in selection.selectedIds) {
                            selection.selectedIds = selection.selectedIds + song.id
                            selection.updateRangeAnchorsForManualSelection(song.id, selectedNow = true)
                        }
                    }
                    val onLibrarySongPlayNext: (Song) -> Unit = { song ->
                        playerViewModel.playNext(song)
                        Toast.makeText(context, context.getString(R.string.song_more_added_to_play_next), Toast.LENGTH_SHORT).show()
                    }
                    val onLibrarySongMore: (Song) -> Unit = { song ->
                        actionSong = song
                    }

                    // Retain both measured endpoints, but let shared cover/text actors own
                    // matching songs throughout the gesture (RawS VirtualList holder geometry).
                    val pinchTransitionActive = libraryPinch.isTransitioning
                    val pinchProgress = libraryPinch.transitionProgress.coerceIn(0f, 1f)
                    val pinchOverpullScale = libraryPinch.transitionScaleFactor
                    val pinchSourceAlpha = if (libraryMorph.active()) 1f - pinchProgress else 1f
                    val pinchSurfaceScale = if (pinchTransitionActive) pinchOverpullScale else libraryPinch.boundaryElasticScale
                    val pinchListContentPadding = PaddingValues(end = listEndInset, bottom = 160.dp)
                    val onPinchCommitted: () -> Unit = {
                        // Swap the two list states so the freshly committed layout keeps the
                        // target state's already-correct scroll position, then persist it.
                        settledListStateUsesA = !settledListStateUsesA
                        pinchTargetReady = false
                        val committedLayout = libraryPinch.currentLayout
                        scope.launch { settingsManager.setLibrarySongLayout(committedLayout) }
                    }

                    PullToRefresh(
                        isRefreshing = libraryRefreshing,
                        onRefresh = {
                            libraryRefreshing = true
                            mainViewModel.scanMusic()
                        },
                        pullToRefreshState = libraryPullToRefreshState,
                        color = MiuixTheme.colorScheme.onSurface,
                        refreshTexts = listOf(
                            stringResource(R.string.library_pull_to_refresh),
                            stringResource(R.string.library_release_to_refresh),
                            stringResource(R.string.library_refreshing),
                            stringResource(R.string.library_refresh_complete)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .weight(1f)
                    ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .clipToBounds()
                            .graphicsLayer {
                                scaleX = pinchSurfaceScale
                                scaleY = pinchSurfaceScale
                            }
                            .libraryMorphSurface(libraryMorph)
                            .libraryPinchGesture(
                                enabled = !selection.selectionMode,
                                state = libraryPinch,
                                onCommitted = onPinchCommitted
                            )
                    ) {
                        // Physical lanes keep their composition identity across commit/rollback.
                        // A target becomes the settled lane; never rebuild its rows at another call site.
                        for (usesA in listOf(true, false)) {
                          if (libraryLanes.retained(usesA, settledListStateUsesA)) {
                            androidx.compose.runtime.key(usesA) {
                                val isSettledLane = usesA == settledListStateUsesA
                                val laneLayout = libraryLanes.layout(usesA)
                                val visible = isSettledLane || pinchTransitionActive
                                LibrarySongsList(
                                    songs = sortedSongs,
                                    layout = laneLayout,
                                    listState = if (usesA) listStateA else listStateB,
                                    selection = selection,
                                    sortMode = sortMode,
                                    currentSongKey = currentSongKey,
                                    favoriteSongKeys = favoriteSongKeys,
                                    listCoversEnabled = listCoversEnabled,
                                    showPlayNextInLists = showPlayNextInLists,
                                    selectedSongsForDrag = selectedSongsForDrag,
                                    libraryLandscape = libraryLandscape,
                                    gridColumns = librarySongGridColumns,
                                    ratingDisplayMode = librarySongRatingDisplayMode,
                                    titleMarqueeEnabled = librarySongTitleMarqueeEnabled && !pinchTransitionActive,
                                    mainViewModel = mainViewModel,
                                    contentPadding = pinchListContentPadding,
                                    userScrollEnabled = isSettledLane && !pinchTransitionActive && !libraryPinch.isPinching,
                                    // Pre-record target holders before transferring draw ownership.
                                    alpha = if (isSettledLane) pinchSourceAlpha else if (libraryMorph.active()) pinchProgress else if (pinchTransitionActive) 0.001f else 0f,
                                    scale = 1f,
                                    morphScene = libraryMorph,
                                    morphLaneId = usesA,
                                    onSongClick = onLibrarySongClick,
                                    onSongLongClick = onLibrarySongLongClick,
                                    onPlayNext = onLibrarySongPlayNext,
                                    onSongMore = onLibrarySongMore,
                                    modifier = Modifier.matchParentSize()
                                        .then(if (!visible) Modifier.clearAndSetSemantics {} else Modifier)
                                        .graphicsLayer { translationX = if (visible) 0f else size.width * 2f }
                                )
                            }
                          }
                        }
                    }
                    }
                }

                if (showFastIndexBar) {
                    FastIndexBar(
                        letters = fastIndexData.letters,
                        reverse = sortMode == HomeSortMode.TitleDesc || sortMode == HomeSortMode.FileNameDesc,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .fillMaxHeight()
                            .padding(end = 0.dp),
                        onLetterClick = { letter ->
                            val index = fastIndexData.targets[letter]
                            if (index != null) {
                                fastScrollJob?.cancel()
                                fastScrollJob = scope.launch {
                                    listState.scrollToItem(index)
                                }
                            }
                        }
                    )
                } else if (showScrollIndicator) {
                    LazyListScrollIndicator(
                        state = listState,
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .fillMaxHeight()
                    )
                }

                androidx.compose.animation.AnimatedVisibility(
                    visible = showLocateCurrentSongButton,
                    modifier = Modifier
                        .align(Alignment.BottomEnd)
                        .padding(end = 22.dp, bottom = 176.dp)
                ) {
                    FloatingActionButton(
                        onClick = { playerViewModel.requestLocateCurrentSong() },
                        minWidth = 46.dp,
                        minHeight = 46.dp,
                        containerColor = MiuixTheme.colorScheme.primary
                    ) {
                        Icon(
                            painter = painterResource(id = R.drawable.ic_my_location),
                            contentDescription = stringResource(R.string.player_locate_current_song),
                            tint = MiuixTheme.colorScheme.onPrimary,
                            modifier = Modifier.size(21.dp)
                        )
                    }
                }
            }
        }

        SongMoreActionHost(
            actionSong = actionSong,
            mainViewModel = mainViewModel,
            playerViewModel = playerViewModel,
            onDismissAction = { actionSong = null },
            onNavigateToAlbum = onNavigateToAlbum,
            onNavigateToArtist = onNavigateToArtist,
            showSongTitleInSheetHeader = false,
            onDeleteSong = { song -> requestDeleteSongs(listOf(song)) }
        )

        if (artistChoices.isNotEmpty()) {
            EllaMiuixBottomSheet(
                show = true,
                enableNestedScroll = false,
                title = stringResource(R.string.song_more_select_artist),
                onDismissRequest = { artistChoices = emptyList() }
            ) {
                ArtistPickerContent(
                    artists = artistChoices,
                    mainViewModel = mainViewModel,
                    onArtistSelected = { artist ->
                        artistChoices = emptyList()
                        onNavigateToArtist(artist)
                    },
                    onDismiss = { artistChoices = emptyList() }
                )
            }
        }

        playlistPickerSongs?.let { songsToAdd ->
            EllaMiuixBottomSheet(
                show = true,
                enableNestedScroll = false,
                title = stringResource(R.string.song_more_add_to_playlist_title),
                onDismissRequest = { playlistPickerSongs = null }
            ) {
                AddToPlaylistSheet(
                playlists = playlists
                    .sortedWith(compareByDescending<com.ella.music.data.model.UserPlaylist> { it.id == FAVORITES_PLAYLIST_ID }.thenByDescending { it.createdAt }),
                songsToAdd = songsToAdd,
                songCount = songsToAdd.size,
                    onDismiss = { playlistPickerSongs = null },
                    onCreatePlaylist = {
                        createPlaylistSongs = songsToAdd
                        playlistPickerSongs = null
                    },
                    onPlaylistsConfirm = { selectedPlaylists, appendToEnd ->
                        selectedPlaylists.forEach { playlist ->
                            mainViewModel.addSongsToPlaylist(playlist.id, songsToAdd, appendToEnd)
                        }
                        Toast.makeText(
                            context,
                            context.getString(R.string.player_added_to_playlists, selectedPlaylists.size),
                            Toast.LENGTH_SHORT
                        ).show()
                        playlistPickerSongs = null
                        selection.finishSelectionMode()
                    }
                )
            }
        }

        createPlaylistSongs?.let { songsToAdd ->
            CreatePlaylistAndAddSheet(
                songCount = songsToAdd.size,
                onDismiss = { createPlaylistSongs = null },
                onCreate = { name ->
                    mainViewModel.createPlaylistOrShowDuplicateToast(context, name) { playlist ->
                        mainViewModel.addSongsToPlaylist(playlist.id, songsToAdd)
                        Toast.makeText(
                            context,
                            context.getString(R.string.player_added_to_playlist_named, playlist.name),
                            Toast.LENGTH_SHORT
                        ).show()
                        createPlaylistSongs = null
                        selection.finishSelectionMode()
                    }
                }
            )
        }

        ConfirmDangerDialog(
            show = pendingConfirmDeleteSongs.isNotEmpty(),
            title = stringResource(R.string.song_more_delete_song_title),
            message = stringResource(R.string.library_delete_selected_message, pendingConfirmDeleteSongs.size),
            confirmText = stringResource(R.string.song_more_delete_permanently),
            onDismiss = { pendingConfirmDeleteSongs = emptyList() },
            onConfirm = {
                requestDeleteSongs(pendingConfirmDeleteSongs)
                pendingConfirmDeleteSongs = emptyList()
                selection.finishSelectionMode()
            }
        )

        tagEditorSong?.let { song ->
            EllaMiuixBottomSheet(
                show = true,
                enableNestedScroll = false,
                title = stringResource(R.string.song_more_edit_tags_title),
                onDismissRequest = { tagEditorSong = null }
            ) {
                SongTagEditorMenu(
                    song = song,
                    options = buildTagEditorOptions(context, song).filter { it.kind == TagEditorOptionKind.Metadata },
                    onDismiss = { tagEditorSong = null },
                    onOptionClick = { option ->
                        launchTagEditorOption(context, option)
                        tagEditorSong = null
                    }
                )
            }
        }

        songInfoSheetSong?.let { song ->
            val pickerTitle = remember(song.id) { mutableStateOf<String?>(null) }
            EllaMiuixBottomSheet(
                show = true,
                enableNestedScroll = false,
                title = pickerTitle.value ?: stringResource(R.string.player_song_info),
                onDismissRequest = { songInfoSheetSong = null }
            ) {
                SongInfoMenu(
                    onPickerTitleChange = { pickerTitle.value = it },
                    mainViewModel = mainViewModel,
                    song = song,
                    audioInfoLoader = mainViewModel::getAudioInfo,
                    tagInfoLoader = mainViewModel::getSongTagInfo,
                    onAiInterpret = {
                        songInfoSheetSong = null
                        aiInterpretationSong = song
                    },
                    onDismiss = { songInfoSheetSong = null }
                )
            }
        }

        aiInterpretationSong?.let { song ->
            SongAiInterpretationMenu(
                song = song,
                mainViewModel = mainViewModel,
                onDismiss = { aiInterpretationSong = null }
            )
        }
    }
}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun LibrarySongsList(
    songs: List<Song>,
    layout: Int,
    listState: androidx.compose.foundation.lazy.LazyListState,
    selection: LibrarySelectionState<Long>,
    sortMode: HomeSortMode,
    currentSongKey: String?,
    favoriteSongKeys: Set<String>,
    listCoversEnabled: Boolean,
    showPlayNextInLists: Boolean,
    selectedSongsForDrag: List<Song>,
    libraryLandscape: Boolean,
    gridColumns: Int,
    ratingDisplayMode: Int,
    titleMarqueeEnabled: Boolean,
    mainViewModel: MainViewModel,
    contentPadding: PaddingValues,
    userScrollEnabled: Boolean,
    alpha: Float,
    scale: Float,
    morphScene: LibraryMorphScene,
    morphLaneId: Boolean,
    onSongClick: (Int) -> Unit,
    onSongLongClick: (Song) -> Unit,
    onPlayNext: (Song) -> Unit,
    onSongMore: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    val multiRow = layout == SettingsManager.LIBRARY_LAYOUT_MULTI_ROW
    val grid = layout == SettingsManager.LIBRARY_LAYOUT_GRID
    val detailed = layout == SettingsManager.LIBRARY_LAYOUT_DETAILS
    val dragColumns = if (grid || multiRow) libraryLayoutColumnCount(multiRow, grid, libraryLandscape, gridColumns) else 1
    val dragIds = remember(songs) { songs.map { it.id } }
    val dragKeys = remember(songs, dragColumns) {
        songs.chunked(dragColumns).associate { (it.first().playlistIdentityKey() as Any) to it.map { song -> song.id } }
    }
    CompositionLocalProvider(LocalLibraryMorphLane provides LibraryMorphLane(morphScene, layout, morphLaneId)) {
    LazyColumn(
        state = listState,
        userScrollEnabled = userScrollEnabled,
        overscrollEffect = null,
        modifier = modifier.dragSelectList(listState, selection.selectionMode && userScrollEnabled, dragIds, selection.selectedIds,
            onSelectionChange = { selection.selectedIds = it; selection.rangeAnchorId = null; selection.rangeTargetId = null },
            onToggle = selection::toggleSelection, itemIdsByKey = dragKeys, columns = dragColumns).graphicsLayer {
            this.alpha = alpha
            scaleX = scale
            scaleY = scale
        },
        contentPadding = contentPadding
    ) {
        if (grid || multiRow) {
            val columnCount = libraryLayoutColumnCount(
                multiRow = multiRow,
                grid = grid,
                landscape = libraryLandscape,
                gridColumns = gridColumns
            )
            itemsIndexed(
                items = songs.chunked(columnCount),
                key = { _, row -> row.first().playlistIdentityKey() }
            ) { rowIndex, rowSongs ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp)
                ) {
                    rowSongs.forEachIndexed { columnIndex, song ->
                        val index = rowIndex * columnCount + columnIndex
                        val selected = song.id in selection.selectedIds
                        val albumArtUri = remember(listCoversEnabled, song.albumId) {
                            song.albumId
                                .takeIf { listCoversEnabled && it > 0L }
                                ?.let(mainViewModel::getAlbumArtUri)
                        }
                        if (multiRow) {
                            SongItem(
                                song = song,
                                titleOverride = sortMode.songDisplaySpec().displayTitleFor(song),
                                isCurrent = song.playlistIdentityKey() == currentSongKey,
                                albumArtUri = albumArtUri,
                                loadCoverArt = mainViewModel::getCoverArtBitmap,
                                loadAudioInfo = mainViewModel::getAudioInfo,
                                loadSongTagInfo = mainViewModel::getSongTagInfo,
                                isFavorite = song.playlistIdentityKey() in favoriteSongKeys,
                                loadSongRating = mainViewModel::getSongRating,
                                ratingDisplayMode = ratingDisplayMode,
                                titleMarqueeEnabledOverride = titleMarqueeEnabled,
                                showPlayNextInLists = showPlayNextInLists,
                                compactMultiRow = true,
                                selectionMode = selection.selectionMode,
                                selected = selected,
                                dragSelectedSongs = selectedSongsForDrag,
                                onLongClick = { onSongLongClick(song) },
                                onClick = {
                                    if (selection.selectionMode) {
                                        selection.toggleSelection(song.id)
                                    } else {
                                        onSongClick(index)
                                    }
                                },
                                onPlayNext = { onPlayNext(song) },
                                onMore = { onSongMore(song) },
                                modifier = Modifier.weight(1f)
                            )
                        } else {
                            LibrarySongGridCard(
                                song = song,
                                title = sortMode.songDisplaySpec().displayTitleFor(song),
                                albumArtUri = albumArtUri,
                                loadCoverArt = mainViewModel::getAlbumCoverArtBitmap,
                                current = song.playlistIdentityKey() == currentSongKey,
                                selectionMode = selection.selectionMode,
                                selected = selected,
                                onLongClick = { onSongLongClick(song) },
                                onClick = {
                                    if (selection.selectionMode) {
                                        selection.toggleSelection(song.id)
                                    } else {
                                        onSongClick(index)
                                    }
                                },
                                onMore = { onSongMore(song) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                    repeat(columnCount - rowSongs.size) { Spacer(modifier = Modifier.weight(1f)) }
                }
            }
        } else {
            itemsIndexed(
                items = songs,
                key = { _, song -> song.playlistIdentityKey() }
            ) { index, song ->
                val selected = song.id in selection.selectedIds
                val albumArtUri = remember(listCoversEnabled, song.albumId) {
                    song.albumId
                        .takeIf { listCoversEnabled && it > 0L }
                        ?.let(mainViewModel::getAlbumArtUri)
                }
                SongItem(
                    song = song,
                    detailed = detailed,
                    loadOriginalCoverArt = mainViewModel::getOriginalCoverModel,
                    compactMultiRow = detailed,
                    showAlbumInSubtitle = !detailed,
                    titleOverride = sortMode.songDisplaySpec().displayTitleFor(song),
                    isCurrent = song.playlistIdentityKey() == currentSongKey,
                    albumArtUri = albumArtUri,
                    loadCoverArt = mainViewModel::getCoverArtBitmap,
                    loadAudioInfo = mainViewModel::getAudioInfo,
                    loadSongTagInfo = mainViewModel::getSongTagInfo,
                    isFavorite = song.playlistIdentityKey() in favoriteSongKeys,
                    loadSongRating = mainViewModel::getSongRating,
                    ratingDisplayMode = ratingDisplayMode,
                    titleMarqueeEnabledOverride = titleMarqueeEnabled,
                    showPlayNextInLists = showPlayNextInLists,
                    selectionMode = selection.selectionMode,
                    selected = selected,
                    dragSelectedSongs = selectedSongsForDrag,
                    onLongClick = { onSongLongClick(song) },
                    onClick = {
                        if (selection.selectionMode) {
                            selection.toggleSelection(song.id)
                        } else {
                            onSongClick(index)
                        }
                    },
                    onPlayNext = { onPlayNext(song) },
                    onMore = { onSongMore(song) }
                )
            }
        }
    }
}

}

@Composable
@OptIn(ExperimentalFoundationApi::class)
private fun LibrarySongGridCard(
    song: Song,
    title: String,
    albumArtUri: Uri?,
    loadCoverArt: (Song) -> Bitmap?,
    current: Boolean,
    selectionMode: Boolean,
    selected: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onMore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coverState = rememberSongArtworkState(
        song = song,
        albumArtUri = albumArtUri,
        loadCoverArt = loadCoverArt,
        usage = ArtworkUsage.LibraryGrid,
        showDefaultWhenMissing = false
    )
    Column(
        modifier = modifier
            .combinedClickable(onClick = onClick, onLongClick = onLongClick)
            .padding(6.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .libraryMorphPart(song.playlistIdentityKey(), "cover")
                .clip(androidx.compose.foundation.shape.RoundedCornerShape(16.dp))
                .background(
                    if (current) MiuixTheme.colorScheme.primary.copy(alpha = 0.16f)
                    else MiuixTheme.colorScheme.surfaceContainer
                )
        ) {
            if (coverState.model != null) {
                SafeCoverImage(
                    model = coverState.model,
                    artworkIdentity = song.playlistIdentityKey(),
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    sizePx = 420,
                    showDefaultPlaceholder = false,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                DefaultAlbumCover(modifier = Modifier.fillMaxSize())
            }
            if (selectionMode) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            if (selected) MiuixTheme.colorScheme.primary.copy(alpha = 0.36f)
                            else Color.Black.copy(alpha = 0.14f)
                        )
                )
                SelectionCheck(
                    selected = selected,
                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp),
                    unselectedColor = Color.White.copy(alpha = 0.30f),
                    checkColor = Color.White
                )
            }
            if (!selectionMode) {
                IconButton(
                    onClick = onMore,
                    modifier = Modifier.align(Alignment.TopEnd)
                ) {
                    Icon(
                        imageVector = MiuixIcons.Regular.More,
                        contentDescription = stringResource(R.string.player_more_actions),
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }
            }
        }
        Text(
            text = title,
            fontSize = 15.sp,
            color = if (current) MiuixTheme.colorScheme.primary else MiuixTheme.colorScheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 7.dp, start = 2.dp, end = 2.dp)
                .libraryMorphPart(song.playlistIdentityKey(), "title")
        )
        Text(
            text = song.artist.ifBlank { stringResource(R.string.player_unknown_artist) },
            fontSize = 12.sp,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(horizontal = 2.dp)
                .libraryMorphPart(song.playlistIdentityKey(), "subtitle")
        )
    }
}

private data class FastIndexData(
    val letters: List<String>,
    val targets: Map<String, Int>
) {
    companion object {
        val Empty = FastIndexData(emptyList(), emptyMap())
    }
}

private data class LibraryLayoutAnchor(
    val songIndex: Int,
    val targetLayout: Int
)

internal fun libraryLayoutColumnCount(
    multiRow: Boolean,
    grid: Boolean,
    landscape: Boolean,
    gridColumns: Int = 2
): Int = when {
    multiRow && landscape -> 3
    multiRow -> 2
    grid -> gridColumns.coerceIn(1, 8)
    else -> 1
}

internal fun libraryLayoutAnchorSongIndex(firstVisibleItemIndex: Int, columns: Int): Int =
    if (columns > 1) firstVisibleItemIndex.coerceAtLeast(0) * columns
    else firstVisibleItemIndex.coerceAtLeast(0)

internal fun libraryLayoutItemIndexForSong(songIndex: Int, columns: Int): Int =
    if (columns > 1) songIndex.coerceAtLeast(0) / columns
    else songIndex.coerceAtLeast(0)

@Composable
private fun Modifier.libraryPinchGesture(
    enabled: Boolean,
    state: LibraryPinchState,
    onCommitted: () -> Unit
): Modifier {
    val currentOnCommitted by rememberUpdatedState(onCommitted)
    return if (!enabled) {
        this
    } else {
        pointerInput(state) {
          kotlinx.coroutines.coroutineScope {
            var settling: kotlinx.coroutines.Job? = null
            var baseSpanDp = 1f
            try {
                while (true) {
                    // Restricted suspension scope: only track the gesture here and hand the
                    // final velocity back so the settling animation can run as a normal suspend.
                    val velocity = awaitPointerEventScope<Float> {
                        while (true) {
                            val initialEvent = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                            val pressed = initialEvent.changes.filter { it.pressed }
                            if (pressed.size < 2) continue

                            val baseDistance = libraryPointerDistance(
                                pressed[0].position,
                                pressed[1].position
                            ).coerceAtLeast(1f)
                            settling?.cancel()
                            baseSpanDp = baseDistance / density
                            state.beginPinch((pressed[0].position + pressed[1].position) / 2f)
                            initialEvent.changes.forEach { it.consume() }

                            var lastDelta = 0f
                            var lastTimestamp = pressed[0].uptimeMillis
                            var velocity = 0f
                            while (true) {
                                val moveEvent = awaitPointerEvent(androidx.compose.ui.input.pointer.PointerEventPass.Initial)
                                moveEvent.changes.forEach { it.consume() }
                                val active = moveEvent.changes.filter { it.pressed }
                                if (active.size < 2) return@awaitPointerEventScope velocity
                                val delta = (
                                    libraryPointerDistance(active[0].position, active[1].position) /
                                        baseDistance
                                    ) - 1f
                                val timestamp = active[0].uptimeMillis
                                val dtSeconds = (timestamp - lastTimestamp) / 1000f
                                if (dtSeconds > 0.008f) {
                                    val instantaneous = (delta - lastDelta) / dtSeconds
                                    velocity = velocity * 0.6f + instantaneous * 0.4f
                                    lastDelta = delta
                                    lastTimestamp = timestamp
                                }
                                state.updatePinch(delta, velocity * baseSpanDp)
                            }
                        }
                        // Unreachable: the outer loop only exits via return@awaitPointerEventScope.
                        error("library pinch gesture loop must not exit")
                    }
                    settling = launch {
                        val committed = state.finishPinch(velocity * baseSpanDp, velocity)
                        if (committed) currentOnCommitted()
                    }
                }
            } finally {
                // Covers coroutine cancellation mid-gesture (e.g. leaving the screen): snap back
                // to the source layout so the settled list stays consistent with its state.
                state.cancelPinch()
            }
          }
        }
    }
}

private fun libraryPointerDistance(first: Offset, second: Offset): Float {
    val x = second.x - first.x
    val y = second.y - first.y
    return kotlin.math.sqrt(x * x + y * y)
}
