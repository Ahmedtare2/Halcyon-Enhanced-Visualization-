package com.ella.music.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import top.yukonga.miuix.kmp.basic.Card
import top.yukonga.miuix.kmp.basic.CardDefaults
import androidx.compose.ui.Modifier
import top.yukonga.miuix.kmp.basic.TextField
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.ella.music.R
import com.ella.music.data.ActionMenuIds
import com.ella.music.data.ActionMenuLayout
import com.ella.music.data.PlaybackStatsStore
import com.ella.music.data.SettingsManager
import com.ella.music.data.decodeNeteaseKey
import com.ella.music.data.detailedAudioInfo
import com.ella.music.data.formatBitRate
import com.ella.music.data.model.AudioInfo
import com.ella.music.data.model.Song
import com.ella.music.data.model.SongTagInfo
import com.ella.music.data.model.formatPlaybackDuration
import com.ella.music.ui.navigation.LocalAppNavigator
import com.ella.music.viewmodel.MainViewModel
import com.ella.music.viewmodel.extractYear
import com.ella.music.viewmodel.parentFolderPath
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import top.yukonga.miuix.kmp.basic.Text
import top.yukonga.miuix.kmp.basic.BasicComponent
import top.yukonga.miuix.kmp.theme.MiuixTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SongInfoSheet(
    song: Song,
    audioInfoLoader: (Song) -> AudioInfo,
    tagInfoLoader: (Song) -> SongTagInfo,
    mainViewModel: MainViewModel,
    onPickerTitleChange: ((String?) -> Unit)? = null,
    onOpenMediaInfo: () -> Unit = {},
    onDismiss: () -> Unit,
    onUpdateModifiedTime: (suspend (Long) -> Boolean)? = null,
    leadingContent: @Composable ColumnScope.() -> Unit = {}
) {
    val context = LocalContext.current
    val navigateTo = LocalAppNavigator.current
    val settingsManager = remember { SettingsManager.getInstance(context) }
    val songInfoLayout by settingsManager.songInfoLayout.collectAsState(initial = "")
    val visibleInfoFields = remember(songInfoLayout) {
        ActionMenuLayout.parse(songInfoLayout, ActionMenuIds.songInfoDefaults)
            .visibleIds(ActionMenuIds.songInfoDefaults)
    }
    val scope = rememberCoroutineScope()
    var showNeteaseKeyInfo by remember(song.id) { mutableStateOf(false) }
    var editingModifiedTime by remember { mutableStateOf(false) }
    var modifiedTimeDraft by remember { mutableStateOf(androidx.compose.ui.text.input.TextFieldValue()) }
    var displayedModifiedMs by remember(song.id, song.dateModified) { mutableStateOf(song.dateModified) }
    var showNeteaseArtistPicker by remember(song.id) { mutableStateOf(false) }
    var neteaseArtistPickerForWiki by remember(song.id) { mutableStateOf(false) }
    var neteaseCommentsSongId by remember(song.id) { mutableStateOf<String?>(null) }
    com.ella.music.ui.player.NeteaseCommentsSheet(
        show = neteaseCommentsSongId != null,
        song = song,
        onDismiss = { neteaseCommentsSongId = null },
        songIdOverride = neteaseCommentsSongId
    )
    var namePicker by remember(song.id) { mutableStateOf<SongInfoNamePicker?>(null) }
    LaunchedEffect(namePicker?.title) { onPickerTitleChange?.invoke(namePicker?.title) }
    val audioInfo by produceState<AudioInfo?>(initialValue = null, song.id, song.dateModified, song.fileSize) {
        value = withContext(Dispatchers.IO) { audioInfoLoader(song) }
    }
    val tagInfo by produceState<SongTagInfo?>(initialValue = null, song.id, song.dateModified, song.fileSize) {
        value = withContext(Dispatchers.IO) { tagInfoLoader(song) }
    }
    val neteaseInfo = remember(tagInfo?.neteaseKey) { decodeNeteaseKey(tagInfo?.neteaseKey.orEmpty()) }
    val neteaseArtists = remember(neteaseInfo) {
        neteaseInfo?.artists.orEmpty().filter { it.id.isNotBlank() }
    }
    val jumpTo: (String?) -> Unit = { route ->
        if (!route.isNullOrBlank()) {
            onDismiss()
            navigateTo(route)
        }
    }
    val jumpField: (SongInfoJump, String, String) -> Unit = { jump, label, value ->
        val choices = songInfoJumpChoices(jump, value)
        when {
            choices.size > 1 -> namePicker = SongInfoNamePicker(
                title = when (jump) {
                    SongInfoJump.Artist, SongInfoJump.AlbumArtist ->
                        context.getString(R.string.song_more_select_artist)
                    SongInfoJump.Composer -> context.getString(R.string.song_more_select_composer)
                    SongInfoJump.Arranger -> context.getString(R.string.song_more_select_arranger)
                    SongInfoJump.Lyricist -> context.getString(R.string.song_more_select_lyricist)
                    SongInfoJump.Genre -> context.getString(R.string.song_more_select_genre)
                    else -> label
                },
                names = choices,
                jump = jump
            )
            else -> jumpTo(songInfoJumpRoute(jump, song, audioInfo, choices.firstOrNull().orEmpty()))
        }
    }

    namePicker?.let { picker ->
        SongSheetColumn {
            if (onPickerTitleChange == null) Text(
                text = picker.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MiuixTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            )
            ArtistPickerRows(picker.names, mainViewModel,
                onArtistSelected = { name -> jumpTo(songInfoJumpRoute(picker.jump, song, audioInfo, name)) },
                categoryType = when (picker.jump) {
                    SongInfoJump.Composer -> "composer"
                    SongInfoJump.Arranger -> "arranger"
                    SongInfoJump.Lyricist -> "lyricist"
                    SongInfoJump.Genre -> "genre"
                    else -> null
                })
            SongMenuItem(stringResource(R.string.common_cancel), onClick = { namePicker = null })
        }
        return
    }

    if (showNeteaseArtistPicker && neteaseArtists.isNotEmpty()) {
        SongSheetColumn {
            Text(
                text = stringResource(R.string.player_choose_netease_artist),
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MiuixTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            )
            neteaseArtists.forEach { artist ->
                SongMenuItem(artist.name.ifBlank { "ID ${artist.id}" }, onClick = {
                    com.ella.music.data.netease.NeteaseLinks.open(context, if (neteaseArtistPickerForWiki) com.ella.music.data.netease.NeteaseLinkKind.ArtistWiki else com.ella.music.data.netease.NeteaseLinkKind.Artist, artist.id)
                })
            }
            SongMenuItem(stringResource(R.string.song_more_back_to_netease_key), onClick = { showNeteaseArtistPicker = false })
        }
        return
    }

    if (showNeteaseKeyInfo && neteaseInfo != null) {
        SongSheetColumn {
            Text(
                text = stringResource(R.string.song_more_netease_key),
                fontSize = 18.sp,
                fontWeight = FontWeight.ExtraBold,
                color = MiuixTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 8.dp)
            )
            neteaseInfo.musicName.takeIf { it.isNotBlank() }?.let { SongInfoRow(stringResource(R.string.player_detail_song), it) }
            neteaseInfo.translatedNames.joinToString(" / ").takeIf { it.isNotBlank() }
                ?.let { SongInfoRow(stringResource(R.string.player_detail_translated_name), it) }
            neteaseInfo.aliases
                .joinToString(" / ")
                .takeIf { it.isNotBlank() }
                ?.let { SongInfoRow(stringResource(R.string.song_more_alias), it) }
            neteaseInfo.artists
                .joinToString(" / ") { it.name.ifBlank { it.id } }
                .takeIf { it.isNotBlank() }
                ?.let { SongInfoRow(stringResource(R.string.player_detail_artist), it) }
            neteaseInfo.albumName.takeIf { it.isNotBlank() }?.let { SongInfoRow(stringResource(R.string.player_detail_album), it) }
            neteaseInfo.comment.takeIf { it.isNotBlank() }?.let { SongInfoRow(stringResource(R.string.player_detail_comment), it) }
            // Order: 歌曲页 → 歌曲评论 → 歌手页 → 艺人百科 → 专辑页 → MV.
            neteaseInfo.musicId.takeIf { it.isNotBlank() }?.let { id ->
                SongMenuItem(stringResource(R.string.player_netease_song_page), onClick = { com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.Song, id) })
                SongMenuItem(stringResource(R.string.netease_link_song_wiki), onClick = { com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.SongWiki, id) })
                SongMenuItem(stringResource(R.string.netease_link_song_comments), onClick = {
                    if (com.ella.music.data.netease.NeteaseLinks.commentsOpenExternally(context)) com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.Comment, id)
                    else neteaseCommentsSongId = id
                })
            }
            if (neteaseArtists.isNotEmpty()) {
                SongMenuItem(
                    title = stringResource(R.string.player_netease_artist_page),
                    onClick = {
                        if (neteaseArtists.size == 1) {
                            com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.Artist, neteaseArtists.first().id)
                        } else {
                            neteaseArtistPickerForWiki = false
                            showNeteaseArtistPicker = true
                        }
                    }
                )
                SongMenuItem(
                    title = stringResource(R.string.netease_link_artist_wiki),
                    onClick = {
                        if (neteaseArtists.size == 1) {
                            com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.ArtistWiki, neteaseArtists.first().id)
                        } else {
                            neteaseArtistPickerForWiki = true
                            showNeteaseArtistPicker = true
                        }
                    }
                )
            }
            neteaseInfo.albumId.takeIf { it.isNotBlank() }?.let { id ->
                SongMenuItem(stringResource(R.string.player_netease_album_page), onClick = { com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.Album, id) })
                SongMenuItem(stringResource(R.string.netease_link_album_comments), onClick = { com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.AlbumComment, id) })
            }
            neteaseInfo.mvId.takeIf { it.isNotBlank() }?.let { id ->
                SongMenuItem(
                    stringResource(R.string.player_netease_music_video),
                    onClick = { com.ella.music.MusicVideoLauncher.openNetease(context, song, id) }
                )
                SongMenuItem(stringResource(R.string.netease_link_mv_comments), onClick = { com.ella.music.data.netease.NeteaseLinks.open(context, com.ella.music.data.netease.NeteaseLinkKind.MusicVideoComment, id) })
            }
            SongInfoRow(stringResource(R.string.song_more_raw_netease_key), neteaseInfo.raw)
            neteaseInfo.decodedJson.takeIf { it.isNotBlank() }?.let {
                SongInfoRow(stringResource(R.string.library_decoded_json), it)
            }
            SongMenuItem(stringResource(R.string.common_back), onClick = { showNeteaseKeyInfo = false })
        }
        return
    }

    val artistValue = tagInfo?.artist?.ifBlank { song.artist } ?: song.artist
    val albumValue = tagInfo?.album?.ifBlank { song.album } ?: song.album
    val albumArtistValue = tagInfo?.albumArtist?.ifBlank { song.albumArtist }.orEmpty()
    val genreValue = tagInfo?.genre?.ifBlank { song.genre }.orEmpty()
    val yearValue = tagInfo?.year?.ifBlank { song.year }.orEmpty()
    val composerValue = tagInfo?.composer?.ifBlank { song.composer }.orEmpty()
    val arrangerValue = tagInfo?.arranger?.ifBlank { song.arranger }.orEmpty()
    val lyricistValue = tagInfo?.lyricist?.ifBlank { song.lyricist }.orEmpty()
    val directoryValue = song.parentFolderPath().orEmpty()
    val artistLabel = stringResource(R.string.player_detail_artist)
    val albumLabel = stringResource(R.string.player_detail_album)
    val albumArtistLabel = stringResource(R.string.song_more_detail_album_artist)
    val genreLabel = stringResource(R.string.song_more_detail_genre)
    val yearLabel = stringResource(R.string.song_more_detail_year)
    val composerLabel = stringResource(R.string.player_detail_composer)
    val arrangerLabel = stringResource(R.string.player_detail_arranger)
    val lyricistLabel = stringResource(R.string.player_detail_lyricist)
    val formatLabelText = stringResource(R.string.song_more_detail_format)
    val bitrateLabel = stringResource(R.string.song_more_detail_bitrate)
    val pathLabel = stringResource(R.string.song_more_detail_path)
    val directoryLabel = stringResource(R.string.song_more_detail_directory)

    val playbackStats = remember(song.id) {
        PlaybackStatsStore.getInstance(context).stats.value.firstOrNull { it.songId == song.id }
    }
    val modifiedLabel = stringResource(R.string.song_more_detail_modified_time)
    val mediaInfoIndex = visibleInfoFields.indexOf(ActionMenuIds.SONG_INFO_MEDIA_INFO)
    val mediaInfoVisible = mediaInfoIndex >= 0
    val mediaInfoAtStart = mediaInfoVisible && mediaInfoIndex == 0
    val mediaInfoAtEnd = mediaInfoVisible && mediaInfoIndex == visibleInfoFields.lastIndex
    EllaMiuixSheetColumn(
        verticalPadding = 8.dp,
        spacing = 8.dp,
        showHandle = false
    ) {
        if (mediaInfoAtStart) {
            EllaMiuixActionMenuGroup {
                SongMenuItem(stringResource(R.string.song_more_open_media_info), onOpenMediaInfo)
            }
        }
        EllaMiuixActionMenuGroup {
            leadingContent()
            for (fieldId in visibleInfoFields) {
                if (fieldId == ActionMenuIds.SONG_INFO_MEDIA_INFO) {
                    if (!mediaInfoAtStart && !mediaInfoAtEnd) {
                        SongMenuItem(stringResource(R.string.song_more_open_media_info), onOpenMediaInfo)
                    }
                    continue
                }
                when (fieldId) {
                ActionMenuIds.SONG_INFO_TITLE ->
                    SongInfoRow(stringResource(R.string.player_detail_song), tagInfo?.title?.ifBlank { song.title } ?: song.title)
                ActionMenuIds.SONG_INFO_ARTIST ->
                    SongInfoRow(artistLabel, artistValue, onClick = { jumpField(SongInfoJump.Artist, artistLabel, artistValue) })
                ActionMenuIds.SONG_INFO_ALBUM ->
                    SongInfoRow(albumLabel, albumValue, onClick = { jumpTo(songInfoJumpRoute(SongInfoJump.Album, song)) })
                ActionMenuIds.SONG_INFO_ALBUM_ARTIST ->
                    SongInfoRow(albumArtistLabel, albumArtistValue, onClick = {
                        jumpField(SongInfoJump.AlbumArtist, albumArtistLabel, albumArtistValue)
                    })
                ActionMenuIds.SONG_INFO_GENRE ->
                    SongInfoRow(genreLabel, genreValue, onClick = { jumpField(SongInfoJump.Genre, genreLabel, genreValue) })
                ActionMenuIds.SONG_INFO_YEAR ->
                    SongInfoRow(
                        yearLabel,
                        yearValue,
                        onClick = yearValue.extractYear()?.let { { jumpField(SongInfoJump.Year, yearLabel, yearValue) } }
                    )
                ActionMenuIds.SONG_INFO_COMPOSER ->
                    SongInfoRow(composerLabel, composerValue, onClick = {
                        jumpField(SongInfoJump.Composer, composerLabel, composerValue)
                    })
                ActionMenuIds.SONG_INFO_ARRANGER ->
                    SongInfoRow(arrangerLabel, arrangerValue, onClick = {
                        jumpField(SongInfoJump.Arranger, arrangerLabel, arrangerValue)
                    })
                ActionMenuIds.SONG_INFO_LYRICIST ->
                    SongInfoRow(lyricistLabel, lyricistValue, onClick = {
                        jumpField(SongInfoJump.Lyricist, lyricistLabel, lyricistValue)
                    })
                ActionMenuIds.SONG_INFO_COMMENT ->
                    SongInfoRow(stringResource(R.string.player_detail_comment), tagInfo?.displayComment.orEmpty())
                ActionMenuIds.SONG_INFO_NETEASE -> if (!tagInfo?.neteaseKey.isNullOrBlank()) {
                    SongInfoActionRow(
                        label = stringResource(R.string.song_more_netease_key),
                        value = neteaseInfo?.musicName?.ifBlank { null }
                            ?: neteaseInfo?.musicId?.takeIf { it.isNotBlank() }?.let {
                                context.getString(R.string.song_more_netease_song_id, it)
                            }
                            ?: stringResource(R.string.song_more_view_netease_info),
                        onClick = { showNeteaseKeyInfo = true }
                    )
                }
                ActionMenuIds.SONG_INFO_FORMAT -> SongInfoRow(
                    formatLabelText,
                    audioInfo?.let { detailedAudioInfo(it) }.orEmpty(),
                    onClick = audioInfo?.let { { jumpTo(songInfoJumpRoute(SongInfoJump.Format, song, it)) } }
                )
                ActionMenuIds.SONG_INFO_BITRATE -> SongInfoRow(
                    bitrateLabel,
                    audioInfo?.let { formatBitRate(it.bitRate) }.orEmpty(),
                    onClick = audioInfo?.let { { jumpTo(songInfoJumpRoute(SongInfoJump.Bitrate, song, it)) } }
                )
                ActionMenuIds.SONG_INFO_DURATION ->
                    SongInfoRow(stringResource(R.string.song_more_detail_duration), song.durationText)
                ActionMenuIds.SONG_INFO_PLAY_COUNT ->
                    SongInfoRow(
                        stringResource(R.string.song_more_detail_play_count),
                        (playbackStats?.playCount ?: 0).toString()
                    )
                ActionMenuIds.SONG_INFO_LISTENED ->
                    SongInfoRow(
                        stringResource(R.string.song_more_detail_listened_duration),
                        (playbackStats?.listenedMs ?: 0L).formatPlaybackDuration()
                    )
                ActionMenuIds.SONG_INFO_LAST_PLAYED ->
                    SongInfoRow(
                        stringResource(R.string.song_more_detail_last_played),
                        playbackStats?.lastPlayedAt?.takeIf { it > 0L }?.formatSongDateTime().orEmpty()
                    )
                ActionMenuIds.SONG_INFO_SIZE ->
                    SongInfoRow(stringResource(R.string.song_more_detail_size), formatFileSize(song.fileSize))
                ActionMenuIds.SONG_INFO_MODIFIED ->
                    SongInfoRow(
                        modifiedLabel,
                        displayedModifiedMs.formatSongDateTime(),
                        onClick = {
                            modifiedTimeDraft = displayedModifiedMs.formatSongDateTime().let { androidx.compose.ui.text.input.TextFieldValue(it, androidx.compose.ui.text.TextRange(0, it.length)) }
                            editingModifiedTime = true
                        }
                    )
                ActionMenuIds.SONG_INFO_ADDED ->
                    SongInfoRow(stringResource(R.string.song_more_detail_added_time), song.dateAdded.formatSongDateTime())
                ActionMenuIds.SONG_INFO_FILE_NAME ->
                    SongInfoRow(
                        stringResource(R.string.song_more_detail_file_name),
                        song.fileName.ifBlank { song.path.substringAfterLast('/') }
                    )
                ActionMenuIds.SONG_INFO_PATH ->
                    SongInfoRow(pathLabel, song.path, onClick = { jumpTo(songInfoJumpRoute(SongInfoJump.Path, song)) })
                ActionMenuIds.SONG_INFO_DIRECTORY ->
                    SongInfoRow(directoryLabel, directoryValue, onClick = { jumpTo(songInfoJumpRoute(SongInfoJump.Directory, song)) })
                }
            }
        }
        if (mediaInfoAtEnd && !mediaInfoAtStart) {
            EllaMiuixActionMenuGroup {
                SongMenuItem(stringResource(R.string.song_more_open_media_info), onOpenMediaInfo)
            }
        }
    }
    EllaMiuixDialog(
        show = editingModifiedTime,
        title = modifiedLabel,
        onDismissRequest = { editingModifiedTime = false }
    ) {
        TextField(
            value = modifiedTimeDraft,
            onValueChange = { modifiedTimeDraft = it },
            label = "yyyy-MM-dd HH:mm:ss",
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth(),
            keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                imeAction = androidx.compose.ui.text.input.ImeAction.Done
            )
        )
        Spacer(modifier = Modifier.padding(top = 12.dp))
        EllaMiuixDialogActions(
            cancelText = stringResource(R.string.common_cancel),
            confirmText = stringResource(R.string.common_save),
            onCancel = { editingModifiedTime = false },
            onConfirm = {
                val parsed = parseSongDateTime(modifiedTimeDraft.text)
                if (parsed == null) {
                    Toast.makeText(context, context.getString(R.string.song_more_modified_time_invalid), Toast.LENGTH_SHORT).show()
                    return@EllaMiuixDialogActions
                }
                scope.launch {
                    val ok = onUpdateModifiedTime?.invoke(parsed) ?: java.io.File(song.path).setLastModified(parsed)
                    if (ok) {
                        displayedModifiedMs = parsed
                        editingModifiedTime = false
                    } else {
                        Toast.makeText(context, context.getString(R.string.song_more_modified_time_failed), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        )
    }
}

internal fun parseSongDateTime(text: String): Long? {
    return runCatching {
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).parse(text.trim())?.time
    }.getOrNull()
}

@Composable
internal fun SongAiInterpretationSheet(
    song: Song,
    mainViewModel: MainViewModel,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val settingsManager = remember(context) { SettingsManager.getInstance(context) }
    val openAiApiKey by settingsManager.openAiApiKey.collectAsState(initial = "")
    val aiFailedText = stringResource(R.string.song_more_ai_failed)
    var requestKey by remember(song.id) { mutableStateOf(0) }
    var isLoading by remember(song.id) { mutableStateOf(false) }
    var resultText by remember(song.id) { mutableStateOf("") }
    var errorText by remember(song.id) { mutableStateOf<String?>(null) }

    LaunchedEffect(song.id, requestKey, openAiApiKey) {
        if (openAiApiKey.isBlank()) {
            Toast.makeText(context, R.string.library_ai_missing_api_key, Toast.LENGTH_SHORT).show()
            onDismiss()
            return@LaunchedEffect
        }
        isLoading = true
        errorText = null
        resultText = ""
        runCatching {
            mainViewModel.interpretSongWithOpenAi(song)
        }.onSuccess {
            resultText = it
        }.onFailure {
            errorText = it.message ?: aiFailedText
        }
        isLoading = false
    }

    EllaMiuixSheetColumn(
        verticalPadding = 8.dp,
        spacing = 10.dp,
        showHandle = false
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            cornerRadius = 16.dp,
            colors = CardDefaults.defaultColors(color = ellaOverlayCardColor())
        ) {
            val displayText = when {
                isLoading -> stringResource(R.string.song_more_loading_ai)
                errorText != null -> errorText.orEmpty()
                resultText.isNotBlank() -> resultText
                else -> ""
            }
            Text(
                text = displayText,
                fontSize = 14.sp,
                lineHeight = 22.sp,
                color = MiuixTheme.colorScheme.onSurface,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp)
            )
        }
        if (errorText != null) {
            EllaMiuixActionMenuGroup {
                SongMenuItem(stringResource(R.string.library_retry), onClick = { requestKey++ })
            }
        } else if (resultText.isNotBlank()) {
            EllaMiuixActionMenuGroup {
                SongMenuItem(stringResource(R.string.library_reinterpret), onClick = { requestKey++ })
            }
        }
        EllaMiuixActionMenuGroup {
            SongMenuItem(stringResource(R.string.common_close), onDismiss)
        }
    }
}

private data class SongInfoNamePicker(
    val title: String,
    val names: List<String>,
    val jump: SongInfoJump
)

@Composable
internal fun SongInfoRow(label: String, value: String, onClick: (() -> Unit)? = null) {
    if (value.isBlank()) return
    val context = LocalContext.current
    BasicComponent(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = { onClick?.invoke() },
                onLongClick = { copySongInfoValue(context, label, value) }
            ),
        insideMargin = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = label,
            style = MiuixTheme.textStyles.body2,
            fontWeight = FontWeight.Bold,
            color = MiuixTheme.colorScheme.onSurfaceVariantSummary
        )
        Text(
            text = value,
            style = MiuixTheme.textStyles.body1,
            color = MiuixTheme.colorScheme.onSurface
        )
    }
}

@Composable
private fun SongInfoActionRow(label: String, value: String, onClick: () -> Unit) {
    val context = LocalContext.current
    BasicComponent(
        modifier = Modifier
            .fillMaxWidth()
            .combinedClickable(
                onClick = onClick,
                onLongClick = { copySongInfoValue(context, label, value) }
            ),
        insideMargin = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Text(
            text = label,
            style = MiuixTheme.textStyles.body2,
            fontWeight = FontWeight.Bold,
            color = MiuixTheme.colorScheme.primary
        )
        Text(
            text = value,
            style = MiuixTheme.textStyles.body1,
            color = MiuixTheme.colorScheme.onSurface
        )
    }
}

internal fun copySongInfoValue(context: Context, label: String, value: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    clipboard.setPrimaryClip(ClipData.newPlainText(label, value))
    Toast.makeText(context, context.getString(R.string.song_more_copied, label), Toast.LENGTH_SHORT).show()
}

private fun openUrl(context: Context, url: String) {
    if (url.isBlank()) return
    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
}

private fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return ""
    val kb = bytes / 1024.0
    val mb = kb / 1024.0
    val gb = mb / 1024.0
    return when {
        gb >= 1 -> String.format(Locale.ROOT, "%.2f GB", gb)
        mb >= 1 -> String.format(Locale.ROOT, "%.2f MB", mb)
        else -> String.format(Locale.ROOT, "%.0f KB", kb)
    }
}

private fun Long.formatSongDateTime(): String {
    if (this <= 0L) return ""
    val millis = if (this < 10_000_000_000L) this * 1000L else this
    return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date(millis))
}
